import pandas as pd


def dp_sqltoget_tablenames(db_conn , SCHEMANAME):
    MY_GLOBAL_DB = db_conn
    q = f'''
SELECT DISTINCT TRIM(TABLE_NAME) AS  TABLE_NAME FROM all_tables WHERE TRIM(OWNER) = '{SCHEMANAME}'
AND (table_name NOT LIKE '%BK%' AND table_name NOT LIKE '%BATCH%' AND table_name NOT LIKE '%TEMP%' AND table_name NOT LIKE 'Z_%'
AND table_name NOT LIKE '%TMP%' AND table_name NOT LIKE '%BCK%' AND UPPER(table_name) NOT LIKE '%DROP%' AND table_name NOT LIKE '%_Exclu%'
AND table_name NOT LIKE '%_Z%' AND table_name NOT LIKE '%20%' AND table_name NOT LIKE '%03%' AND table_name NOT LIKE '%TABLE%' 
AND table_name NOT LIKE '%_1%' AND table_name NOT LIKE '%_2%'   AND table_name NOT LIKE '%_3%'   AND table_name NOT LIKE '%_4%'  
AND table_name NOT LIKE '%_5%'  AND table_name NOT LIKE '%_6%' AND table_name NOT LIKE '%_7%'  AND table_name NOT LIKE '%_8%'   
AND table_name NOT LIKE '%_9%' AND table_name NOT LIKE '%0%' AND table_name NOT LIKE '%_DUP%' AND table_name NOT LIKE '%TEST%' 
AND table_name NOT LIKE '%_CNT%' AND table_name NOT LIKE '%_NEW%' AND table_name NOT LIKE '%SQL%' AND table_name NOT LIKE '%LOAD%'
AND UPPER(table_name) NOT LIKE '%REFERENCES%') AND NUM_ROWS > 0   
ORDER BY TRIM(TABLE_NAME) '''
    try:
        df = pd.read_sql_query(q, MY_GLOBAL_DB)
        list_of_tables = df['TABLE_NAME'].tolist()
    except:
        df = pd.DataFrame({'Name':['No Record Found']})
        list_of_tables = ' '
    return list_of_tables


def dp_query(db_conn , SCHEMANAME, TABLENAME):
    MY_GLOBAL_DB = db_conn

    column_sql = f''' 
SELECT DISTINCT TRIM(COLUMN_NAME) AS COLUMN_NAME 
FROM all_tab_columns WHERE OWNER = '{SCHEMANAME}' AND TABLE_NAME =  '{TABLENAME}' 
ORDER BY COLUMN_NAME  '''
    dataframes_final = pd.DataFrame()
    t_var = ''

    try:
        column_df = pd.read_sql_query(column_sql, MY_GLOBAL_DB)
        list_of_columnnames = column_df['COLUMN_NAME'].tolist()        
        for i in list_of_columnnames:
            t_var = i
            q = f"""SELECT TRIM('{t_var}') AS column_name,  Count(*) AS TOTAL_COUNT,
CASE WHEN Sum ( CASE WHEN  Cast({t_var} AS VARCHAR(250))  IS NULL THEN 1 ELSE 0 END) > 0 THEN 'YES' ELSE 'NO' END AS NULL_VALUES,
NVL(Sum(CASE WHEN  Cast({t_var} AS VARCHAR(250))  IS NULL THEN 1 ELSE 0 END), '0') AS NULL_COUNT,
ROUND(NVL(100*Sum( CASE WHEN  Cast({t_var} AS VARCHAR(250)) IS NULL THEN 1.0000 ELSE 0.0000 END) /Count(*),'0.00'), 5) AS NULL_PERCENT,
NVL(Sum(CASE WHEN Trim( Cast({t_var} AS VARCHAR(250)) ) IN ('', ' ') THEN 1 ELSE 0 END),'0') AS BLANK_COUNT,
Count(DISTINCT(Cast({t_var} AS VARCHAR(250)))) AS DISTINCT_COUNT_EXCEPT_NULL ,
NVL(Max(Length(Trim( Cast({t_var} AS VARCHAR(250))  ))),'0') AS MAX_LENGTH,
NVL(Min(Length(Trim( Cast({t_var} AS VARCHAR(250)) ))),'0') AS MIN_LENGTH,
NVL(Trim(Max ( Cast({t_var} AS VARCHAR(250))  )),'0') AS MAX_VALUE,
NVL(Trim(Min ( Cast({t_var} AS VARCHAR(250))  )),'0') AS MIN_VALUE
FROM  {SCHEMANAME}.{TABLENAME} GROUP BY  '{t_var}'
"""
            df = pd.read_sql_query(q, MY_GLOBAL_DB)
            dataframes_final= dataframes_final.append(df, ignore_index=True)
            # dataframes_final.set_index('COLUMN_NAME', inplace=True)
    except:
        dataframes_final = pd.DataFrame({'Name':['No Record Found']})
    return dataframes_final
