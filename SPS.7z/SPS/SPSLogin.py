import cx_Oracle
import pandas as pd


def TDLogin(GLOBAL_USERNAME, GLOBAL_PASSWORD, GLOBAL_DBCNAME):

    # g_username = GLOBAL_USERNAME
    # g_password = GLOBAL_PASSWORD
    g_username = 'AH02855'
    g_password = 'Aszr6$S$'

    dsn_tns = cx_Oracle.makedsn('va33dx13v1-scan1', '1525', service_name='spsodsvcu') 
    db_conn = cx_Oracle.connect(user=f"{g_username}", password=f"{g_password}", dsn=dsn_tns) 
    q = '''Select * from XTROWNER4.PROV FETCH NEXT 10 ROWS ONLY'''
    #index_columns = ['MSTR_PROV_ID', 'PROV_CTGRY_CD']
    #df = pd.read_sql_query(q, db_conn, index_col= index_columns)
    df = pd.read_sql_query(q, db_conn)
    print("Success", df)
    MY_GLOBAL_DB = db_conn
    verdict = 'Success'

    return verdict, MY_GLOBAL_DB, df


def calc_spsoption_1(db_conn):
    print("In calc_spsoption_1")
    MY_GLOBAL_DB = db_conn
    q = f"""
SELECT DISTINCT p.PROV_ORG_NM AS PROV_ORGANIZATION_NAME, p.NPI, pai.ALTID_TXT AS MEDID, 
p.PROV_ORG_FED_TAX_ID AS TAX_ID, ptax.PROV_ORG_TAX_ID_EFCTV_DT AS TAX_EFF_DT, ptax.PROV_ORG_TAX_ID_TRMNTN_DT AS TAX_END_DT, 
cv_adrs.CD_VAL_NM AS ADDRESS_TYPE, (TRIM(sa.ADRS_LINE_1_TXT) || ' ' || TRIM(sa.ADRS_LINE_2_TXT)) AS PROV_ADDRESS, sa.POSTL_CD_ST_PRVNC_NM AS STATE,
sa.ADRS_CITY_NM AS CITY, sa.POSTL_CD AS ZIP, cv_org_spcl.CD_VAL_NM AS PROV_ORG_SPCLTY_DESC, ps.TXNMY_CD, cv_taxonomy.CD_VAL_NM  AS TAXONOMY_DESC,
pai_st_license.ALTID_TXT AS LICENSE, pai_facility.ALTID_TXT AS FACILITY_ID
FROM XTROWNER4.PROV p 
INNER JOIN XTROWNER4.POA p2 ON p.MSTR_PROV_ID = p2.MSTR_PROV_ID AND p2.PADRS_TRMNTN_RSN_CD IS NULL AND p.PROV_TRMNTN_RSN_CD IS NULL 
INNER JOIN XTROWNER4.CD_VAL cv_adrs ON cv_adrs.CD_VAL_CD = p2.PADRS_TYPE_CD AND cv_adrs.ITEM_ID = 10313
INNER JOIN XTROWNER4.STNDRDZD_ADRS sa ON sa.SPS_STNDRDZD_ADRS_ID = p2.SPS_STNDRDZD_ADRS_ID AND p2.PRMRY_PADRS_IND = 'Y'
INNER JOIN XTROWNER4.PROV_ORG_TAX_IDFCTN ptax ON ptax.MSTR_PROV_ID = p.MSTR_PROV_ID  
INNER JOIN XTROWNER4.CD_VAL cv_org_spcl ON cv_org_spcl.CD_VAL_CD = p.PROV_ORG_SPCLTY_CD AND cv_org_spcl.ITEM_ID = 10327
LEFT JOIN XTROWNER4.PROV_SPCLTY ps ON ps.MSTR_PROV_ID = p.MSTR_PROV_ID AND ps.PRMRY_SPCLTY_IND = 'Y'
INNER JOIN XTROWNER4.CD_VAL cv_taxonomy ON cv_taxonomy.CD_VAL_CD = ps.TXNMY_CD AND cv_taxonomy.ITEM_ID = 10330
INNER JOIN XTROWNER4.PROV_ALT_IDFCTN pai ON pai.MSTR_PROV_ID = p.MSTR_PROV_ID AND pai.ALTID_TYPE_CD = '31'
LEFT JOIN XTROWNER4.PROV_ALT_IDFCTN pai_st_license ON pai_st_license.MSTR_PROV_ID = p.MSTR_PROV_ID AND pai.ALTID_TYPE_CD = '8001'
LEFT JOIN XTROWNER4.PROV_ALT_IDFCTN pai_facility ON pai_facility.MSTR_PROV_ID = p.MSTR_PROV_ID AND pai.ALTID_TYPE_CD = '879'
WHERE p.PROV_CTGRY_CD = '182'  
ORDER BY p.NPI FETCH NEXT 100 ROWS ONLY
"""    
    try:
        df = pd.read_sql_query(q, MY_GLOBAL_DB)
        print("SQL Executed Successfully!!!")
    except:
        df = pd.DataFrame()
    return df

