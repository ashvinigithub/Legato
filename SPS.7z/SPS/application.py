import os
from SPS_wsgi import application

if __name__ == "__main__":
    application.secret_key = os.urandom(24)
    application.run(host='127.0.0.1', port=5000)

