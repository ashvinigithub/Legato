import pandas as pd


def check_safety_net_query(db_conn , SCHEMANAME):
    MY_GLOBAL_DB = db_conn
    dataframes_final = pd.DataFrame()
    try:
        q = f"""with PRV AS
(select PROV_CTGRY_CD, count(distinct MSTR_PROV_ID) AS TOTAL_CNT from {SCHEMANAME}.PROV Group by PROV_CTGRY_CD),
DQ AS (SELECT P.PROV_CTGRY_CD ,E.ERR_CD, E.ERR_DESC, COUNT(DISTINCT P.MSTR_PROV_ID)  AS ERR_CNT
FROM {SCHEMANAME}.PROV P
inner join {SCHEMANAME}.PROV_DQ_CHK D
on D.MSTR_PROV_ID = P.MSTR_PROV_ID
inner join {SCHEMANAME}.DQ_ERR_DTL E
on D.ERR_CD = E.ERR_CD
group by  P.PROV_CTGRY_CD ,E.ERR_CD, E.ERR_DESC
) select DISTINCT
E.ERR_CD, E.ERR_DESC,
CASE WHEN P.PROV_CTGRY_CD = '181' THEN 'Individual Provider' 
WHEN P.PROV_CTGRY_CD = '182' THEN 'Organization Provider' ELSE ' ' END AS PROVIDER_TYPE,
NVL(D.ERR_CNT,0) AS ERR_CNT, 
NVL(ROUND((D.ERR_CNT/P.TOTAL_CNT)*100, 2),0) AS ERR_PERCENTAGE
from {SCHEMANAME}.DQ_ERR_DTL E
left outer join DQ D
on E.ERR_CD = D.ERR_CD
left outer join PRV P
on P.PROV_CTGRY_CD = D.PROV_CTGRY_CD
order by   E.ERR_CD, PROVIDER_TYPE
"""
        df = pd.read_sql_query(q, MY_GLOBAL_DB)
        dataframes_final= dataframes_final.append(df, ignore_index=True)
    except:
        dataframes_final = pd.DataFrame({'Name':['No Record Found']})
    return dataframes_final
