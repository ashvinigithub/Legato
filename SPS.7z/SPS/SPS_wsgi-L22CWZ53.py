from flask import Flask, flash, redirect, render_template, request, session, abort, url_for, send_file, g, jsonify
import os
import pandas as pd
from datetime import timedelta
import SPSLogin, SPSRunSqlInd, SPSRunSqlOrg, SPSdp, SPSSafetyNet

application = app = Flask(__name__)
application.config['SECRET_KEY'] = os.urandom(24)
application.config['DEBUG'] = False
# cnctstrng = "DRIVER={/Library/Application Support/teradata/client/16.20/lib/tdataodbc_sbu.dylib};DBCName="+td_usr_dsn+";AUTHENTICATION=LDAP;UID="+msid+";PWD="+pwd+";"

class User:
    def __init__(self, id, dbcname, username, password):
        self.id = id
        self.dbcname = dbcname
        self.username = username
        self.password = password

    def __repr__(self):
        return f'{[self.username, self.password, self.dbcname]}'

users = []
users.append(User(id=1, dbcname='dbcname', username='dummy', password='password'))

@app.before_request
def before_request():
    g.user = None
    session.permanent = True
    app.permanent_session_lifetime = timedelta(minutes=10)
    if 'user_id' in session:
        user = [x for x in users if x.id == session['user_id']][0]
        g.user = user

@app.route('/', methods=['GET'])
def home():
    global GLOBAL_USERNAME
    global GLOBAL_PASSWORD
    global GLOBAL_DBCNAME
    global verdict
    global list_of_schemas
    if not session.get('logged_in'):
        return render_template('login.html' , verdict='Success')
    else:
        return render_template('SPSOptions.html')

# Choose the Options
@app.route('/SPSOptions', methods=['GET', 'POST'])
def SPSOptions():
    verdict = check_verdict()
    print("VERDICT @ SPSOptions::",verdict)
    if verdict == 'Success':
        return render_template('SPSOptions.html')
    return render_template('login.html', verdict='Fail')

# Choose the Options
@app.route('/StringFormatter', methods=['GET', 'POST'])
def StringFormatter():
    return render_template('StringFormatter.html')

# SPSOption1 -- Provider Organization
@app.route('/SPSOption1', methods=['GET', 'POST'])
def SPSOption1():
    verdict = check_verdict()
    print("VERDICT @ SPSOption1::",verdict)
    if verdict == 'Success':
        return render_template('SPSOption1.html')
    return render_template('SPSOptions.html')

"""*********************************************************
************************* Page Options *********************
*********************************************************"""
def check_verdict():
    if session.get('logged_in'):
        v = 'Success'
    else:
        v = 'Fail'
    return v

@app.route('/Logout', methods=['GET', 'POST'])
def Logout():
    session['logged_in'] = False
    return render_template('login.html', verdict='Fail')

"""*********************************************************
************************* Organization *********************
*********************************************************"""

@app.route('/Calc_option1', methods=['POST'])
def Calc_option1():
    return render_template('SPSOption1.html', list_of_schemas = list_of_schemas)

@app.route("/npi_org",methods=["POST","GET"])
def npi_org():
    searchbox = request.form.get("text")
    selected_schema = request.form.get("selected_schema")
    q = f'''SELECT DISTINCT PROV_CTGRY_CD FROM {selected_schema}.PROV WHERE NPI = '{searchbox}' ORDER BY PROV_CTGRY_CD'''
    df_prov_ctgry_cd = pd.read_sql_query(q, MY_GLOBAL_DB)
    prov_ctgry_cd = df_prov_ctgry_cd['PROV_CTGRY_CD'].tolist()
    print(prov_ctgry_cd)
    if (prov_ctgry_cd == ['182']):
        df = SPSRunSqlOrg.npi_sql(MY_GLOBAL_DB, searchbox, selected_schema)
    else: 
        df = SPSRunSqlInd.npi_sql(MY_GLOBAL_DB, searchbox, selected_schema)
          
    result = df.to_json(orient="records")
    return jsonify(result)

@app.route("/taxid_org",methods=["POST","GET"])
def taxid_org():
    searchbox = request.form.get("text")
    selected_schema = request.form.get("selected_schema")
    df = SPSRunSqlOrg.taxid_sql(MY_GLOBAL_DB, searchbox, selected_schema)
    result = df.to_json(orient="records")
    return jsonify(result)

@app.route("/mstr_prov_id_org",methods=["POST","GET"])
def mstr_prov_id_org():
    searchbox = request.form.get("text")
    selected_schema = request.form.get("selected_schema")
    df = SPSRunSqlOrg.mstr_prov_id_sql(MY_GLOBAL_DB, searchbox, selected_schema)
    result = df.to_json(orient="records")
    return jsonify(result)

"""*********************************************************
************************* Individual ***********************
*********************************************************"""

@app.route('/Calc_option2', methods=['POST'])
def Calc_option2():
    return render_template('SPSOption2.html', list_of_schemas = list_of_schemas)

@app.route("/npi",methods=["POST","GET"])
def npi():
    searchbox = request.form.get("text")
    selected_schema = request.form.get("selected_schema")
    q = f'''SELECT DISTINCT PROV_CTGRY_CD FROM {selected_schema}.PROV WHERE NPI = '{searchbox}' ORDER BY PROV_CTGRY_CD'''
    df_prov_ctgry_cd = pd.read_sql_query(q, MY_GLOBAL_DB)
    prov_ctgry_cd = df_prov_ctgry_cd['PROV_CTGRY_CD'].tolist()
    print(prov_ctgry_cd)
    if (prov_ctgry_cd == ['182']):
        df = SPSRunSqlOrg.npi_sql(MY_GLOBAL_DB, searchbox, selected_schema)
    else: 
        df = SPSRunSqlInd.npi_sql(MY_GLOBAL_DB, searchbox, selected_schema)
          
    result = df.to_json(orient="records")
    return jsonify(result)

@app.route("/taxid",methods=["POST","GET"])
def taxid():
    searchbox = request.form.get("text")
    selected_schema = request.form.get("selected_schema")
    df = SPSRunSqlInd.taxid_sql(MY_GLOBAL_DB, searchbox, selected_schema)
    result = df.to_json(orient="records")
    return jsonify(result)

@app.route("/mstr_prov_id",methods=["POST","GET"])
def mstr_prov_id():
    searchbox = request.form.get("text")
    selected_schema = request.form.get("selected_schema")
    df = SPSRunSqlInd.mstr_prov_id_sql(MY_GLOBAL_DB, searchbox, selected_schema)
    result = df.to_json(orient="records")
    return jsonify(result)


"""*********************************************************
******************* Schema Search Option 3 *****************
*********************************************************"""

@app.route('/Calc_option3', methods=['POST'])
def Calc_option3():
    return render_template('SPSOption3.html')


@app.route("/npi_schema",methods=["POST","GET"])
def npi_schema():
    searchbox = request.form.get("text")
    df_schema = pd.DataFrame()
    q = f'''select DISTINCT OWNER from all_tab_columns where SUBSTR(OWNER,1,4) = 'XTRO' ORDER BY OWNER DESC '''
    df = pd.read_sql_query(q, MY_GLOBAL_DB)
    list_of_schemas = df['OWNER'].tolist()
    print(list_of_schemas)
    for selected_schema in list_of_schemas:
        q = f'''SELECT DISTINCT '{selected_schema}' AS SCHEMANAME, NPI, MSTR_PROV_ID, PROV_CTGRY_CD 
        FROM {selected_schema}.PROV WHERE NPI = '{searchbox}' ORDER BY NPI'''
        df_s = pd.read_sql_query(q, MY_GLOBAL_DB)
        df_schema = df_schema.append(df_s, ignore_index=True)
    result = df_schema.to_json(orient="records")
    return jsonify(result)

@app.route("/tax_schema",methods=["POST","GET"])
def tax_schema():
    searchbox = request.form.get("text")
    df_schema = pd.DataFrame()
    q = f'''select DISTINCT OWNER from all_tab_columns where SUBSTR(OWNER,1,4) = 'XTRO' ORDER BY OWNER DESC '''
    df = pd.read_sql_query(q, MY_GLOBAL_DB)
    list_of_schemas = df['OWNER'].tolist()
    print(list_of_schemas)
    for selected_schema in list_of_schemas:
        q = f'''SELECT DISTINCT '{selected_schema}' AS SCHEMANAME, PROV_ORG_FED_TAX_ID, PROV_CTGRY_CD 
        FROM {selected_schema}.PROV WHERE PROV_ORG_FED_TAX_ID = '{searchbox}' ORDER BY PROV_ORG_FED_TAX_ID'''
        df_s = pd.read_sql_query(q, MY_GLOBAL_DB)
        df_schema = df_schema.append(df_s, ignore_index=True)
    result = df_schema.to_json(orient="records")
    return jsonify(result)

@app.route("/mstr_prov_id_schema",methods=["POST","GET"])
def mstr_prov_id_schema():
    searchbox = request.form.get("text")
    df_schema = pd.DataFrame()
    q = f'''select DISTINCT OWNER from all_tab_columns where SUBSTR(OWNER,1,4) = 'XTRO' ORDER BY OWNER DESC '''
    df = pd.read_sql_query(q, MY_GLOBAL_DB)
    list_of_schemas = df['OWNER'].tolist()
    print(list_of_schemas)
    for selected_schema in list_of_schemas:
        q = f'''SELECT DISTINCT '{selected_schema}' AS SCHEMANAME, NPI, MSTR_PROV_ID, PROV_CTGRY_CD 
        FROM {selected_schema}.PROV WHERE mstr_prov_id = '{searchbox}' ORDER BY mstr_prov_id'''
        df_s = pd.read_sql_query(q, MY_GLOBAL_DB)
        df_schema = df_schema.append(df_s, ignore_index=True)
    result = df_schema.to_json(orient="records")
    return jsonify(result)


"""*********************************************************
******************* Schema Search Option 4 *****************
*********************************************************"""

@app.route('/Calc_option4', methods=['POST'])
def Calc_option4():
    return render_template('SPSOption4.html', list_of_schemas = list_of_schemas)


@app.route("/dp",methods=["POST","GET"])
def dp():
    selected_schema = request.form.get("selected_schema")
    list_of_tables = SPSdp.dp_sqltoget_tablenames(MY_GLOBAL_DB, selected_schema)
    return jsonify(list_of_tables)


@app.route("/dp_eval",methods=["POST","GET"])
def dp_eval():
    selected_schema = request.form.get("selected_schema")
    selected_table = request.form.get("selected_table")
    df = SPSdp.dp_query(MY_GLOBAL_DB, selected_schema, selected_table)
    result = df.to_json(orient="records")
    return jsonify(result)

"""*********************************************************
******************* Schema Search Option 5 *****************
*********************************************************"""

@app.route('/Calc_option5', methods=['POST', 'GET'])
def Calc_option5():
    return render_template('SPSOption5.html')


@app.route('/Calc_option5a', methods=['POST'])
def Calc_option5a():
    return render_template('SPSOption5a.html', list_of_schemas = list_of_schemas)


@app.route("/check_safety_net",methods=["POST","GET"])
def check_safety_net():
    selected_schema = request.form.get("selected_schema")
    df = SPSSafetyNet.check_safety_net_query(MY_GLOBAL_DB, selected_schema)
    result = df.to_json(orient="records")
    return jsonify(result)


"""*********************************************************
************************* Login ****************************
*********************************************************"""

@app.route('/login', methods=['POST'])
def do_admin_login():
    global MY_GLOBAL_DB
    global list_of_schemas
    GLOBAL_PASSWORD = request.form['password']
    GLOBAL_USERNAME = request.form['username']
    GLOBAL_DBCNAME = request.form['DBCNAME_id']
    users.append(User(id=2, dbcname=GLOBAL_DBCNAME, username=GLOBAL_USERNAME, password=GLOBAL_PASSWORD))
    users[1].username = GLOBAL_USERNAME
    users[1].password = GLOBAL_PASSWORD
    users[1].dbcname = GLOBAL_DBCNAME
    print(GLOBAL_DBCNAME)
    verdict, MY_GLOBAL_DB, list_of_schemas = SPSLogin.Temp_TDLogin(GLOBAL_USERNAME, GLOBAL_PASSWORD, GLOBAL_DBCNAME)
    # verdict, MY_GLOBAL_DB, list_of_schemas = SPSLogin.TDLogin(GLOBAL_USERNAME, GLOBAL_PASSWORD, GLOBAL_DBCNAME)
    print(verdict, list_of_schemas)
    if verdict != 'Fail':
        flash("Successful! Welcome to SPS !", category="alert")
        session['logged_in'] = True
        print("Successfully Logged in by User: ", GLOBAL_USERNAME)
        messages = f'Successfully Logged in by User: {GLOBAL_USERNAME}'
        return render_template('SPSOptions.html', verdict='Success', messages = messages)
    else:
        flash('Invalid username or password. Please try again!', category="alert")
        messages = 'Invalid username or password. Please try again!'
        session['logged_in'] = False
        return render_template('login.html', verdict= verdict)

# if __name__ == "__main__":
#     app.secret_key = os.urandom(24)
#     app.run(host='127.0.0.1', port=5000)



