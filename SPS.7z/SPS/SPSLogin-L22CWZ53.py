import cx_Oracle
import pandas as pd



def TDLogin(GLOBAL_USERNAME, GLOBAL_PASSWORD, GLOBAL_DBCNAME):

    if (GLOBAL_DBCNAME == 'SPSODSVCP'):
        host = 'va10px09v1-scan1'
    else:
        host = 'va33dx13v1-scan1'

    try:
        dsn_tns = cx_Oracle.makedsn(f'{host}', '1525', service_name=f'{GLOBAL_DBCNAME}') 
        db_conn = cx_Oracle.connect(user=f"{GLOBAL_USERNAME}", password=f"{GLOBAL_PASSWORD}", dsn=dsn_tns) 
        verdict = 'Success'
        q1 = f'''select DISTINCT OWNER from all_tab_columns where SUBSTR(OWNER,1,4) = 'XTRO' ORDER BY OWNER DESC '''
        df1 = pd.read_sql_query(q1, db_conn)
        list_of_schemas = df1['OWNER'].tolist()
    except:
        verdict = 'Fail'
        db_conn = ''
        list_of_schemas = []
    return verdict, db_conn, list_of_schemas


def Temp_TDLogin(GLOBAL_USERNAME, GLOBAL_PASSWORD, GLOBAL_DBCNAME):

    # g_username = GLOBAL_USERNAME
    # g_password = GLOBAL_PASSWORD
    g_username = 'AH02855'
    g_password = 'Eszr6$S$'

    dsn_tns = cx_Oracle.makedsn('va33dx13v1-scan1', '1525', service_name=f"{GLOBAL_DBCNAME}") 
    print(dsn_tns)
    db_conn = cx_Oracle.connect(user=f"{g_username}", password=f"{g_password}", dsn=dsn_tns) 
    #q = '''Select * from XTROWNER4.PROV FETCH NEXT 10 ROWS ONLY'''
    #index_columns = ['MSTR_PROV_ID', 'PROV_CTGRY_CD']
    #df = pd.read_sql_query(q, db_conn, index_col= index_columns)
    #df = pd.read_sql_query(q, db_conn)

    q1 = f'''select DISTINCT OWNER from all_tab_columns where SUBSTR(OWNER,1,4) = 'XTRO' ORDER BY OWNER DESC '''
    df1 = pd.read_sql_query(q1, db_conn)
    list_of_schemas = df1['OWNER'].tolist()
    print("Success")
    MY_GLOBAL_DB = db_conn
    verdict = 'Success'
    return verdict, MY_GLOBAL_DB, list_of_schemas

