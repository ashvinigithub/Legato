
# Python code demonstrate creating 
# DataFrame from dict narray / lists 
# By default addresses.
  
import pandas as pd
   
# Create DataFrame
df = pd.DataFrame({'Name':['No Record Found']})
df.reset_index(drop=True, inplace=True)
  
# Print the output.
print(df)