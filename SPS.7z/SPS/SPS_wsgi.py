from flask import Flask, flash, redirect, render_template, request, session, abort, url_for, send_file, g
import os
from io import BytesIO
import pandas as pd
import xlsxwriter
from datetime import timedelta
import SPSLogin


app = Flask(__name__)
app.config['SECRET_KEY'] = os.urandom(24)
app.config['DEBUG'] = True
# cnctstrng = "DRIVER={/Library/Application Support/teradata/client/16.20/lib/tdataodbc_sbu.dylib};DBCName="+td_usr_dsn+";AUTHENTICATION=LDAP;UID="+msid+";PWD="+pwd+";"

class User:
    def __init__(self, id, dbcname, username, password):
        self.id = id
        self.dbcname = dbcname
        self.username = username
        self.password = password

    def __repr__(self):
        return f'{[self.username, self.password, self.dbcname]}'

users = []
users.append(User(id=1, dbcname='dbcname', username='dummy', password='password'))



@app.before_request
def before_request():
    g.user = None
    session.permanent = True
    app.permanent_session_lifetime = timedelta(minutes=5)
    if 'user_id' in session:
        user = [x for x in users if x.id == session['user_id']][0]
        g.user = user


@app.route('/', methods=['GET'])
def home():
    global GLOBAL_USERNAME
    global GLOBAL_PASSWORD
    global GLOBAL_DBCNAME
    global verdict
    if not session.get('logged_in'):
        return render_template('login.html')
    else:
        return render_template('SPSOptions.html')


# Choose the Options
@app.route('/SPSOptions', methods=['GET', 'POST'])
def SPSOptions():
    verdict = check_verdict()
    print("VERDICT @ SPSOptions::",verdict)
    if verdict == 'Success':
        return render_template('SPSOptions.html')
    return render_template('login.html')

# SPSOption1 -- Provider Organization
@app.route('/SPSOption1', methods=['GET', 'POST'])
def SPSOption1():
    verdict = check_verdict()
    print("VERDICT @ SPSOption1::",verdict)
    if verdict == 'Success':
        return render_template('SPSOption1.html')
    return render_template('SPSOptions.html')

"""*********************************************************
************************* Page Options *********************
*********************************************************"""
def check_verdict():
    if session.get('logged_in'):
        v = 'Success'
    else:
        v = 'Fail'
    return v


@app.route('/Calc_option1', methods=['POST'])
def Calc_option1():
    print(MY_GLOBAL_DB)
    f_result = SPSLogin.calc_spsoption_1(MY_GLOBAL_DB)
    print("Return from function completed")
    return render_template('SPSOption1.html', f_result=f_result)


"""*********************************************************
************************* Login ****************************
*********************************************************"""

@app.route('/login', methods=['POST'])
def do_admin_login():
    global MY_GLOBAL_DB
    GLOBAL_PASSWORD = request.form['password']
    GLOBAL_USERNAME = request.form['username']
    GLOBAL_DBCNAME = request.form['DBCNAME_id']
    users.append(User(id=2, dbcname=GLOBAL_DBCNAME, username=GLOBAL_USERNAME, password=GLOBAL_PASSWORD))
    users[1].username = GLOBAL_USERNAME
    users[1].password = GLOBAL_PASSWORD
    users[1].dbcname = GLOBAL_DBCNAME
    # verdict, MY_GLOBAL_DB, df = SPSLogin.TDLogin(GLOBAL_USERNAME, GLOBAL_PASSWORD, GLOBAL_DBCNAME)
    # if verdict != 'Fail':
    #     flash("Successful! Welcome to SPS !", category="alert")
    #     session['logged_in'] = True
    #     print("Successfully Logged in by User: ", GLOBAL_USERNAME)
    #     return render_template('SPSOptions.html')
    # else:
    #     flash('Invalid username or password. Please try again!', category="alert")
    #     session['logged_in'] = False
    #     return render_template('login.html')
    return render_template('SPSOptions.html')

if __name__ == "__main__":
    app.secret_key = os.urandom(24)
    app.run(host='127.0.0.1', port=5000)



