import pandas as pd
import pyodbc  
import psycopg2

# # Redshift Connection
con = psycopg2.connect(dbname= 'cmd', host= 'cmd-redshift-cluster-1-preprod.cxtv8kvoqr5f.us-east-1.redshift.amazonaws.com', port= '5439', user= 'u', password= 'p')
q1 = f'''Select * from mdl_stage.testing_vw_EDW_PRCHSR_ORG_MLSA'''
preprod_df =  pd.read_sql_query(q1, con)
preprod_df = preprod_df.astype(str)
preprod_df.fillna(value = 0, inplace = True)
con.close

# # SQL Server Connection
cnxn_str = ("Driver=SQL Server Native Client 11.0;" "Server= VA10TWPSQL020\SQL01,10001;" "Database=CMD_Work;" "Trusted_Connection=yes;")
print(cnxn_str)
cnxn = pyodbc.connect(cnxn_str, autocommit=True)
crsr = cnxn.cursor()
cols = "','".join([str(i) for i in preprod_df.columns.tolist()])
for i, row in preprod_df.iterrows():
    sql = "INSERT INTO CMD_work.dbo.testing_vw_EDW_PRCHSR_ORG_MLSA_Redshift ('" +cols + "') values(" + "?,"*(len(row) -1) + "?)"
    crsr.execute(sql, *tuple(row))
    cnxn.commit()
    crsr.commit()
crsr.close()
cnxn.close()

