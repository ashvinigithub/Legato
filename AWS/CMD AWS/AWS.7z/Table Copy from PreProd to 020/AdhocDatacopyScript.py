import pandas as pd
import pyodbc  
import psycopg2

# table testing_vw_EDW_PRCHSR_ORG_MLSA

# Redshift Connection
# port = '5439'
# dbname = 'cmd'
# user = 'ah02855'
# password = 'J3Nyeu75'
# host = 'cmd-redshift-cluster-1-preprod.cxtv8kvoqr5f.us-east-1.redshift.amazonaws.com'

# con = psycopg2.connect(dbname= f'{dbname}', host= f'{host}', port= f'{port}', user= f'{user}', password= f'{password}')
# q1 = f'''Select * from mdl_stage.testing_vw_EDW_PRCHSR_ORG_MLSA'''
# preprod_df =  pd.read_sql_query(q1, con)
# preprod_df = preprod_df.astype(str)
# preprod_df.fillna(value = 0, inplace = True)
# preprod_df_list = list(preprod_df.itertuples(index=False, name=None))
# print(preprod_df_list[0])
# # print(preprod_df.columns)
# con.close


# # SQL Server Connection
# driver_name = str([i for i in pyodbc.drivers() if "SQL Server Native Client" in i])[2:-2]
# server_name = 'VA10TWPSQL020\SQL01,10001' 
# Database = 'CMD_Work'
# cnxn_str = (f"Driver={driver_name};" f"Server={server_name};" f"Database={Database};" "Trusted_Connection=yes;")
# print(cnxn_str)
# cnxn = pyodbc.connect(cnxn_str, autocommit=True)
# crsr = cnxn.cursor()

# cols = "','".join([str(i) for i in preprod_df.columns.tolist()])

# # for i, row in preprod_df.iterrows():
# #     # sql = "INSERT INTO CMD_work.dbo.testing_vw_EDW_PRCHSR_ORG_MLSA_Redshift ('" +cols + "') values(" + "?,"*(len(row) -1) + "?)"
# #     sql = "INSERT INTO CMD_work.dbo.testing_vw_EDW_PRCHSR_ORG_MLSA_Redshift values(" + "?,"*(len(row) -1) + "?)"
# #     # print(sql, tuple(row))
# #     print(f"Inserted {i} data!")
# #     crsr.execute(sql, *tuple(row))
# #     cnxn.commit()


# with cnxn:
#     crsr.fast_executemany = True
#     print("Connection Complete! ", cnxn)
#     crsr.executemany("INSERT INTO CMD_work.dbo.testing_vw_EDW_PRCHSR_ORG_MLSA_Redshift VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", preprod_df_list)
#     crsr.commit()
#     print("Inserts Complete! ")

# crsr.close()
# cnxn.close()



# table = MelissaTest_CVEmp_OutputData_Redshift


# Redshift Connection
port = '5439'
dbname = 'cmd'
user = 'ah02855'
password = 'J3Nyeu75'
host = 'cmd-redshift-cluster-1-preprod.cxtv8kvoqr5f.us-east-1.redshift.amazonaws.com'

con = psycopg2.connect(dbname= f'{dbname}', host= f'{host}', port= f'{port}', user= f'{user}', password= f'{password}')
q1 = f'''Select * from mdl_stage.MelissaTest_CVEmp_OutputData'''
preprod_df =  pd.read_sql_query(q1, con)
preprod_df = preprod_df.astype(str)
preprod_df.fillna(value = 0, inplace = True)
preprod_df_list = list(preprod_df.itertuples(index=False, name=None))
print(preprod_df_list[0])
# print(preprod_df.columns)
con.close


# SQL Server Connection
driver_name = str([i for i in pyodbc.drivers() if "SQL Server Native Client" in i])[2:-2]
server_name = 'VA10TWPSQL020\SQL01,10001' 
Database = 'CMD_Work'
cnxn_str = (f"Driver={driver_name};" f"Server={server_name};" f"Database={Database};" "Trusted_Connection=yes;")
print(cnxn_str)
cnxn = pyodbc.connect(cnxn_str, autocommit=True)
crsr = cnxn.cursor()

cols = "','".join([str(i) for i in preprod_df.columns.tolist()])
set_ansi = "SET ANSI_WARNINGS OFF"
crsr.execute(set_ansi)

with cnxn:
    
    crsr.fast_executemany = True
    print("Connection Complete! ", cnxn)
    crsr.executemany("INSERT INTO CMD_work.dbo.MelissaTest_CVEmp_OutputData_Redshift VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", preprod_df_list)
    crsr.commit()
    print("Inserts Complete! ")

set_ansi = "SET ANSI_WARNINGS ON"
crsr.execute(set_ansi)
crsr.close()
cnxn.close()