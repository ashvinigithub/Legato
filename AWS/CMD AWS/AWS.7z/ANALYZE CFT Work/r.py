


sub = 'GL-Redshift-ExecuteVacuumdeleteAndAnalyzeCommands completed for mdl_physical.EmployerAccount_SF_Attributes'[0:99]
# s =sub[0:99]
print(sub)