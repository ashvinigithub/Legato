import boto3
import os
import json
import sys
from awsglue.utils import getResolvedOptions
import psycopg2

smclient = boto3.client("secretsmanager", region_name="us-east-1")

try:
    args = getResolvedOptions(sys.argv,['JOB_NAME','RD_DB_Env','COMMAND'])
    print(args)
    
    RedshiftEnv=args['RD_DB_Env']
    storedPROC=args['COMMAND']
    HostMc=json.loads(smclient.get_secret_value(SecretId="cmd-AWS-Envdet")['SecretString']).get('Env-Inst')
    strTopicarn=json.loads(smclient.get_secret_value(SecretId="cmd-AWS-Envdet")['SecretString']).get('LO-DL')
    
    get_secret_value_response = smclient.get_secret_value(SecretId=RedshiftEnv)
    secret = get_secret_value_response['SecretString']
    secret = json.loads(secret)
    connectUrl="dbname={0} user={1} host={2} password={3}".format(secret.get('database'),secret.get('user'),secret.get('host'),secret.get('passwd'))
    #print(connectUrl)
    #conn = psycopg2.connect(connectUrl)
    con=psycopg2.connect(dbname=secret.get('database'), host=secret.get('host').replace(":5439",""), port="5439", user=secret.get('user'), password=secret.get('passwd'))
    con.set_session(readonly=False, autocommit=True)
    cur = con.cursor()
    # cur.execute(f"call {storedPROC}")
    cur.execute(f"Vacuum delete only {storedPROC}")
    cur.execute(f"analyze {storedPROC}")
    
    print(f"Vacuum delete & analyze commands on {storedPROC} completed. ")
    cur.close()
    con.close()
    boto3.client('sns').publish(TopicArn=strTopicarn, Subject=f"{args['JOB_NAME']} completed for {storedPROC}", Message=f"Delete Vacuum & Analyze Commands on ({storedPROC}) has completed. \n")

except Exception as err:
    err1=str(err).replace("\'","")
    boto3.client('sns').publish(TopicArn=strTopicarn, Subject=f"{args['JOB_NAME']} for {storedPROC} failed", Message=f"Delete Vacuum & Analyze Command Job on ({storedPROC}) has failed with error - {err1} \n")
    raise err     
