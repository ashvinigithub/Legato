# cmdfunctions.py

import json
import os
import boto3
import urllib
from datetime import datetime
import dateutil
from dateutil.parser import parse
smclnt = boto3.client("secretsmanager", region_name="us-east-1")

s3_Clnt = boto3.client('s3', region_name='us-east-1')
s3_Rsrc = boto3.resource('s3', region_name='us-east-1')
Glu_client = boto3.client('glue', region_name='us-east-1')
lambda_clnt = boto3.client('lambda', region_name='us-east-1')

try:
 HostMcNm=json.loads(smclnt.get_secret_value(SecretId="cmd-AWS-Envdet")['SecretString']).get('Env-Inst')
 snsTopicarn=json.loads(smclnt.get_secret_value(SecretId="cmd-AWS-Envdet")['SecretString']).get('LO-DL')
except Exception as err:
 #strerr=str(err).replace("\'","")
 #boto3.client('sns').publish(TopicArn='arn:aws:sns:us-east-1:600749888086:CMD-LO-Notify', Subject=f"{os.environ['AWS_LAMBDA_FUNCTION_NAME']} failed", Message=strerr)
 raise err


# function to extract file details from s3 event definition
def extractfilenams3key(event):
 try:
  #print(str(event))
  strBucketNm=event['Records'][0]['s3']['bucket']['name']
  #print(strBucketNm)
  strKey=event['Records'][0]['s3']['object']['key']
  #print(strKey)
  strSrcDir=os.path.split(event['Records'][0]['s3']['object']['key'])[0]
  #print(strSrcDir)
  strTrigFileNm=os.path.split(event['Records'][0]['s3']['object']['key'])[1]
  #print(strTrigFileNm)
  #LoadFile="s3://"+strBucketNm+"/"+urllib.parse.unquote_plus(strKey)
  strunquoteKey=urllib.parse.unquote_plus(strKey)
  return strBucketNm, strunquoteKey
 except Exception as err:
  raise err
  
# function to extract file details from sqs event definition
def extractfilenamsqskey(event,strBucketNm):
 try:
  #print(str(event))
  strKey=event['Records'][0]['body']
  #print(strKey)
  strSrcDir=os.path.split(event['Records'][0]['body'])[0]
  #print(strSrcDir)
  strTrigFileNm=os.path.split(event['Records'][0]['body'])[1]
  #print(strTrigFileNm)
  #LoadFile="s3://"+strBucketNm+"/"+urllib.parse.unquote_plus(strKey)
  strunquoteKey=urllib.parse.unquote_plus(strKey)
  return strBucketNm, strunquoteKey
 except Exception as err:
  raise err  
        
    
# Aurora MySQL database connect call
def dbconnect(MySQLEnv):
 import mysql.connector
 try:
  
  client = boto3.client("secretsmanager", region_name="us-east-1")
  get_secret_value_response = client.get_secret_value(SecretId=MySQLEnv)
  secret = get_secret_value_response['SecretString']
  secret = json.loads(secret)    
  mydb = mysql.connector.connect(
          host=secret.get('host'),
          user=secret.get('user'),
          passwd=secret.get('passwd'),
          database=secret.get('database')
         )
  print(f"Connection to DB instance {secret.get('Env-DBInst')} successful")
  return mydb
 except mysql.connector.Error as err:
  print(f"Following connection Error occured --> {err}")
  #boto3.client('sns').publish(TopicArn=snsTopicarn, Subject=f"{os.environ['AWS_LAMBDA_FUNCTION_NAME']} failed", Message=f"Connection to DB instance {secret.get('Env-DBInst')} failed with error - {err}")
  raise err
  
# Redshift database connect call
def Redshift_dbconnect(RDEnv):
 from pgdb import connect
 try:

  client = boto3.client("secretsmanager", region_name="us-east-1")
  get_secret_value_response = client.get_secret_value(SecretId=RDEnv)
  secret = get_secret_value_response['SecretString']
  secret = json.loads(secret)
  mydb=connect(host=secret.get('host'),database=secret.get('database'),user=secret.get('user'), password=secret.get('passwd'))
  print(f"Connection to DB instance {secret.get('Env-DBInst')} successful")
  return mydb
 except Exception as err:
  print(f"Following connection Error occured --> {err}")
  #boto3.client('sns').publish(TopicArn=snsTopicarn, Subject=f"{os.environ['AWS_LAMBDA_FUNCTION_NAME']} failed", Message=f"Connection to DB instance {secret.get('Env-DBInst')} failed with error - {err}")
  raise err  

# Function to perform Audit insert    
def LogAudit(JobNm, TrigFileNm, strHostMc, strstatus, strstatusinfo, DBEnv):
 try:
  dbconn=dbconnect(DBEnv)
  dbconn.get_warnings=True
  auditsql=f"Insert into cmd_audit.cmd_aws_audit_logs (JobName, TaskName, Host_Machine, Status, Status_Info, Load_TS) values ('{JobNm}', '{TrigFileNm}', '{strHostMc}', '{strstatus}', '{strstatusinfo}', current_timestamp());"
  #print(auditsql)
  mycursor = dbconn.cursor()
  mycursor.execute(auditsql)
  dbconn.commit()
  rowcount=mycursor.rowcount
  strwarnings=mycursor.fetchwarnings()
  mycursor.close()
  dbconn.close()
  return rowcount, strwarnings
 except Exception as err:
  print(f"Following Error occured in LogAudit module --> {err}")
  boto3.client('sns').publish(TopicArn=snsTopicarn, Subject=f"{JobNm} failed", Message=f"Following Error occured in LogAudit module --> {err}")
  raise err
  
# Function to perform Audit insert    
def Redshift_LogAudit(JobNm, TrigFileNm, strHostMc, strstatus, strstatusinfo, DBEnv):
 try:
  dbconn=Redshift_dbconnect(DBEnv)
  #dbconn.get_warnings=True
  auditsql=f"Insert into mdl_audit.cmd_aws_audit_logs (JobName, TaskName, Host_Machine, Status, Status_Info) values ('{JobNm}', '{TrigFileNm}', '{strHostMc}', '{strstatus}', '{strstatusinfo}');"
  #print(auditsql)
  mycursor = dbconn.cursor()
  mycursor.execute(auditsql)
  dbconn.commit()
  rowcount=mycursor.rowcount
  #strwarnings=mycursor.fetchwarnings()
  mycursor.close()
  dbconn.close()
  return rowcount
 except Exception as err:
  print(f"Following Error occured in Redshift_LogAudit module --> {err}")
  boto3.client('sns').publish(TopicArn=snsTopicarn, Subject=f"{JobNm} failed", Message=f"Following Error occured in Redshift_LogAudit module --> {err}")
  raise err  

# json parser call    
def parsejson(filedet,tblprefix, SFEnv):
 try:
  sfobj=s3_Clnt.get_object(Bucket = filedet[0], Key = filedet[1])
  sfobjcontent=sfobj["Body"].read().decode('utf-8')
  #print(sfobjcontent)
  #with open(LoadFile,"r") as jf:
  # sfdat=json.load(jf)
  sfdat=json.loads(sfobjcontent) 
  id=sfdat["data"]["payload"]["ChangeEventHeader"]["recordIds"][0]
  print(f"Record ID: {id}")
  dml_typ=sfdat["data"]["payload"]["ChangeEventHeader"]["changeType"]
  dml_tbl=sfdat["data"]["payload"]["ChangeEventHeader"]["entityName"]
  
  if (dml_typ.upper() in ["CREATE","UNDELETE"]):
   col_lst="id"
   dat_lst=[id]
   for col,dat in sfdat["data"]["payload"].items():
    if (col not in ["ChangeEventHeader"]):
     if (isinstance(dat,dict) and ("ADDRESS" in col.upper())):
      for col_in,dat_in in sfdat["data"]["payload"][col].items():
       if (col_in.upper() in ["ACCURACY", "CITY", "COUNTRY", "COUNTRYCODE", "LATITUDE", "LONGITUDE", "POSTALCODE", "STATE", "STATECODE", "STREET"]):
        col_lst=f"{col_lst}, {col[0:-7]+col_in}"
        dat_in_tmp=dat_in
        if (IsDate(dat_in)):
         dat_in_tmp=str(TzConvert(dat_in)[1])
        dat_lst.append(str(dat_in_tmp).replace("\'",""))
     elif ((isinstance(dat,dict)) and ("__c" in col)):
      for col_in,dat_in in sfdat["data"]["payload"][col].items():
       if ((col_in.upper()=="LATITUDE") or (col_in.upper()=="LONGITUDE")):
        col_lst=f"{col_lst}, {col[0:-3]}__{col_in}__s"
        dat_in_tmp=dat_in
        if (IsDate(dat_in)):
         dat_in_tmp=str(TzConvert(dat_in)[1])
        dat_lst.append(str(dat_in_tmp).replace("\'",""))
     else:
      col_lst=f"{col_lst}, {col}"
      dat_tmp=dat
      if (IsDate(dat) is True):
       dat_tmp=str(TzConvert(dat)[1])
      dat_lst.append(str(dat_tmp).replace("\'",""))
   strQry=f"Insert into {tblprefix}{dml_tbl} ({col_lst}) values ({str(dat_lst)[1:-1]});"
  elif (dml_typ.upper() == "UPDATE"):
   fields2upd=len(sfdat["data"]["payload"]["ChangeEventHeader"]["changedFields"])
   print(f"fields to be updated: {fields2upd}")
   cnt=1
   for col,dat in sfdat["data"]["payload"].items():
    dat_tmp=dat
    if (IsDate(dat)):
     dat_tmp=str(TzConvert(dat)[1])
    dat1=str(dat_tmp).replace("\'","")
    if (col not in ["ChangeEventHeader"]):
     if (isinstance(dat,dict) and ("ADDRESS" in col.upper())):
      for col_in,dat_in in sfdat["data"]["payload"][col].items():
       if (col_in.upper() in ["ACCURACY", "CITY", "COUNTRY", "COUNTRYCODE", "LATITUDE", "LONGITUDE", "POSTALCODE", "STATE", "STATECODE", "STREET"]):
        dat_in_tmp=dat_in
        if (IsDate(dat_in)):
         dat_in_tmp=str(TzConvert(dat_in)[1])
        data_in_frmt=str(dat_in_tmp).replace("\'","")
        if (cnt==1):
         upd_lst=f"set {col[0:-7]+col_in}='{data_in_frmt}'"
        else:
         #print(f"{col[0:-7]+col_in}")
         upd_lst=f"{upd_lst}, {col[0:-7]+col_in}='{data_in_frmt}'"
     elif ((isinstance(dat,dict)) and ("__c" in col)):
      for col_in,dat_in in sfdat["data"]["payload"][col].items():
       if ((col_in.upper()=="LATITUDE") or (col_in.upper()=="LONGITUDE")):
        dat_in_tmp=dat_in
        if (IsDate(dat_in)):
         dat_in_tmp=str(TzConvert(dat_in)[1])
        data_in_frmt=str(dat_in_tmp).replace("\'","")
        if (cnt==1):
         upd_lst=f"set {col[0:-3]}__{col_in}__s='{data_in_frmt}'"
        else:
         upd_lst=f"{upd_lst}, {col[0:-3]}__{col_in}__s='{data_in_frmt}'"
     else:
      if (cnt==1):
       upd_lst=f"set {col}='{dat1}'"
      else:
       upd_lst=f"{upd_lst}, {col}='{dat1}'"
     cnt=cnt+1
   if (cnt>1):
    strQry=f"Update {tblprefix}{dml_tbl} {upd_lst} where id='{id}';"
   else:
    strQry=""
  elif (dml_typ.upper() in ["DELETE","GAP_DELETE"]):
   Recs2upd=len(sfdat["data"]["payload"]["ChangeEventHeader"]["recordIds"])
   id1=f"'{id}'"
   if (Recs2upd > 1):    
    for cnt in range(1,Recs2upd):
     tmp=eval(f"sfdat[\"data\"][\"payload\"][\"ChangeEventHeader\"][\"recordIds\"][{cnt}]")
     id1=f"{id1},'{tmp}'"
     id=f"{id},{tmp}"
   strQry=f"Delete from {tblprefix}{dml_tbl} where id in ({id1});"
  elif (dml_typ.upper() in ["GAP_CREATE","GAP_UNDELETE"]):
   print(f"Initailizing check @ salesforce for {dml_typ.upper()} of {id},{tblprefix}, {dml_tbl}")
   strQry=SFPullbyRecordID(id,tblprefix, dml_tbl, "CREATE", SFEnv)
  elif (dml_typ.upper() in ["GAP_UPDATE"]):
   print(f"Initailizing check @ salesforce for {dml_typ.upper()} of {id},{tblprefix}, {dml_tbl}")
   strQry=SFPullbyRecordID(id,tblprefix, dml_tbl, "UPDATE", SFEnv)
  else:
   raise ValueError (f"User Error: Event type in the notification is not supported. Event type recieved is {dml_typ}")
  print(strQry)
  return strQry, dml_typ.upper(), id
 except Exception as err:
  raise err


# Function to connect to Salesforce for data record    
def SFConnect(SFEnv):
 try:
  SFusr=json.loads(smclnt.get_secret_value(SecretId=SFEnv)['SecretString']).get('username')
  SFpwd=json.loads(smclnt.get_secret_value(SecretId=SFEnv)['SecretString']).get('password')
  SFtkn=json.loads(smclnt.get_secret_value(SecretId=SFEnv)['SecretString']).get('security_token')
  if (SFtkn=='None'):
   sfconn = Salesforce(username=SFusr, password=SFpwd)
  else:
   sfconn = Salesforce(username=SFusr, password=SFpwd, security_token=SFtkn)
  #print(sfconn)
  return sfconn
 except Exception as err:
  raise err


# Function to connect to Salesforce for data record    
def SFPullbyRecordID(SFid,tblprefix, dbtbl, qtyp, SFEnv):
 from simple_salesforce import Salesforce
 try:
  sf=SFConnect(SFEnv)
  print(f"connected with salesforce for {dbtbl}")  
  desc=eval(f"sf.{dbtbl}.describe()")
  field_names = [field['name'] for field in desc['fields']]
  soql = f"SELECT {','.join(field_names)} FROM {dbtbl}"
  print(f"SF fetch qry: {soql} where id='{SFid}'")
  sfdat = sf.query_all(f"{soql} where id='{SFid}'")
  if (qtyp.upper() == "CREATE"):
   cnt=1
   dat_lst=[]
   for col,dat in sfdat["records"][0].items():
    if (col not in ["attributes"]):
     if not (isinstance(dat,dict)):
      if (dat is not None):
       if (cnt==1):
        col_lst=f"{col}"
       else:
        col_lst=f"{col_lst}, {col}"
       cnt=cnt+1
       dat_tmp=dat
       if (type(dat)==bool):
        dat_tmp=int(str(dat).upper()=='TRUE')
       if (IsDate(dat) is True):
        dat_tmp=str(TzConvert(dat)[1])
       dat_lst.append(str(dat_tmp).replace("\'",""))
   strQry=f"Insert into {tblprefix}{dbtbl} ({col_lst}) values ({str(dat_lst)[1:-1]});"
  elif (qtyp.upper() == "UPDATE"):
   cnt=1
   for col,dat in sfdat["records"][0].items():
    if (col not in ["attributes"]):
     if not (isinstance(dat,dict)):
      if (dat is not None):
       dat_tmp=dat
       if (type(dat)==bool):
        dat_tmp=int(str(dat).upper()=='TRUE')
       if (IsDate(dat)):
        dat_tmp=str(TzConvert(dat)[1])
       dat1=str(dat_tmp).replace("\'","")
       if (cnt==1):
        upd_lst=f"set {col}='{dat1}'"
       else:
        upd_lst=f"{upd_lst}, {col}='{dat1}'"
       cnt=cnt+1
   strQry=f"Update {tblprefix}{dbtbl} {upd_lst} where id='{id}';"
   print(f"SF fetch results based qry: {strQry}")
  return strQry
 except Exception as err:
  raise err
  
  
# Archive file post processing    
def ArchiveFile(fldet,dtsuffix):
 try:
  copy_source = {'Bucket': fldet[0], 'Key': fldet[1]}
  strDestDir='Archive'
  if(dtsuffix==True):
   dateTimeObj = datetime.now()
   tmprnt=str(TzConvert(str(dateTimeObj))[1].strftime('%Y%m%d%H%M%S%f'))
   tmppath=os.path.splitext(fldet[1])[0] + "_" + tmprnt + os.path.splitext(fldet[1])[1]
   strDest=os.path.join(strDestDir, tmppath)
  else:
   strDest=os.path.join(strDestDir, fldet[1])
  s3_Rsrc.meta.client.copy(copy_source, fldet[0], strDest)
  s3_Clnt.delete_object(Bucket=fldet[0], Key=fldet[1])
  print(f"File {os.path.split(fldet[1])[1]} has been archived")
 except Exception as err:
  raise err

# validate if datetime    
def IsDate(strdt):
 try:
  flg=''
  #for fmt in ('%Y-%m-%d', '%H:%M:%S.%fZ', '%Y-%m-%dT%H:%M:%S.%fZ'):
  for fmt in ('%Y-%m-%dT%H:%M:%S.%fZ','%Y-%m-%d %H:%M:%S.%f'):
   try:
    #print(str(strdt))
    dt=datetime.strptime(str(strdt), fmt)
    flg=True
    break
   except ValueError:
    flg=False
    pass
  return flg
 except ValueError:
  return False
  
# utc to est   
def TzConvert(strdtz):
 try: 
  to_zone = dateutil.tz.gettz('America/New_York')
  dtutc=parse(strdtz, fuzzy=False)
  dtest=dtutc.astimezone(to_zone)
  return True, dtest
 except ValueError:
  return False, strdtz
  
# Bulk load csv data into MySQl table   
def Loadcsv2MySql(fldet,ldtbl,fldlst,setfld,setchrencode,DBEnv):
 try:
  LoadFile="s3://"+fldet[0]+"/"+fldet[1]
  print(LoadFile)
  sql = "LOAD DATA FROM S3 '"+LoadFile+"' "
  sql = sql + "REPLACE INTO TABLE "+ldtbl+" "
  if (setchrencode!='None'):
   sql = sql + "CHARACTER SET " + setchrencode
  sql = sql + "FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '\"' LINES TERMINATED BY '\\r\\n' IGNORE 1 LINES "
  sql = sql + "(" + fldlst + ")"
  if (setfld!='None'):
   sql = sql + "set " + setfld
  print("load script : " + sql)
  dbconn=dbconnect(DBEnv)
  dbconn.get_warnings=True
  result=dbconn.cmd_query(sql)
  qryinfo=result['info_msg']
  dbconn.commit()
  #print(qryinfo)
  dbconn.close()
  return qryinfo
 except Exception as err:
  raise err
  
#Truncate specified table     
def TruncateTable(dtbl,DBEnv):
 try:
  dbconn=dbconnect(DBEnv)
  dbconn.get_warnings=True
  sql = "TRUNCATE TABLE "+dtbl+";"
  #print(sql)
  mycursor = dbconn.cursor()
  mycursor.execute(sql)
  dbconn.commit()
  rowcount=mycursor.rowcount
  strwarnings=mycursor.fetchwarnings()
  mycursor.close()
  dbconn.close()
  print(f"{dtbl} table has been truncated")
  return rowcount, strwarnings
 except Exception as err:
  raise err  
  
#Disable the 1st trigger for the specified lambda function     
def LambdaDisableTrigger(lmbfunc):
 try:
  getresp = lambda_clnt.list_event_source_mappings(FunctionName=lmbfunc)
  print(getresp['EventSourceMappings'][0]['UUID'])
  setresp = lambda_clnt.update_event_source_mapping(UUID=getresp['EventSourceMappings'][0]['UUID'], Enabled=False)
  print(setresp['State'])
  if (setresp['State'] in ["Disabling","Updating"]):
   stat=f"Trigger {getresp['EventSourceMappings'][0]['EventSourceArn']} in function {getresp['EventSourceMappings'][0]['FunctionArn']} has been disabled. Once the issue is resolved, please check the dead queue to proces any failed messages & then enable the trigger manually"
  else:
   stat="Error in disabling the trigger {getresp['EventSourceMappings'][0]['EventSourceArn']} in function {getresp['EventSourceMappings'][0]['FunctionArn']}. Please disable manually now.  Once the issue is resolved, please check the dead queue to proces any failed messages & then enable the trigger manually"
  return stat
 except Exception as err:
  raise err

 
