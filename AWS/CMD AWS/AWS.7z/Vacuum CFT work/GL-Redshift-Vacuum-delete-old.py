import cmdfunctions
from pgdb import connect
import boto3
import os
import json
import sys
from awsglue.utils import getResolvedOptions

smclient = boto3.client("secretsmanager", region_name="us-east-1")

try:
    args = getResolvedOptions(sys.argv,['JOB_NAME','RD_DB_Env','COMMAND'])
    print(args)
    RedshiftEnv=args['RD_DB_Env']
    Command=args['COMMAND']
    # HostMc=json.loads(smclient.get_secret_value(SecretId="cmd-AWS-Envdet")['SecretString']).get('Env-Inst')
    # strTopicarn=json.loads(smclient.get_secret_value(SecretId="cmd-AWS-Envdet")['SecretString']).get('LO-DL')
    
    DBConn = cmdfunctions.Redshift_dbconnect(RedshiftEnv)
    cursor = DBConn.cursor()
    cursor.execute(f"Vacuum delete only {Command}")
    DBConn.commit()

    print(f"{Command} execution succeeded. ")
    cursor.close()
    DBConn.close()
    # boto3.client('sns').publish(TopicArn=strTopicarn, Subject=f"{args['JOB_NAME']} completed for {Command}", Message=f"Vacuum Job for ({Command}) has completed \n")

except Exception as err:
    err1=str(err).replace("\'","")
    # boto3.client('sns').publish(TopicArn=strTopicarn, Subject=f"{args['JOB_NAME']} for {Command} failed", Message=f"Vacuum Job for ({Command}) has failed with error - {err1} \n")
    raise err     
