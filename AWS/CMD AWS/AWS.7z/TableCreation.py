# -*- coding: utf-8 -*-
"""
Created on Wed Apr 28 13:47:55 2021

@author: AD76188
"""

import sys 

def PrimaryCheck(key):
    
    global PriArr
    
    flag = 0
    #print(key)
    
    for x in range(len(PriArr)):
        
        flag = 0
        
        if key.lower() == PriArr[x].lower():
            #print("found")
            return "NOT NULL"
            break
    
    if flag == 0:
        
        return ""

Inputfilepath = "C:\\Users\\AH02855\\OneDrive - Anthem\\Desktop\\AWS\\ProdInputstructure.txt"

Content = open(Inputfilepath, "r")

MainContent = str(Content.read())

Content.close()

TableName = str(MainContent.split('\n', 1)[0]).replace("Tablename:","").strip()
PrimaryCol = str(MainContent.split('\n', 2)[1]).replace("PrimaryCol:","").strip()
DistKey = str(MainContent.split('\n', 3)[2]).replace("DistKey:","").strip()
SortKey = str(MainContent.split('\n', 4)[3]).replace("SortKey:","").strip()
OnlyMainTableFlag = str(MainContent.split('\n', 5)[4]).replace("OnlyMainTable:","").strip()

PriArr = []

PrimaryColCNT = PrimaryCol.count(",")

for q in range(PrimaryColCNT + 1):
    
    PriArr.append(PrimaryCol.split(',',q+1)[q].strip())
    
#print(PriArr)
#print(TableName)
#print(PrimaryCol)
#print(DistKey)
#print(SortKey)
#print(OnlyMainTableFlag)
#sys.exit()

MainContent = MainContent.split('\n', 6)[6]

#print(MainContent)


MainContent = MainContent.replace("NOT NULL,", "")
MainContent = MainContent.replace("NULL,", "")
MainContent = MainContent.replace("NOT NULL", "")
MainContent = MainContent.replace("NULL", "")
MainContent = MainContent.replace("[", "")
MainContent = MainContent.replace("]", "")



#CNT = MainContent.rfind("\n")

#MainContent = MainContent[:CNT]

#print(MainContent)

Arr = []

for i in range(MainContent.count("\n")):
    
    #print(MainContent.split('\n',(i+1))[i])
    Arr.append(str(MainContent.split('\n',(i+1))[i]))

CNT = MainContent.rfind("\n")

Arr.append(str(MainContent[CNT + 1:]))
    
#print(Arr)


Details = {}
SpecDetails = {}

# for val in Arr:
    
#     #print("********************************************")
#     #print(val)
    
#     ColName = val.split(" ",1)[0]
#     Coltype = val.split(" ",1)[1]
    
#     ColName = ColName.strip()
#     #Coltype = Coltype.replace(",","")
#     Coltype = Coltype.strip()
    
#     #print(ColName,Coltype)
    
#     Details[ColName] = Coltype


for val in Arr:
    
    #print("********************************************")
    #print("val is --> ", val)
    if len(val.strip()) != 0:
        ColName = val.split(" ",1)[0]
        Coltype = val.split(" ",1)[1]
        # print(ColName,Coltype)
        
        ColName = ColName.strip()
        #Coltype = Coltype.replace(",","")
        Coltype = Coltype.strip()
        
        # print(ColName,Coltype)
        
        Details[ColName] = Coltype
        
        
#print(Details)


Outputfilepath = "C:\\Users\\AH02855\\OneDrive - Anthem\\Desktop\\AWS\\Outputstructure - "+str(TableName)+".txt"

Outf= open(Outputfilepath,"w+")

Outf.write("--************************** PROD TABLE *************************** \n\n")

Outf.write("-- DROP TABLE mdl_physical."+str(TableName)+";\n\n")
Outf.write("CREATE TABLE mdl_physical."+str(TableName)+" ( \n")

for key,val in Details.items():

    #print(key,val)
    
    if val.lower().find("nvarchar") >= 0:
        
        if val[val.find("(") + 1:val.find(")")] != 'max':
            
            size = int(val[val.find("(") + 1:val.find(")")])    
            size = size * 3
        else:
            size = val[val.find("(") + 1:val.find(")")]
            
        Outf.write(""+str(key)+" nvarchar("+str(size)+") "+str(PrimaryCheck(key))+" encode zstd, \n")
            
        SpecDetails[key] = "nvarchar("+str(size)+")"
        
    elif val.lower().find("varchar") >= 0:
        
        size = int(val[val.find("(") + 1:val.find(")")])

        size = size * 3
        
        Outf.write(""+str(key)+" varchar("+str(size)+") "+str(PrimaryCheck(key))+" encode zstd, \n")
        
        SpecDetails[key] = "varchar("+str(size)+")"
        
    
    elif val.lower().find("char") >= 0:
        
        size = int(val[val.find("(") + 1:val.find(")")])

        size = size * 3
        
        Outf.write(""+str(key)+" char("+str(size)+") "+str(PrimaryCheck(key))+" encode zstd, \n")      
        
        SpecDetails[key] = "char("+str(size)+")"

        
    elif val.lower().find("bigint") >= 0:
        
        Outf.write(""+str(key)+" bigint "+str(PrimaryCheck(key))+" encode lzo, \n")    
        
        SpecDetails[key] = "bigint"

    elif val.lower().find("tinyint") >= 0 or val.lower().find("bit") >= 0:
        
        Outf.write(""+str(key)+" smallint "+str(PrimaryCheck(key))+" encode lzo, \n")     
        
        SpecDetails[key] = "smallint"
        

    elif val.lower().find("int") >= 0 or val.lower().find("bit") >= 0:
        
        Outf.write(""+str(key)+" integer "+str(PrimaryCheck(key))+" encode lzo, \n")  
        
        SpecDetails[key] = "integer"

    elif val.lower().find("datetime") >= 0:
        
        Outf.write(""+str(key)+" timestamp "+str(PrimaryCheck(key))+" encode az64, \n")
        
        SpecDetails[key] = "timestamp without time zone"

    elif val.lower().find("date") >= 0:
        
        Outf.write(""+str(key)+" date "+str(PrimaryCheck(key))+" encode az64, \n")
        
        SpecDetails[key] = "date"
        

    elif val.lower().find("float") >= 0:
        
        Outf.write(""+str(key)+" real "+str(PrimaryCheck(key))+" encode zstd, \n")
        
        SpecDetails[key] = "real"
        
        
    elif val.lower().find("decimal") >= 0:
        
        if val.find("(") >= 0:
            
            size = val[val.find("(") + 1:val.find(")")]
            Outf.write(""+str(key)+" numeric("+str(size)+") "+str(PrimaryCheck(key))+" encode az64, \n")
            SpecDetails[key] = "numeric("+str(size)+")"
            
        else:
            
            Outf.write(""+str(key)+" numeric "+str(PrimaryCheck(key))+" encode az64, \n")
            SpecDetails[key] = "numeric"


    elif val.lower().find("money") >= 0:
        
        Outf.write(""+str(key)+" decimal(19,4) "+str(PrimaryCheck(key))+" encode lzo, \n")    
        
        SpecDetails[key] = "decimal(19,4)"


    elif val.lower().find("varbinary") >= 0:
        
        size = int(val[val.find("(") + 1:val.find(")")])

        size = size * 3
        
        Outf.write(""+str(key)+" varchar("+str(size)+") "+str(PrimaryCheck(key))+" encode zstd, \n")      
        
        SpecDetails[key] = "varchar("+str(size)+")"      
        
    else:
        
        Outf.write(""+str(key)+" "+str(val)+", ------------ Please check this column, no match found \n")     
        SpecDetails[key] = ""+str(val)+", ------------ Please check this column, no match found \n"


ModDateFlag = 0
        
for key,val in Details.items():
    
    if key.lower() == 'modifieddate':

        ModDateFlag = 1
        break
    

if ModDateFlag == 0:
    
    Outf.write("ModifiedDate timestamp default sysdate encode az64,\n")
        
Outf.write("primary key("+str(PrimaryCol)+")) \n")
if DistKey.lower() == "even":
    Outf.write("DISTSTYLE EVEN \n")
else:
    Outf.write("distkey("+str(DistKey)+") \n")
Outf.write("interleaved sortkey ("+str(SortKey)+"); \n")


if str(OnlyMainTableFlag).strip().lower() != 'n':
    
    Outf.write("\n;\n")    
    Outf.write("\n--***************************************************************** \n\n")
    
    Outf.close() 

    sys.exit()
    
Inputfilepath = "C:\\Users\\AH02855\\OneDrive - Anthem\\Desktop\\AWS\\SpectrumInputstructure.txt"

Content = open(Inputfilepath, "r")

SpecMainContent = str(Content.read())

Content.close()

#print(SpecMainContent)


CNT = SpecMainContent.find("\n")

FirstRow = SpecMainContent.split("\n",1)[0].strip()

#print(FirstRow)

TokenCol = SpecMainContent.split("\n",2)[1].replace("TokenCol:","").strip()

TokenColArr = []

for g in range(TokenCol.count(",") + 1):
    
    TokenColArr.append(TokenCol.split(",", g+ 1)[g].strip())
    
#print(TokenColArr)

#print(len(TokenColArr))

SpecMainContent = SpecMainContent.split("\n",2)[2].strip()

#print(SpecMainContent)


Outf.write("\n--************************** SPECTRUM TABLE *************************** \n\n")

Outf.write("-- DROP TABLE mdl_spectrum."+str(TableName)+";\n\n")
Outf.write("CREATE EXTERNAL TABLE mdl_spectrum."+str(TableName)+" ( \nROWNUM INTEGER\n")

SpecArr = []

if FirstRow.strip().lower() == 'token: y':
    
    for i in range(SpecMainContent.count("\n")):
        
        val = SpecMainContent.split('\n',(i+1))[i]
        #print(val)
        
        flag = 0
        
        for y in range(len(TokenColArr)):
            flag = 0
    
            if val.lower() == TokenColArr[y].lower():
                
                TokenColArr[y] = val
                flag = 1
                break
            
        if flag == 0:   
            
            SpecArr.append(str(val))
    
    
    CNT = SpecMainContent.rfind("\n")
    
    
    val = SpecMainContent[CNT + 1:]
    #print(val)
    
    flag = 0
    
    for y in range(len(TokenColArr)):
        flag = 0
        
        if val.lower() == TokenColArr[y].lower():
            
            TokenColArr[y] = val
            flag = 1
            break
        
    if flag == 0:   
        
        SpecArr.append(str(val))
    
    
    for r in range(len(TokenColArr)):
        
        SpecArr.append(TokenColArr[r])
    
    
    #print(SpecArr)
    
    #sys.exit()
    
    #print(SpecDetails)
    
    
    for item in SpecArr:
        
        Outf.write(","+str(item)+" "+str(SpecDetails[item])+"\n")
    

    Outf.write(")\nROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'\nWITH SERDEPROPERTIES (\n'separatorChar' = '^',\n'quoteChar' = '\\\"',\n'escapeChar' = '¤'\n)\nstored as textfile\nlocation 's3://antm-cmd-inbound/BCP/"+str(TableName)+"/'\ntable properties ('skip.header.line.count'='1');\n")

else:

    for i in range(SpecMainContent.count("\n")):
        
        #print(SpecMainContent.split('\n',(i+1))[i])
        SpecArr.append(str(SpecMainContent.split('\n',(i+1))[i]))
    
    CNT = SpecMainContent.rfind("\n")
    
    SpecArr.append(str(SpecMainContent[CNT + 1:]))
    
    #print(SpecArr)
    
    #print(SpecDetails)
    
    
    for item in SpecArr:
        
        Outf.write(","+str(item)+" "+str(SpecDetails[item])+"\n")
        
    Outf.write(")\nrow format delimited\nfields terminated by '^'\nstored as textfile\nlocation 's3://antm-cmd-inbound/BCP/"+str(TableName)+"/'\n")

Outf.write("\n;\n")    
Outf.write("\n--***************************************************************** \n\n")

Outf.close() 
