"""
  **************************************************************
    Below variables are used for Monthly/Daily/ Catchup Loads
  **************************************************************
"""
'''First, we define a volatile table to hold flattened records from the save filter detail table of name-value pairs.  The column names and field lengths shown
       correspond to various parameters passed to the ACIISST_APPL.UPDATE_USER_SGMNTN stored procedure.'''
create_vfltr_rllup = """
CREATE TABLE {db_name}.vfltr_rllup
( SAVE_FLTR_ID INTEGER NOT NULL
  , SAVE_FLTR_NM VARCHAR(100) NOT NULL
  , ACCT_ID VARCHAR(20) NOT NULL
  , SAVE_FLTR_TYPE_CD VARCHAR(20) NOT NULL
  , EFCTV_DTM TIMESTAMP NOT NULL
  , GRP_ID_LIST TEXT NOT NULL
  , SUB_GRP_ID_LIST TEXT NOT NULL
  , PROD_SRVC_TYPE_LIST TEXT NOT NULL
  , GRP_STTS_CD_LIST TEXT NOT NULL
  , EMPLR_DEPT_NBR_LIST TEXT NOT NULL
  , PLAN_ID_LIST TEXT NOT NULL
  , SUBGRP_RLUP_1_CD_LIST TEXT NOT NULL
  , SUBGRP_RLUP_2_CD_LIST TEXT NOT NULL
  , SUBGRP_RLUP_3_CD_LIST TEXT NOT NULL
  , SUBGRP_RLUP_4_CD_LIST TEXT NOT NULL
  , RPTG_EMPLR_GRP_RPTG_1_CD_LIST TEXT NOT NULL
  , RPTG_EMPLR_GRP_RPTG_2_CD_LIST TEXT NOT NULL
  , RPTG_EMPLR_GRP_RPTG_3_CD_LIST TEXT NOT NULL
)"""


'''PREPARE the latest set of filters and also added logic to re-process any unchanged filters that are mapped to changed primary filters; otherwise, the segmentation details 
       for unchanged filters will be incorrect'''
insert_vfltr_rllup = """
INSERT INTO {db_name}.vfltr_rllup
( SAVE_FLTR_ID, SAVE_FLTR_NM, ACCT_ID, SAVE_FLTR_TYPE_CD, EFCTV_DTM
  , GRP_ID_LIST, SUB_GRP_ID_LIST, PROD_SRVC_TYPE_LIST, GRP_STTS_CD_LIST
  , EMPLR_DEPT_NBR_LIST, PLAN_ID_LIST, SUBGRP_RLUP_1_CD_LIST, SUBGRP_RLUP_2_CD_LIST
  , SUBGRP_RLUP_3_CD_LIST, SUBGRP_RLUP_4_CD_LIST, RPTG_EMPLR_GRP_RPTG_1_CD_LIST
  , RPTG_EMPLR_GRP_RPTG_2_CD_LIST, RPTG_EMPLR_GRP_RPTG_3_CD_LIST
)
SELECT fltr.save_fltr_id,fltr.save_fltr_nm,fltr.acct_id,fltr.save_fltr_type_cd,fltr.UPDTD_DTM AS EFCTV_DTM
  , ('@'||REPLACE(CAST(STRING_AGG((CASE WHEN fldt.fltr_parm_nm='group' THEN TRIM(fldt.fltr_type_cd)||'@' ELSE '' END), '' ORDER BY TRIM(fldt.fltr_type_cd)) AS TEXT),'@ ','@')) AS GRP_ID_LIST
  , ('@'||REPLACE(CAST(STRING_AGG((CASE WHEN fldt.fltr_parm_nm='subgroup' THEN TRIM(fldt.fltr_type_cd)||'@' ELSE '' END), '' ORDER BY TRIM(fldt.fltr_type_cd)) AS TEXT),'@ ','@')) AS SUB_GRP_ID_LIST
  , ('@'||REPLACE(CAST(STRING_AGG((CASE WHEN fldt.fltr_parm_nm='product' THEN TRIM(fldt.fltr_type_cd)||'@' ELSE '' END), '' ORDER BY TRIM(fldt.fltr_type_cd)) AS TEXT),'@ ','@')) AS PROD_SRVC_TYPE_LIST
  , ('@'||REPLACE(CAST(STRING_AGG((CASE WHEN fldt.fltr_parm_nm='status' THEN TRIM(fldt.fltr_type_cd)||'@' ELSE '' END), '' ORDER BY TRIM(fldt.fltr_type_cd)) AS TEXT),'@ ','@')) AS GRP_STTS_CD_LIST
  , ('@'||REPLACE(CAST(STRING_AGG((CASE WHEN fldt.fltr_parm_nm='department' THEN TRIM(fldt.fltr_type_cd)||'@' ELSE '' END), '' ORDER BY TRIM(fldt.fltr_type_cd)) AS TEXT),'@ ','@')) AS EMPLR_DEPT_NBR_LIST
  , ('@'||REPLACE(CAST(STRING_AGG((CASE WHEN fldt.fltr_parm_nm='package' THEN TRIM(fldt.fltr_type_cd)||'@' ELSE '' END), '' ORDER BY TRIM(fldt.fltr_type_cd)) AS TEXT),'@ ','@')) AS PLAN_ID_LIST
  , ('@'||REPLACE(CAST(STRING_AGG((CASE WHEN fldt.fltr_parm_nm='subGroupRollup1' THEN TRIM(fldt.fltr_type_cd)||'@' ELSE '' END), '' ORDER BY TRIM(fldt.fltr_type_cd)) AS TEXT),'@ ','@')) AS SUBGRP_RLUP_1_CD_LIST
  , ('@'||REPLACE(CAST(STRING_AGG((CASE WHEN fldt.fltr_parm_nm='subGroupRollup2' THEN TRIM(fldt.fltr_type_cd)||'@' ELSE '' END), '' ORDER BY TRIM(fldt.fltr_type_cd)) AS TEXT),'@ ','@')) AS SUBGRP_RLUP_2_CD_LIST
  , ('@'||REPLACE(CAST(STRING_AGG((CASE WHEN fldt.fltr_parm_nm='subGroupRollup3' THEN TRIM(fldt.fltr_type_cd)||'@' ELSE '' END), '' ORDER BY TRIM(fldt.fltr_type_cd)) AS TEXT),'@ ','@')) AS SUBGRP_RLUP_3_CD_LIST
  , ('@'||REPLACE(CAST(STRING_AGG((CASE WHEN fldt.fltr_parm_nm='subGroupRollup4' THEN TRIM(fldt.fltr_type_cd)||'@' ELSE '' END), '' ORDER BY TRIM(fldt.fltr_type_cd)) AS TEXT),'@ ','@')) AS SUBGRP_RLUP_4_CD_LIST
  , ('@'||REPLACE(CAST(STRING_AGG((CASE WHEN fldt.fltr_parm_nm='employerGroupReporting1' THEN TRIM(fldt.fltr_type_cd)||'@' ELSE '' END), '' ORDER BY TRIM(fldt.fltr_type_cd)) AS TEXT),'@ ','@')) AS RPTG_EMPLR_GRP_RPTG_1_CD_LIST
  , ('@'||REPLACE(CAST(STRING_AGG((CASE WHEN fldt.fltr_parm_nm='employerGroupReporting2' THEN TRIM(fldt.fltr_type_cd)||'@' ELSE '' END), '' ORDER BY TRIM(fldt.fltr_type_cd)) AS TEXT),'@ ','@')) AS RPTG_EMPLR_GRP_RPTG_2_CD_LIST
  , ('@'||REPLACE(CAST(STRING_AGG((CASE WHEN fldt.fltr_parm_nm='employerGroupReporting3' THEN TRIM(fldt.fltr_type_cd)||'@' ELSE '' END), '' ORDER BY TRIM(fldt.fltr_type_cd)) AS TEXT),'@ ','@')) AS RPTG_EMPLR_GRP_RPTG_3_CD_LIST
FROM
  {db_name}.ACIISST_SAVE_FLTR FLTR
  INNER JOIN {db_name}.ACIISST_SAVE_FLTR_DTL FLDT
    ON FLTR.save_fltr_id = FLDT.save_fltr_id
    AND FLDT.actv_fltr_flag_cd IN ('Y','P')
WHERE
  FLTR.actv_fltr_flag_cd IN ('Y','P')
  AND FLDT.fltr_val_txt <> 'ALL-SELECTED'
  AND FLTR.save_fltr_id IN
    ( SELECT FL1.save_fltr_id
      FROM
        {db_name}.ACIISST_SAVE_FLTR FL1
        INNER JOIN {db_name}.SAVE_FLTR_CNTRL C1
          ON C1.LKUP_ID = 5
          AND FL1.UPDTD_DTM BETWEEN C1.SAVE_FLTR_LOW_DTM AND C1.SAVE_FLTR_HIGH_DTM
          AND (FL1.EFCTV_DTM, FL1.TRMNTN_DTM) OVERLAPS (C1.SAVE_FLTR_LOW_DTM, C1.SAVE_FLTR_HIGH_DTM)
      GROUP BY FL1.save_fltr_id
      UNION
      SELECT SFSB1.SAVE_FLTR_ID
      FROM
        {db_name}.ACIISST_SAVE_FLTR FL1
        INNER JOIN {db_name}.SAVE_FLTR_CNTRL C1
          ON C1.LKUP_ID = 5
          AND FL1.UPDTD_DTM BETWEEN C1.SAVE_FLTR_LOW_DTM AND C1.SAVE_FLTR_HIGH_DTM
          AND (FL1.EFCTV_DTM, FL1.TRMNTN_DTM) OVERLAPS (C1.SAVE_FLTR_LOW_DTM, C1.SAVE_FLTR_HIGH_DTM)
        INNER JOIN {db_name}.SAVE_FLTR_SGMNTN_BRDG SFSB1
          ON SFSB1.PRMRY_FLTR_ID = FL1.save_fltr_id
      GROUP BY SFSB1.SAVE_FLTR_ID
    )
GROUP BY fltr.save_fltr_id, fltr.save_fltr_nm, fltr.acct_id, fltr.save_fltr_type_cd, fltr.UPDTD_DTM"""


'''Delete records from vt where all the strings are @; this means none of the filters from account structure are selected'''
del_vfltr_rllup_no_acct_struct = """
DELETE FROM {db_name}.vfltr_rllup
WHERE
  GRP_ID_LIST = '@'
  AND SUB_GRP_ID_LIST = '@'
  AND PROD_SRVC_TYPE_LIST = '@'
  AND GRP_STTS_CD_LIST = '@'
  AND EMPLR_DEPT_NBR_LIST = '@'
  AND PLAN_ID_LIST = '@'
  AND SUBGRP_RLUP_1_CD_LIST = '@'
  AND SUBGRP_RLUP_2_CD_LIST = '@'
  AND SUBGRP_RLUP_3_CD_LIST = '@'
  AND SUBGRP_RLUP_4_CD_LIST = '@'
  AND RPTG_EMPLR_GRP_RPTG_1_CD_LIST = '@'
  AND RPTG_EMPLR_GRP_RPTG_2_CD_LIST = '@'
  AND RPTG_EMPLR_GRP_RPTG_3_CD_LIST = '@' """


'''Append to Bridge table any rows corresponding to new primaries, This for Daily and Catch Saved filters, which does not process saved filters coming from ACIISST_MSTR_SGMNTN'''
insert_save_fltr_sgmnt_brdg = """
INSERT INTO {db_name}.SAVE_FLTR_SGMNTN_BRDG
( SAVE_FLTR_ID, ACCT_ID, EFCTV_DTM, PRMRY_FLTR_ID )
SELECT vt.SAVE_FLTR_ID, vt.ACCT_ID, vt.EFCTV_DTM
  , FIRST_VALUE(vt.SAVE_FLTR_ID) OVER(PARTITION BY vt.ACCT_ID, vt.GRP_ID_LIST, vt.SUB_GRP_ID_LIST
      , vt.PROD_SRVC_TYPE_LIST, vt.GRP_STTS_CD_LIST, vt.EMPLR_DEPT_NBR_LIST, vt.PLAN_ID_LIST
      , vt.SUBGRP_RLUP_1_CD_LIST, vt.SUBGRP_RLUP_2_CD_LIST, vt.SUBGRP_RLUP_3_CD_LIST
      , vt.SUBGRP_RLUP_4_CD_LIST, vt.RPTG_EMPLR_GRP_RPTG_1_CD_LIST, vt.RPTG_EMPLR_GRP_RPTG_2_CD_LIST
      , vt.RPTG_EMPLR_GRP_RPTG_3_CD_LIST ORDER BY vt.SAVE_FLTR_ID) AS PRMRY_FLTR_ID
FROM
  {db_name}.vfltr_rllup vt
  LEFT OUTER JOIN {db_name}.SAVE_FLTR_SGMNTN_BRDG SFSB
    ON SFSB.SAVE_FLTR_ID = vt.SAVE_FLTR_ID
WHERE
  SFSB.SAVE_FLTR_ID IS NULL """


'''Append to Bridge table any rows corresponding to new primaries, This is only for Monthly Process, It process the saved filters coming from ACIISST_MSTR_SGMNTN as well'''
insert_save_fltr_sgmnt_brdg_mnthly = """
INSERT INTO {db_name}.SAVE_FLTR_SGMNTN_BRDG
( SAVE_FLTR_ID, ACCT_ID, EFCTV_DTM, PRMRY_FLTR_ID )
SELECT final.SAVE_FLTR_ID, final.ACCT_ID, final.EFCTV_DTM, final.PRMRY_FLTR_ID from
(SELECT vt.SAVE_FLTR_ID, vt.ACCT_ID, vt.EFCTV_DTM
  , FIRST_VALUE(vt.SAVE_FLTR_ID) OVER(PARTITION BY vt.ACCT_ID, vt.GRP_ID_LIST, vt.SUB_GRP_ID_LIST
      , vt.PROD_SRVC_TYPE_LIST, vt.GRP_STTS_CD_LIST, vt.EMPLR_DEPT_NBR_LIST, vt.PLAN_ID_LIST
      , vt.SUBGRP_RLUP_1_CD_LIST, vt.SUBGRP_RLUP_2_CD_LIST, vt.SUBGRP_RLUP_3_CD_LIST
      , vt.SUBGRP_RLUP_4_CD_LIST, vt.RPTG_EMPLR_GRP_RPTG_1_CD_LIST, vt.RPTG_EMPLR_GRP_RPTG_2_CD_LIST
      , vt.RPTG_EMPLR_GRP_RPTG_3_CD_LIST ORDER BY vt.SAVE_FLTR_ID) AS PRMRY_FLTR_ID
FROM
  {db_name}.vfltr_rllup vt
  LEFT OUTER JOIN {db_name}.SAVE_FLTR_SGMNTN_BRDG SFSB
    ON SFSB.SAVE_FLTR_ID = vt.SAVE_FLTR_ID
WHERE
  SFSB.SAVE_FLTR_ID IS NULL
  UNION ALL
  select distinct acct_filtr_key as save_fltr_id
          ,acct_id 
          ,current_timestamp as efctv_dtm
          ,acct_filtr_key as prmry_fltr_id
      from {actv_db_name}.aciisst_mstr_sgmntn
      where upper(trim(smry_load_ind)) = 'Y'
      and acct_filtr_key <> -1 ) final"""

  
'''Update EFCTV_DTM value for primary rows to the max EFCTV_DTM of children'''
updt_save_fltr_sgmnt_brdg = """
UPDATE {db_name}.SAVE_FLTR_SGMNTN_BRDG
SET
  EFCTV_DTM = SRC.MAX_EFCTV_DTM
FROM
  {db_name}.SAVE_FLTR_SGMNTN_BRDG TGT,
  ( SELECT PRMRY_FLTR_ID, MAX(EFCTV_DTM) AS MAX_EFCTV_DTM
    FROM {db_name}.SAVE_FLTR_SGMNTN_BRDG
    GROUP BY PRMRY_FLTR_ID
  ) SRC
WHERE
  TGT.SAVE_FLTR_ID = SRC.PRMRY_FLTR_ID
  AND TGT.EFCTV_DTM < SRC.MAX_EFCTV_DTM """

  
'''Delete any existing entries in the table before inserting; this is to make sure that the segmentation keys get updated for any updates to
       existing saved filter definitions'''
del_saved_fltr_sgmnt_delta = """
DELETE FROM {db_name}.SAVE_FLTR_SGMNTN
WHERE SAVE_FLTR_ID IN (SELECT SAVE_FLTR_ID FROM {db_name}.vfltr_rllup) """


'''Process Account Segmentation Mapping, This for Daily and Catch Saved filters, which does not process saved filters coming from ACIISST_MSTR_SGMNTN'''
insert_save_fltr_sgmntn = """
INSERT INTO {db_name}.SAVE_FLTR_SGMNTN
(SAVE_FLTR_ID, SGMNTN_DIM_KEY, ACCT_ID)
SELECT DISTINCT fltr.save_fltr_id, sgmnt.ACIISST_SGMNTN_DIM_KEY, acct.ACCT_ID
FROM
  {actv_db_name}.ACIISST_DDIM_SGMNTN sgmnt
INNER JOIN {actv_db_name}.ACIISST_ACCT_PRFL acct
    ON TRIM(acct.acct_id) = TRIM(sgmnt.acct_id)
INNER JOIN {actv_db_name}.ACIISST_GRP_PRFL grp
    ON TRIM(sgmnt.SGMNTN_GRP_ID) = TRIM(grp.GRP_ID)
    AND TRIM(sgmnt.SGMNTN_SOR_CD) = TRIM(grp.GRP_SOR_CD)
LEFT JOIN {actv_db_name}.ACIISST_SUBGRP_RLUP sgrlp
    ON TRIM(sgrlp.SGMNTN_GRP_ID) = TRIM(sgmnt.SGMNTN_GRP_ID)
    AND TRIM(sgrlp.SGMNTN_SUBGRP_ID) = TRIM(sgmnt.SGMNTN_SUBGRP_ID)
    AND TRIM(sgrlp.SGMNTN_SOR_CD) = TRIM(sgmnt.SGMNTN_SOR_CD)
INNER JOIN (
    SELECT * FROM {db_name}.vfltr_rllup WHERE SAVE_FLTR_ID IN (
      SELECT DISTINCT PRMRY_FLTR_ID FROM {db_name}.SAVE_FLTR_SGMNTN_BRDG )
    ) fltr
    ON fltr.acct_id = sgmnt.acct_id
    AND (fltr.GRP_ID_LIST='@' OR POSITION('@'||TRIM(sgmnt.SGMNTN_GRP_ID)||'@' IN fltr.GRP_ID_LIST) >0)
    AND (fltr.SUB_GRP_ID_LIST='@' OR POSITION('@'||TRIM(sgmnt.SGMNTN_SUBGRP_ID)||'@' IN fltr.SUB_GRP_ID_LIST) >0)
    AND (fltr.PROD_SRVC_TYPE_LIST='@' OR POSITION('@'||TRIM(sgmnt.HLTH_PROD_SRVC_TYPE_CD)||'@' IN fltr.PROD_SRVC_TYPE_LIST) >0)
    AND (fltr.GRP_STTS_CD_LIST='@' OR POSITION('@'||TRIM(sgmnt.GRP_STTS_CD)||'@' IN fltr.GRP_STTS_CD_LIST) >0
        OR POSITION('@'||TRIM(sgrlp.SUBGRP_RLUP_STTS_CD)||'@' IN fltr.GRP_STTS_CD_LIST) >0)
    AND (fltr.EMPLR_DEPT_NBR_LIST='@' OR POSITION('@'||TRIM(sgmnt.EMPLR_DEPT_NBR)||'@' IN fltr.EMPLR_DEPT_NBR_LIST) >0)
    AND (fltr.PLAN_ID_LIST='@' OR POSITION('@'||TRIM(sgmnt.PLAN_ID)||'@' IN fltr.PLAN_ID_LIST) >0)
    AND (fltr.SUBGRP_RLUP_1_CD_LIST='@' OR POSITION('@'||TRIM(sgrlp.SUBGRP_RLUP_1_CD)||'@' IN fltr.SUBGRP_RLUP_1_CD_LIST) >0)
    AND (fltr.SUBGRP_RLUP_2_CD_LIST='@' OR POSITION('@'||TRIM(sgrlp.SUBGRP_RLUP_2_CD)||'@' IN fltr.SUBGRP_RLUP_2_CD_LIST) >0)
    AND (fltr.SUBGRP_RLUP_3_CD_LIST='@' OR POSITION('@'||TRIM(sgrlp.SUBGRP_RLUP_3_CD)||'@' IN fltr.SUBGRP_RLUP_3_CD_LIST) >0)
    AND (fltr.SUBGRP_RLUP_4_CD_LIST='@' OR POSITION('@'||TRIM(sgrlp.SUBGRP_RLUP_4_CD)||'@' IN fltr.SUBGRP_RLUP_4_CD_LIST) >0)
    AND (fltr.RPTG_EMPLR_GRP_RPTG_1_CD_LIST='@' OR POSITION('@'||TRIM(sgrlp.RPTG_EMPLR_GRP_RPTG_1_CD)||'@' IN fltr.RPTG_EMPLR_GRP_RPTG_1_CD_LIST) >0)
    AND (fltr.RPTG_EMPLR_GRP_RPTG_2_CD_LIST='@' OR POSITION('@'||TRIM(sgrlp.RPTG_EMPLR_GRP_RPTG_2_CD)||'@' IN fltr.RPTG_EMPLR_GRP_RPTG_2_CD_LIST) >0)
    AND (fltr.RPTG_EMPLR_GRP_RPTG_3_CD_LIST='@' OR POSITION('@'||TRIM(sgrlp.RPTG_EMPLR_GRP_RPTG_3_CD)||'@' IN fltr.RPTG_EMPLR_GRP_RPTG_3_CD_LIST) >0) """


'''Process Account Segmentation Mapping, This is only for Monthly Process, It process the saved filters coming from ACIISST_MSTR_SGMNTN as well'''
insert_save_fltr_sgmntn_mnthly = """
INSERT INTO {db_name}.SAVE_FLTR_SGMNTN
(SAVE_FLTR_ID, SGMNTN_DIM_KEY, ACCT_ID)
SELECT DISTINCT final.save_fltr_id, final.SGMNTN_DIM_KEY, final.ACCT_ID from
(select segs_to_load.save_fltr_id
           ,asb.sgmntn_dim_key,segs_to_load.acct_id
    from (select acct_id, acct_filtr_key as save_fltr_id
             ,mstr_sgmntn_id
          from {actv_db_name}.aciisst_mstr_sgmntn
          where upper(trim(smry_load_ind)) = 'Y'
          and acct_filtr_key <> -1 and acct_filtr_key < {low_range} AND acct_filtr_key >= {high_range} ) segs_to_load
        inner join {actv_db_name}.aciisst_sgmntn_brdg_scd asb 
        on segs_to_load.acct_id = asb.acct_id
        and segs_to_load.mstr_sgmntn_id = asb.src_fltr_id
        and upper(trim(asb.fltr_src_nm)) = 'ERSU' ) final"""
    

'''Do one final cleanup of orphan segmentation records'''
sgmnt_brdg_cleanup = """
DELETE FROM {db_name}.SAVE_FLTR_SGMNTN WHERE SAVE_FLTR_ID NOT IN
  (SELECT PRMRY_FLTR_ID FROM {db_name}.SAVE_FLTR_SGMNTN_BRDG) """


"""
  ******************************************************
    Below variables are used only for Daily/ Catchup Loads
  ******************************************************
"""

'''If daily or catchup then prepare a primary filter set.'''
create_vfltr_rllup_primary = """
CREATE TABLE {db_name}.vfltr_rllup_primary
( SAVE_FLTR_ID INTEGER NOT NULL
  , SAVE_FLTR_NM VARCHAR(100) NOT NULL
  , ACCT_ID VARCHAR(20) NOT NULL
  , SAVE_FLTR_TYPE_CD VARCHAR(20) NOT NULL
  , EFCTV_DTM TIMESTAMP NOT NULL
  , GRP_ID_LIST TEXT NOT NULL
  , SUB_GRP_ID_LIST TEXT NOT NULL
  , PROD_SRVC_TYPE_LIST TEXT NOT NULL
  , GRP_STTS_CD_LIST TEXT NOT NULL
  , EMPLR_DEPT_NBR_LIST TEXT NOT NULL
  , PLAN_ID_LIST TEXT NOT NULL
  , SUBGRP_RLUP_1_CD_LIST TEXT NOT NULL
  , SUBGRP_RLUP_2_CD_LIST TEXT NOT NULL
  , SUBGRP_RLUP_3_CD_LIST TEXT NOT NULL
  , SUBGRP_RLUP_4_CD_LIST TEXT NOT NULL
  , RPTG_EMPLR_GRP_RPTG_1_CD_LIST TEXT NOT NULL
  , RPTG_EMPLR_GRP_RPTG_2_CD_LIST TEXT NOT NULL
  , RPTG_EMPLR_GRP_RPTG_3_CD_LIST TEXT NOT NULL
)"""


'''Insert Primary Set filters'''
insert_vfltr_rllup_primary = """
INSERT INTO {db_name}.vfltr_rllup_primary
( SAVE_FLTR_ID, SAVE_FLTR_NM, ACCT_ID, SAVE_FLTR_TYPE_CD, EFCTV_DTM
  , GRP_ID_LIST, SUB_GRP_ID_LIST, PROD_SRVC_TYPE_LIST, GRP_STTS_CD_LIST
  , EMPLR_DEPT_NBR_LIST, PLAN_ID_LIST, SUBGRP_RLUP_1_CD_LIST, SUBGRP_RLUP_2_CD_LIST
  , SUBGRP_RLUP_3_CD_LIST, SUBGRP_RLUP_4_CD_LIST, RPTG_EMPLR_GRP_RPTG_1_CD_LIST
  , RPTG_EMPLR_GRP_RPTG_2_CD_LIST, RPTG_EMPLR_GRP_RPTG_3_CD_LIST
)
SELECT fltr.save_fltr_id,fltr.save_fltr_nm,fltr.acct_id,fltr.save_fltr_type_cd,fltr.UPDTD_DTM AS EFCTV_DTM
  , ('@'||REPLACE(CAST(STRING_AGG((CASE WHEN fldt.fltr_parm_nm='group' THEN TRIM(fldt.fltr_type_cd)||'@' ELSE '' END), '' ORDER BY TRIM(fldt.fltr_type_cd)) AS TEXT),'@ ','@')) AS GRP_ID_LIST
  , ('@'||REPLACE(CAST(STRING_AGG((CASE WHEN fldt.fltr_parm_nm='subgroup' THEN TRIM(fldt.fltr_type_cd)||'@' ELSE '' END), '' ORDER BY TRIM(fldt.fltr_type_cd)) AS TEXT),'@ ','@')) AS SUB_GRP_ID_LIST
  , ('@'||REPLACE(CAST(STRING_AGG((CASE WHEN fldt.fltr_parm_nm='product' THEN TRIM(fldt.fltr_type_cd)||'@' ELSE '' END), '' ORDER BY TRIM(fldt.fltr_type_cd)) AS TEXT),'@ ','@')) AS PROD_SRVC_TYPE_LIST
  , ('@'||REPLACE(CAST(STRING_AGG((CASE WHEN fldt.fltr_parm_nm='status' THEN TRIM(fldt.fltr_type_cd)||'@' ELSE '' END), '' ORDER BY TRIM(fldt.fltr_type_cd)) AS TEXT),'@ ','@')) AS GRP_STTS_CD_LIST
  , ('@'||REPLACE(CAST(STRING_AGG((CASE WHEN fldt.fltr_parm_nm='department' THEN TRIM(fldt.fltr_type_cd)||'@' ELSE '' END), '' ORDER BY TRIM(fldt.fltr_type_cd)) AS TEXT),'@ ','@')) AS EMPLR_DEPT_NBR_LIST
  , ('@'||REPLACE(CAST(STRING_AGG((CASE WHEN fldt.fltr_parm_nm='package' THEN TRIM(fldt.fltr_type_cd)||'@' ELSE '' END), '' ORDER BY TRIM(fldt.fltr_type_cd)) AS TEXT),'@ ','@')) AS PLAN_ID_LIST
  , ('@'||REPLACE(CAST(STRING_AGG((CASE WHEN fldt.fltr_parm_nm='subGroupRollup1' THEN TRIM(fldt.fltr_type_cd)||'@' ELSE '' END), '' ORDER BY TRIM(fldt.fltr_type_cd)) AS TEXT),'@ ','@')) AS SUBGRP_RLUP_1_CD_LIST
  , ('@'||REPLACE(CAST(STRING_AGG((CASE WHEN fldt.fltr_parm_nm='subGroupRollup2' THEN TRIM(fldt.fltr_type_cd)||'@' ELSE '' END), '' ORDER BY TRIM(fldt.fltr_type_cd)) AS TEXT),'@ ','@')) AS SUBGRP_RLUP_2_CD_LIST
  , ('@'||REPLACE(CAST(STRING_AGG((CASE WHEN fldt.fltr_parm_nm='subGroupRollup3' THEN TRIM(fldt.fltr_type_cd)||'@' ELSE '' END), '' ORDER BY TRIM(fldt.fltr_type_cd)) AS TEXT),'@ ','@')) AS SUBGRP_RLUP_3_CD_LIST
  , ('@'||REPLACE(CAST(STRING_AGG((CASE WHEN fldt.fltr_parm_nm='subGroupRollup4' THEN TRIM(fldt.fltr_type_cd)||'@' ELSE '' END), '' ORDER BY TRIM(fldt.fltr_type_cd)) AS TEXT),'@ ','@')) AS SUBGRP_RLUP_4_CD_LIST
  , ('@'||REPLACE(CAST(STRING_AGG((CASE WHEN fldt.fltr_parm_nm='employerGroupReporting1' THEN TRIM(fldt.fltr_type_cd)||'@' ELSE '' END), '' ORDER BY TRIM(fldt.fltr_type_cd)) AS TEXT),'@ ','@')) AS RPTG_EMPLR_GRP_RPTG_1_CD_LIST
  , ('@'||REPLACE(CAST(STRING_AGG((CASE WHEN fldt.fltr_parm_nm='employerGroupReporting2' THEN TRIM(fldt.fltr_type_cd)||'@' ELSE '' END), '' ORDER BY TRIM(fldt.fltr_type_cd)) AS TEXT),'@ ','@')) AS RPTG_EMPLR_GRP_RPTG_2_CD_LIST
  , ('@'||REPLACE(CAST(STRING_AGG((CASE WHEN fldt.fltr_parm_nm='employerGroupReporting3' THEN TRIM(fldt.fltr_type_cd)||'@' ELSE '' END), '' ORDER BY TRIM(fldt.fltr_type_cd)) AS TEXT),'@ ','@')) AS RPTG_EMPLR_GRP_RPTG_3_CD_LIST
FROM
  {db_name}.ACIISST_SAVE_FLTR FLTR
  JOIN {db_name}.ACIISST_SAVE_FLTR_DTL FLDT
    ON FLTR.save_fltr_id = FLDT.save_fltr_id
WHERE
  FLDT.actv_fltr_flag_cd IN ('Y','P')
  AND FLTR.actv_fltr_flag_cd IN ('Y','P')
  AND FLTR.SAVE_FLTR_ID IN (SELECT PRMRY_FLTR_ID FROM {db_name}.SAVE_FLTR_SGMNTN_BRDG)
  AND FLDT.fltr_val_txt <> 'ALL-SELECTED'
GROUP BY fltr.save_fltr_id,fltr.save_fltr_nm,fltr.acct_id,fltr.save_fltr_type_cd,fltr.UPDTD_DTM """


''' delete any existing data in segmentation bridge table '''
del_existng_sgmnt_brdg = """
DELETE FROM {db_name}.SAVE_FLTR_SGMNTN_BRDG
WHERE SAVE_FLTR_ID IN (SELECT SAVE_FLTR_ID FROM {db_name}.vfltr_rllup) """


''' Insert into Segmentation Bridge, only map filters where the filter ids do not match '''
insrt_sgmnt_brdg = """
INSERT INTO {db_name}.SAVE_FLTR_SGMNTN_BRDG
( SAVE_FLTR_ID, ACCT_ID, PRMRY_FLTR_ID, EFCTV_DTM )
SELECT SAVE_FLTR_ID, ACCT_ID, PRMRY_FLTR_ID, EFCTV_DTM
FROM
(
  SELECT A.SAVE_FLTR_ID, A.ACCT_ID, B.SAVE_FLTR_ID AS PRMRY_FLTR_ID, B.EFCTV_DTM
  FROM
    {db_name}.vfltr_rllup A
    INNER JOIN {db_name}.vfltr_rllup_primary B
      ON A.ACCT_ID = B.ACCT_ID
      AND A.GRP_ID_LIST = B.GRP_ID_LIST
      AND A.SUB_GRP_ID_LIST = B.SUB_GRP_ID_LIST
      AND A.PROD_SRVC_TYPE_LIST = B.PROD_SRVC_TYPE_LIST
      AND A.GRP_STTS_CD_LIST = B.GRP_STTS_CD_LIST
      AND A.EMPLR_DEPT_NBR_LIST = B.EMPLR_DEPT_NBR_LIST
      AND A.PLAN_ID_LIST = B.PLAN_ID_LIST
      AND A.SUBGRP_RLUP_1_CD_LIST = B.SUBGRP_RLUP_1_CD_LIST
      AND A.SUBGRP_RLUP_2_CD_LIST = B.SUBGRP_RLUP_2_CD_LIST
      AND A.SUBGRP_RLUP_3_CD_LIST = B.SUBGRP_RLUP_3_CD_LIST
      AND A.SUBGRP_RLUP_4_CD_LIST = B.SUBGRP_RLUP_4_CD_LIST
      AND A.RPTG_EMPLR_GRP_RPTG_1_CD_LIST = B.RPTG_EMPLR_GRP_RPTG_1_CD_LIST
      AND A.RPTG_EMPLR_GRP_RPTG_2_CD_LIST = B.RPTG_EMPLR_GRP_RPTG_2_CD_LIST
      AND A.RPTG_EMPLR_GRP_RPTG_3_CD_LIST = B.RPTG_EMPLR_GRP_RPTG_3_CD_LIST
  WHERE
    A.SAVE_FLTR_ID <> B.SAVE_FLTR_ID
) Compare1 """


'''Only delete the entries where incoming saved filter is not a primary filter'''
del_non_prim_filters = """
DELETE FROM {db_name}.vfltr_rllup
WHERE SAVE_FLTR_ID IN (SELECT SAVE_FLTR_ID FROM {db_name}.SAVE_FLTR_SGMNTN_BRDG WHERE SAVE_FLTR_ID <> PRMRY_FLTR_ID) """
