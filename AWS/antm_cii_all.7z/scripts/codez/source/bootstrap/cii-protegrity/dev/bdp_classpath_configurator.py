import shutil

# location on AWS EC2 instance where individual template xml files are stored
mapred_config = '/var/aws/emr/bigtop-deploy/puppet/modules/hadoop/templates/mapred-site.xml'
tez_config = '/var/aws/emr/bigtop-deploy/puppet/modules/tez/templates/tez-site.xml'
hive_config = '/var/aws/emr/bigtop-deploy/puppet/modules/hadoop_hive/templates/hive-site.xml'
coresite_config = '/var/aws/emr/bigtop-deploy/puppet/modules/hadoop/templates/core-site.xml'
yarn_config = '/var/aws/emr/bigtop-deploy/puppet/modules/hadoop/templates/yarn-site.xml'
hbase_config = '/var/aws/emr/bigtop-deploy/puppet/modules/hadoop_hbase/templates/hbase-site.xml'
pig_config = '/var/aws/emr/bigtop-deploy/puppet/modules/hadoop_pig/templates/pig-env.sh'
hive_env = '/var/aws/emr/bigtop-deploy/puppet/modules/hadoop_hive/templates/hive-env.sh'
hbase_env = '/var/aws/emr/bigtop-deploy/puppet/modules/hadoop_hbase/templates/hbase-env.sh'
spark_config = '/var/aws/emr/bigtop-deploy/puppet/modules/spark/templates/spark-defaults.conf'


class ClassPathSetter(object):
    """Utility to update Template Configuration files (xml) on AWS.

    This utility takes the xml file to be updated as input along with
    mapping of classpath properties and values to be updated in the xml file
    """

    def __init__(self, config_file):
        self.config_file = config_file
        self.updated_file = config_file + '_new'

    def update_classpath(self, classpath_entries):
        """Finds the properties in the xml file and appends the corresponding values to the existing values.
        If the property does not exist, we create the property tag by ourselves and append it at the end
         of the xml file just before the Configuration tag.
        """
        old_file = open(self.config_file, 'r')
        new_file = open(self.updated_file, 'w')
        # read the xml file in memory
        lines = old_file.readlines()
        # find for all input properties in the xml
        for pattern in classpath_entries.keys():
            pattern_found = False
            for index, val in enumerate(lines):
                # if property is found, append to the existing values
                if "<name>" + pattern + "</name>" in val:
                    pattern_found = True
                    counter = index
                    # we append to the end of value tag i.e </value>, so if the value tag spans multiple lines,
                    # scan further lines until end value tag is found.
                    while "</value>" not in val:
                        counter = counter + 1
                        val = lines[counter]
                    lines[counter] = lines[counter].replace("</value>", classpath_entries[pattern] + "</value>")
                    break
            # if the property is not found, add one
            if not pattern_found:
                value_tag = "  <value>"
                # for env properties, LD_LIBRARY_PATH needs to prefixed to the value
                if ".env" in pattern:
                    value_tag = "  <value>LD_LIBRARY_PATH="
                additional_property = "  \n<property>\n" \
                                      + "  <name>" + pattern + "</name>\n" \
                                      + value_tag + classpath_entries[pattern][1:] + "</value>\n" \
                                      + "  </property>\n\n"
                # scan for end configuration from the end of xml file and add the new property
                for i in range(len(lines) - 1, 0, -1):
                    if "</configuration>" in lines[i]:
                        lines[i] = lines[i].replace("</configuration>", additional_property + "</configuration>")

        new_file.writelines(lines)
        new_file.close()
        old_file.close()
        shutil.move(self.updated_file, self.config_file)


def set_mapreduce_classpath(install_dir):
    """update classpath entries for mapred"""
    mr_classpath_setter = ClassPathSetter(mapred_config)
    mappings = {
        "mapreduce.admin.user.env": ":{0}/jpeplite/lib".format(install_dir),
        "mapreduce.application.classpath": ",{0}/pepmapreduce/lib/*,{0}/pephive/lib/*".format(install_dir)
        # commenting out HDFSFP classpath entries
        # "mapreduce.output.fileoutputformat.compress":"true",
        # "mapreduce.output.fileoutputformat.compress.type": "BLOCK",
        # "mapreduce.output.fileoutputformat.compress.codec": ",com.protegrity.hadoop.fileprotector.crypto.codec.PtyCryptoCodec"
    }
    mr_classpath_setter.update_classpath(mappings)


def set_tez_classpath(install_dir):
    """update classpath entries for Tez"""
    tez_classpath_setter = ClassPathSetter(tez_config)
    mappings = {
        "tez.am.launch.env": ":{0}/jpeplite/lib".format(install_dir),
        "tez.cluster.additional.classpath.prefix": ":{0}/pephive/lib/*".format(install_dir)
    }
    tez_classpath_setter.update_classpath(mappings)


def set_hive_classpath():
    """update classpath entries for Hive"""
    hive_classpath_setter = ClassPathSetter(hive_config)
    mappings = {
        "hive.exec.pre.hooks": ",com.protegrity.hive.PtyHiveUserPreHook"
    }
    hive_classpath_setter.update_classpath(mappings)


def set_coresite_classpath():
    """update core site xml"""
    core_classpath_setter = ClassPathSetter(coresite_config)
    mappings = {
        "io.compression.codecs": ",com.protegrity.hadoop.fileprotector.crypto.codec.PtyCryptoCodec"
    }
    core_classpath_setter.update_classpath(mappings)


def set_yarn_classpath(install_dir):
    """update yarn site xml"""
    yarn_classpath_setter = ClassPathSetter(yarn_config)
    mappings = {
        "yarn.application.classpath": ",{0}/hdfsfp/*".format(install_dir)
    }
    yarn_classpath_setter.update_classpath(mappings)


def set_hbase_classpath():
    """update hbase site xml"""
    hbase_classpath_setter = ClassPathSetter(hbase_config)
    mappings = {
        "hbase.coprocessor.region.classes": ",com.protegrity.hbase.PTYRegionObserver"
    }
    hbase_classpath_setter.update_classpath(mappings)

def set_classpath_in_env_files(env_file_loc, classpath):
    """Append classpath to the end of the env files"""
    new_env_file_loc = env_file_loc + '_new'
    env_file = open(env_file_loc, 'r')
    new_env_file = open(new_env_file_loc, 'w')
    while True:
        line = env_file.readline()
        if line == '':
            break
        new_env_file.writelines(line)
    new_env_file.writelines(classpath)
    env_file.close()
    new_env_file.close()
    shutil.move(new_env_file_loc, env_file_loc)

def set_hbase_env(install_dir):
    """update hbase-env.sh with classpath entries"""
    classpath = "\nexport HBASE_CLASSPATH=\"${{HBASE_CLASSPATH}}:{0}/pephbase/lib/*\"\n" \
                "export JAVA_LIBRARY_PATH=\"${{JAVA_LIBRARY_PATH}}:{0}/jpeplite/lib/\"".format(install_dir)
    set_classpath_in_env_files(hbase_env, classpath)

def set_hive_env(install_dir):
    """update the hive-env.sh with classpath entries"""
    classpath = "\nexport HIVE_CLASSPATH=\"${{HIVE_CLASSPATH}}:{0}/pephive/lib/*\"\n" \
                "export JAVA_LIBRARY_PATH=\"${{JAVA_LIBRARY_PATH}}:{0}/jpeplite/lib/\"".format(install_dir)
    set_classpath_in_env_files(hive_env, classpath)

def set_pig_env_classpath(install_dir):
    """update the pig env with java.library.path entry"""
    # {JAVA_LIBRARY_PATH} is escaped by {{JAVA_LIBRARY_PATH}}
    # else it gives KeyError
    classpath = "export PIG_CLASSPATH=\"${{PIG_CLASSPATH}}:{0}/peppig/lib/*\"\n" \
                "export JAVA_LIBRARY_PATH=\"${{JAVA_LIBRARY_PATH}}:{0}/jpeplite/lib\"\n".format(install_dir)
    set_classpath_in_env_files(pig_config, classpath)

def set_spark_defaults_classpath(install_dir):
    """Updates spark-defaults.conf with classpath entries"""
    new_spark_config = spark_config + '_new'
    config_file = open(spark_config, 'r')
    new_config_file = open(new_spark_config, 'w')
    extra_classpath = "$extraLib += ['{0}/pephive/lib/*', '{0}/pepspark/lib/*']\n".format(install_dir)
    extra_libpath = "$nativeLib += ['{0}/jpeplite/lib']\n".format(install_dir)
    classpath_found = False
    libpath_found = False
    while True:
        line = config_file.readline()
        if line == '':
            break
        if "extraLib += " in line and not classpath_found:
            line = line + extra_classpath
            classpath_found = True
        if "nativeLib += " in line and not libpath_found:
            line = line + extra_libpath
            libpath_found = True
        new_config_file.writelines(line)
    config_file.close()
    new_config_file.close()
    shutil.move(new_spark_config, spark_config)

def validate_hbase_site():

    new_config_file = hbase_config + '_new'
    config_file = open(hbase_config, 'r')
    new_site_file = open(new_config_file, 'w')
    propFound = False
    while True:
        line = config_file.readline()
        if line != '' and '@kerberos_realm' in line:
            propFound = True
        if line == '':
            break
        new_site_file.writelines(line)
    config_file.close()
    new_site_file.close()
    shutil.move(new_config_file, hbase_config)
    if propFound == False:
        hbase_classpath_setter = ClassPathSetter(hbase_config)
        mappings = {
        "hbase.coprocessor.region.classes": ",com.protegrity.hbase.PTYRegionObserver"
        }
        hbase_classpath_setter.update_classpath(mappings)
    else:
        reopen_config = hbase_config + 'new'
        read_file = open(hbase_config, 'r')
        write_file = open(reopen_config,'w')
        additional_property = "  \n<property>\n" \
                                      + "  <name>hbase.coprocessor.region.classes</name>\n" \
                                      + "<value>com.protegrity.hbase.PTYRegionObserver</value>\n" \
                                      + "  </property>\n\n"
        while True:
            line = read_file.readline()
            if line == '':
                break
            if "</configuration>" in line:
                line = line.replace("</configuration>", additional_property + "</configuration>")
            write_file.writelines(line)
        read_file.close()
        write_file.close()
        shutil.move(reopen_config, hbase_config)

if __name__ == "__main__":
    install_dir = "/opt/protegrity"
    import sys
    if len(sys.argv) > 1:
        install_dir = sys.argv[1]
    set_mapreduce_classpath(install_dir)
    set_tez_classpath(install_dir)
    set_hive_classpath()
    # commenting out the below two setters, since they are required only for HDFSFP
    # set_coresite_classpath()
    # set_yarn_classpath(install_dir)
    validate_hbase_site()
    set_pig_env_classpath(install_dir)
    set_hbase_env(install_dir)
    set_hive_env(install_dir)
    set_spark_defaults_classpath(install_dir)

