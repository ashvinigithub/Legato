#!/bin/bash

install_pgp(){
	sudo python3 -m pip install gnupg
	sudo python3 -m pip install boto3
	sudo systemctl enable amazon-ssm-agent
	sudo systemctl start amazon-ssm-agent
	if [ $? -ne 0 ]; then
		echo "Unable to install python libraries"
		exit 1
	fi
}

install_pgp
#----------------------------------------------------------------------------------------------------#
#!/bin/bash

BUCKET_PATH="s3://antm-cii-sit-codez-nogbd-nophi-useast1/bootstrap/cii-protegrity/sit"
INSTALL_DIR=$1

lc=$(echo -n "$BUCKET_PATH" | tail -c 1)
if [ "$lc" == "/" ]; then
    BUCKET_PATH=${BUCKET_PATH%?}
fi
PROTECTOR_FILE="$BUCKET_PATH/BigDataProtector_AMZL-2-64_x86-64_EMR-5.30.0-64_7.1.0.122.tgz"
CONFIG_UPDATER="$BUCKET_PATH/bdp_classpath_configurator.py"
BDP_INSTALL_FILE="BdpInstall*.sh"

validate_arguments() {
	
	if [ $# -ne 3 ]; then
		echo "No arguments specified..Please specify the bucket path, installation directory, demo option"
		exit 1
	fi
}

clean_up()
{
	printf "\nError encountered while executing bootstrap, exiting....\n"

	if [ -d /tmp/protegrity ]; then
		rm -rf /tmp/protegrity
	fi

	exit 1
}

validate_input() {

	
	if [ -z $INSTALL_DIR ]; then
		echo "No installation directory specified..Installing in /opt/protegrity"
		INSTALL_DIR="/opt/protegrity"
	fi

}

fetch_extract_BDP() {
	
	GET_DIR=`pwd`
	aws s3 cp "$PROTECTOR_FILE" $GET_DIR

	if [ $? -ne 0 ]; then
		echo "Unable to download the product from S3 location"
		clean_up
	fi

	if [ ! -d /tmp/protegrity ]; then
		mkdir -p /tmp/protegrity
    	else
    		rm -rf /tmp/protegrity/*
    	fi

    	tar -xzf BigDataProtector_AMZL-2-64_x86-64_EMR-5.30.0-64_7.1.0.122.tgz -C /tmp/protegrity

    	if [ $? -ne 0 ]; then
		echo "Unable to extract the product tgz"
		clean_up
	fi

}

install_BDP() {
	
	cd /tmp/protegrity

	if [ $? -ne 0 ]; then
		echo "Error encountered while installing product.."
		clean_up
	fi

	CURR_DIR=`pwd`
	bdp_file=`find $CURR_DIR -name "${BDP_INSTALL_FILE}"`
	bdp_file=${bdp_file##*/}
	

	./$bdp_file $INSTALL_DIR

	if [ $? -ne 0 ]; then
		echo "Error encountered while installing product.."
		clean_up
	fi
}

modify_configuration() {
	
	GET_DIR=`pwd`
	aws s3 cp "$CONFIG_UPDATER" $GET_DIR
	
	if [ $? -ne 0 ]; then
		echo "Unable to download the config updater from S3 location"
		clean_up
	fi

	sudo chmod 755 bdp_classpath_configurator.py

	sudo python bdp_classpath_configurator.py $INSTALL_DIR

	if [ $? -ne 0 ]; then
		echo "Unable to update emr config with protegrity classpath entries.."
		clean_up
	fi

}

configure_pepserver_auto_restart() {

	if [ -f $INSTALL_DIR/defiance_dps/bin/pepsrvctrl ];then
		export INIT_SCRIPT="/etc/init.d/pepserver"

		sudo cp $INSTALL_DIR/defiance_dps/bin/pepsrvctrl $INIT_SCRIPT
		sudo chmod +x $INIT_SCRIPT

		# Finding the number of the line within Init Script that starts the pepserver
		line_no=$(sudo sed -n '/^[[:space:]]\+\.\/\$PTY_SERVER_NAME/=' $INIT_SCRIPT)
		previous_line=$(( line_no - 1 ))

		# Modifying the Init Script so that the pepserver is started using ptyitusr
		sudo sed -i "${line_no} s|\(^[[:space:]]\+\)\(.*\)|\1sudo -u \$PROTEGRITY_IT_USR \2|g" $INIT_SCRIPT
		sudo sed -i "${previous_line} a \ \ \ \ \ \ \ \ PROTEGRITY_IT_USR=\"ptyitusr\"" $INIT_SCRIPT

		sudo chkconfig --add pepserver
	else
		echo "$INSTALL_DIR/defiance_dps/bin/pepsrvctrl does not Exist. Can't register PepServer for AutoRestart."
		clean_up 
	fi	
}


validate_input

fetch_extract_BDP

install_BDP

modify_configuration

configure_pepserver_auto_restart

#----------------------------------------------------------------------------------------------------#
exit 0