/*************************************************************************************************************
 # TITLE           : TABLE CII_SR_ACCT_SGMNTN_TM_PRD_PARM
 # FILENAME        : cii_sr_acct_sgmntn_tm_prd_parm.sql
 # DESCRIPTION     : THIS SCRIPT LOADS CII_SR_ACCT_SGMNTN_TM_PRD_PARM table for Clinet insert
 # DEVELOPER       : LEGATO
 # CREATED ON      : 3/08/2022
 # LOGIC           : LOAD TARGET TABLE
 # VERSION         : 1.0
 ***************************************************************************************************************/

delete from CII_EVOLVE.CII_SR_ACCT_SGMNTN_TM_PRD_PARM WHERE (AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD) AND 'YES' = ${re_run} AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))) AND (RPT_SHRT_NM in (${rpt_shrt_nm}) OR 'ALL' in (${rpt_shrt_nm})); 

insert into CII_EVOLVE.CII_SR_ACCT_SGMNTN_TM_PRD_PARM
with CII_SR_ACCT_SGMNTN_PARM_PAID_CONV as(
select distinct
parm.acct_id
,parm.SRC_FLTR_ID
,parm.RPT_SHRT_NM
,parm.DFLT_CNTRCT_TYPE_CD
,parm.CLNT_PRTY_GRP_CD
,parm.BNCHMRK_ID
,parm.ACCT_SGMNTN_TYPE_NM
,parm.RPT_ID
,parm.DFLT_HCC_THRSHLD_AMT
,INC3_PAID_TABLE.INCRD_PAID_CD as INCRD_PAID_CD
,case when tm_prd_tbl.tm_prd = 'pytd'
then CAST(CASE WHEN parm.RPTG_PLAN_MNTH_NBR NOT IN(1,2,3,4,5,6,7,8,9,10,11,12) THEN 1 else RPTG_PLAN_MNTH_NBR end as STRING)  ELSE 
tm_prd_tbl.tm_prd end as DFLT_TM_PRD_TYPE_CD

 from ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_PARM parm 
 
 CROSS JOIN
(select 'pytd' tm_prd union 
select 'r12m' tm_prd union
select 'r3m' tm_prd union
select 'cytd' tm_prd) tm_prd_tbl

 CROSS JOIN
(select 'PAID' INCRD_PAID_CD union
select 'INC3' INCRD_PAID_CD 
) INC3_PAID_TABLE

where  parm.RPT_SHRT_NM not like 'HCC%'  and parm.INCRD_PAID_CD = 'PAID' and parm.PRE_RUN_IND = 'Y'
  ),
  
  CII_SR_ACCT_SGMNTN_PARM_INC2_CONV as(
select distinct
parm.acct_id
,parm.SRC_FLTR_ID
,parm.RPT_SHRT_NM
,parm.DFLT_CNTRCT_TYPE_CD
,parm.CLNT_PRTY_GRP_CD
,parm.BNCHMRK_ID
,parm.ACCT_SGMNTN_TYPE_NM
,parm.RPT_ID
,parm.DFLT_HCC_THRSHLD_AMT
,parm.INCRD_PAID_CD as INCRD_PAID_CD
,case when tm_prd_tbl.tm_prd = 'pytd'
then CAST(CASE WHEN parm.RPTG_PLAN_MNTH_NBR NOT IN(1,2,3,4,5,6,7,8,9,10,11,12) THEN 1 else RPTG_PLAN_MNTH_NBR end as STRING)  ELSE 
tm_prd_tbl.tm_prd end as DFLT_TM_PRD_TYPE_CD

 from ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_PARM parm 

 CROSS JOIN
(select 'pytd' tm_prd union
select 'r12m' tm_prd union
select 'r3m' tm_prd union
select 'cytd' tm_prd) tm_prd_tbl

 where  parm.RPT_SHRT_NM not like 'HCC%'  and parm.INCRD_PAID_CD = 'INC2' and parm.PRE_RUN_IND = 'Y'
   )
   
   ,
   
   CII_SR_ACCT_SGMNTN_PARM_INC3_CONV as(
select distinct
parm.acct_id
,parm.SRC_FLTR_ID
,parm.RPT_SHRT_NM
,parm.DFLT_CNTRCT_TYPE_CD
,parm.CLNT_PRTY_GRP_CD
,parm.BNCHMRK_ID
,parm.ACCT_SGMNTN_TYPE_NM
,parm.RPT_ID
,parm.DFLT_HCC_THRSHLD_AMT
,parm.INCRD_PAID_CD as INCRD_PAID_CD
,case when tm_prd_tbl.tm_prd = 'pytd'
then CAST(CASE WHEN parm.RPTG_PLAN_MNTH_NBR NOT IN(1,2,3,4,5,6,7,8,9,10,11,12) THEN 1 else RPTG_PLAN_MNTH_NBR end as STRING)  ELSE 
tm_prd_tbl.tm_prd end as DFLT_TM_PRD_TYPE_CD

 from ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_PARM parm 

 CROSS JOIN
(select 'pytd' tm_prd union
select 'r12m' tm_prd union
select 'r3m' tm_prd union
select 'cytd' tm_prd) tm_prd_tbl

 where  parm.RPT_SHRT_NM not like 'HCC%'  and parm.INCRD_PAID_CD = 'INC3' and parm.PRE_RUN_IND = 'Y'
   )
   ,
   CII_SR_ACCT_SGMNTN_PARM_HCC_CONV as(
select distinct
parm.acct_id
,parm.SRC_FLTR_ID
,parm.RPT_SHRT_NM
,parm.DFLT_CNTRCT_TYPE_CD
,parm.CLNT_PRTY_GRP_CD
,parm.BNCHMRK_ID
,parm.ACCT_SGMNTN_TYPE_NM
,parm.RPT_ID
--,thrshld_tbl.thrshld as DFLT_HCC_THRSHLD_AMT
,parm.DFLT_HCC_THRSHLD_AMT
,INC3_PAID_TABLE.INCRD_PAID_CD as INCRD_PAID_CD
,case when tm_prd_tbl.tm_prd = 'pytd'
then CAST(CASE WHEN parm.RPTG_PLAN_MNTH_NBR NOT IN(1,2,3,4,5,6,7,8,9,10,11,12) THEN 1 else RPTG_PLAN_MNTH_NBR end as STRING)  ELSE 
tm_prd_tbl.tm_prd end as DFLT_TM_PRD_TYPE_CD

 from ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_PARM parm 
 
 CROSS JOIN
(select 'pytd' tm_prd union
select 'r12m' tm_prd union
select 'r3m' tm_prd union
select 'cytd' tm_prd) tm_prd_tbl

 CROSS JOIN
(select 'PAID' INCRD_PAID_CD union
select 'INC3' INCRD_PAID_CD 
) INC3_PAID_TABLE
  
/*CROSS JOIN
(select 100000.000000 thrshld union
select 25000.000000  thrshld union
select 50000.000000  thrshld union
select 75000.000000  thrshld union
select 200000.000000  thrshld  ) thrshld_tbl*/

where  parm.RPT_SHRT_NM like 'HCC%'  and parm.INCRD_PAID_CD = 'PAID' and parm.PRE_RUN_IND = 'Y'
  
union all
  
select distinct
parm.acct_id
,parm.SRC_FLTR_ID
,parm.RPT_SHRT_NM
,parm.DFLT_CNTRCT_TYPE_CD
,parm.CLNT_PRTY_GRP_CD
,parm.BNCHMRK_ID
,parm.ACCT_SGMNTN_TYPE_NM
,parm.RPT_ID
--,thrshld_tbl.thrshld as DFLT_HCC_THRSHLD_AMT
,parm.DFLT_HCC_THRSHLD_AMT
,parm.INCRD_PAID_CD as INCRD_PAID_CD
,case when tm_prd_tbl.tm_prd = 'pytd'
then CAST(CASE WHEN parm.RPTG_PLAN_MNTH_NBR NOT IN(1,2,3,4,5,6,7,8,9,10,11,12) THEN 1 else RPTG_PLAN_MNTH_NBR end as STRING)  ELSE 
tm_prd_tbl.tm_prd end as DFLT_TM_PRD_TYPE_CD

 from ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_PARM parm 
 
 CROSS JOIN
(select 'pytd' tm_prd union
select 'r12m' tm_prd union
select 'r3m' tm_prd union
select 'cytd' tm_prd) tm_prd_tbl

  
/*CROSS JOIN
(select 100000.000000 thrshld union
select 25000.000000  thrshld union
select 50000.000000  thrshld union
select 75000.000000  thrshld union
select 200000.000000  thrshld  ) thrshld_tbl*/

where  parm.RPT_SHRT_NM like 'HCC%'  and parm.INCRD_PAID_CD = 'INC2' and parm.PRE_RUN_IND = 'Y'

union all
  
select distinct
parm.acct_id
,parm.SRC_FLTR_ID
,parm.RPT_SHRT_NM
,parm.DFLT_CNTRCT_TYPE_CD
,parm.CLNT_PRTY_GRP_CD
,parm.BNCHMRK_ID
,parm.ACCT_SGMNTN_TYPE_NM
,parm.RPT_ID
--,thrshld_tbl.thrshld as DFLT_HCC_THRSHLD_AMT
,parm.DFLT_HCC_THRSHLD_AMT
,parm.INCRD_PAID_CD as INCRD_PAID_CD
,case when tm_prd_tbl.tm_prd = 'pytd'
then CAST(CASE WHEN parm.RPTG_PLAN_MNTH_NBR NOT IN(1,2,3,4,5,6,7,8,9,10,11,12) THEN 1 else RPTG_PLAN_MNTH_NBR end as STRING)  ELSE 
tm_prd_tbl.tm_prd end as DFLT_TM_PRD_TYPE_CD

 from ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_PARM parm 
 
 CROSS JOIN
(select 'pytd' tm_prd union
select 'r12m' tm_prd union
select 'r3m' tm_prd union
select 'cytd' tm_prd) tm_prd_tbl

  
/*CROSS JOIN
(select 100000.000000 thrshld union
select 25000.000000  thrshld union
select 50000.000000  thrshld union
select 75000.000000  thrshld union
select 200000.000000  thrshld  ) thrshld_tbl*/

where  parm.RPT_SHRT_NM like 'HCC%'  and parm.INCRD_PAID_CD = 'INC3' and parm.PRE_RUN_IND = 'Y'
  
 
  )
  , CII_SR_ACCT_SGMNTN_PARM_ALL_COMBINATION as (
select acct_id,SRC_FLTR_ID,RPT_SHRT_NM,DFLT_CNTRCT_TYPE_CD,CLNT_PRTY_GRP_CD,BNCHMRK_ID,ACCT_SGMNTN_TYPE_NM,RPT_ID,
  DFLT_HCC_THRSHLD_AMT,INCRD_PAID_CD,DFLT_TM_PRD_TYPE_CD from CII_SR_ACCT_SGMNTN_PARM_PAID_CONV
  where DFLT_TM_PRD_TYPE_CD <> '1' and DFLT_TM_PRD_TYPE_CD <> 'r3m' and RPT_SHRT_NM NOT IN ('FIN-04','DEN-04','VIS-04')
    
  union all
  
  select acct_id,SRC_FLTR_ID,RPT_SHRT_NM,DFLT_CNTRCT_TYPE_CD,CLNT_PRTY_GRP_CD,BNCHMRK_ID,ACCT_SGMNTN_TYPE_NM,RPT_ID,
  DFLT_HCC_THRSHLD_AMT,INCRD_PAID_CD,DFLT_TM_PRD_TYPE_CD from CII_SR_ACCT_SGMNTN_PARM_INC2_CONV
  where DFLT_TM_PRD_TYPE_CD <> '1' and DFLT_TM_PRD_TYPE_CD <> 'r3m' and RPT_SHRT_NM NOT IN ('FIN-04','DEN-04','VIS-04')
    
  union all
  
  select acct_id,SRC_FLTR_ID,RPT_SHRT_NM,DFLT_CNTRCT_TYPE_CD,CLNT_PRTY_GRP_CD,BNCHMRK_ID,ACCT_SGMNTN_TYPE_NM,RPT_ID,
  DFLT_HCC_THRSHLD_AMT,INCRD_PAID_CD,DFLT_TM_PRD_TYPE_CD from CII_SR_ACCT_SGMNTN_PARM_INC3_CONV
  where DFLT_TM_PRD_TYPE_CD <> '1' and DFLT_TM_PRD_TYPE_CD <> 'r3m' and RPT_SHRT_NM NOT IN ('FIN-04','DEN-04','VIS-04')
    
  union all
  
  select acct_id,SRC_FLTR_ID,RPT_SHRT_NM,DFLT_CNTRCT_TYPE_CD,CLNT_PRTY_GRP_CD,BNCHMRK_ID,ACCT_SGMNTN_TYPE_NM,RPT_ID,
  DFLT_HCC_THRSHLD_AMT,INCRD_PAID_CD,DFLT_TM_PRD_TYPE_CD from CII_SR_ACCT_SGMNTN_PARM_HCC_CONV
  where DFLT_TM_PRD_TYPE_CD <> '1' and DFLT_TM_PRD_TYPE_CD <> 'r3m' and RPT_SHRT_NM NOT IN ('FIN-04','DEN-04','VIS-04')
 
 -- for den/vis/fin04
 
  union all
  
  select acct_id,SRC_FLTR_ID,RPT_SHRT_NM,DFLT_CNTRCT_TYPE_CD,CLNT_PRTY_GRP_CD,BNCHMRK_ID,ACCT_SGMNTN_TYPE_NM,RPT_ID,
  DFLT_HCC_THRSHLD_AMT,INCRD_PAID_CD,DFLT_TM_PRD_TYPE_CD from CII_SR_ACCT_SGMNTN_PARM_PAID_CONV
  where  RPT_SHRT_NM IN ('FIN-04','DEN-04','VIS-04') and DFLT_TM_PRD_TYPE_CD = 'r12m'
    
  union all
  
  select acct_id,SRC_FLTR_ID,RPT_SHRT_NM,DFLT_CNTRCT_TYPE_CD,CLNT_PRTY_GRP_CD,BNCHMRK_ID,ACCT_SGMNTN_TYPE_NM,RPT_ID,
  DFLT_HCC_THRSHLD_AMT,INCRD_PAID_CD,DFLT_TM_PRD_TYPE_CD from CII_SR_ACCT_SGMNTN_PARM_INC2_CONV
  where  RPT_SHRT_NM  IN ('FIN-04','DEN-04','VIS-04')  and DFLT_TM_PRD_TYPE_CD = 'r12m'
    
  union all
  
  select acct_id,SRC_FLTR_ID,RPT_SHRT_NM,DFLT_CNTRCT_TYPE_CD,CLNT_PRTY_GRP_CD,BNCHMRK_ID,ACCT_SGMNTN_TYPE_NM,RPT_ID,
  DFLT_HCC_THRSHLD_AMT,INCRD_PAID_CD,DFLT_TM_PRD_TYPE_CD from CII_SR_ACCT_SGMNTN_PARM_INC3_CONV
  where  RPT_SHRT_NM  IN ('FIN-04','DEN-04','VIS-04')  and DFLT_TM_PRD_TYPE_CD = 'r12m'
    
  union all
  
  select acct_id,SRC_FLTR_ID,RPT_SHRT_NM,DFLT_CNTRCT_TYPE_CD,CLNT_PRTY_GRP_CD,BNCHMRK_ID,ACCT_SGMNTN_TYPE_NM,RPT_ID,
  DFLT_HCC_THRSHLD_AMT,INCRD_PAID_CD,DFLT_TM_PRD_TYPE_CD from CII_SR_ACCT_SGMNTN_PARM_HCC_CONV
  where  RPT_SHRT_NM  IN ('FIN-04','DEN-04','VIS-04')  and DFLT_TM_PRD_TYPE_CD = 'r12m'
  )
  
  
  
select distinct
trim(dtp.AS_OF_MNTH_NBR) AS AS_OF_YEAR_MNTH_NBR,
trim(brdg.ACCT_ID) AS ACCT_ID,
trim(brdg.SRC_FLTR_ID) AS SRC_FLTR_ID,
trim(parm.RPT_SHRT_NM)  as RPT_SHRT_NM,
trim(dtp.TM_PRD_TYPE_CD) AS TM_PRD_TYPE_CD,
trim(parm.DFLT_HCC_THRSHLD_AMT) AS HCC_THRSHLD_AMT,
trim(dtp.INCRD_PAID_CD) AS INCRD_PAID_CD,
brdg.sgmntn_dim_key AS SGMNTN_DIM_KEY,
trim(parm.DFLT_CNTRCT_TYPE_CD) as DFLT_CNTRCT_TYPE_CD,
case when parm.CLNT_PRTY_GRP_CD='NA' then 'NA' 
ELSE 'PG'||MOD(CAST(SUBSTR(brdg.SRC_FLTR_ID, 10, 5) AS INT), 20) END  as CLNT_PRTY_GRP_CD,
CASE 
WHEN STRT_MNTH_NBR<>'111101' AND trim(parm.RPT_SHRT_NM) IN ('FIN-04','DEN-04','VIS-04') then to_number(to_varchar(add_months(to_date(concat(END_MNTH_NBR,'01'),'yyyyMMdd'), -35),'yyyyMM' ))
when trim(parm.RPT_SHRT_NM) in ('MCC-03') then to_number(to_varchar(add_months(to_date(concat(STRT_MNTH_NBR,'01'),'yyyyMMdd'), -1),'yyyyMM' ))
else STRT_MNTH_NBR end as STRT_MNTH_NBR,

case when trim(parm.RPT_SHRT_NM) in ('MCC-03') then to_number(to_varchar(add_months(to_date(concat(END_MNTH_NBR,'01'),'yyyyMMdd'), -1),'yyyyMM' ))
else END_MNTH_NBR end AS END_MNTH_NBR,

CASE 
WHEN SRVC_STRT_MNTH_NBR<>'111101' AND trim(parm.RPT_SHRT_NM) IN ('FIN-04','DEN-04','VIS-04') then to_number(to_varchar(add_months(to_date(concat(SRVC_END_MNTH_NBR,'01'),'yyyyMMdd'), -35),'yyyyMM' ))
when trim(parm.RPT_SHRT_NM) in ('MCC-03') then to_number(to_varchar(add_months(to_date(concat(SRVC_STRT_MNTH_NBR,'01'),'yyyyMMdd'), -1),'yyyyMM' ))
 else SRVC_STRT_MNTH_NBR end as SRVC_STRT_MNTH_NBR,
 
case when trim(parm.RPT_SHRT_NM) in ('MCC-03') then to_number(to_varchar(add_months(to_date(concat(SRVC_END_MNTH_NBR,'01'),'yyyyMMdd'), -1),'yyyyMM' ))
else SRVC_END_MNTH_NBR  end AS SRVC_END_MNTH_NBR,

CASE 
WHEN PAID_STRT_MNTH_NBR<>'111101' AND trim(parm.RPT_SHRT_NM) IN ('FIN-04','DEN-04','VIS-04') then to_number(to_varchar(add_months(to_date(concat(PAID_END_MNTH_NBR,'01'),'yyyyMMdd'), -35),'yyyyMM' ))
 when trim(parm.RPT_SHRT_NM) in ('MCC-03') then to_number(to_varchar(add_months(to_date(concat(PAID_STRT_MNTH_NBR,'01'),'yyyyMMdd'), -1),'yyyyMM' ))
 else PAID_STRT_MNTH_NBR end as PAID_STRT_MNTH_NBR,
 
 case when trim(parm.RPT_SHRT_NM) in ('MCC-03') then to_number(to_varchar(add_months(to_date(concat(PAID_END_MNTH_NBR,'01'),'yyyyMMdd'), -1),'yyyyMM' )) 
else PAID_END_MNTH_NBR end AS PAID_END_MNTH_NBR,
brdg.ACCT_ID as AGRGT_ACCT_ID,
brdg.SRC_FLTR_ID as AGRGT_SRC_FLTR_ID,
case when trim(parm.RPT_SHRT_NM) IN ('FIN-04','DEN-04','VIS-04') and dtp.YEAR_ID > 1 then -1 else dtp.YEAR_ID end AS YEAR_ID,
'Client' as BNCHMRK_RUN_TYPE_CD, 
'1' as RPT_RUN_ID,
md5_number_lower64(dtp.AS_OF_MNTH_NBR||brdg.SRC_FLTR_ID||parm.RPT_SHRT_NM||dtp.TM_PRD_TYPE_CD||parm.DFLT_HCC_THRSHLD_AMT||dtp.INCRD_PAID_CD||1) as RPT_INSTNC_MTDTA_ID,
parm.BNCHMRK_ID as BNCHMRK_ID,
parm.ACCT_SGMNTN_TYPE_NM as ACCT_SGMNTN_TYPE_NM,
Case 					
when rsi.SRC_FLTR_ID is not null and rsi.acct_id is not null and (parm.RPT_SHRT_NM like 'FIN-%' or parm.RPT_SHRT_NM like 'HCC-%' or parm.RPT_SHRT_NM like 'MEM-%') and (RSI.AVG_MBR_MDCL_CVRG_CNT > 30 or AVG_MBR_RX_CVRG_CNT > 30) THEN 'N'
WHEN rsi.SRC_FLTR_ID is not null and rsi.acct_id is not null and parm.RPT_SHRT_NM like  ('DEN-%') and (RSI.AVG_MBR_DNTL_CVRG_CNT > 1) THEN 'N'
WHEN rsi.SRC_FLTR_ID is not null and rsi.acct_id is not null and parm.RPT_SHRT_NM like  ('VIS-%') and (RSI.AVG_MBR_VSN_CVRG_CNT > 1) THEN 'N'
WHEN rsi.SRC_FLTR_ID is not null and rsi.acct_id is not null and parm.RPT_SHRT_NM like  ('RX-%') and (RSI.AVG_MBR_RX_CVRG_CNT > 30) THEN 'N'
WHEN rsi.SRC_FLTR_ID is not null and rsi.acct_id is not null and (parm.RPT_SHRT_NM like 'MCC-%' or parm.RPT_SHRT_NM like 'UTIL-%') and RSI.AVG_MBR_MDCL_CVRG_CNT > 30 THEN 'N'
else 'Y' end as RPT_SPRSN_IND,
parm.RPT_ID as RPT_ID,
'N' as SCRTY_LVL_CD,
current_timestamp LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY,
trim(dtp.AS_OF_MNTH_NBR) AS UI_AS_OF_YEAR_MNTH_NBR,
case when trim(dtp.TM_PRD_TYPE_CD) in('1','2','3','4','5','6','7','8','9','10','11','12')  then 'pytd' else trim(dtp.TM_PRD_TYPE_CD) end AS UI_TM_PRD_TYPE_CD
from  ${aciisst_adhoc_schema_name}.DIM_TM_PRD dtp

join ( select * from  CII_SR_ACCT_SGMNTN_PARM_ALL_COMBINATION 
      	where  (RPT_SHRT_NM in (${rpt_shrt_nm}) OR 'ALL' in (${rpt_shrt_nm})) ) parm 
ON trim(dtp.INCRD_PAID_CD)=trim(parm.INCRD_PAID_CD)
and dtp.TM_PRD_TYPE_CD=parm.DFLT_TM_PRD_TYPE_CD


JOIN ${aciisst_schema_name}.ACIISST_SGMNTN_BRDG_SCD brdg
ON brdg.acct_id = parm.acct_id
and brdg.SRC_FLTR_ID= parm.SRC_FLTR_ID

JOIN ${aciisst_adhoc_schema_name}.CII_RUN_PRD crrp
on dtp.AS_OF_MNTH_NBR = crrp.RUN_YEAR_MNTH_NBR 

left join 					
(SELECT DISTINCT ACCT_ID,SRC_FLTR_ID,AVG_MBR_MDCL_CVRG_CNT,AVG_MBR_RX_CVRG_CNT,AVG_MBR_DNTL_CVRG_CNT,AVG_MBR_VSN_CVRG_CNT FROM 					
(SELECT A.ACCT_ID,b.SRC_FLTR_ID,					
SUM(CASE WHEN MBR_CVRG_TYPE_CD='001' THEN MBR_CVRG_CNT ELSE 0 END)/ COUNT(DISTINCT ELGBLTY_CY_MNTH_END_NBR) as AVG_MBR_MDCL_CVRG_CNT ,					
SUM(CASE WHEN MBR_CVRG_TYPE_CD='102' THEN MBR_CVRG_CNT ELSE 0 END)/ COUNT(DISTINCT ELGBLTY_CY_MNTH_END_NBR) as AVG_MBR_RX_CVRG_CNT ,					
SUM(CASE WHEN MBR_CVRG_TYPE_CD='103' THEN MBR_CVRG_CNT ELSE 0 END)/ COUNT(DISTINCT ELGBLTY_CY_MNTH_END_NBR) as AVG_MBR_DNTL_CVRG_CNT ,					
SUM(CASE WHEN MBR_CVRG_TYPE_CD='104' THEN MBR_CVRG_CNT ELSE 0 END)/ COUNT(DISTINCT ELGBLTY_CY_MNTH_END_NBR) as AVG_MBR_VSN_CVRG_CNT ,					
'N' AS RPT_SPRSN_IND					
FROM ${aciisst_adhoc_schema_name}.CII_FACT_MBRSHP_CNSLDTD A					
INNER JOIN ${aciisst_schema_name}.ACIISST_SGMNTN_BRDG_SCD B					
ON A.ACCT_ID=B.ACCT_ID					
AND A.SGMNTN_DIM_KEY=B.SGMNTN_DIM_KEY					
INNER JOIN (SELECT DISTINCT ACCT_ID,SRC_FLTR_ID,STRT_MNTH_NBR,END_MNTH_NBR 					
FROM ${aciisst_adhoc_schema_name}.DIM_TM_PRD dtp					
join ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_PARM parm 					
ON trim(dtp.INCRD_PAID_CD)=trim(parm.INCRD_PAID_CD)					
and dtp.TM_PRD_TYPE_CD=parm.DFLT_TM_PRD_TYPE_CD					
INNER JOIN ${aciisst_adhoc_schema_name}.CII_RUN_PRD crrp					
on dtp.AS_OF_MNTH_NBR = crrp.RUN_YEAR_MNTH_NBR 					
WHERE YEAR_ID=1) PARM 					
ON PARM.ACCT_ID=B.ACCT_ID					
AND PARM.SRC_FLTR_ID=B.SRC_FLTR_ID
AND A.BK_FILL_IND = 'N'
WHERE FLTR_SRC_NM='ERSU'					
AND ELGBLTY_CY_MNTH_END_NBR BETWEEN STRT_MNTH_NBR AND END_MNTH_NBR					
GROUP BY 1,2 ) A ) RSI
on parm.acct_id=rsi.acct_id					
and parm.SRC_FLTR_ID=rsi.SRC_FLTR_ID
WHERE brdg.FLTR_SRC_NM = 'ERSU' and (case when trim(parm.RPT_SHRT_NM) IN ('FIN-04','DEN-04','VIS-04') and dtp.YEAR_ID > 1 then -1 else dtp.YEAR_ID end) > 0
  AND 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND (RPT_SHRT_NM in (${rpt_shrt_nm}) OR 'ALL' in (${rpt_shrt_nm}))
 AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
  on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR)
;
