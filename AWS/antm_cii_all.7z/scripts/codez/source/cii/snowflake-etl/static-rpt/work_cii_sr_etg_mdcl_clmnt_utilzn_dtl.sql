/*************************************************************************************************************
 # TITLE           : work table cii_sr_etg_mdcl_clmnt_utilzn_dtl
 # FILENAME        : work_cii_sr_etg_mdcl_clmnt_utilzn_dtl.sql
 # DESCRIPTION     : THIS SCRIPT LOADS CII_SR_ETG_MDCL_CLMNT_UTILZN_DTL table
 # DEVELOPER       : LEGATO
 # CREATED ON      : 3/11/2022
 # LOGIC           : APPEND TARGET TABLE
 # VERSION         : 1.0
 ***************************************************************************************************************/

delete from CII_EVOLVE.CII_SR_ETG_MDCL_CLMNT_UTILZN_DTL WHERE (AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.cii_run_prd) AND 'YES' = ${re_run} AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})));

insert  into CII_EVOLVE.CII_SR_ETG_MDCL_CLMNT_UTILZN_DTL
SELECT distinct
AS_OF_YEAR_MNTH_NBR,
INCRD_PAID_CD,
SRC_FLTR_ID,
ACCT_ID,
TM_PRD_TYPE_CD,
YEAR_ID,
RPT_RUN_ID,
RPT_INSTNC_MTDTA_ID,
ACCT_SGMNTN_TYPE_NM,
BNCHMRK_ID,
CLMNT_CNT_TYPE_CD,
DIM1 AS ETG_SRVC_DIAG_DESC,
DIM2 AS ETG_SRVC_CTGRY_DIAG_DESC,
CLMNT_1_CNT,
CLMNT_2_CNT,
CLMNT_3_CNT,
SCRTY_LVL_CD,
current_timestamp as LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY
	FROM(
SELECT	amstp.AGRGT_ACCT_ID AS ACCT_ID, amstp.YEAR_ID AS YEAR_ID, amstp.AS_OF_YEAR_MNTH_NBR, amstp.AGRGT_SRC_FLTR_ID AS SRC_FLTR_ID, amstp.TM_PRD_TYPE_CD, amstp.INCRD_PAID_CD, amstp.BNCHMRK_ID,amstp.RPT_RUN_ID,-1 as RPT_INSTNC_MTDTA_ID,amstp.ACCT_SGMNTN_TYPE_NM,
'ETG_CTGRY_CLMNT' as CLMNT_CNT_TYPE_CD,
dim_etg.ETG_CTGRY_SMRY_DESC as DIM1,
'NA' as DIM2,
COUNT(DISTINCT fact.MCID) AS CLMNT_1_CNT,
CAST(0 as INTEGER) as CLMNT_2_CNT,
CAST(0 as INTEGER) as CLMNT_3_CNT,
amstp.SCRTY_LVL_CD
FROM ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact

INNER JOIN (SELECT DISTINCT
AS_OF_YEAR_MNTH_NBR
,ACCT_ID
,AGRGT_ACCT_ID
,SRC_FLTR_ID
,AGRGT_SRC_FLTR_ID
,TM_PRD_TYPE_CD
,INCRD_PAID_CD
,SGMNTN_DIM_KEY
,SRVC_STRT_MNTH_NBR
,SRVC_END_MNTH_NBR
,PAID_STRT_MNTH_NBR
,PAID_END_MNTH_NBR
,YEAR_ID
,ACCT_SGMNTN_TYPE_NM
,BNCHMRK_ID
,RPT_RUN_ID
,CII_SR_ACCT_SGMNTN_TM_PRD_PARM.SCRTY_LVL_CD
FROM ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM
JOIN ${aciisst_adhoc_schema_name}.CII_RUN_PRD PRD
ON PRD.RUN_YEAR_MNTH_NBR=AS_OF_YEAR_MNTH_NBR
where YEAR_ID <= 1 and RPT_SHRT_NM in ('MCC-04','MCC-04A')
 AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
 AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) 
AND RPT_SPRSN_IND = 'N'
) amstp
ON fact.acct_id = amstp.acct_id
AND fact.RPTG_PAID_YEAR_MNTH_NBR between amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY

INNER JOIN ${aciisst_adhoc_schema_name}.DIM_ETG_CLM_OUTPUT dim_etg
ON fact.CLM_FACT_KEY = dim_etg.CLM_ADJSTMNT_KEY
AND fact.FACT_CLM_LINE_NBR = dim_etg.CLM_LINE_NBR
AND dim_etg.ETG_RUN_DURTN_IND ='M'

group by amstp.AGRGT_ACCT_ID , amstp.YEAR_ID , amstp.AS_OF_YEAR_MNTH_NBR, amstp.AGRGT_SRC_FLTR_ID , amstp.TM_PRD_TYPE_CD, amstp.INCRD_PAID_CD, amstp.BNCHMRK_ID,dim_etg.ETG_CTGRY_SMRY_DESC,amstp.RPT_RUN_ID,amstp.ACCT_SGMNTN_TYPE_NM,amstp.SCRTY_LVL_CD
)

WHERE 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_ETG_MDCL_CLMNT_UTILZN_DTL
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR);


insert  into CII_EVOLVE.CII_SR_ETG_MDCL_CLMNT_UTILZN_DTL
SELECT distinct
AS_OF_YEAR_MNTH_NBR,
INCRD_PAID_CD,
SRC_FLTR_ID,
ACCT_ID,
TM_PRD_TYPE_CD,
YEAR_ID,
RPT_RUN_ID,
RPT_INSTNC_MTDTA_ID,
ACCT_SGMNTN_TYPE_NM,
BNCHMRK_ID,
CLMNT_CNT_TYPE_CD,
DIM1 AS ETG_SRVC_DIAG_DESC,
DIM2 AS ETG_SRVC_CTGRY_DIAG_DESC,
CLMNT_1_CNT,
CLMNT_2_CNT,
CLMNT_3_CNT,
SCRTY_LVL_CD,
current_timestamp as LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY
	FROM(
SELECT	amstp.AGRGT_ACCT_ID AS ACCT_ID, amstp.YEAR_ID AS YEAR_ID, amstp.AS_OF_YEAR_MNTH_NBR, amstp.AGRGT_SRC_FLTR_ID AS SRC_FLTR_ID, amstp.TM_PRD_TYPE_CD, amstp.INCRD_PAID_CD, amstp.BNCHMRK_ID,amstp.RPT_RUN_ID,-1 as RPT_INSTNC_MTDTA_ID,amstp.ACCT_SGMNTN_TYPE_NM,
'ETG_CGRY_TP25_CLMNT' CLMNT_CNT_TYPE_CD,
      case when RNK_PERMS.PD_ROWNBR between 1 and 25 then 'Top25' 
      when RNK_PERMS.PD_ROWNBR >25 then 'All Other' end as DIM1,
'NA' as DIM2,
COUNT(DISTINCT fact.MCID) AS CLMNT_1_CNT,
CAST(0 as INTEGER) as CLMNT_2_CNT,
CAST(0 as INTEGER) as CLMNT_3_CNT,
amstp.SCRTY_LVL_CD
FROM ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact

INNER JOIN (SELECT DISTINCT
AS_OF_YEAR_MNTH_NBR
,ACCT_ID
,AGRGT_ACCT_ID
,SRC_FLTR_ID
,AGRGT_SRC_FLTR_ID
,TM_PRD_TYPE_CD
,INCRD_PAID_CD
,SGMNTN_DIM_KEY
,SRVC_STRT_MNTH_NBR
,SRVC_END_MNTH_NBR
,PAID_STRT_MNTH_NBR
,PAID_END_MNTH_NBR
,YEAR_ID
,ACCT_SGMNTN_TYPE_NM
,BNCHMRK_ID
,RPT_RUN_ID
,CII_SR_ACCT_SGMNTN_TM_PRD_PARM.SCRTY_LVL_CD
FROM ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM
JOIN ${aciisst_adhoc_schema_name}.CII_RUN_PRD PRD
ON PRD.RUN_YEAR_MNTH_NBR=AS_OF_YEAR_MNTH_NBR
where YEAR_ID <= 1 and RPT_SHRT_NM in ('MCC-04','MCC-04A')
 AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
 AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) 
AND RPT_SPRSN_IND = 'N'
) amstp
ON fact.acct_id = amstp.acct_id
AND fact.RPTG_PAID_YEAR_MNTH_NBR between amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY

INNER JOIN ${aciisst_adhoc_schema_name}.DIM_ETG_CLM_OUTPUT dim_etg
ON fact.CLM_FACT_KEY = dim_etg.CLM_ADJSTMNT_KEY
AND fact.FACT_CLM_LINE_NBR = dim_etg.CLM_LINE_NBR
AND dim_etg.ETG_RUN_DURTN_IND ='M' 


LEFT JOIN  (
SELECT	amstp.AGRGT_ACCT_ID AS ACCT_ID,amstp.AS_OF_YEAR_MNTH_NBR,amstp.AGRGT_SRC_FLTR_ID AS SRC_FLTR_ID,amstp.TM_PRD_TYPE_CD,amstp.INCRD_PAID_CD,amstp.YEAR_ID,amstp.BNCHMRK_ID
,dim_etg.ETG_CTGRY_SMRY_DESC AS ETG_CTGRY_SMRY_DESC,
ROW_NUMBER() OVER( PARTITION BY amstp.AGRGT_ACCT_ID,amstp.AS_OF_YEAR_MNTH_NBR,amstp.AGRGT_SRC_FLTR_ID,amstp.TM_PRD_TYPE_CD,amstp.INCRD_PAID_CD,amstp.YEAR_ID
ORDER BY SUM(fact.ACCT_PAID_AMT) DESC,dim_etg.ETG_CTGRY_SMRY_DESC ASC) as PD_ROWNBR
FROM ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact

--TIME PERIOD BASED ON SERVICE START AND END, ONE TIME PERIOD HERE
INNER JOIN (SELECT DISTINCT
AS_OF_YEAR_MNTH_NBR
,ACCT_ID
,AGRGT_ACCT_ID
,SRC_FLTR_ID
,AGRGT_SRC_FLTR_ID
,TM_PRD_TYPE_CD
,INCRD_PAID_CD
,SGMNTN_DIM_KEY
,SRVC_STRT_MNTH_NBR
,SRVC_END_MNTH_NBR
,PAID_STRT_MNTH_NBR
,PAID_END_MNTH_NBR
,YEAR_ID
,ACCT_SGMNTN_TYPE_NM
,BNCHMRK_ID
,RPT_RUN_ID
,CII_SR_ACCT_SGMNTN_TM_PRD_PARM.SCRTY_LVL_CD
FROM ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM
JOIN ${aciisst_adhoc_schema_name}.CII_RUN_PRD PRD
ON PRD.RUN_YEAR_MNTH_NBR=AS_OF_YEAR_MNTH_NBR
where YEAR_ID <= 1 and RPT_SHRT_NM in ('MCC-04','MCC-04A')
 AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
 AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
AND RPT_SPRSN_IND = 'N') amstp
ON fact.acct_id = amstp.acct_id
AND fact.RPTG_PAID_YEAR_MNTH_NBR between amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY

INNER JOIN  ${aciisst_adhoc_schema_name}.DIM_ETG_CLM_OUTPUT dim_etg
ON fact.CLM_FACT_KEY = dim_etg.CLM_ADJSTMNT_KEY
AND fact.FACT_CLM_LINE_NBR = dim_etg.CLM_LINE_NBR 
AND dim_etg.ETG_RUN_DURTN_IND ='M'

WHERE fact.MBR_CVRG_TYPE_CD  IN ('001','102')  
AND fact.BK_FILL_IND = 'N' and amstp.YEAR_ID = 1
GROUP BY amstp.AGRGT_ACCT_ID, amstp.YEAR_ID,amstp.AS_OF_YEAR_MNTH_NBR,amstp.AGRGT_SRC_FLTR_ID,amstp.TM_PRD_TYPE_CD,amstp.INCRD_PAID_CD,
amstp.BNCHMRK_ID,dim_etg.ETG_CTGRY_SMRY_DESC) RNK_PERMS
ON amstp.ACCT_ID = RNK_PERMS.ACCT_ID
AND dim_etg.ETG_CTGRY_SMRY_DESC = RNK_PERMS.ETG_CTGRY_SMRY_DESC
AND amstp.BNCHMRK_ID = RNK_PERMS.BNCHMRK_ID
AND amstp.SRC_FLTR_ID = RNK_PERMS.SRC_FLTR_ID
AND amstp.TM_PRD_TYPE_CD = RNK_PERMS.TM_PRD_TYPE_CD
AND amstp.INCRD_PAID_CD = RNK_PERMS.INCRD_PAID_CD
AND amstp.AS_OF_YEAR_MNTH_NBR = RNK_PERMS.AS_OF_YEAR_MNTH_NBR
AND amstp.YEAR_ID = RNK_PERMS.YEAR_ID

group by amstp.AGRGT_ACCT_ID , amstp.YEAR_ID , amstp.AS_OF_YEAR_MNTH_NBR, amstp.AGRGT_SRC_FLTR_ID , 
      amstp.TM_PRD_TYPE_CD, amstp.INCRD_PAID_CD, amstp.BNCHMRK_ID,
      case when RNK_PERMS.PD_ROWNBR between 1 and 25 then 'Top25' 
      when RNK_PERMS.PD_ROWNBR >25 then 'All Other' end,
      amstp.RPT_RUN_ID,amstp.ACCT_SGMNTN_TYPE_NM,amstp.SCRTY_LVL_CD
)

WHERE 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_ETG_MDCL_CLMNT_UTILZN_DTL
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR);


insert  into CII_EVOLVE.CII_SR_ETG_MDCL_CLMNT_UTILZN_DTL
SELECT distinct
AS_OF_YEAR_MNTH_NBR,
INCRD_PAID_CD,
SRC_FLTR_ID,
ACCT_ID,
TM_PRD_TYPE_CD,
YEAR_ID,
RPT_RUN_ID,
RPT_INSTNC_MTDTA_ID,
ACCT_SGMNTN_TYPE_NM,
BNCHMRK_ID,
CLMNT_CNT_TYPE_CD,
DIM1 AS ETG_SRVC_DIAG_DESC,
DIM2 AS ETG_SRVC_CTGRY_DIAG_DESC,
CLMNT_1_CNT,
CLMNT_2_CNT,
CLMNT_3_CNT,
SCRTY_LVL_CD,
current_timestamp as LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY
	FROM(
SELECT	amstp.AGRGT_ACCT_ID AS ACCT_ID, amstp.YEAR_ID AS YEAR_ID, amstp.AS_OF_YEAR_MNTH_NBR, amstp.AGRGT_SRC_FLTR_ID AS SRC_FLTR_ID, amstp.TM_PRD_TYPE_CD, amstp.INCRD_PAID_CD, amstp.BNCHMRK_ID,amstp.RPT_RUN_ID,-1 as RPT_INSTNC_MTDTA_ID,amstp.ACCT_SGMNTN_TYPE_NM,
'ETG_BASE_CLS_CLMNT' as CLMNT_CNT_TYPE_CD,
dim_etg.ETG_CTGRY_SMRY_DESC as DIM1,
dim_etg.ETG_BASE_CLS_LONG_DESC as DIM2,
COUNT(DISTINCT fact.MCID) AS CLMNT_1_CNT,
CAST(0 as INTEGER) as CLMNT_2_CNT,
CAST(0 as INTEGER) as CLMNT_3_CNT,
amstp.SCRTY_LVL_CD
FROM ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact

INNER JOIN (SELECT DISTINCT
AS_OF_YEAR_MNTH_NBR
,ACCT_ID
,AGRGT_ACCT_ID
,SRC_FLTR_ID
,AGRGT_SRC_FLTR_ID
,TM_PRD_TYPE_CD
,INCRD_PAID_CD
,SGMNTN_DIM_KEY
,SRVC_STRT_MNTH_NBR
,SRVC_END_MNTH_NBR
,PAID_STRT_MNTH_NBR
,PAID_END_MNTH_NBR
,YEAR_ID
,ACCT_SGMNTN_TYPE_NM
,BNCHMRK_ID
,RPT_RUN_ID
,CII_SR_ACCT_SGMNTN_TM_PRD_PARM.SCRTY_LVL_CD
FROM ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM
JOIN ${aciisst_adhoc_schema_name}.CII_RUN_PRD PRD
ON PRD.RUN_YEAR_MNTH_NBR=AS_OF_YEAR_MNTH_NBR
where YEAR_ID <= 1 and RPT_SHRT_NM in ('MCC-04','MCC-04A')
 AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
 AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
AND RPT_SPRSN_IND = 'N'
) amstp
ON fact.acct_id = amstp.acct_id
AND fact.RPTG_PAID_YEAR_MNTH_NBR between amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY

INNER JOIN ${aciisst_adhoc_schema_name}.DIM_ETG_CLM_OUTPUT dim_etg
ON fact.CLM_FACT_KEY = dim_etg.CLM_ADJSTMNT_KEY
AND fact.FACT_CLM_LINE_NBR = dim_etg.CLM_LINE_NBR
AND dim_etg.ETG_RUN_DURTN_IND ='M'

group by amstp.AGRGT_ACCT_ID , amstp.YEAR_ID , amstp.AS_OF_YEAR_MNTH_NBR, amstp.AGRGT_SRC_FLTR_ID , amstp.TM_PRD_TYPE_CD, amstp.INCRD_PAID_CD, amstp.BNCHMRK_ID,dim_etg.ETG_CTGRY_SMRY_DESC,dim_etg.ETG_BASE_CLS_LONG_DESC,amstp.RPT_RUN_ID,amstp.ACCT_SGMNTN_TYPE_NM,amstp.SCRTY_LVL_CD
)

WHERE 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_ETG_MDCL_CLMNT_UTILZN_DTL
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR);

insert  into CII_EVOLVE.CII_SR_ETG_MDCL_CLMNT_UTILZN_DTL
SELECT distinct
	AS_OF_YEAR_MNTH_NBR,
	INCRD_PAID_CD,
	SRC_FLTR_ID,
	ACCT_ID,
	TM_PRD_TYPE_CD,
	YEAR_ID,
	RPT_RUN_ID,
	RPT_INSTNC_MTDTA_ID,
	ACCT_SGMNTN_TYPE_NM,
	BNCHMRK_ID,
	CLMNT_CNT_TYPE_CD,
	DIM1 AS ETG_SRVC_DIAG_DESC,
	DIM2 AS ETG_SRVC_CTGRY_DIAG_DESC,
	CLMNT_1_CNT,
	CLMNT_2_CNT,
	CLMNT_3_CNT,
	SCRTY_LVL_CD,
	current_timestamp as LOAD_DTM,
	MD5(current_timestamp) as LOAD_LOG_KEY
	FROM(
SELECT	amstp.AGRGT_ACCT_ID AS ACCT_ID, amstp.YEAR_ID AS YEAR_ID, amstp.AS_OF_YEAR_MNTH_NBR, amstp.AGRGT_SRC_FLTR_ID AS SRC_FLTR_ID, amstp.TM_PRD_TYPE_CD, amstp.INCRD_PAID_CD, amstp.BNCHMRK_ID,amstp.RPT_RUN_ID,-1 as RPT_INSTNC_MTDTA_ID,amstp.ACCT_SGMNTN_TYPE_NM,
'ETG_CGRY_TOP5_CLMNT' CLMNT_CNT_TYPE_CD,
      case when RNK_PERMS.PD_ROWNBR between 1 and 5 then 'Top5' 
      when RNK_PERMS.PD_ROWNBR >5 then 'All Other' end as DIM1,
'NA' as DIM2,
COUNT(DISTINCT fact.MCID) AS CLMNT_1_CNT,
CAST(0 as INTEGER) as CLMNT_2_CNT,
CAST(0 as INTEGER) as CLMNT_3_CNT,
amstp.SCRTY_LVL_CD
FROM ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact

INNER JOIN (SELECT DISTINCT
AS_OF_YEAR_MNTH_NBR
,ACCT_ID
,AGRGT_ACCT_ID
,SRC_FLTR_ID
,AGRGT_SRC_FLTR_ID
,TM_PRD_TYPE_CD
,INCRD_PAID_CD
,SGMNTN_DIM_KEY
,SRVC_STRT_MNTH_NBR
,SRVC_END_MNTH_NBR
,PAID_STRT_MNTH_NBR
,PAID_END_MNTH_NBR
,YEAR_ID
,ACCT_SGMNTN_TYPE_NM
,BNCHMRK_ID
,RPT_RUN_ID
,CII_SR_ACCT_SGMNTN_TM_PRD_PARM.SCRTY_LVL_CD
FROM ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM
JOIN ${aciisst_adhoc_schema_name}.CII_RUN_PRD PRD
ON PRD.RUN_YEAR_MNTH_NBR=AS_OF_YEAR_MNTH_NBR
where YEAR_ID <= 1 and RPT_SHRT_NM in ('MCC-04','MCC-04A')
 AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
 AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
AND RPT_SPRSN_IND = 'N'
) amstp
ON fact.acct_id = amstp.acct_id
AND fact.RPTG_PAID_YEAR_MNTH_NBR between amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY

INNER JOIN ${aciisst_adhoc_schema_name}.DIM_ETG_CLM_OUTPUT dim_etg
ON fact.CLM_FACT_KEY = dim_etg.CLM_ADJSTMNT_KEY
AND fact.FACT_CLM_LINE_NBR = dim_etg.CLM_LINE_NBR
AND dim_etg.ETG_RUN_DURTN_IND ='M' 


LEFT JOIN  (
SELECT	amstp.AGRGT_ACCT_ID AS ACCT_ID,amstp.AS_OF_YEAR_MNTH_NBR,amstp.AGRGT_SRC_FLTR_ID AS SRC_FLTR_ID,amstp.TM_PRD_TYPE_CD,amstp.INCRD_PAID_CD,amstp.YEAR_ID,amstp.BNCHMRK_ID
,dim_etg.ETG_CTGRY_SMRY_DESC AS ETG_CTGRY_SMRY_DESC,
ROW_NUMBER() OVER( PARTITION BY amstp.AGRGT_ACCT_ID,amstp.AS_OF_YEAR_MNTH_NBR,amstp.AGRGT_SRC_FLTR_ID,amstp.TM_PRD_TYPE_CD,amstp.INCRD_PAID_CD,amstp.YEAR_ID
ORDER BY SUM(fact.ACCT_PAID_AMT) DESC,dim_etg.ETG_CTGRY_SMRY_DESC ASC) as PD_ROWNBR
FROM ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact

--TIME PERIOD BASED ON SERVICE START AND END, ONE TIME PERIOD HERE
INNER JOIN (SELECT DISTINCT
AS_OF_YEAR_MNTH_NBR
,ACCT_ID
,AGRGT_ACCT_ID
,SRC_FLTR_ID
,AGRGT_SRC_FLTR_ID
,TM_PRD_TYPE_CD
,INCRD_PAID_CD
,SGMNTN_DIM_KEY
,SRVC_STRT_MNTH_NBR
,SRVC_END_MNTH_NBR
,PAID_STRT_MNTH_NBR
,PAID_END_MNTH_NBR
,YEAR_ID
,ACCT_SGMNTN_TYPE_NM
,BNCHMRK_ID
,RPT_RUN_ID
,CII_SR_ACCT_SGMNTN_TM_PRD_PARM.SCRTY_LVL_CD
FROM ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM
JOIN ${aciisst_adhoc_schema_name}.CII_RUN_PRD PRD
ON PRD.RUN_YEAR_MNTH_NBR=AS_OF_YEAR_MNTH_NBR
where YEAR_ID <= 1 and RPT_SHRT_NM in ('MCC-04','MCC-04A')
 AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
 AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
AND RPT_SPRSN_IND = 'N') amstp
ON fact.acct_id = amstp.acct_id
AND fact.RPTG_PAID_YEAR_MNTH_NBR between amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY

INNER JOIN  ${aciisst_adhoc_schema_name}.DIM_ETG_CLM_OUTPUT dim_etg
ON fact.CLM_FACT_KEY = dim_etg.CLM_ADJSTMNT_KEY
AND fact.FACT_CLM_LINE_NBR = dim_etg.CLM_LINE_NBR 
AND dim_etg.ETG_RUN_DURTN_IND ='M'

WHERE fact.MBR_CVRG_TYPE_CD  IN ('001','102')  
AND fact.BK_FILL_IND = 'N' and amstp.YEAR_ID = 1
GROUP BY amstp.AGRGT_ACCT_ID, amstp.YEAR_ID,amstp.AS_OF_YEAR_MNTH_NBR,amstp.AGRGT_SRC_FLTR_ID,amstp.TM_PRD_TYPE_CD,amstp.INCRD_PAID_CD,
amstp.BNCHMRK_ID,dim_etg.ETG_CTGRY_SMRY_DESC) RNK_PERMS
ON amstp.ACCT_ID = RNK_PERMS.ACCT_ID
AND dim_etg.ETG_CTGRY_SMRY_DESC = RNK_PERMS.ETG_CTGRY_SMRY_DESC
AND amstp.BNCHMRK_ID = RNK_PERMS.BNCHMRK_ID
AND amstp.SRC_FLTR_ID = RNK_PERMS.SRC_FLTR_ID
AND amstp.TM_PRD_TYPE_CD = RNK_PERMS.TM_PRD_TYPE_CD
AND amstp.INCRD_PAID_CD = RNK_PERMS.INCRD_PAID_CD
AND amstp.AS_OF_YEAR_MNTH_NBR = RNK_PERMS.AS_OF_YEAR_MNTH_NBR
AND amstp.YEAR_ID = RNK_PERMS.YEAR_ID

group by amstp.AGRGT_ACCT_ID , amstp.YEAR_ID , amstp.AS_OF_YEAR_MNTH_NBR, amstp.AGRGT_SRC_FLTR_ID , 
      amstp.TM_PRD_TYPE_CD, amstp.INCRD_PAID_CD, amstp.BNCHMRK_ID,
      case when RNK_PERMS.PD_ROWNBR between 1 and 5 then 'Top5' 
      when RNK_PERMS.PD_ROWNBR >5 then 'All Other' end,
      amstp.RPT_RUN_ID,amstp.ACCT_SGMNTN_TYPE_NM,amstp.SCRTY_LVL_CD
)

WHERE 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_ETG_MDCL_CLMNT_UTILZN_DTL
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR);

insert  into CII_EVOLVE.CII_SR_ETG_MDCL_CLMNT_UTILZN_DTL
SELECT distinct
AS_OF_YEAR_MNTH_NBR,
INCRD_PAID_CD,
SRC_FLTR_ID,
ACCT_ID,
TM_PRD_TYPE_CD,
YEAR_ID,
RPT_RUN_ID,
RPT_INSTNC_MTDTA_ID,
ACCT_SGMNTN_TYPE_NM,
BNCHMRK_ID,
CLMNT_CNT_TYPE_CD,
DIM1 AS ETG_SRVC_DIAG_DESC,
DIM2 AS ETG_SRVC_CTGRY_DIAG_DESC,
CLMNT_1_CNT,
CLMNT_2_CNT,
CLMNT_3_CNT,
SCRTY_LVL_CD,
current_timestamp as LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY
	FROM(
SELECT	amstp.AGRGT_ACCT_ID AS ACCT_ID, amstp.YEAR_ID AS YEAR_ID, amstp.AS_OF_YEAR_MNTH_NBR, amstp.AGRGT_SRC_FLTR_ID AS SRC_FLTR_ID, amstp.TM_PRD_TYPE_CD, amstp.INCRD_PAID_CD, amstp.BNCHMRK_ID,amstp.RPT_RUN_ID,-1 as RPT_INSTNC_MTDTA_ID,amstp.ACCT_SGMNTN_TYPE_NM,
'ETG_TTL_CLMNT' as CLMNT_CNT_TYPE_CD,
'NA' as DIM1,
'NA' as DIM2,
COUNT(DISTINCT fact.MCID) AS CLMNT_1_CNT,
CAST(0 as INTEGER) as CLMNT_2_CNT,
CAST(0 as INTEGER) as CLMNT_3_CNT,
amstp.SCRTY_LVL_CD
FROM ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact

INNER JOIN (SELECT DISTINCT
AS_OF_YEAR_MNTH_NBR
,ACCT_ID
,AGRGT_ACCT_ID
,SRC_FLTR_ID
,AGRGT_SRC_FLTR_ID
,TM_PRD_TYPE_CD
,INCRD_PAID_CD
,SGMNTN_DIM_KEY
,SRVC_STRT_MNTH_NBR
,SRVC_END_MNTH_NBR
,PAID_STRT_MNTH_NBR
,PAID_END_MNTH_NBR
,YEAR_ID
,ACCT_SGMNTN_TYPE_NM
,BNCHMRK_ID
,RPT_RUN_ID
,CII_SR_ACCT_SGMNTN_TM_PRD_PARM.SCRTY_LVL_CD
FROM ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM
JOIN ${aciisst_adhoc_schema_name}.CII_RUN_PRD PRD
ON PRD.RUN_YEAR_MNTH_NBR=AS_OF_YEAR_MNTH_NBR
where YEAR_ID <= 1 and RPT_SHRT_NM in ('MCC-04','MCC-04A')
 AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
 AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
AND RPT_SPRSN_IND = 'N'
) amstp
ON fact.acct_id = amstp.acct_id
AND fact.RPTG_PAID_YEAR_MNTH_NBR between amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY

INNER JOIN ${aciisst_adhoc_schema_name}.DIM_ETG_CLM_OUTPUT dim_etg
ON fact.CLM_FACT_KEY = dim_etg.CLM_ADJSTMNT_KEY
AND fact.FACT_CLM_LINE_NBR = dim_etg.CLM_LINE_NBR
AND dim_etg.ETG_RUN_DURTN_IND ='M'

group by amstp.AGRGT_ACCT_ID , amstp.YEAR_ID , amstp.AS_OF_YEAR_MNTH_NBR, amstp.AGRGT_SRC_FLTR_ID , amstp.TM_PRD_TYPE_CD, amstp.INCRD_PAID_CD, amstp.BNCHMRK_ID,amstp.RPT_RUN_ID,amstp.ACCT_SGMNTN_TYPE_NM,amstp.SCRTY_LVL_CD
)

WHERE 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_ETG_MDCL_CLMNT_UTILZN_DTL
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR);
