-----------------------------------------------------------------------------------------------------------------
-- TITLE              : DIM_CII_ER_YRLY_OFFST
-- FILENAME           : dim_cii_er_yrly_offst.sql
-- DESCRIPTION        : THIS SCRIPT LOADS DIM_CII_ER_YRLY_OFFST table
-- DEVELOPER          : LEGATO
-- CREATED ON         : 07-01-2022 (MM-DD-YYYY)
-- VERSION            : 1.0
-- VERSION DESCRIPTION: Initial Version
-----------------------------------------------------------------------------------------------------------------


INSERT overwrite into ACIISST_ADHOC.DIM_CII_ER_YRLY_OFFST select
	YRLY_OFFST_STRT_YEAR_MNTH_NBR,
	YRLY_OFFST_END_YEAR_MNTH_NBR,
	YRLY_OFFST_AMT,
    'N' AS SCRTY_LVL_CD,
	MD5(current_timestamp) as LOAD_LOG_KEY,
	current_timestamp as LOAD_DTM FROM ACIISST_VLDTN.BOT_CII_ER_YRLY_OFFST;
    
INSERT overwrite into ACIISST_ADHOC_VLDTN.DIM_CII_ER_YRLY_OFFST select
	YRLY_OFFST_STRT_YEAR_MNTH_NBR,
	YRLY_OFFST_END_YEAR_MNTH_NBR,
	YRLY_OFFST_AMT,
    'N' AS SCRTY_LVL_CD,
	MD5(current_timestamp) as LOAD_LOG_KEY,
	current_timestamp as LOAD_DTM FROM ACIISST_VLDTN.BOT_CII_ER_YRLY_OFFST
