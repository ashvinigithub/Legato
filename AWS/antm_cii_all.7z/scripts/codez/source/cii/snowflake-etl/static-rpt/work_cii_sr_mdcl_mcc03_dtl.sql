/*************************************************************************************************************
 # TITLE           : REPORT MCC03 SMRY
 # FILENAME        : work_cii_sr_mdcl_mcc03_dtl.sql
 # DESCRIPTION     : THIS SCRIPT LOADS CII_SR_MDCL_MCC03_SMRY_TEMP table
 # DEVELOPER       : LEGATO
 # CREATED ON      : 11/07/2022
 # LOGIC           : Append Data to Target Table, Overwrite only for first time Load.
 # VERSION         : 1.0
 ***************************************************************************************************************/

delete from CII_EVOLVE.CII_SR_MDCL_MCC03_DTL WHERE (AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD) AND 'YES' = ${re_run} AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})));

INSERT INTO CII_EVOLVE.CII_SR_MDCL_MCC03_DTL

SELECT DISTINCT PERMS.AS_OF_YEAR_MNTH_NBR,
PERMS.INCRD_PAID_CD,
PERMS.AGRGT_SRC_FLTR_ID AS SRC_FLTR_ID,
PERMS.AGRGT_ACCT_ID AS ACCT_ID,
PERMS.TM_PRD_TYPE_CD,
PERMS.YEAR_ID,
PERMS.RPT_RUN_ID,
PERMS.RPT_INSTNC_MTDTA_ID, 
PERMS.BNCHMRK_ID,
perms.ACCT_SGMNTN_TYPE_NM,
FACT2.RULE_ID,
COALESCE(FACT2.RPTG_CMPLNC_RULE_NM,'NA') AS RPTG_CMPLNC_RULE_NM,
COALESCE(FACT2.CP_ELGBL_CNT,0) AS CP_ELGBL_CNT,
COALESCE(FACT2.PP_ELGBL_CNT,0) AS PP_ELGBL_CNT,
COALESCE(FACT2.CP_RCVNG_CARE_CNT,0) AS CP_RCVG_CARE_CNT,
COALESCE(FACT2.PP_RCVNG_CARE_CNT,0) AS PP_RCVG_CARE_CNT,
COALESCE(FACT2.RTN_CMPLNCE_CNT,0) AS RETAIN_CMPLNC_CNT,
COALESCE(FACT2.RTN_CMPLNC_TTL_CNT,0) AS TOTL_RETAIN_CMPLNC_CNT,
perms.SCRTY_LVL_CD,
current_timestamp as LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY

FROM
(SELECT DISTINCT amstp.AS_OF_YEAR_MNTH_NBR,
         INCRD_PAID_CD,
         SRC_FLTR_ID, AGRGT_SRC_FLTR_ID,
         ACCT_ID, AGRGT_ACCT_ID,
         TM_PRD_TYPE_CD,
         YEAR_ID,
         RPT_INSTNC_MTDTA_ID,
         amstp.SCRTY_LVL_CD,
         BNCHMRK_ID,
         ACCT_SGMNTN_TYPE_NM,
         RPT_RUN_ID
                               
         FROM ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM amstp 
         JOIN ${aciisst_adhoc_schema_name}.CII_RUN_PRD PRD
         ON TRIM(PRD.RUN_YEAR_MNTH_NBR)=TRIM(amstp.AS_OF_YEAR_MNTH_NBR)
         
        WHERE YEAR_ID = 1  AND RPT_SHRT_NM IN ('MCC-03', 'BNCHMRK')
       AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
       AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
       AND RPT_SPRSN_IND = 'N') PERMS
                                                                  
LEFT JOIN 

(SELECT RULE_ID, RPTG_CMPLNC_RULE_NM,ACCT_ID as ACCT_ID,SRC_FLTR_ID as SRC_FLTR_ID,BNCHMRK_ID,
TM_PRD_TYPE_CD as TM_PRD_TYPE_CD,INCRD_PAID_CD as INCRD_PAID_CD,FACT1.AS_OF_YEAR_MNTH_NBR as AS_OF_YEAR_MNTH_NBR,
SUM(CP_ELGBL_IND) AS CP_ELGBL_CNT,
SUM(CP_RCVNG_CARE_IND) AS CP_RCVNG_CARE_CNT,
SUM(PP_ELGBL_IND) AS PP_ELGBL_CNT,
SUM(PP_RCVNG_CARE_IND) AS PP_RCVNG_CARE_CNT,
SUM(CASE WHEN CP_ELGBL_IND IS NOT NULL AND PP_ELGBL_IND IS NOT NULL THEN 1 ELSE 0 END) RTN_CMPLNC_TTL_CNT,
SUM(CASE WHEN CP_RCVNG_CARE_IND = 1 AND PP_RCVNG_CARE_IND = 0 THEN 1 ELSE 0 END) AS RTN_CMPLNCE_CNT from

( SELECT 
FACT.RULE_ID,
FACT.MCID,
MAX(CASE WHEN amstp.YEAR_ID = 1 THEN 1 END) AS CP_ELGBL_IND,
MAX(CASE WHEN amstp.YEAR_ID = 1 AND ((FACT.MSR_CMPLNC_CD = '02' AND FACT.RULE_ID IN ('19242','19244','18644','18645','18639','18642','18643','18641','18646','18640','19240','19241','19243')) 
OR (FACT.MSR_CMPLNC_CD = '01' AND FACT.RULE_ID NOT IN ('19242', '19244','18644','18645','18639','18642','18643','18641','18646','18640','19240','19241','19243')))
THEN 1 WHEN amstp.YEAR_ID = 1 THEN 0  END) AS CP_RCVNG_CARE_IND,
MAX(CASE WHEN amstp.YEAR_ID = 2 THEN 1 END) AS PP_ELGBL_IND,
MAX(CASE WHEN amstp.YEAR_ID = 2 AND ((FACT.MSR_CMPLNC_CD = '02' AND FACT.RULE_ID IN ('19242','19244','18644','18645','18639','18642','18643','18641','18646','18640','19240','19241','19243')) 
OR (FACT.MSR_CMPLNC_CD = '01' AND FACT.RULE_ID NOT IN ('19242', '19244','18644','18645','18639','18642','18643','18641','18646','18640','19240','19241','19243')))
THEN 1 WHEN amstp.YEAR_ID = 2 THEN 0  END) AS PP_RCVNG_CARE_IND,
DIM.RPTG_CMPLNC_RULE_NM,amstp.AGRGT_SRC_FLTR_ID AS SRC_FLTR_ID,amstp.AGRGT_ACCT_ID AS ACCT_ID ,amstp.TM_PRD_TYPE_CD ,amstp.BNCHMRK_ID ,amstp.AS_OF_YEAR_MNTH_NBR,amstp.INCRD_PAID_CD
  FROM ${aciisst_adhoc_schema_name}.CII_FACT_RHI_MBR_CMPLNC FACT 
  
  
INNER JOIN ${aciisst_adhoc_schema_name}.DIM_RULE DIM ON DIM.RULE_ID=FACT.RULE_ID

INNER JOIN 
( SELECT DISTINCT amstp.AS_OF_YEAR_MNTH_NBR
           ,amstp.INCRD_PAID_CD
           ,amstp.AGRGT_SRC_FLTR_ID
           ,amstp.AGRGT_ACCT_ID
           ,amstp.SRC_FLTR_ID
           ,amstp.ACCT_ID
           ,amstp.STRT_MNTH_NBR
           ,amstp.END_MNTH_NBR
           ,amstp.SRVC_STRT_MNTH_NBR
           ,amstp.SRVC_END_MNTH_NBR
           ,amstp.SGMNTN_DIM_KEY
           ,PAID_STRT_MNTH_NBR
           ,PAID_END_MNTH_NBR
           ,amstp.TM_PRD_TYPE_CD
           ,amstp.YEAR_ID
           ,amstp.RPT_RUN_ID
          ,amstp.RPT_INSTNC_MTDTA_ID
           ,amstp.BNCHMRK_ID
           ,amstp.ACCT_SGMNTN_TYPE_NM
           ,amstp.SCRTY_LVL_CD
        FROM ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM amstp
                    JOIN ${aciisst_adhoc_schema_name}.CII_RUN_PRD PRD ON PRD.RUN_YEAR_MNTH_NBR = amstp.AS_OF_YEAR_MNTH_NBR
                                WHERE amstp.YEAR_ID <= 2
                                AND amstp.RPT_SHRT_NM in ('MCC-03','BNCHMRK')
                                AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
                                AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
                                AND amstp.RPT_SPRSN_IND = 'N') amstp ON 
                                FACT.acct_id = amstp.acct_id
                                AND FACT.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY
								AND amstp.END_MNTH_NBR BETWEEN ANLYSS_AS_OF_STRT_YEAR_MNTH_NBR AND ANLYSS_AS_OF_END_YEAR_MNTH_NBR 
                                AND FACT.RULE_ID IN (45317,45318,44886,18644,18642,18643,18645,18646,19240,19241,19243,19518,19519)                                                                                                                              
                         GROUP BY FACT.RULE_ID,
FACT.MCID,DIM.RPTG_CMPLNC_RULE_NM,amstp.AGRGT_SRC_FLTR_ID,amstp.AGRGT_ACCT_ID ,amstp.TM_PRD_TYPE_CD ,amstp.BNCHMRK_ID,amstp.AS_OF_YEAR_MNTH_NBR,amstp.INCRD_PAID_CD
)FACT1
group by 
RULE_ID, RPTG_CMPLNC_RULE_NM ,ACCT_ID,SRC_FLTR_ID,BNCHMRK_ID,
TM_PRD_TYPE_CD,INCRD_PAID_CD,FACT1.AS_OF_YEAR_MNTH_NBR
) FACT2

                                ON PERMS.AGRGT_ACCT_ID = FACT2.ACCT_ID
                                AND PERMS.AGRGT_SRC_FLTR_ID = FACT2.SRC_FLTR_ID
                                AND PERMS.TM_PRD_TYPE_CD = FACT2.TM_PRD_TYPE_CD
                                AND PERMS.INCRD_PAID_CD = FACT2.INCRD_PAID_CD
                               AND PERMS.AS_OF_YEAR_MNTH_NBR = FACT2.AS_OF_YEAR_MNTH_NBR
							   AND PERMS.BNCHMRK_ID = FACT2.BNCHMRK_ID

WHERE FACT2.RULE_ID IS NOT NULL
  AND 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_MDCL_MCC03_DTL
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR)
;
