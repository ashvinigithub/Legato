-----------------------------------------------------------------------------------------------------------------
-- TITLE              : CII_SR_MDCL_CLMNT_UTILZN_DTL
-- FILENAME           : work_cii_sr_mdcl_clmnt_utilzn_dtl.sql
-- DESCRIPTION        : THIS SCRIPT LOADS CII_SR_MDCL_CLMNT_UTILZN_DTL table
-- DEVELOPER          : LEGATO
-- CREATED ON         : 02-23-2022 (MM-DD-YYYY)
-- LOGIC              : Append Data to Target Table, SQLs runs in Asynchronous Mode.
-- VERSION            : 1.0
-- VERSION DESCRIPTION: Initial Version
-----------------------------------------------------------------------------------------------------------------

delete from CII_EVOLVE.CII_SR_MDCL_CLMNT_UTILZN_DTL WHERE (AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD) AND 'YES' = ${re_run} AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})));

INSERT INTO CII_EVOLVE.CII_SR_MDCL_CLMNT_UTILZN_DTL
SELECT distinct
AS_OF_YEAR_MNTH_NBR,
INCRD_PAID_CD,
SRC_FLTR_ID,
ACCT_ID,
TM_PRD_TYPE_CD,
YEAR_ID,
RPT_RUN_ID,
RPT_INSTNC_MTDTA_ID,
ACCT_SGMNTN_TYPE_NM,
BNCHMRK_ID,
CLMNT_CNT_TYPE_CD,
DIM1 AS RPTG_SRVC_DIAG_DESC,
DIM2 AS RPTG_SRVC_CTGRY_DIAG_DESC,
CLMNT_1_CNT,
CLMNT_2_CNT,
CLMNT_3_CNT,
SCRTY_LVL_CD,
current_timestamp as LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY
	FROM (SELECT	amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID as SRC_FLTR_ID, amstp.AGRGT_ACCT_ID as ACCT_ID, 
	amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		'SETG_CD' as CLMNT_CNT_TYPE_CD, 
		CASE WHEN fact.SITE_SRVC_CD IN ('OP','ED') THEN 'OUTPT' WHEN fact.SITE_SRVC_CD='IP' THEN 'INPT' ELSE  'PROF' END  AS DIM1, --SRVC_SETG_CD
		'NA' as DIM2,
		'NA' as DIM3,
		COUNT(DISTINCT fact.MCID) AS CLMNT_1_CNT,
		CAST(0 as INTEGER) as CLMNT_2_CNT,
		CAST(0 as INTEGER) as CLMNT_3_CNT,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD
	FROM    ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact
    
	
	INNER JOIN 
	(SELECT DISTINCT ACCT_ID, SGMNTN_DIM_KEY, AGRGT_SRC_FLTR_ID, SRC_FLTR_ID, AGRGT_ACCT_ID, PAID_STRT_MNTH_NBR, PAID_END_MNTH_NBR, SRVC_STRT_MNTH_NBR, SRVC_END_MNTH_NBR, TM_PRD_TYPE_CD, YEAR_ID, 
INCRD_PAID_CD, AS_OF_YEAR_MNTH_NBR,RPT_RUN_ID, -1 AS RPT_INSTNC_MTDTA_ID, ACCT_SGMNTN_TYPE_NM,CII_SR_ACCT_SGMNTN_TM_PRD_PARM.SCRTY_LVL_CD, BNCHMRK_ID
from ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM
	JOIN ${aciisst_adhoc_schema_name}.CII_RUN_PRD PRD
		ON PRD.RUN_YEAR_MNTH_NBR=AS_OF_YEAR_MNTH_NBR
WHERE RPT_SHRT_NM in ('UTIL-02','UTIL-01','FIN-03','UTIL-04','UTIL-05','UTIL-02A','BNCHMRK')
AND YEAR_ID <= 3 
AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
   AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
AND RPT_SPRSN_IND = 'N'
) amstp	
		ON fact.acct_id = amstp.acct_id
		AND fact.RPTG_PAID_YEAR_MNTH_NBR between  amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
		AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
		AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY
		WHERE fact.MBR_CVRG_TYPE_CD = '001' AND fact.BK_FILL_IND = 'N'
	GROUP BY amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID, amstp.AGRGT_ACCT_ID , amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
			CASE WHEN fact.SITE_SRVC_CD IN ('OP','ED') THEN 'OUTPT' WHEN fact.SITE_SRVC_CD='IP' THEN 'INPT' ELSE  'PROF' END,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD)
        
WHERE 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_MDCL_CLMNT_UTILZN_DTL
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR)

UNION ALL
		
SELECT distinct
AS_OF_YEAR_MNTH_NBR,
INCRD_PAID_CD,
SRC_FLTR_ID,
ACCT_ID,
TM_PRD_TYPE_CD,
YEAR_ID,
RPT_RUN_ID,
RPT_INSTNC_MTDTA_ID,
ACCT_SGMNTN_TYPE_NM,
BNCHMRK_ID,
CLMNT_CNT_TYPE_CD,
DIM1 AS RPTG_SRVC_DIAG_DESC,
DIM2 AS RPTG_SRVC_CTGRY_DIAG_DESC,
CLMNT_1_CNT,
CLMNT_2_CNT,
CLMNT_3_CNT,
SCRTY_LVL_CD,
current_timestamp as LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY
	FROM (SELECT	amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID as SRC_FLTR_ID, amstp.AGRGT_ACCT_ID as ACCT_ID, 
	amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		'SETG_CD_ABC' as CLMNT_CNT_TYPE_CD, 
		CASE WHEN fact.SITE_SRVC_CD IN ('OP','ED') THEN 'OUTPT' WHEN fact.SITE_SRVC_CD='IP' THEN 'INPT' ELSE  'PROF' END  AS DIM1, --SRVC_SETG_CD
		dsc.SRVC_SETG_NM as DIM2,
		'NA' as DIM3,
		COUNT(DISTINCT fact.MCID) AS CLMNT_1_CNT,
		CAST(0 as INTEGER) as CLMNT_2_CNT,
		CAST(0 as INTEGER) as CLMNT_3_CNT,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD
	FROM    ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact
    JOIN ${aciisst_adhoc_schema_name}.DIM_SRVC_CTGRY dsc on fact.SRVC_CTGRY_CD  = dsc.SRVC_CTGRY_CD
	
	INNER JOIN 
	(SELECT DISTINCT ACCT_ID, SGMNTN_DIM_KEY, AGRGT_SRC_FLTR_ID, SRC_FLTR_ID, AGRGT_ACCT_ID, PAID_STRT_MNTH_NBR, PAID_END_MNTH_NBR, SRVC_STRT_MNTH_NBR, SRVC_END_MNTH_NBR, TM_PRD_TYPE_CD, YEAR_ID, 
INCRD_PAID_CD, AS_OF_YEAR_MNTH_NBR,RPT_RUN_ID, -1 AS RPT_INSTNC_MTDTA_ID, ACCT_SGMNTN_TYPE_NM,CII_SR_ACCT_SGMNTN_TM_PRD_PARM.SCRTY_LVL_CD, BNCHMRK_ID
from ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM
	JOIN ${aciisst_adhoc_schema_name}.CII_RUN_PRD PRD
		ON PRD.RUN_YEAR_MNTH_NBR=AS_OF_YEAR_MNTH_NBR
WHERE RPT_SHRT_NM in ('UTIL-01C','UTIL-01B','UTIL-01A','BNCHMRK')
AND YEAR_ID <= 3 
AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
   AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
AND RPT_SPRSN_IND = 'N'
) amstp	
		ON fact.acct_id = amstp.acct_id
		AND fact.RPTG_PAID_YEAR_MNTH_NBR between  amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
		AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
		AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY
		WHERE fact.MBR_CVRG_TYPE_CD = '001' AND fact.BK_FILL_IND = 'N'
	GROUP BY amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID, amstp.AGRGT_ACCT_ID , amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
			CASE WHEN fact.SITE_SRVC_CD IN ('OP','ED') THEN 'OUTPT' WHEN fact.SITE_SRVC_CD='IP' THEN 'INPT' ELSE  'PROF' END,dsc.SRVC_SETG_NM,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD)

WHERE 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_MDCL_CLMNT_UTILZN_DTL
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR)

UNION ALL

SELECT distinct
AS_OF_YEAR_MNTH_NBR,
INCRD_PAID_CD,
SRC_FLTR_ID,
ACCT_ID,
TM_PRD_TYPE_CD,
YEAR_ID,
RPT_RUN_ID,
RPT_INSTNC_MTDTA_ID,
ACCT_SGMNTN_TYPE_NM,
BNCHMRK_ID,
CLMNT_CNT_TYPE_CD,
DIM1 AS RPTG_SRVC_DIAG_DESC,
DIM2 AS RPTG_SRVC_CTGRY_DIAG_DESC,
CLMNT_1_CNT,
CLMNT_2_CNT,
CLMNT_3_CNT,
SCRTY_LVL_CD,
current_timestamp as LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY
	FROM (SELECT	amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID as SRC_FLTR_ID, amstp.AGRGT_ACCT_ID as ACCT_ID, 
	amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		'SETG_CD_ABC' as CLMNT_CNT_TYPE_CD, 
		CASE WHEN fact.SITE_SRVC_CD IN ('OP','ED') THEN 'OUTPT' WHEN fact.SITE_SRVC_CD='IP' THEN 'INPT' ELSE  'PROF' END  AS DIM1, --SRVC_SETG_CD
		'Telehealth' as DIM2,
		'NA' as DIM3,
		COUNT(DISTINCT fact.MCID) AS CLMNT_1_CNT,
		CAST(0 as INTEGER) as CLMNT_2_CNT,
		CAST(0 as INTEGER) as CLMNT_3_CNT,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD
	FROM    ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact
	JOIN ${aciisst_adhoc_schema_name}.DIM_SRVC_CTGRY dsc on fact.SRVC_CTGRY_CD  = dsc.SRVC_CTGRY_CD
	
	INNER JOIN 
	(SELECT DISTINCT ACCT_ID, SGMNTN_DIM_KEY, AGRGT_SRC_FLTR_ID, SRC_FLTR_ID, AGRGT_ACCT_ID, PAID_STRT_MNTH_NBR, PAID_END_MNTH_NBR, SRVC_STRT_MNTH_NBR, SRVC_END_MNTH_NBR, TM_PRD_TYPE_CD, YEAR_ID, 
INCRD_PAID_CD, AS_OF_YEAR_MNTH_NBR,RPT_RUN_ID, -1 AS RPT_INSTNC_MTDTA_ID, ACCT_SGMNTN_TYPE_NM,CII_SR_ACCT_SGMNTN_TM_PRD_PARM.SCRTY_LVL_CD, BNCHMRK_ID
from ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM
	JOIN ${aciisst_adhoc_schema_name}.CII_RUN_PRD PRD
		ON PRD.RUN_YEAR_MNTH_NBR=AS_OF_YEAR_MNTH_NBR
WHERE RPT_SHRT_NM in ('UTIL-01C','UTIL-01B','UTIL-01A','BNCHMRK')
AND YEAR_ID <= 3 
AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
   AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
AND RPT_SPRSN_IND = 'N'
) amstp	
		ON fact.acct_id = amstp.acct_id
		AND fact.RPTG_PAID_YEAR_MNTH_NBR between  amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
		AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
		AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY
		WHERE fact.MBR_CVRG_TYPE_CD = '001' AND fact.BK_FILL_IND = 'N' AND TLHLTH_SRVC_IND='Y'
	GROUP BY amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID, amstp.AGRGT_ACCT_ID , amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
			CASE WHEN fact.SITE_SRVC_CD IN ('OP','ED') THEN 'OUTPT' WHEN fact.SITE_SRVC_CD='IP' THEN 'INPT' ELSE  'PROF' END,
			dsc.SRVC_SETG_NM ,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD)
        
WHERE 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_MDCL_CLMNT_UTILZN_DTL
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR)		

UNION ALL
		
SELECT distinct
AS_OF_YEAR_MNTH_NBR,
INCRD_PAID_CD,
SRC_FLTR_ID,
ACCT_ID,
TM_PRD_TYPE_CD,
YEAR_ID,
RPT_RUN_ID,
RPT_INSTNC_MTDTA_ID,
ACCT_SGMNTN_TYPE_NM,
BNCHMRK_ID,
CLMNT_CNT_TYPE_CD,
DIM1 AS RPTG_SRVC_DIAG_DESC,
DIM2 AS RPTG_SRVC_CTGRY_DIAG_DESC,
CLMNT_1_CNT,
CLMNT_2_CNT,
CLMNT_3_CNT,
SCRTY_LVL_CD,
current_timestamp as LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY
	FROM (
SELECT	amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID as SRC_FLTR_ID, amstp.AGRGT_ACCT_ID as ACCT_ID, amstp.YEAR_ID,amstp.TM_PRD_TYPE_CD,
		'SETG_TYPE' as CLMNT_CNT_TYPE_CD,
		CASE WHEN fact.SITE_SRVC_CD = 'IP' AND fact.SRVC_CTGRY_CD NOT IN ('IP106','IP109') THEN 'IPACUTE'
				 WHEN fact.SITE_SRVC_CD = 'PROF' THEN COALESCE(CASE WHEN TXNMY_CTGRY_CD='SPEC_PROV' THEN 'Specialty - Provider'WHEN TXNMY_CTGRY_CD='SPEC_ANC' THEN 'Specialty - Ancillary'WHEN TXNMY_CTGRY_CD='SPEC_FAC' THEN 'Specialty - Facility'WHEN TXNMY_CTGRY_CD='PRMRY_CARE' THEN 'PCP'WHEN TXNMY_CTGRY_CD='SPEC_PRV_O' THEN 'Specialty - Provider Other'ELSE 'Specialty Other' END ,'NA') ELSE fact.SITE_SRVC_CD END AS DIM1,--SETG_TYPE,
		'NA' as DIM2,
		'NA' as DIM3,		
		COUNT(DISTINCT fact.MCID) AS CLMNT_1_CNT,
		CAST(0 as INTEGER) as CLMNT_2_CNT,
		CAST(0 as INTEGER) as CLMNT_3_CNT,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD
	FROM    ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact
	INNER JOIN (SELECT DISTINCT ACCT_ID, SGMNTN_DIM_KEY, AGRGT_SRC_FLTR_ID, SRC_FLTR_ID, AGRGT_ACCT_ID, PAID_STRT_MNTH_NBR, PAID_END_MNTH_NBR, SRVC_STRT_MNTH_NBR, SRVC_END_MNTH_NBR, TM_PRD_TYPE_CD, YEAR_ID, 
INCRD_PAID_CD, AS_OF_YEAR_MNTH_NBR,RPT_RUN_ID, -1 AS RPT_INSTNC_MTDTA_ID, ACCT_SGMNTN_TYPE_NM,CII_SR_ACCT_SGMNTN_TM_PRD_PARM.SCRTY_LVL_CD, BNCHMRK_ID
from ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM
	JOIN ${aciisst_adhoc_schema_name}.CII_RUN_PRD PRD
		ON PRD.RUN_YEAR_MNTH_NBR=AS_OF_YEAR_MNTH_NBR
WHERE RPT_SHRT_NM in ('UTIL-02','UTIL-01C','UTIL-01B','UTIL-01A','UTIL-01','FIN-03','UTIL-04','UTIL-05','UTIL-02A','BNCHMRK')
AND YEAR_ID <= 3 
AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
   AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
AND RPT_SPRSN_IND = 'N'
 ) amstp 
		ON fact.acct_id = amstp.acct_id
		AND fact.RPTG_PAID_YEAR_MNTH_NBR between  amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
		AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
		AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY
	LEFT JOIN (SELECT DISTINCT RPTG_TXNMY_CD,TXNMY_CTGRY_CD FROM ${aciisst_adhoc_schema_name}.DIM_RPTG_TXNMY) AS DIM_RPTG_TXNMY
		ON FACT.RPTG_TXNMY_CD = DIM_RPTG_TXNMY.RPTG_TXNMY_CD 
		WHERE fact.MBR_CVRG_TYPE_CD = '001' AND fact.BK_FILL_IND = 'N'
		GROUP BY amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID , amstp.AGRGT_ACCT_ID  , amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		CASE WHEN fact.SITE_SRVC_CD = 'IP' AND fact.SRVC_CTGRY_CD NOT IN ('IP106','IP109') THEN 'IPACUTE'
				 WHEN fact.SITE_SRVC_CD = 'PROF' THEN COALESCE(CASE WHEN TXNMY_CTGRY_CD='SPEC_PROV' THEN 'Specialty - Provider'WHEN TXNMY_CTGRY_CD='SPEC_ANC' THEN 'Specialty - Ancillary'WHEN TXNMY_CTGRY_CD='SPEC_FAC' THEN 'Specialty - Facility'WHEN TXNMY_CTGRY_CD='PRMRY_CARE' THEN 'PCP'WHEN TXNMY_CTGRY_CD='SPEC_PRV_O' THEN 'Specialty - Provider Other'ELSE 'Specialty Other' END ,'NA') ELSE fact.SITE_SRVC_CD END ,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD )

WHERE 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_MDCL_CLMNT_UTILZN_DTL
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR)

UNION ALL	
		
SELECT	distinct amstp.AS_OF_YEAR_MNTH_NBR,
 amstp.INCRD_PAID_CD,
 amstp.AGRGT_SRC_FLTR_ID as SRC_FLTR_ID, 
 amstp.AGRGT_ACCT_ID as ACCT_ID,
 amstp.TM_PRD_TYPE_CD,
 amstp.YEAR_ID,	
amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		'SETG_TYPE' as CLMNT_CNT_TYPE_CD,
		'SPEC'AS RPTG_SRVC_DIAG_DESC,
		'NA' as RPTG_SRVC_CTGRY_DIAG_DESC,
		COUNT(DISTINCT fact.MCID) AS CLMNT_1_CNT,
		CAST(0 as INTEGER) as CLMNT_2_CNT,
		CAST(0 as INTEGER) as CLMNT_3_CNT,
		amstp.SCRTY_LVL_CD,
		current_timestamp as LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY
	FROM    ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact	
	INNER JOIN (SELECT DISTINCT ACCT_ID, SGMNTN_DIM_KEY, AGRGT_SRC_FLTR_ID, SRC_FLTR_ID, AGRGT_ACCT_ID, PAID_STRT_MNTH_NBR, PAID_END_MNTH_NBR, SRVC_STRT_MNTH_NBR, SRVC_END_MNTH_NBR, TM_PRD_TYPE_CD, YEAR_ID, 	
INCRD_PAID_CD, AS_OF_YEAR_MNTH_NBR,RPT_RUN_ID, -1 AS RPT_INSTNC_MTDTA_ID, ACCT_SGMNTN_TYPE_NM,CII_SR_ACCT_SGMNTN_TM_PRD_PARM.SCRTY_LVL_CD, BNCHMRK_ID		
from ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM		
	JOIN ${aciisst_adhoc_schema_name}.CII_RUN_PRD PRD	
		ON PRD.RUN_YEAR_MNTH_NBR=AS_OF_YEAR_MNTH_NBR
WHERE RPT_SHRT_NM in ('UTIL-02','UTIL-01C','UTIL-01B','UTIL-01A','UTIL-01','FIN-03','UTIL-04','UTIL-05','UTIL-02A','BNCHMRK')		
AND YEAR_ID <= 3 		
AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
   AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
AND RPT_SPRSN_IND = 'N'		
 ) amstp 		
		ON fact.acct_id = amstp.acct_id
		AND fact.RPTG_PAID_YEAR_MNTH_NBR between  amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
		AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
		AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY
	LEFT JOIN (SELECT DISTINCT RPTG_TXNMY_CD,TXNMY_CTGRY_CD FROM ${aciisst_adhoc_schema_name}.DIM_RPTG_TXNMY) AS DIM_RPTG_TXNMY	
		ON FACT.RPTG_TXNMY_CD = DIM_RPTG_TXNMY.RPTG_TXNMY_CD 
		WHERE fact.MBR_CVRG_TYPE_CD = '001' AND fact.BK_FILL_IND = 'N'
		and fact.SITE_SRVC_CD = 'PROF' and DIM_RPTG_TXNMY.TXNMY_CTGRY_CD not in  ('PRMRY_CARE')
        AND 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
                             when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
                             when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
                             when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
                        FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
                    LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_MDCL_CLMNT_UTILZN_DTL
                        WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
                           on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR)

GROUP BY amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID , amstp.AGRGT_ACCT_ID  , amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		'SPEC',
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD 

UNION ALL

SELECT distinct
AS_OF_YEAR_MNTH_NBR,
INCRD_PAID_CD,
SRC_FLTR_ID,
ACCT_ID,
TM_PRD_TYPE_CD,
YEAR_ID,
RPT_RUN_ID,
RPT_INSTNC_MTDTA_ID,
ACCT_SGMNTN_TYPE_NM,
BNCHMRK_ID,
CLMNT_CNT_TYPE_CD,
DIM1 AS RPTG_SRVC_DIAG_DESC,
DIM2 AS RPTG_SRVC_CTGRY_DIAG_DESC,
CLMNT_1_CNT,
CLMNT_2_CNT,
CLMNT_3_CNT,
SCRTY_LVL_CD,
current_timestamp as LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY
	FROM (
SELECT	amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID as SRC_FLTR_ID, amstp.AGRGT_ACCT_ID as ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		'SRVC_CTGRY' as CLMNT_CNT_TYPE_CD,
		CASE WHEN fact.SITE_SRVC_CD IN ('OP','ED') THEN 'OUTPT' WHEN fact.SITE_SRVC_CD='IP' THEN 'INPT' ELSE  'PROF' END  AS DIM1, 
		dsc.SRVC_CTGRY_NM as DIM2,
		'NA' as DIM3,			
		COUNT(DISTINCT fact.MCID) AS CLMNT_1_CNT,
		CAST(0 as INTEGER) as CLMNT_2_CNT,
		CAST(0 as INTEGER) as CLMNT_3_CNT,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD				
	FROM    ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact
	JOIN ${aciisst_adhoc_schema_name}.DIM_SRVC_CTGRY dsc on fact.SRVC_CTGRY_CD  = dsc.SRVC_CTGRY_CD
	INNER JOIN (SELECT DISTINCT ACCT_ID, SGMNTN_DIM_KEY, AGRGT_SRC_FLTR_ID, SRC_FLTR_ID, AGRGT_ACCT_ID, PAID_STRT_MNTH_NBR, PAID_END_MNTH_NBR, SRVC_STRT_MNTH_NBR, SRVC_END_MNTH_NBR, TM_PRD_TYPE_CD, YEAR_ID, 
INCRD_PAID_CD, AS_OF_YEAR_MNTH_NBR,RPT_RUN_ID, -1 AS RPT_INSTNC_MTDTA_ID, ACCT_SGMNTN_TYPE_NM,CII_SR_ACCT_SGMNTN_TM_PRD_PARM.SCRTY_LVL_CD, BNCHMRK_ID
from ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM
	JOIN ${aciisst_adhoc_schema_name}.CII_RUN_PRD PRD
		ON PRD.RUN_YEAR_MNTH_NBR=AS_OF_YEAR_MNTH_NBR
WHERE RPT_SHRT_NM in ('UTIL-02','UTIL-01C','UTIL-01B','UTIL-01A','UTIL-01','FIN-03','UTIL-04','UTIL-05','UTIL-02A','BNCHMRK')
AND YEAR_ID <= 3 
AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
   AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
AND RPT_SPRSN_IND = 'N'
 ) amstp 
		ON fact.acct_id = amstp.acct_id
		AND fact.RPTG_PAID_YEAR_MNTH_NBR between  amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
		AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
		AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY
		WHERE fact.MBR_CVRG_TYPE_CD = '001' AND fact.BK_FILL_IND = 'N'
		GROUP BY amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID , amstp.AGRGT_ACCT_ID  , amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
			CASE WHEN fact.SITE_SRVC_CD IN ('OP','ED') THEN 'OUTPT' WHEN fact.SITE_SRVC_CD='IP' THEN 'INPT' ELSE  'PROF' END,
			dsc.SRVC_CTGRY_NM,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD )

WHERE 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_MDCL_CLMNT_UTILZN_DTL
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR)

UNION ALL
		
SELECT distinct
AS_OF_YEAR_MNTH_NBR,
INCRD_PAID_CD,
SRC_FLTR_ID,
ACCT_ID,
TM_PRD_TYPE_CD,
YEAR_ID,
RPT_RUN_ID,
RPT_INSTNC_MTDTA_ID,
ACCT_SGMNTN_TYPE_NM,
BNCHMRK_ID,
CLMNT_CNT_TYPE_CD,
DIM1 AS RPTG_SRVC_DIAG_DESC,
DIM2 AS RPTG_SRVC_CTGRY_DIAG_DESC,
CLMNT_1_CNT,
CLMNT_2_CNT,
CLMNT_3_CNT,
SCRTY_LVL_CD,
current_timestamp as LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY
	FROM (
SELECT	amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID as SRC_FLTR_ID, amstp.AGRGT_ACCT_ID as ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		'SRVC_CTGRY' as CLMNT_CNT_TYPE_CD,
         'Telehealth' as DIM1,
	dsc.SRVC_CTGRY_NM as DIM2,
		'NA' as DIM3,			
		COUNT(DISTINCT fact.MCID) AS CLMNT_1_CNT,
		CAST(0 as INTEGER) as CLMNT_2_CNT,
		CAST(0 as INTEGER) as CLMNT_3_CNT,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD				
	FROM    ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact
	JOIN ${aciisst_adhoc_schema_name}.DIM_SRVC_CTGRY dsc on fact.SRVC_CTGRY_CD  = dsc.SRVC_CTGRY_CD
	INNER JOIN (SELECT DISTINCT ACCT_ID, SGMNTN_DIM_KEY, AGRGT_SRC_FLTR_ID, SRC_FLTR_ID, AGRGT_ACCT_ID, PAID_STRT_MNTH_NBR, PAID_END_MNTH_NBR, SRVC_STRT_MNTH_NBR, SRVC_END_MNTH_NBR, TM_PRD_TYPE_CD, YEAR_ID, 
INCRD_PAID_CD, AS_OF_YEAR_MNTH_NBR,RPT_RUN_ID, -1 AS RPT_INSTNC_MTDTA_ID, ACCT_SGMNTN_TYPE_NM,CII_SR_ACCT_SGMNTN_TM_PRD_PARM.SCRTY_LVL_CD, BNCHMRK_ID
from ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM
	JOIN ${aciisst_adhoc_schema_name}.CII_RUN_PRD PRD
		ON PRD.RUN_YEAR_MNTH_NBR=AS_OF_YEAR_MNTH_NBR
WHERE RPT_SHRT_NM in ('UTIL-02','UTIL-01C','UTIL-01B','UTIL-01A','UTIL-01','FIN-03','UTIL-04','UTIL-05','UTIL-02A','BNCHMRK')
AND YEAR_ID <= 3 
AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
   AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
AND RPT_SPRSN_IND = 'N'
 ) amstp 
		ON fact.acct_id = amstp.acct_id
		AND fact.RPTG_PAID_YEAR_MNTH_NBR between  amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
		AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
		AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY
		WHERE fact.MBR_CVRG_TYPE_CD = '001' AND fact.BK_FILL_IND = 'N' AND TLHLTH_SRVC_IND='Y'
		GROUP BY amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID , amstp.AGRGT_ACCT_ID  , amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
			dsc.SRVC_CTGRY_NM,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD )
		
WHERE 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_MDCL_CLMNT_UTILZN_DTL
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR)

UNION ALL
		
SELECT distinct
AS_OF_YEAR_MNTH_NBR,
INCRD_PAID_CD,
SRC_FLTR_ID,
ACCT_ID,
TM_PRD_TYPE_CD,
YEAR_ID,
RPT_RUN_ID,
RPT_INSTNC_MTDTA_ID,
ACCT_SGMNTN_TYPE_NM,
BNCHMRK_ID,
CLMNT_CNT_TYPE_CD,
DIM1 AS RPTG_SRVC_DIAG_DESC,
DIM2 AS RPTG_SRVC_CTGRY_DIAG_DESC,
CLMNT_1_CNT,
CLMNT_2_CNT,
CLMNT_3_CNT,
SCRTY_LVL_CD,
current_timestamp as LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY
	FROM (
SELECT	amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID as SRC_FLTR_ID, amstp.AGRGT_ACCT_ID as ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		'SRVC_CTGRY' as CLMNT_CNT_TYPE_CD,
		SRVC_SETG_NM as DIM1,
	dsc.SRVC_CTGRY_NM as DIM2,
		'NA' as DIM3,			
		COUNT(DISTINCT fact.MCID) AS CLMNT_1_CNT,
		CAST(0 as INTEGER) as CLMNT_2_CNT,
		CAST(0 as INTEGER) as CLMNT_3_CNT,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD				
	FROM    ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact
	JOIN ${aciisst_adhoc_schema_name}.DIM_SRVC_CTGRY dsc on fact.SRVC_CTGRY_CD  = dsc.SRVC_CTGRY_CD
	INNER JOIN (SELECT DISTINCT ACCT_ID, SGMNTN_DIM_KEY, AGRGT_SRC_FLTR_ID, SRC_FLTR_ID, AGRGT_ACCT_ID, PAID_STRT_MNTH_NBR, PAID_END_MNTH_NBR, SRVC_STRT_MNTH_NBR, SRVC_END_MNTH_NBR, TM_PRD_TYPE_CD, YEAR_ID, 
INCRD_PAID_CD, AS_OF_YEAR_MNTH_NBR,RPT_RUN_ID, -1 AS RPT_INSTNC_MTDTA_ID, ACCT_SGMNTN_TYPE_NM,CII_SR_ACCT_SGMNTN_TM_PRD_PARM.SCRTY_LVL_CD, BNCHMRK_ID
from ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM
	JOIN ${aciisst_adhoc_schema_name}.CII_RUN_PRD PRD
		ON PRD.RUN_YEAR_MNTH_NBR=AS_OF_YEAR_MNTH_NBR
WHERE RPT_SHRT_NM in ('UTIL-02','UTIL-01C','UTIL-01B','UTIL-01A','UTIL-01','FIN-03','UTIL-04','UTIL-05','UTIL-02A','BNCHMRK')
AND YEAR_ID <= 3 
AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
   AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
AND RPT_SPRSN_IND = 'N'
 ) amstp 
		ON fact.acct_id = amstp.acct_id
		AND fact.RPTG_PAID_YEAR_MNTH_NBR between  amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
		AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
		AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY
		WHERE fact.MBR_CVRG_TYPE_CD = '001' AND fact.BK_FILL_IND = 'N'
		GROUP BY amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID , amstp.AGRGT_ACCT_ID  , amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
			SRVC_SETG_NM,
			dsc.SRVC_CTGRY_NM,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD )
		
WHERE 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_MDCL_CLMNT_UTILZN_DTL
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR)

UNION ALL
		
SELECT distinct
AS_OF_YEAR_MNTH_NBR,
INCRD_PAID_CD,
SRC_FLTR_ID,
ACCT_ID,
TM_PRD_TYPE_CD,
YEAR_ID,
RPT_RUN_ID,
RPT_INSTNC_MTDTA_ID,
ACCT_SGMNTN_TYPE_NM,
BNCHMRK_ID,
CLMNT_CNT_TYPE_CD,
DIM1 AS RPTG_SRVC_DIAG_DESC,
DIM2 AS RPTG_SRVC_CTGRY_DIAG_DESC,
CLMNT_1_CNT,
CLMNT_2_CNT,
CLMNT_3_CNT,
SCRTY_LVL_CD,
current_timestamp as LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY
	FROM (
SELECT	amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID AS SRC_FLTR_ID , amstp.AGRGT_ACCT_ID AS ACCT_ID , amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		'MHSA_CLMNT' as CLMNT_CNT_TYPE_CD,
		MH_SA_CD as DIM1, 
		'NA' as DIM2,
		'NA' as DIM3,			
		COUNT(DISTINCT fact.MCID) AS CLMNT_1_CNT,
		COUNT(DISTINCT CASE WHEN RPTG_ENCNTR_CD <> 'YX' THEN fact.MCID END) as CLMNT_2_CNT,
		CAST(0 as INTEGER) as CLMNT_3_CNT,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD			
	FROM    ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact
	INNER JOIN (SELECT DISTINCT ACCT_ID, SGMNTN_DIM_KEY, AGRGT_SRC_FLTR_ID, SRC_FLTR_ID, AGRGT_ACCT_ID, PAID_STRT_MNTH_NBR, PAID_END_MNTH_NBR, SRVC_STRT_MNTH_NBR, SRVC_END_MNTH_NBR, TM_PRD_TYPE_CD, YEAR_ID, 
INCRD_PAID_CD, AS_OF_YEAR_MNTH_NBR,RPT_RUN_ID, -1 AS RPT_INSTNC_MTDTA_ID, ACCT_SGMNTN_TYPE_NM,CII_SR_ACCT_SGMNTN_TM_PRD_PARM.SCRTY_LVL_CD, BNCHMRK_ID
from ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM
	JOIN ${aciisst_adhoc_schema_name}.CII_RUN_PRD PRD
		ON PRD.RUN_YEAR_MNTH_NBR=AS_OF_YEAR_MNTH_NBR 
WHERE RPT_SHRT_NM in ('UTIL-02','UTIL-01C','UTIL-01B','UTIL-01A','UTIL-01','FIN-03','UTIL-04','UTIL-05','UTIL-02A','BNCHMRK')
AND YEAR_ID <= 3 
AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
   AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
AND RPT_SPRSN_IND = 'N'
 ) amstp 
		ON fact.acct_id = amstp.acct_id
		AND fact.RPTG_PAID_YEAR_MNTH_NBR between  amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
		AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
		AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY
		WHERE fact.MBR_CVRG_TYPE_CD = '001' AND MH_SA_CD NOT IN ('NA'	,'-3') AND fact.BK_FILL_IND = 'N'
		GROUP BY amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID , amstp.AGRGT_ACCT_ID  , amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
			MH_SA_CD,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD )
		
WHERE 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_MDCL_CLMNT_UTILZN_DTL
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR)

UNION ALL
		
SELECT distinct
AS_OF_YEAR_MNTH_NBR,
INCRD_PAID_CD,
SRC_FLTR_ID,
ACCT_ID,
TM_PRD_TYPE_CD,
YEAR_ID,
RPT_RUN_ID,
RPT_INSTNC_MTDTA_ID,
ACCT_SGMNTN_TYPE_NM,
BNCHMRK_ID,
CLMNT_CNT_TYPE_CD,
DIM1 AS RPTG_SRVC_DIAG_DESC,
DIM2 AS RPTG_SRVC_CTGRY_DIAG_DESC,
CLMNT_1_CNT,
CLMNT_2_CNT,
CLMNT_3_CNT,
SCRTY_LVL_CD,
current_timestamp as LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY
	FROM (
SELECT	amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID AS SRC_FLTR_ID , amstp.AGRGT_ACCT_ID AS ACCT_ID , amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		'BHSACLMNT' as CLMNT_CNT_TYPE_CD,
		CASE WHEN DIM_DIAG.SA_DSRDR_IND = 'Y' THEN 'Substance Abuse' 
         WHEN DIM_DIAG.MH_DSRDR_IND = 'Y' THEN 'Behavioral Health' ELSE 'Other' END AS DIM1, 
		'NA' as DIM2,
		'NA' as DIM3,			
		COUNT(DISTINCT fact.MCID) AS CLMNT_1_CNT,
		CAST(0 as INTEGER) as CLMNT_2_CNT,
		CAST(0 as INTEGER) as CLMNT_3_CNT,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD			
	FROM    ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact
	INNER JOIN ${aciisst_adhoc_schema_name}.DIM_DIAG DIM_DIAG  ON fact.RPTG_PRNCPAL_DIAG_KEY = DIM_DIAG.DIAG_KEY 
	INNER JOIN (SELECT DISTINCT ACCT_ID, SGMNTN_DIM_KEY, AGRGT_SRC_FLTR_ID, SRC_FLTR_ID, AGRGT_ACCT_ID, PAID_STRT_MNTH_NBR, PAID_END_MNTH_NBR, SRVC_STRT_MNTH_NBR, SRVC_END_MNTH_NBR, TM_PRD_TYPE_CD, YEAR_ID, 
INCRD_PAID_CD, AS_OF_YEAR_MNTH_NBR,RPT_RUN_ID, -1 AS RPT_INSTNC_MTDTA_ID, ACCT_SGMNTN_TYPE_NM,CII_SR_ACCT_SGMNTN_TM_PRD_PARM.SCRTY_LVL_CD, BNCHMRK_ID
from ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM
	JOIN ${aciisst_adhoc_schema_name}.CII_RUN_PRD PRD
		ON PRD.RUN_YEAR_MNTH_NBR=AS_OF_YEAR_MNTH_NBR
WHERE RPT_SHRT_NM in ('UTIL-02','UTIL-01C','UTIL-01B','UTIL-01A','UTIL-01','FIN-03','UTIL-04','UTIL-05','UTIL-02A','BNCHMRK')
AND YEAR_ID <= 3 
AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
   AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
AND RPT_SPRSN_IND = 'N'
 ) amstp 
		ON fact.acct_id = amstp.acct_id
		AND fact.RPTG_PAID_YEAR_MNTH_NBR between  amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
		AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
		AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY
		WHERE fact.MBR_CVRG_TYPE_CD = '001' AND MH_SA_CD NOT IN ('NA'	,'-3') AND fact.BK_FILL_IND = 'N'
		GROUP BY amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID , amstp.AGRGT_ACCT_ID  , amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		CASE WHEN DIM_DIAG.SA_DSRDR_IND = 'Y' THEN 'Substance Abuse' 
         WHEN DIM_DIAG.MH_DSRDR_IND = 'Y' THEN 'Behavioral Health' ELSE 'Other' END,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD )
		
WHERE 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_MDCL_CLMNT_UTILZN_DTL
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR)

UNION ALL
		
SELECT distinct
AS_OF_YEAR_MNTH_NBR,
INCRD_PAID_CD,
SRC_FLTR_ID,
ACCT_ID,
TM_PRD_TYPE_CD,
YEAR_ID,
RPT_RUN_ID,
RPT_INSTNC_MTDTA_ID,
ACCT_SGMNTN_TYPE_NM,
BNCHMRK_ID,
CLMNT_CNT_TYPE_CD,
DIM1 AS RPTG_SRVC_DIAG_DESC,
DIM2 AS RPTG_SRVC_CTGRY_DIAG_DESC,
CLMNT_1_CNT,
CLMNT_2_CNT,
CLMNT_3_CNT,
SCRTY_LVL_CD,
current_timestamp as LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY
	FROM (
SELECT	amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID as SRC_FLTR_ID, amstp.AGRGT_ACCT_ID as ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		'BHSA_TTL_CLMNT' as CLMNT_CNT_TYPE_CD,
		'NA' as DIM1, 
		'NA' as DIM2,
		'NA' as DIM3,			
		COUNT(DISTINCT fact.MCID) AS CLMNT_1_CNT,
		COUNT(DISTINCT CASE WHEN RPTG_ENCNTR_CD <> 'YX' THEN fact.MCID END) as CLMNT_2_CNT,
		CAST(0 as INTEGER) as CLMNT_3_CNT,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD				
	FROM    ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact
	INNER JOIN (SELECT DISTINCT ACCT_ID, SGMNTN_DIM_KEY, AGRGT_SRC_FLTR_ID, SRC_FLTR_ID, AGRGT_ACCT_ID, PAID_STRT_MNTH_NBR, PAID_END_MNTH_NBR, SRVC_STRT_MNTH_NBR, SRVC_END_MNTH_NBR, TM_PRD_TYPE_CD, YEAR_ID, 
INCRD_PAID_CD, AS_OF_YEAR_MNTH_NBR,RPT_RUN_ID, -1 AS RPT_INSTNC_MTDTA_ID, ACCT_SGMNTN_TYPE_NM,CII_SR_ACCT_SGMNTN_TM_PRD_PARM.SCRTY_LVL_CD, BNCHMRK_ID
from ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM
	JOIN ${aciisst_adhoc_schema_name}.CII_RUN_PRD PRD
		ON PRD.RUN_YEAR_MNTH_NBR=AS_OF_YEAR_MNTH_NBR
WHERE RPT_SHRT_NM in ('UTIL-02','BNCHMRK')
AND YEAR_ID <= 3 
AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
   AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
AND RPT_SPRSN_IND = 'N'
 ) amstp 
		ON fact.acct_id = amstp.acct_id
		AND fact.RPTG_PAID_YEAR_MNTH_NBR between  amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
		AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
		AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY
		WHERE fact.MBR_CVRG_TYPE_CD = '001' AND fact.BK_FILL_IND = 'N' AND fact.MH_SA_NM <> 'NA'
		GROUP BY amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID , amstp.AGRGT_ACCT_ID , amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD )
		
WHERE 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_MDCL_CLMNT_UTILZN_DTL
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR)

UNION ALL
		
SELECT distinct
AS_OF_YEAR_MNTH_NBR,
INCRD_PAID_CD,
SRC_FLTR_ID,
ACCT_ID,
TM_PRD_TYPE_CD,
YEAR_ID,
RPT_RUN_ID,
RPT_INSTNC_MTDTA_ID,
ACCT_SGMNTN_TYPE_NM,
BNCHMRK_ID,
CLMNT_CNT_TYPE_CD,
DIM1 AS RPTG_SRVC_DIAG_DESC,
DIM2 AS RPTG_SRVC_CTGRY_DIAG_DESC,
CLMNT_1_CNT,
CLMNT_2_CNT,
CLMNT_3_CNT,
SCRTY_LVL_CD,
current_timestamp as LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY
	FROM (
SELECT	amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID as SRC_FLTR_ID, amstp.AGRGT_ACCT_ID as ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		'TTL_CLMNT' as CLMNT_CNT_TYPE_CD,
		'NA' as DIM1, 
		'NA' as DIM2,
		'NA' as DIM3,			
		COUNT(DISTINCT fact.MCID) AS CLMNT_1_CNT,
		COUNT(DISTINCT CASE WHEN RPTG_ENCNTR_CD <> 'YX' THEN fact.MCID END) as CLMNT_2_CNT,
		CAST(0 as INTEGER) as CLMNT_3_CNT,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD				
	FROM    ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact
	INNER JOIN (SELECT DISTINCT ACCT_ID, SGMNTN_DIM_KEY, AGRGT_SRC_FLTR_ID, SRC_FLTR_ID, AGRGT_ACCT_ID, PAID_STRT_MNTH_NBR, PAID_END_MNTH_NBR, SRVC_STRT_MNTH_NBR, SRVC_END_MNTH_NBR, TM_PRD_TYPE_CD, YEAR_ID, 
INCRD_PAID_CD, AS_OF_YEAR_MNTH_NBR,RPT_RUN_ID, -1 AS RPT_INSTNC_MTDTA_ID, ACCT_SGMNTN_TYPE_NM,CII_SR_ACCT_SGMNTN_TM_PRD_PARM.SCRTY_LVL_CD, BNCHMRK_ID
from ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM
	JOIN ${aciisst_adhoc_schema_name}.CII_RUN_PRD PRD
		ON PRD.RUN_YEAR_MNTH_NBR=AS_OF_YEAR_MNTH_NBR
WHERE RPT_SHRT_NM in ('UTIL-02','UTIL-01C','UTIL-01B','UTIL-01A','UTIL-01','FIN-03','UTIL-04','UTIL-05','UTIL-02A','BNCHMRK')
AND YEAR_ID <= 3 
AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
   AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
AND RPT_SPRSN_IND = 'N'
 ) amstp 
		ON fact.acct_id = amstp.acct_id
		AND fact.RPTG_PAID_YEAR_MNTH_NBR between  amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
		AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
		AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY
		WHERE fact.MBR_CVRG_TYPE_CD = '001' AND fact.BK_FILL_IND = 'N'
		GROUP BY amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID , amstp.AGRGT_ACCT_ID , amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD )
		
WHERE 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_MDCL_CLMNT_UTILZN_DTL
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR)

UNION ALL
		
SELECT distinct
AS_OF_YEAR_MNTH_NBR,
INCRD_PAID_CD,
SRC_FLTR_ID,
ACCT_ID,
TM_PRD_TYPE_CD,
YEAR_ID,
RPT_RUN_ID,
RPT_INSTNC_MTDTA_ID,
ACCT_SGMNTN_TYPE_NM,
BNCHMRK_ID,
CLMNT_CNT_TYPE_CD,
DIM1 AS RPTG_SRVC_DIAG_DESC,
DIM2 AS RPTG_SRVC_CTGRY_DIAG_DESC,
CLMNT_1_CNT,
CLMNT_2_CNT,
CLMNT_3_CNT,
SCRTY_LVL_CD,
current_timestamp as LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY
	FROM (
SELECT	amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID AS SRC_FLTR_ID , amstp.AGRGT_ACCT_ID AS ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		'BH_DTL_CLMNT' as CLMNT_CNT_TYPE_CD,
		MH_SA_CD as DIM1, 
		CASE WHEN DIM_DIAG.SA_DSRDR_IND = 'Y' THEN 'Substance Abuse' 
         WHEN DIM_DIAG.MH_DSRDR_IND = 'Y' THEN 'Behavioral Health' ELSE 'Other' END as DIM2,
		'NA' as DIM3,			
		COUNT(DISTINCT fact.MCID) AS CLMNT_1_CNT,
		COUNT(DISTINCT CASE WHEN RPTG_ENCNTR_CD <> 'YX'  THEN fact.MCID END)  as CLMNT_2_CNT,
		CAST(0 as INTEGER) as CLMNT_3_CNT,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD		
	FROM    ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact
	INNER JOIN ${aciisst_adhoc_schema_name}.DIM_DIAG DIM_DIAG  ON fact.RPTG_PRNCPAL_DIAG_KEY = DIM_DIAG.DIAG_KEY 	
	INNER JOIN (SELECT DISTINCT ACCT_ID, SGMNTN_DIM_KEY, AGRGT_SRC_FLTR_ID, SRC_FLTR_ID, AGRGT_ACCT_ID, PAID_STRT_MNTH_NBR, PAID_END_MNTH_NBR, SRVC_STRT_MNTH_NBR, SRVC_END_MNTH_NBR, TM_PRD_TYPE_CD, YEAR_ID, 
INCRD_PAID_CD, AS_OF_YEAR_MNTH_NBR,RPT_RUN_ID, -1 AS RPT_INSTNC_MTDTA_ID, ACCT_SGMNTN_TYPE_NM,CII_SR_ACCT_SGMNTN_TM_PRD_PARM.SCRTY_LVL_CD, BNCHMRK_ID
from ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM
	JOIN ${aciisst_adhoc_schema_name}.CII_RUN_PRD PRD
		ON PRD.RUN_YEAR_MNTH_NBR=AS_OF_YEAR_MNTH_NBR 
WHERE RPT_SHRT_NM in ('UTIL-02','UTIL-01C','UTIL-01B','UTIL-01A','UTIL-01','FIN-03','UTIL-04','UTIL-05','UTIL-02A','BNCHMRK')
AND YEAR_ID <= 3 
AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
   AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
AND RPT_SPRSN_IND = 'N'
 ) amstp 
		ON fact.acct_id = amstp.acct_id
		AND fact.RPTG_PAID_YEAR_MNTH_NBR between  amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
		AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
		AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY
		WHERE fact.MBR_CVRG_TYPE_CD = '001' AND MH_SA_CD NOT IN ('NA'	,'-3') AND fact.BK_FILL_IND = 'N'
		GROUP BY amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID, amstp.AGRGT_ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		MH_SA_CD, 
		CASE WHEN DIM_DIAG.SA_DSRDR_IND = 'Y' THEN 'Substance Abuse' 
         WHEN DIM_DIAG.MH_DSRDR_IND = 'Y' THEN 'Behavioral Health' ELSE 'Other' END,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD )
		
WHERE 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_MDCL_CLMNT_UTILZN_DTL
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR)

UNION ALL
		
SELECT distinct
AS_OF_YEAR_MNTH_NBR,
INCRD_PAID_CD,
SRC_FLTR_ID,
ACCT_ID,
TM_PRD_TYPE_CD,
YEAR_ID,
RPT_RUN_ID,
RPT_INSTNC_MTDTA_ID,
ACCT_SGMNTN_TYPE_NM,
BNCHMRK_ID,
CLMNT_CNT_TYPE_CD,
DIM1 AS RPTG_SRVC_DIAG_DESC,
DIM2 AS RPTG_SRVC_CTGRY_DIAG_DESC,
CLMNT_1_CNT,
CLMNT_2_CNT,
CLMNT_3_CNT,
SCRTY_LVL_CD,
current_timestamp as LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY
	FROM (
SELECT	amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID as SRC_FLTR_ID, amstp.AGRGT_ACCT_ID as ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		'BH_DTL_CLMNT' as CLMNT_CNT_TYPE_CD,
		'TLHLTH' as DIM1, 
		CASE WHEN DIM_DIAG.SA_DSRDR_IND = 'Y' THEN 'Substance Abuse' 
         WHEN DIM_DIAG.MH_DSRDR_IND = 'Y' THEN 'Behavioral Health' ELSE 'Other' END as DIM2,
		'NA' as DIM3,			
		COUNT(DISTINCT fact.MCID) AS CLMNT_1_CNT,
		COUNT(DISTINCT CASE WHEN RPTG_ENCNTR_CD <> 'YX'  THEN fact.MCID END)  as CLMNT_2_CNT,
		CAST(0 as INTEGER) as CLMNT_3_CNT,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD				
	FROM    ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact
	INNER JOIN ${aciisst_adhoc_schema_name}.DIM_DIAG DIM_DIAG  ON fact.RPTG_PRNCPAL_DIAG_KEY = DIM_DIAG.DIAG_KEY 	
	INNER JOIN (SELECT DISTINCT ACCT_ID, SGMNTN_DIM_KEY, AGRGT_SRC_FLTR_ID, SRC_FLTR_ID, AGRGT_ACCT_ID, PAID_STRT_MNTH_NBR, PAID_END_MNTH_NBR, SRVC_STRT_MNTH_NBR, SRVC_END_MNTH_NBR, TM_PRD_TYPE_CD, YEAR_ID, 
INCRD_PAID_CD, AS_OF_YEAR_MNTH_NBR,RPT_RUN_ID, -1 AS RPT_INSTNC_MTDTA_ID, ACCT_SGMNTN_TYPE_NM,CII_SR_ACCT_SGMNTN_TM_PRD_PARM.SCRTY_LVL_CD, BNCHMRK_ID
from ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM
	JOIN ${aciisst_adhoc_schema_name}.CII_RUN_PRD PRD
		ON PRD.RUN_YEAR_MNTH_NBR=AS_OF_YEAR_MNTH_NBR
WHERE RPT_SHRT_NM in ('UTIL-02','UTIL-01C','UTIL-01B','UTIL-01A','UTIL-01','FIN-03','UTIL-04','UTIL-05','UTIL-02A','BNCHMRK')
AND YEAR_ID <= 3 
AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
   AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
AND RPT_SPRSN_IND = 'N'
 ) amstp 
		ON fact.acct_id = amstp.acct_id
		AND fact.RPTG_PAID_YEAR_MNTH_NBR between  amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
		AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
		AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY
		WHERE fact.MBR_CVRG_TYPE_CD = '001' AND MH_SA_CD NOT IN ( 'NA','-3') AND TLHLTH_SRVC_IND='Y' AND fact.BK_FILL_IND = 'N'
		GROUP BY amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID , amstp.AGRGT_ACCT_ID , amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		
		CASE WHEN DIM_DIAG.SA_DSRDR_IND = 'Y' THEN 'Substance Abuse' 
         WHEN DIM_DIAG.MH_DSRDR_IND = 'Y' THEN 'Behavioral Health' ELSE 'Other' END,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD )
		
WHERE 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_MDCL_CLMNT_UTILZN_DTL
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR)

UNION ALL
		
SELECT distinct
AS_OF_YEAR_MNTH_NBR,
INCRD_PAID_CD,
SRC_FLTR_ID,
ACCT_ID,
TM_PRD_TYPE_CD,
YEAR_ID,
RPT_RUN_ID,
RPT_INSTNC_MTDTA_ID,
ACCT_SGMNTN_TYPE_NM,
BNCHMRK_ID,
CLMNT_CNT_TYPE_CD,
DIM1 AS RPTG_SRVC_DIAG_DESC,
DIM2 AS RPTG_SRVC_CTGRY_DIAG_DESC,
CLMNT_1_CNT,
CLMNT_2_CNT,
CLMNT_3_CNT,
SCRTY_LVL_CD,
current_timestamp as LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY
	FROM (

SELECT	amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID AS SRC_FLTR_ID , amstp.AGRGT_ACCT_ID AS ACCT_ID , amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		'MHSA_CLMNT' as CLMNT_CNT_TYPE_CD,
		'TLHLTH' as DIM1,
		'NA' as DIM2,
		'NA' as DIM3,
		COUNT(DISTINCT fact.MCID) AS CLMNT_1_CNT,
		COUNT(DISTINCT CASE WHEN RPTG_ENCNTR_CD <> 'YX' THEN fact.MCID END) as CLMNT_2_CNT,
		CAST(0 as INTEGER) as CLMNT_3_CNT,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD
	FROM    ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact
	INNER JOIN (SELECT DISTINCT ACCT_ID, SGMNTN_DIM_KEY, AGRGT_SRC_FLTR_ID, SRC_FLTR_ID, AGRGT_ACCT_ID, PAID_STRT_MNTH_NBR, PAID_END_MNTH_NBR, SRVC_STRT_MNTH_NBR, SRVC_END_MNTH_NBR, TM_PRD_TYPE_CD, YEAR_ID,
INCRD_PAID_CD, AS_OF_YEAR_MNTH_NBR,RPT_RUN_ID, -1 AS RPT_INSTNC_MTDTA_ID, ACCT_SGMNTN_TYPE_NM,CII_SR_ACCT_SGMNTN_TM_PRD_PARM.SCRTY_LVL_CD, BNCHMRK_ID
from ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM
	JOIN ${aciisst_adhoc_schema_name}.CII_RUN_PRD PRD
		ON PRD.RUN_YEAR_MNTH_NBR=AS_OF_YEAR_MNTH_NBR
WHERE RPT_SHRT_NM in ('UTIL-02','UTIL-01C','UTIL-01B','UTIL-01A','UTIL-01','FIN-03','UTIL-04','UTIL-05','UTIL-02A','BNCHMRK')
AND YEAR_ID <= 3
AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
   AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
AND RPT_SPRSN_IND = 'N'
 ) amstp
		ON fact.acct_id = amstp.acct_id
		AND fact.RPTG_PAID_YEAR_MNTH_NBR between  amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
		AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
		AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY
		WHERE fact.MBR_CVRG_TYPE_CD = '001' AND MH_SA_CD NOT IN ('NA'	,'-3') AND fact.BK_FILL_IND = 'N' AND TLHLTH_SRVC_IND='Y' AND fact.BK_FILL_IND = 'N'
		GROUP BY amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID , amstp.AGRGT_ACCT_ID  , amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
			'TLHLTH',
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD)
		
WHERE 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_MDCL_CLMNT_UTILZN_DTL
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR)

UNION ALL
		
SELECT distinct
AS_OF_YEAR_MNTH_NBR,
INCRD_PAID_CD,
SRC_FLTR_ID,
ACCT_ID,
TM_PRD_TYPE_CD,
YEAR_ID,
RPT_RUN_ID,
RPT_INSTNC_MTDTA_ID,
ACCT_SGMNTN_TYPE_NM,
BNCHMRK_ID,
CLMNT_CNT_TYPE_CD,
DIM1 AS RPTG_SRVC_DIAG_DESC,
DIM2 AS RPTG_SRVC_CTGRY_DIAG_DESC,
CLMNT_1_CNT,
CLMNT_2_CNT,
CLMNT_3_CNT,
SCRTY_LVL_CD,
current_timestamp as LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY
	FROM (
SELECT	amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID AS SRC_FLTR_ID , amstp.AGRGT_ACCT_ID AS ACCT_ID , amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		'CLMNT_ICD' as CLMNT_CNT_TYPE_CD,
		CASE WHEN BHSA_RNK.PD_RNK <=15 THEN dicc.ICD_CHPTR_CTGRY_DESC ELSE 'All Other Behavioral Health' END as DIM1, -- Add a CASE statement HERE
		'NA' as DIM2,
		'NA' as DIM3,			
		COUNT(DISTINCT fact.MCID) AS CLMNT_1_CNT,
		COUNT(DISTINCT CASE WHEN RPTG_ENCNTR_CD <> 'YX' THEN fact.MCID END) as CLMNT_2_CNT, 
		CAST(0 as INTEGER) as CLMNT_3_CNT,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD				
	FROM    ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact
	INNER JOIN ${aciisst_adhoc_schema_name}.DIM_ICD_CHPTR_CTGRY dicc  ON fact.ICD_CHPTR_CTGRY_KEY = dicc.ICD_CHPTR_CTGRY_KEY 
	INNER JOIN (SELECT DISTINCT ACCT_ID, SGMNTN_DIM_KEY, AGRGT_SRC_FLTR_ID, SRC_FLTR_ID, AGRGT_ACCT_ID, PAID_STRT_MNTH_NBR, PAID_END_MNTH_NBR, SRVC_STRT_MNTH_NBR, SRVC_END_MNTH_NBR, TM_PRD_TYPE_CD, YEAR_ID, 
INCRD_PAID_CD, AS_OF_YEAR_MNTH_NBR,RPT_RUN_ID, -1 AS RPT_INSTNC_MTDTA_ID, ACCT_SGMNTN_TYPE_NM,CII_SR_ACCT_SGMNTN_TM_PRD_PARM.SCRTY_LVL_CD, BNCHMRK_ID
from ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM
	JOIN ${aciisst_adhoc_schema_name}.CII_RUN_PRD PRD
		ON PRD.RUN_YEAR_MNTH_NBR=AS_OF_YEAR_MNTH_NBR
WHERE RPT_SHRT_NM in ('UTIL-02','UTIL-01C','UTIL-01B','UTIL-01A','UTIL-01','FIN-03','UTIL-04','UTIL-05','UTIL-02A','BNCHMRK')
AND YEAR_ID <= 3 
AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
   AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
AND RPT_SPRSN_IND = 'N'
 ) amstp 
		ON fact.acct_id = amstp.acct_id
		AND fact.RPTG_PAID_YEAR_MNTH_NBR between  amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
		AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
		AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY
	INNER JOIN (	
			SELECT	amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD, amstp.TM_PRD_TYPE_CD, amstp.YEAR_ID,
			amstp.AGRGT_ACCT_ID as ACCT_ID,	amstp.AGRGT_SRC_FLTR_ID as SRC_FLTR_ID,
			DIM_ICD_CHPTR_CTGRY.ICD_CHPTR_CTGRY_CD AS ICD_CHPTR_CTGRY_CD, 
			ROW_NUMBER() OVER( PARTITION BY amstp.AGRGT_ACCT_ID,amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD, amstp.TM_PRD_TYPE_CD, amstp.YEAR_ID,  amstp.AGRGT_SRC_FLTR_ID
			ORDER BY SUM(fact.ACCT_PAID_AMT) DESC, DIM_ICD_CHPTR_CTGRY.ICD_CHPTR_CTGRY_CD ) as PD_RNK
			FROM	${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact
			INNER JOIN ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM amstp			
				ON fact.acct_id = amstp.acct_id
				AND fact.RPTG_PAID_YEAR_MNTH_NBR between  PAID_STRT_MNTH_NBR and PAID_END_MNTH_NBR
				AND fact.CLM_SRVC_YEAR_MNTH_NBR between SRVC_STRT_MNTH_NBR and SRVC_END_MNTH_NBR
				AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY 
			INNER JOIN ${aciisst_adhoc_schema_name}.DIM_ICD_CHPTR_CTGRY  ON fact.ICD_CHPTR_CTGRY_KEY = DIM_ICD_CHPTR_CTGRY.ICD_CHPTR_CTGRY_KEY 
			WHERE fact.MBR_CVRG_TYPE_CD  IN ('001')  AND  MH_SA_CD NOT IN ('NA'	,'-3') AND fact.BK_FILL_IND = 'N'
             AND RPT_SHRT_NM in ('UTIL-02','UTIL-01C','UTIL-01B','UTIL-01A','UTIL-01','FIN-03','UTIL-04','UTIL-05','UTIL-02A','BNCHMRK')
             AND YEAR_ID <= 3 
             AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
             AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
             AND RPT_SPRSN_IND = 'N'
			GROUP BY amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD, amstp.TM_PRD_TYPE_CD, amstp.YEAR_ID, amstp.AGRGT_ACCT_ID,	amstp.AGRGT_SRC_FLTR_ID,
			DIM_ICD_CHPTR_CTGRY.ICD_CHPTR_CTGRY_CD
		)BHSA_RNK	
		ON 	amstp.AS_OF_YEAR_MNTH_NBR = BHSA_RNK.AS_OF_YEAR_MNTH_NBR 
			AND amstp.INCRD_PAID_CD = BHSA_RNK.INCRD_PAID_CD
			AND amstp.TM_PRD_TYPE_CD = BHSA_RNK.TM_PRD_TYPE_CD
			AND amstp.YEAR_ID = BHSA_RNK.YEAR_ID
			AND amstp.ACCT_ID = BHSA_RNK.ACCT_ID
			AND amstp.SRC_FLTR_ID = BHSA_RNK.SRC_FLTR_ID
			AND dicc.ICD_CHPTR_CTGRY_CD = BHSA_RNK.ICD_CHPTR_CTGRY_CD 
			AND fact.MH_SA_CD <> 'NA'		
		WHERE fact.MBR_CVRG_TYPE_CD = '001' AND MH_SA_CD NOT IN ('NA'	,'-3') AND fact.BK_FILL_IND = 'N'
		GROUP BY amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID , amstp.AGRGT_ACCT_ID ,amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
			CASE WHEN BHSA_RNK.PD_RNK <=15 THEN dicc.ICD_CHPTR_CTGRY_DESC ELSE 'All Other Behavioral Health' END,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD)
		
WHERE 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_MDCL_CLMNT_UTILZN_DTL
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR)

UNION ALL

SELECT  distinct
AS_OF_YEAR_MNTH_NBR,
INCRD_PAID_CD,
SRC_FLTR_ID,
ACCT_ID,
TM_PRD_TYPE_CD,
YEAR_ID,
RPT_RUN_ID,
RPT_INSTNC_MTDTA_ID,
ACCT_SGMNTN_TYPE_NM,
BNCHMRK_ID,
CLMNT_CNT_TYPE_CD,
DIM1 AS RPTG_SRVC_DIAG_DESC,
DIM2 AS RPTG_SRVC_CTGRY_DIAG_DESC,
CLMNT_1_CNT,
CLMNT_2_CNT,
CLMNT_3_CNT,
SCRTY_LVL_CD,
current_timestamp as LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY
FROM
(SELECT	amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID AS SRC_FLTR_ID , amstp.AGRGT_ACCT_ID AS ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		'PRVCTGRY_CLMNT' as CLMNT_CNT_TYPE_CD,
		CASE WHEN TXNMY_CTGRY_CD='SPEC_PROV' THEN 'Specialty - Provider'WHEN TXNMY_CTGRY_CD='SPEC_ANC' THEN 'Specialty - Ancillary'WHEN TXNMY_CTGRY_CD='SPEC_FAC' THEN 'Specialty - Facility'WHEN TXNMY_CTGRY_CD='PRMRY_CARE' THEN 'PCP'WHEN TXNMY_CTGRY_CD='SPEC_PRV_O' THEN 'Specialty - Provider Other'ELSE 'Specialty Other' END AS DIM1,
		COALESCE(DIM_RPTG_TXNMY.RPTG_TXNMY_DESC, 'NA') as DIM2,	
		'NA' as DIM3,			
		COUNT(DISTINCT fact.MCID) AS CLMNT_1_CNT,
		COUNT(DISTINCT CASE WHEN fact.RPTG_INN_IND = 'Y' THEN  fact.MCID END) AS CLMNT_2_CNT,
		COUNT(DISTINCT CASE WHEN fact.RPTG_INN_IND <> 'Y' THEN  fact.MCID END) as CLMNT_3_CNT,		
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD		
	FROM    ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact
	LEFT JOIN ${aciisst_adhoc_schema_name}.DIM_RPTG_TXNMY  ON fact.RPTG_TXNMY_CD = DIM_RPTG_TXNMY.RPTG_TXNMY_CD
	INNER JOIN (SELECT DISTINCT ACCT_ID, SGMNTN_DIM_KEY, AGRGT_SRC_FLTR_ID, SRC_FLTR_ID, AGRGT_ACCT_ID, PAID_STRT_MNTH_NBR, PAID_END_MNTH_NBR, SRVC_STRT_MNTH_NBR, SRVC_END_MNTH_NBR, TM_PRD_TYPE_CD, YEAR_ID, 
INCRD_PAID_CD, AS_OF_YEAR_MNTH_NBR,RPT_RUN_ID, -1 AS RPT_INSTNC_MTDTA_ID, ACCT_SGMNTN_TYPE_NM,CII_SR_ACCT_SGMNTN_TM_PRD_PARM.SCRTY_LVL_CD, BNCHMRK_ID
from ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM
	JOIN ${aciisst_adhoc_schema_name}.CII_RUN_PRD PRD
		ON PRD.RUN_YEAR_MNTH_NBR=AS_OF_YEAR_MNTH_NBR
WHERE RPT_SHRT_NM in ('UTIL-02','UTIL-01C','UTIL-01B','UTIL-01A','UTIL-01','FIN-03','UTIL-04','UTIL-05','UTIL-02A')
AND YEAR_ID <= 3 
AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
   AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
AND RPT_SPRSN_IND = 'N'
               )amstp 
		ON fact.RPTG_PAID_YEAR_MNTH_NBR between  amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
		AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
		AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY
		WHERE fact.MBR_CVRG_TYPE_CD = '001' AND fact.SITE_SRVC_CD = 'PROF' AND fact.BK_FILL_IND = 'N'
		AND YEAR_ID <=3
		GROUP BY amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID , amstp.AGRGT_ACCT_ID , amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		CASE WHEN TXNMY_CTGRY_CD='SPEC_PROV' THEN 'Specialty - Provider'WHEN TXNMY_CTGRY_CD='SPEC_ANC' THEN 'Specialty - Ancillary'WHEN TXNMY_CTGRY_CD='SPEC_FAC' THEN 'Specialty - Facility'WHEN TXNMY_CTGRY_CD='PRMRY_CARE' THEN 'PCP'WHEN TXNMY_CTGRY_CD='SPEC_PRV_O' THEN 'Specialty - Provider Other'ELSE 'Specialty Other' END,
		DIM_RPTG_TXNMY.RPTG_TXNMY_DESC,amstp.RPT_RUN_ID,amstp.RPT_INSTNC_MTDTA_ID,	amstp.ACCT_SGMNTN_TYPE_NM,amstp.BNCHMRK_ID,amstp.SCRTY_LVL_CD)
		
WHERE 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_MDCL_CLMNT_UTILZN_DTL
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR)

UNION ALL

SELECT distinct
AS_OF_YEAR_MNTH_NBR,
INCRD_PAID_CD,
SRC_FLTR_ID,
ACCT_ID,
TM_PRD_TYPE_CD,
YEAR_ID,
RPT_RUN_ID,
RPT_INSTNC_MTDTA_ID,
ACCT_SGMNTN_TYPE_NM,
BNCHMRK_ID,
CLMNT_CNT_TYPE_CD,
DIM1 AS RPTG_SRVC_DIAG_DESC,
DIM2 AS RPTG_SRVC_CTGRY_DIAG_DESC,
CLMNT_1_CNT,
CLMNT_2_CNT,
CLMNT_3_CNT,
SCRTY_LVL_CD,
current_timestamp as LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY
FROM
(SELECT	amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID AS SRC_FLTR_ID , amstp.AGRGT_ACCT_ID AS ACCT_ID , amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		'PRVCTGRY_INOUT_CLMNT' as CLMNT_CNT_TYPE_CD,
		CASE WHEN TXNMY_CTGRY_CD='SPEC_PROV' THEN 'Specialty - Provider'WHEN TXNMY_CTGRY_CD='SPEC_ANC' THEN 'Specialty - Ancillary'WHEN TXNMY_CTGRY_CD='SPEC_FAC' THEN 'Specialty - Facility'WHEN TXNMY_CTGRY_CD='PRMRY_CARE' THEN 'PCP'WHEN TXNMY_CTGRY_CD='SPEC_PRV_O' THEN 'Specialty - Provider Other'ELSE 'Specialty Other' END AS DIM1,
		'NA'  as DIM2,	
		'NA' as DIM3,			
		COUNT(DISTINCT fact.MCID) AS CLMNT_1_CNT,
		COUNT(DISTINCT CASE WHEN fact.RPTG_INN_IND = 'Y' THEN  fact.MCID END) AS CLMNT_2_CNT,
		COUNT(DISTINCT CASE WHEN fact.RPTG_INN_IND <> 'Y' THEN  fact.MCID END) as CLMNT_3_CNT,		
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD		
	FROM    ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact
	LEFT JOIN ${aciisst_adhoc_schema_name}.DIM_RPTG_TXNMY  ON fact.RPTG_TXNMY_CD = DIM_RPTG_TXNMY.RPTG_TXNMY_CD

	INNER JOIN (SELECT DISTINCT ACCT_ID, SGMNTN_DIM_KEY, AGRGT_SRC_FLTR_ID, SRC_FLTR_ID, AGRGT_ACCT_ID, PAID_STRT_MNTH_NBR, PAID_END_MNTH_NBR, SRVC_STRT_MNTH_NBR, SRVC_END_MNTH_NBR, TM_PRD_TYPE_CD, YEAR_ID, 
INCRD_PAID_CD, AS_OF_YEAR_MNTH_NBR,RPT_RUN_ID, -1 AS RPT_INSTNC_MTDTA_ID, ACCT_SGMNTN_TYPE_NM,CII_SR_ACCT_SGMNTN_TM_PRD_PARM.SCRTY_LVL_CD, BNCHMRK_ID
from ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM
	JOIN ${aciisst_adhoc_schema_name}.CII_RUN_PRD PRD
		ON PRD.RUN_YEAR_MNTH_NBR=AS_OF_YEAR_MNTH_NBR 
WHERE RPT_SHRT_NM in ('UTIL-02','UTIL-01C','UTIL-01B','UTIL-01A','UTIL-01','FIN-03','UTIL-04','UTIL-05','UTIL-02A')
AND YEAR_ID <= 3 
AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
   AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
AND RPT_SPRSN_IND = 'N'
               )amstp 
		ON fact.RPTG_PAID_YEAR_MNTH_NBR between  amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
		AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
		AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY
		WHERE fact.MBR_CVRG_TYPE_CD = '001' AND fact.SITE_SRVC_CD = 'PROF' AND fact.BK_FILL_IND = 'N'
		AND YEAR_ID <=3
		GROUP BY amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID , amstp.AGRGT_ACCT_ID , amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		CASE WHEN TXNMY_CTGRY_CD='SPEC_PROV' THEN 'Specialty - Provider'WHEN TXNMY_CTGRY_CD='SPEC_ANC' THEN 'Specialty - Ancillary'WHEN TXNMY_CTGRY_CD='SPEC_FAC' THEN 'Specialty - Facility'WHEN TXNMY_CTGRY_CD='PRMRY_CARE' THEN 'PCP'WHEN TXNMY_CTGRY_CD='SPEC_PRV_O' THEN 'Specialty - Provider Other'ELSE 'Specialty Other' END,
		amstp.RPT_RUN_ID,amstp.RPT_INSTNC_MTDTA_ID,	amstp.ACCT_SGMNTN_TYPE_NM,amstp.BNCHMRK_ID,amstp.SCRTY_LVL_CD)
		
WHERE 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_MDCL_CLMNT_UTILZN_DTL
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR)

UNION ALL
		
SELECT distinct
AS_OF_YEAR_MNTH_NBR,
INCRD_PAID_CD,
SRC_FLTR_ID,
ACCT_ID,
TM_PRD_TYPE_CD,
YEAR_ID,
RPT_RUN_ID,
RPT_INSTNC_MTDTA_ID,
ACCT_SGMNTN_TYPE_NM,
BNCHMRK_ID,
CLMNT_CNT_TYPE_CD,
DIM1 AS RPTG_SRVC_DIAG_DESC,
DIM2 AS RPTG_SRVC_CTGRY_DIAG_DESC,
CLMNT_1_CNT,
CLMNT_2_CNT,
CLMNT_3_CNT,
SCRTY_LVL_CD,
current_timestamp as LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY
	FROM (
SELECT	amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID as SRC_FLTR_ID, amstp.AGRGT_ACCT_ID as ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		'VIS_TTL_CLMNT' as CLMNT_CNT_TYPE_CD,
		'NA' as DIM1,
		'NA' as DIM2,
		'NA' as DIM3,
		COUNT(DISTINCT fact.MCID) AS CLMNT_1_CNT,
		CAST(0 as INTEGER) as CLMNT_2_CNT,
		CAST(0 as INTEGER) as CLMNT_3_CNT,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD				
FROM ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact
	INNER JOIN (SELECT DISTINCT ACCT_ID, SGMNTN_DIM_KEY, AGRGT_SRC_FLTR_ID, SRC_FLTR_ID, AGRGT_ACCT_ID, PAID_STRT_MNTH_NBR, PAID_END_MNTH_NBR, SRVC_STRT_MNTH_NBR, SRVC_END_MNTH_NBR, TM_PRD_TYPE_CD, YEAR_ID, 
INCRD_PAID_CD, AS_OF_YEAR_MNTH_NBR,RPT_RUN_ID, -1 AS RPT_INSTNC_MTDTA_ID, ACCT_SGMNTN_TYPE_NM,CII_SR_ACCT_SGMNTN_TM_PRD_PARM.SCRTY_LVL_CD, BNCHMRK_ID
FROM ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM
	JOIN ${aciisst_adhoc_schema_name}.CII_RUN_PRD PRD
	  ON PRD.RUN_YEAR_MNTH_NBR=AS_OF_YEAR_MNTH_NBR
WHERE RPT_SHRT_NM IN ('VIS-02','BNCHMRK')
AND YEAR_ID <= 3
AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
   AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
AND RPT_SPRSN_IND = 'N'
 ) amstp 
		ON fact.ACCT_ID = amstp.ACCT_ID
		AND fact.RPTG_PAID_YEAR_MNTH_NBR between amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
		AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
		AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY
		WHERE fact.MBR_CVRG_TYPE_CD = '104' AND fact.BK_FILL_IND = 'N'
		GROUP BY amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD, amstp.AGRGT_SRC_FLTR_ID , amstp.AGRGT_ACCT_ID , amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD 
)

WHERE 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_MDCL_CLMNT_UTILZN_DTL
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR)

UNION ALL

SELECT distinct
AS_OF_YEAR_MNTH_NBR,
INCRD_PAID_CD,
SRC_FLTR_ID,
ACCT_ID,
TM_PRD_TYPE_CD,
YEAR_ID,
RPT_RUN_ID,
RPT_INSTNC_MTDTA_ID,
ACCT_SGMNTN_TYPE_NM,
BNCHMRK_ID,
CLMNT_CNT_TYPE_CD,
DIM1 AS RPTG_SRVC_DIAG_DESC,
DIM2 AS RPTG_SRVC_CTGRY_DIAG_DESC,
CLMNT_1_CNT,
CLMNT_2_CNT,
CLMNT_3_CNT,
SCRTY_LVL_CD,
current_timestamp as LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY
	FROM (
(
  SELECT amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID as SRC_FLTR_ID, amstp.AGRGT_ACCT_ID as ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		'VIS_SRVC_CTGRY' as CLMNT_CNT_TYPE_CD,
		(CASE WHEN dvsc.VSN_SRVC_CTGRY_3_RLUP_CD IN ('EXAM','MATERIALS') THEN INITCAP(dvsc.VSN_SRVC_CTGRY_3_RLUP_CD) END) as DIM1,
		'NA' as DIM2,
		'NA' as DIM3,		
		COUNT(DISTINCT fact.MCID) AS CLMNT_1_CNT,
		CAST(0 as INTEGER) as CLMNT_2_CNT,
		CAST(0 as INTEGER) as CLMNT_3_CNT,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD				
	FROM ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact
	JOIN ${aciisst_adhoc_schema_name}.DIM_VSN_SRVC_CTGRY dvsc on fact.VSN_SRVC_CTGRY_CD = dvsc.VSN_SRVC_CTGRY_CD
	INNER JOIN (SELECT DISTINCT ACCT_ID, SGMNTN_DIM_KEY, AGRGT_SRC_FLTR_ID, SRC_FLTR_ID, AGRGT_ACCT_ID, PAID_STRT_MNTH_NBR, PAID_END_MNTH_NBR, SRVC_STRT_MNTH_NBR, SRVC_END_MNTH_NBR, TM_PRD_TYPE_CD, YEAR_ID, 
INCRD_PAID_CD, AS_OF_YEAR_MNTH_NBR,RPT_RUN_ID, -1 AS RPT_INSTNC_MTDTA_ID, ACCT_SGMNTN_TYPE_NM,CII_SR_ACCT_SGMNTN_TM_PRD_PARM.SCRTY_LVL_CD, BNCHMRK_ID
from ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM
	JOIN ${aciisst_adhoc_schema_name}.CII_RUN_PRD PRD
		ON PRD.RUN_YEAR_MNTH_NBR=AS_OF_YEAR_MNTH_NBR
WHERE RPT_SHRT_NM in ('VIS-02','BNCHMRK')
AND YEAR_ID <= 1
AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
   AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
AND RPT_SPRSN_IND = 'N'
 ) amstp 
		ON fact.acct_id = amstp.acct_id
		AND fact.RPTG_PAID_YEAR_MNTH_NBR between amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
		AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
		AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY
		WHERE fact.MBR_CVRG_TYPE_CD = '104' AND fact.BK_FILL_IND = 'N'
		GROUP BY amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID , amstp.AGRGT_ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		(CASE WHEN dvsc.VSN_SRVC_CTGRY_3_RLUP_CD IN ('EXAM','MATERIALS') THEN INITCAP(dvsc.VSN_SRVC_CTGRY_3_RLUP_CD) END),
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD 
)
      
UNION
    
(SELECT amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID as SRC_FLTR_ID, amstp.AGRGT_ACCT_ID as ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		'VIS_SRVC_CTGRY' as CLMNT_CNT_TYPE_CD,
		(CASE WHEN dvsc.VSN_SRVC_CTGRY_2_RLUP_CD = 'CONTACTS'  THEN 'Contact Lenses'
	        WHEN fact.VSN_MTRL_CTGRY_CD = 'G' THEN 'Complete Pair Eyeglasses' 
		      WHEN ((fact.VSN_MTRL_CTGRY_CD = 'F') OR (fact.VSN_MTRL_CTGRY_CD = 'N' AND fact.VSN_SRVC_CTGRY_CD ='FRAMES')) then 'Frame Only' 
		      WHEN fact.VSN_MTRL_CTGRY_CD = 'L' THEN 'Lenses Only' 
          ELSE 'NA'
      END) as DIM1,
    'NA' as DIM2,
		'NA' as DIM3,		
		COUNT(DISTINCT fact.MCID) AS CLMNT_1_CNT,
		CAST(0 as INTEGER) as CLMNT_2_CNT,
		CAST(0 as INTEGER) as CLMNT_3_CNT,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD				
	FROM ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact
	JOIN ${aciisst_adhoc_schema_name}.DIM_VSN_SRVC_CTGRY dvsc on fact.VSN_SRVC_CTGRY_CD = dvsc.VSN_SRVC_CTGRY_CD
	INNER JOIN (SELECT DISTINCT ACCT_ID, SGMNTN_DIM_KEY, AGRGT_SRC_FLTR_ID, SRC_FLTR_ID, AGRGT_ACCT_ID, PAID_STRT_MNTH_NBR, PAID_END_MNTH_NBR, SRVC_STRT_MNTH_NBR, SRVC_END_MNTH_NBR, TM_PRD_TYPE_CD, YEAR_ID, 
INCRD_PAID_CD, AS_OF_YEAR_MNTH_NBR,RPT_RUN_ID, -1 AS RPT_INSTNC_MTDTA_ID, ACCT_SGMNTN_TYPE_NM,CII_SR_ACCT_SGMNTN_TM_PRD_PARM.SCRTY_LVL_CD, BNCHMRK_ID
from ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM
	JOIN ${aciisst_adhoc_schema_name}.CII_RUN_PRD PRD
		ON PRD.RUN_YEAR_MNTH_NBR=AS_OF_YEAR_MNTH_NBR
WHERE RPT_SHRT_NM in ('VIS-02','BNCHMRK')
AND YEAR_ID <= 1
AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
   AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
AND RPT_SPRSN_IND = 'N'
 ) amstp 
		ON fact.acct_id = amstp.acct_id
		AND fact.RPTG_PAID_YEAR_MNTH_NBR between amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
		AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
		AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY
		WHERE fact.MBR_CVRG_TYPE_CD = '104' AND fact.BK_FILL_IND = 'N'
		GROUP BY amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID , amstp.AGRGT_ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		(CASE WHEN dvsc.VSN_SRVC_CTGRY_2_RLUP_CD = 'CONTACTS'  THEN 'Contact Lenses'
	        WHEN fact.VSN_MTRL_CTGRY_CD = 'G' THEN 'Complete Pair Eyeglasses' 
		      WHEN ((fact.VSN_MTRL_CTGRY_CD = 'F') OR (fact.VSN_MTRL_CTGRY_CD = 'N' AND fact.VSN_SRVC_CTGRY_CD ='FRAMES')) then 'Frame Only' 
		      WHEN fact.VSN_MTRL_CTGRY_CD = 'L' THEN 'Lenses Only' 
          ELSE 'NA'
     END),
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD 
)

UNION
    
(SELECT amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID as SRC_FLTR_ID, amstp.AGRGT_ACCT_ID as ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		'VIS_SRVC_CTGRY' as CLMNT_CNT_TYPE_CD,
		(CASE WHEN (dvsc.VSN_SRVC_CTGRY_1_RLUP_CD ='LENSES' AND dvsc.VSN_SRVC_CTGRY_CD <> 'LLENS') THEN VSN_SRVC_CTGRY_NM
          ELSE 'NA'
      END) as DIM1,
    'NA' as DIM2,
		'NA' as DIM3,		
		COUNT(DISTINCT fact.MCID) AS CLMNT_1_CNT,
		CAST(0 as INTEGER) as CLMNT_2_CNT,
		CAST(0 as INTEGER) as CLMNT_3_CNT,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD				
	FROM ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact
	JOIN ${aciisst_adhoc_schema_name}.DIM_VSN_SRVC_CTGRY dvsc on fact.VSN_SRVC_CTGRY_CD = dvsc.VSN_SRVC_CTGRY_CD
	INNER JOIN (SELECT DISTINCT ACCT_ID, SGMNTN_DIM_KEY, AGRGT_SRC_FLTR_ID, SRC_FLTR_ID, AGRGT_ACCT_ID, PAID_STRT_MNTH_NBR, PAID_END_MNTH_NBR, SRVC_STRT_MNTH_NBR, SRVC_END_MNTH_NBR, TM_PRD_TYPE_CD, YEAR_ID, 
INCRD_PAID_CD, AS_OF_YEAR_MNTH_NBR,RPT_RUN_ID, -1 AS RPT_INSTNC_MTDTA_ID, ACCT_SGMNTN_TYPE_NM,CII_SR_ACCT_SGMNTN_TM_PRD_PARM.SCRTY_LVL_CD, BNCHMRK_ID
from ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM
	JOIN ${aciisst_adhoc_schema_name}.CII_RUN_PRD PRD
		ON PRD.RUN_YEAR_MNTH_NBR=AS_OF_YEAR_MNTH_NBR
WHERE RPT_SHRT_NM in ('VIS-02','BNCHMRK')
AND YEAR_ID <= 1
AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
   AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
AND RPT_SPRSN_IND = 'N'
 ) amstp 
		ON fact.acct_id = amstp.acct_id
		AND fact.RPTG_PAID_YEAR_MNTH_NBR between amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
		AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
		AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY
		WHERE fact.MBR_CVRG_TYPE_CD = '104' AND fact.BK_FILL_IND = 'N'
		GROUP BY amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID , amstp.AGRGT_ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		(CASE WHEN (dvsc.VSN_SRVC_CTGRY_1_RLUP_CD ='LENSES' AND dvsc.VSN_SRVC_CTGRY_CD <> 'LLENS') THEN VSN_SRVC_CTGRY_NM
          ELSE 'NA'
     END),
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD 
)

)

WHERE 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_MDCL_CLMNT_UTILZN_DTL
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR);
