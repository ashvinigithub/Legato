 /*********************************************************************
 # TITLE           : REPORT DEN03 SMRY
 # FILENAME        : CII_SR_DNTL_DEN03_SMRY.sql
 # DESCRIPTION     : THIS SCRIPT LOADS CII_SR_DNTL_DEN03_SMRY table
 # DEVELOPER       : LEGATO
 # CREATED ON      : 04/07/2022
 # LOGIC           : APPEND TARGET TABLE
 # VERSION         : 1.0
 **********************************************************************/

delete from CII_EVOLVE.CII_SR_DNTL_DEN03_SMRY WHERE (AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD) AND 'YES' = ${re_run} AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})));

insert into CII_EVOLVE.CII_SR_DNTL_DEN03_SMRY


SELECT 
PERMS.AS_OF_YEAR_MNTH_NBR,
PERMS.INCRD_PAID_CD,
PERMS.SRC_FLTR_ID,
PERMS.ACCT_ID,
PERMS.TM_PRD_TYPE_CD,
PERMS.YEAR_ID,
PERMS.RPT_RUN_ID,
PERMS.RPT_INSTNC_MTDTA_ID,
PERMS.ACCT_SGMNTN_TYPE_NM,
PERMS.BNCHMRK_ID,
PERMS.RPTG_INN_IND AS RPTG_NTWK_STTS_CD, 
COALESCE(CLMS.CLMNT_CNT,0) AS CLMNT_CNT,
COALESCE(CLM_CNT,0) AS CLM_CNT,  
COALESCE(ACCT_BILLD_CHRG_AMT,0) AS ACCT_BILLD_CHRG_AMT,  
COALESCE(NON_CVRD_EXPNS_AMT,0) AS NON_CVRD_EXPNS_AMT,  
COALESCE(CVRD_EXPNS_AMT,0) AS CVRD_EXPNS_AMT,  
COALESCE(DSCNT_AMT,0) AS DSCNT_AMT, 
COALESCE(ACCT_ALWD_AMT,0) AS ACCT_ALWD_AMT, 
COALESCE(ACCT_COINSRN_AMT,0) AS ACCT_COINSRN_AMT,  
COALESCE(ACCT_DDCTBL_AMT,0) AS ACCT_DDCTBL_AMT,
COALESCE(ACCT_PAID_AMT,0) AS ACCT_PAID_AMT, 
 COALESCE(COB_SVNGS_AMT,0) AS COB_SVNGS_AMT, 
COALESCE(RPTG_OTHR_RDCTN_AMT,0) AS RPTG_OTHR_RDCTN_AMT,  
COALESCE(TTL_CLMNT.CLMNT_CNT,0) AS TOTL_CLMNT_CNT  ,
PERMS.SCRTY_LVL_CD,
current_timestamp as LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY		
FROM 
(SELECT DISTINCT AS_OF_YEAR_MNTH_NBR,
		INCRD_PAID_CD,
		 SRC_FLTR_ID,
		 ACCT_ID,
		TM_PRD_TYPE_CD,
		YEAR_ID,
		RPT_INSTNC_MTDTA_ID,
		amstp.SCRTY_LVL_CD,
		BNCHMRK_ID,
		ACCT_SGMNTN_TYPE_NM,
		RPT_RUN_ID,
		RPTG_INN_IND		
			FROM ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM amstp 
			JOIN ${aciisst_adhoc_schema_name}.CII_RUN_PRD PRD
			ON TRIM(PRD.RUN_YEAR_MNTH_NBR)=TRIM(amstp.AS_OF_YEAR_MNTH_NBR)
		cross join(	SELECT DISTINCT RPTG_FULLY_INSRD_CD AS RPTG_INN_IND FROM ${aciisst_adhoc_schema_name}.DIM_RPTG_FULLY_INSRD WHERE RPTG_FULLY_INSRD_CD <> 'NA')
		WHERE 
				amstp.YEAR_ID = 1 and amstp.RPT_SHRT_NM in ('DEN-03')
  				AND (amstp.CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}) OR CLNT_PRTY_GRP_CD like '${clnt_prty_grp_cd_bnchmrk}')
				AND (amstp.RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
				AND amstp.RPT_SPRSN_IND = 'N') PERMS

LEFT JOIN (
SELECT 	
  			amstp.INCRD_PAID_CD as INCRD_PAID_CD,
			amstp.TM_PRD_TYPE_CD as TM_PRD_TYPE_CD,
            amstp.SRC_FLTR_ID as SRC_FLTR_ID,
            amstp.AS_OF_YEAR_MNTH_NBR,
            CLM_LINE.ACCT_ID AS ACCT_ID,
		    CLM_LINE.RPTG_INN_IND AS RPTG_INN_IND,
            COUNT(DISTINCT CLM_LINE.MCID) AS CLMNT_CNT,
            COUNT(DISTINCT CLM_LINE.CLM_NBR) AS CLM_CNT,
            SUM(CLM_LINE.ACCT_BILLD_CHRG_AMT) AS ACCT_BILLD_CHRG_AMT,
			
            SUM(CLM_LINE.NON_CVRD_EXPNS_AMT) AS NON_CVRD_EXPNS_AMT,
            SUM(CLM_LINE.CVRD_EXPNS_AMT) AS CVRD_EXPNS_AMT,
            SUM(CLM_LINE.DSCNT_AMT) AS DSCNT_AMT,
            SUM(CLM_LINE.ACCT_ALWD_AMT) AS ACCT_ALWD_AMT,
            SUM(CLM_LINE.ACCT_DDCTBL_AMT) AS ACCT_DDCTBL_AMT,
            SUM(CLM_LINE.ACCT_COINSRN_AMT) AS ACCT_COINSRN_AMT,
            SUM(CLM_LINE.COB_SVNGS_AMT) AS COB_SVNGS_AMT,   
            SUM(CLM_LINE.RPTG_OTHR_RDCTN_AMT) AS RPTG_OTHR_RDCTN_AMT, 
            SUM(CLM_LINE.ACCT_PAID_AMT) AS ACCT_PAID_AMT
			FROM 
                ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD CLM_LINE
			INNER JOIN (
			SELECT DISTINCT 
                        amstp.AS_OF_YEAR_MNTH_NBR
		                                    ,amstp.INCRD_PAID_CD
		                                    ,amstp.AGRGT_SRC_FLTR_ID
		                                    ,amstp.AGRGT_ACCT_ID
                                            ,amstp.SRC_FLTR_ID
		                                    ,amstp.ACCT_ID
		                                    ,amstp.STRT_MNTH_NBR
		                                    ,amstp.END_MNTH_NBR
		                                    ,amstp.SRVC_STRT_MNTH_NBR
		                                    ,amstp.SRVC_END_MNTH_NBR
                                            ,amstp.SGMNTN_DIM_KEY
		                                    ,PAID_STRT_MNTH_NBR
		                                    ,PAID_END_MNTH_NBR
		                                    ,amstp.TM_PRD_TYPE_CD
		                                    ,amstp.YEAR_ID
		                                    ,amstp.RPT_RUN_ID
		                                    ,amstp.RPT_INSTNC_MTDTA_ID
		                                    ,amstp.BNCHMRK_ID
		                                    ,amstp.ACCT_SGMNTN_TYPE_NM
		                                    ,amstp.SCRTY_LVL_CD
                                       FROM ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM amstp
	                                   JOIN ${aciisst_adhoc_schema_name}.CII_RUN_PRD PRD ON PRD.RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR
                                       WHERE amstp.YEAR_ID = 1
		AND amstp.RPT_SHRT_NM in ('DEN-03')
		AND (amstp.CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd})) 
		AND (amstp.RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
		AND amstp.RPT_SPRSN_IND = 'N') amstp 
			        ON 
                                CLM_LINE.acct_id = amstp.acct_id
		                    AND CLM_LINE.CLM_SRVC_YEAR_MNTH_NBR BETWEEN amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
		                    AND CLM_LINE.RPTG_PAID_YEAR_MNTH_NBR BETWEEN amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
 		                    AND CLM_LINE.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY
                WHERE 
				CLM_LINE.MBR_CVRG_TYPE_CD in ('Dental','103')
				AND CLM_LINE.BK_FILL_IND = 'N'
	GROUP BY 
			    CLM_LINE.ACCT_ID,
		        CLM_LINE.RPTG_INN_IND,
				amstp.INCRD_PAID_CD ,
				amstp.TM_PRD_TYPE_CD ,
				amstp.SRC_FLTR_ID,
				amstp.AS_OF_YEAR_MNTH_NBR) AS CLMS
          ON 
          PERMS.ACCT_ID = CLMS.ACCT_ID 
		  AND PERMS.RPTG_INN_IND = CLMS.RPTG_INN_IND
		AND PERMS.SRC_FLTR_ID = CLMS.SRC_FLTR_ID
		AND PERMS.TM_PRD_TYPE_CD = CLMS.TM_PRD_TYPE_CD
		AND PERMS.INCRD_PAID_CD = CLMS.INCRD_PAID_CD
		AND PERMS.AS_OF_YEAR_MNTH_NBR = CLMS.AS_OF_YEAR_MNTH_NBR
		LEFT JOIN (
SELECT 	
  			amstp.INCRD_PAID_CD as INCRD_PAID_CD,
			amstp.TM_PRD_TYPE_CD as TM_PRD_TYPE_CD,
            amstp.SRC_FLTR_ID as SRC_FLTR_ID,
            amstp.AS_OF_YEAR_MNTH_NBR,
            CLM_LINE.ACCT_ID AS ACCT_ID,
            COUNT(DISTINCT CLM_LINE.MCID) AS CLMNT_CNT
			FROM 
                ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD CLM_LINE
			INNER JOIN (
			SELECT DISTINCT 
                        amstp.AS_OF_YEAR_MNTH_NBR
		                                    ,amstp.INCRD_PAID_CD
		                                    ,amstp.AGRGT_SRC_FLTR_ID
		                                    ,amstp.AGRGT_ACCT_ID
                                            ,amstp.SRC_FLTR_ID
		                                    ,amstp.ACCT_ID
		                                    ,amstp.STRT_MNTH_NBR
		                                    ,amstp.END_MNTH_NBR
		                                    ,amstp.SRVC_STRT_MNTH_NBR
		                                    ,amstp.SRVC_END_MNTH_NBR
                                            ,amstp.SGMNTN_DIM_KEY
		                                    ,PAID_STRT_MNTH_NBR
		                                    ,PAID_END_MNTH_NBR
		                                    ,amstp.TM_PRD_TYPE_CD
		                                    ,amstp.YEAR_ID
		                                    ,amstp.RPT_RUN_ID
		                                    ,amstp.RPT_INSTNC_MTDTA_ID
		                                    ,amstp.BNCHMRK_ID
		                                    ,amstp.ACCT_SGMNTN_TYPE_NM
		                                    ,amstp.SCRTY_LVL_CD
                                       FROM ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM amstp
	                                   JOIN ${aciisst_adhoc_schema_name}.CII_RUN_PRD PRD ON PRD.RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR
                                       WHERE amstp.YEAR_ID = 1
		AND amstp.RPT_SHRT_NM in ('DEN-03')
		AND (amstp.CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd})) 
		AND (amstp.RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
		AND amstp.RPT_SPRSN_IND = 'N') amstp 
			        ON 
                                CLM_LINE.acct_id = amstp.acct_id
		                    AND CLM_LINE.CLM_SRVC_YEAR_MNTH_NBR BETWEEN amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
		                    AND CLM_LINE.RPTG_PAID_YEAR_MNTH_NBR BETWEEN amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
 		                    AND CLM_LINE.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY
                WHERE 
				CLM_LINE.MBR_CVRG_TYPE_CD in ('Dental','103')
				AND CLM_LINE.BK_FILL_IND = 'N'
	GROUP BY 
			    CLM_LINE.ACCT_ID,
				amstp.INCRD_PAID_CD ,
				amstp.TM_PRD_TYPE_CD ,
				amstp.SRC_FLTR_ID,
				amstp.AS_OF_YEAR_MNTH_NBR) AS TTL_CLMNT
          ON 
          PERMS.ACCT_ID = TTL_CLMNT.ACCT_ID 
		AND PERMS.SRC_FLTR_ID = TTL_CLMNT.SRC_FLTR_ID
		AND PERMS.TM_PRD_TYPE_CD = TTL_CLMNT.TM_PRD_TYPE_CD
		AND PERMS.INCRD_PAID_CD = TTL_CLMNT.INCRD_PAID_CD
		AND PERMS.AS_OF_YEAR_MNTH_NBR = TTL_CLMNT.AS_OF_YEAR_MNTH_NBR
        
WHERE 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_DNTL_DEN03_SMRY
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR);
