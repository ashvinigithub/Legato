 /*************************************************************************************************************
 # TITLE           : REPORT VISION 03 DTL
 # FILENAME        : cii_sr_vsn_vsn03_dtl.sql
 # DESCRIPTION     : THIS SCRIPT LOADS cii_sr_vsn_vsn03_dtl table
 # DEVELOPER       : LEGATO
 # CREATED ON      : 07/05/2022
 # LOGIC           : APPEND AND RELOAD TARGET TABLE
 # VERSION         : 1.0
 ***************************************************************************************************************/

delete from cii_evolve.cii_sr_vsn_vsn03_dtl WHERE (AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM  ${aciisst_adhoc_schema_name}.cii_run_prd) AND 'YES' = ${re_run} AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})));

insert into cii_evolve.cii_sr_vsn_vsn03_dtl
SELECT distinct PERMS.AS_OF_YEAR_MNTH_NBR
		,PERMS.INCRD_PAID_CD
		,PERMS.SRC_FLTR_ID
		,PERMS.ACCT_ID
		,PERMS.TM_PRD_TYPE_CD
		,1 as YEAR_ID 
		,PERMS.RPT_RUN_ID
		,PERMS.RPT_INSTNC_MTDTA_ID
		,PERMS.ACCT_SGMNTN_TYPE_NM
		,PERMS.BNCHMRK_ID
		    ,PERMS.NTWRK_SORT AS NTWK_PAID_AMT_RANK_NBR
			,PERMS.NTWK_DTL_CD AS NTWK_DTL_CD
			,COALESCE(CLMS.RETAILER_CD,'All Others') AS RETAILER_CD
			,COALESCE(CLMS.RETAILER_NM,'All Others') AS RETAILER_NM
			,COALESCE(CLMS.SORT_ORDER, 999)  AS RETAILER_PAID_AMT_RANK_NBR
            ,SUM(COALESCE(CP_CLM_CNT,0)) AS CP_CLMNT_CNT
			,SUM(COALESCE(PP_CLM_CNT,0)) AS PP_1_CLMNT_CNT
            ,SUM(COALESCE(CP_ACCT_PAID_AMT,0)) AS CP_ACCT_PAID_AMT
			,SUM(COALESCE(PP_ACCT_PAID_AMT,0)) AS PP_1_ACCT_PAID_AMT
			,SUM(COALESCE(CP_DSCNT_AMT,0)) AS CP_DSCNT_AMT
			,SUM(COALESCE(PP_DSCNT_AMT,0)) AS PP_1_DSCNT_AMT
            ,SUM(COALESCE(CP_CVRD_EXPNS_AMT,0)) AS CP_CVRD_EXPNS_AMT
			,SUM(COALESCE(PP_CVRD_EXPNS_AMT,0)) AS PP_1_CVRD_EXPNS_AMT
            ,SUM(COALESCE(CP_EXAM_CNT,0)) AS CP_VSN_EXAM_CNT
            ,SUM(COALESCE(CP_EXAM_ACCT_PD_AMT,0)) AS CP_VSN_EXAM_ACCT_PAID_AMT
            ,SUM(COALESCE(CP_MTRL_CNT,0)) AS CP_VSN_MTRL_CNT
            ,SUM(COALESCE(CP_MTRL_ACCT_PD_AMT,0)) AS CP_VSN_MTRL_ACCT_PAID_AMT
            ,SUM(COALESCE(CP_WKND_CNT,0)) AS CP_VSN_CLM_WKND_CNT
            ,PERMS.SCRTY_LVL_CD
            ,current_timestamp as LOAD_DTM
			,MD5(current_timestamp) as LOAD_LOG_KEY
FROM (SELECT distinct
	amstp.AS_OF_YEAR_MNTH_NBR, 
	amstp.INCRD_PAID_CD, 
	amstp.AGRGT_SRC_FLTR_ID as SRC_FLTR_ID,
	amstp.AGRGT_ACCT_ID as ACCT_ID,
	amstp.TM_PRD_TYPE_CD, 
	amstp.RPT_RUN_ID,
	'-1' as RPT_INSTNC_MTDTA_ID,
	amstp.ACCT_SGMNTN_TYPE_NM,
	amstp.BNCHMRK_ID,	
	amstp.SCRTY_LVL_CD,
	current_timestamp as LOAD_DTM,
	MD5(current_timestamp) as LOAD_LOG_KEY,
      NTWRK_SORT,
      NTWK_DTL_CD
	FROM (SELECT DISTINCT 
	AS_OF_YEAR_MNTH_NBR
	,ACCT_ID
	,AGRGT_ACCT_ID
	,SRC_FLTR_ID
	,AGRGT_SRC_FLTR_ID
	,TM_PRD_TYPE_CD
	,INCRD_PAID_CD
	,SRVC_STRT_MNTH_NBR
	,SRVC_END_MNTH_NBR
	,PAID_STRT_MNTH_NBR
	,PAID_END_MNTH_NBR
	,RPT_RUN_ID
	,RPT_INSTNC_MTDTA_ID
	,ACCT_SGMNTN_TYPE_NM
	,BNCHMRK_ID
	,CII_SR_ACCT_SGMNTN_TM_PRD_PARM.SCRTY_LVL_CD
	FROM ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM
    JOIN  ${aciisst_adhoc_schema_name}.cii_run_prd PRD
         ON PRD.RUN_YEAR_MNTH_NBR=AS_OF_YEAR_MNTH_NBR
	where YEAR_ID <= 1 and RPT_SHRT_NM in ('VIS-03','BNCHMRK') 
	AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd})) 
	AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
  	AND RPT_SPRSN_IND = 'N'
	               ) amstp	 
      CROSS JOIN (
		SELECT DISTINCT 
			CASE WHEN UPPER(VSN_MRKT_BAND_RLUP_DESC) = 'IN-RETAIL' THEN 1 WHEN UPPER(VSN_MRKT_BAND_RLUP_DESC) = 'IN-OTHER' THEN 2 ELSE 3 END AS NTWRK_SORT,  
			CASE WHEN UPPER(VSN_MRKT_BAND_RLUP_DESC) ='IN-RETAIL' THEN 'In Network - Retail' WHEN UPPER(VSN_MRKT_BAND_RLUP_DESC) ='IN-OTHER' THEN 'In Network - Independent' ELSE 'Out of Network' END as NTWK_DTL_CD
						FROM ${aciisst_adhoc_schema_name}.DIM_VSN_MRKT_BAND WHERE UPPER(VSN_MRKT_BAND_RLUP_DESC) IN ('IN-RETAIL','IN-OTHER','OUT')
						) dband
			) AS PERMS
LEFT JOIN ( SELECT fact.AS_OF_YEAR_MNTH_NBR, fact.INCRD_PAID_CD, fact.TM_PRD_TYPE_CD,
			fact.SRC_FLTR_ID, fact.ACCT_ID, fact.ACCT_SGMNTN_TYPE_NM, fact.BNCHMRK_ID,
		    fact.NTWK_DTL_CD,
			COALESCE(TOP5.RETAILER_CD,CASE WHEN fact.NTWK_DTL_CD = 'In Network - Retail' THEN 'OTHRTLR' 
                     WHEN fact.NTWK_DTL_CD = 'In Network - Independent' THEN 'OTHRIP'
                    ELSE 'OON' END)  AS RETAILER_CD,
			COALESCE(TOP5.RETAILER_NM,CASE WHEN fact.NTWK_DTL_CD = 'In Network - Retail' THEN 'Other Retailer' 
                     WHEN fact.NTWK_DTL_CD = 'In Network - Independent' THEN 'Other Independent Provider'
                    ELSE 'Out of Network' END)  AS RETAILER_NM,
			COALESCE(TOP5.SORT_ORDER, 999) AS SORT_ORDER, 
            CASE WHEN YEAR_ID = 1 THEN fact.CLM_CNT ELSE 0 END AS CP_CLM_CNT,
			CASE WHEN YEAR_ID = 2 THEN fact.CLM_CNT ELSE 0 END AS PP_CLM_CNT,
            CASE WHEN YEAR_ID = 1 THEN fact.ACCT_PAID_AMT END AS CP_ACCT_PAID_AMT,
			CASE WHEN YEAR_ID = 2 THEN fact.ACCT_PAID_AMT END AS PP_ACCT_PAID_AMT,
            CASE WHEN YEAR_ID = 1 THEN fact.DSCNT_AMT END AS CP_DSCNT_AMT,
			CASE WHEN YEAR_ID = 2 THEN fact.DSCNT_AMT END AS PP_DSCNT_AMT,
            CASE WHEN YEAR_ID = 1 THEN fact.CVRD_EXPNS_AMT END AS CP_CVRD_EXPNS_AMT,
			CASE WHEN YEAR_ID = 2 THEN fact.CVRD_EXPNS_AMT END AS PP_CVRD_EXPNS_AMT,
            CASE WHEN YEAR_ID = 1 THEN fact.EXAM_CNT END AS CP_EXAM_CNT,
			CASE WHEN YEAR_ID = 1 THEN fact.EXAM_ACCT_PD_AMT END AS CP_EXAM_ACCT_PD_AMT,
            CASE WHEN YEAR_ID = 1 THEN fact.MTRL_CNT END AS CP_MTRL_CNT,
            CASE WHEN YEAR_ID = 1 THEN fact.MTRL_ACCT_PD_AMT END AS CP_MTRL_ACCT_PD_AMT,
            CASE WHEN YEAR_ID = 1 THEN fact.WKND_CNT END AS CP_WKND_CNT 
			FROM (
				SELECT amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD, amstp.TM_PRD_TYPE_CD,
				amstp.AGRGT_SRC_FLTR_ID as SRC_FLTR_ID, amstp.AGRGT_ACCT_ID as ACCT_ID, 
				amstp.ACCT_SGMNTN_TYPE_NM, amstp.BNCHMRK_ID, amstp.YEAR_ID, 
			    fact.NTWK_DTL_CD, fact.VSN_RETAILER_CD as RETAILER_CD,
				COUNT(DISTINCT fact.CLM_NBR) as CLM_CNT,
				SUM(fact.ACCT_PAID_AMT) as ACCT_PAID_AMT,
				SUM(fact.DSCNT_AMT) as DSCNT_AMT,
				SUM(fact.CVRD_EXPNS_AMT) as CVRD_EXPNS_AMT,
				COUNT(DISTINCT CASE WHEN fact.VSN_SRVC_CTGRY_CD = 'EXAM' THEN fact.CLM_NBR END) as EXAM_CNT,
				SUM(CASE WHEN fact.VSN_SRVC_CTGRY_CD = 'EXAM' THEN fact.ACCT_PAID_AMT END) AS EXAM_ACCT_PD_AMT,
	            COUNT(DISTINCT CASE WHEN (DIM_VSN_SRVC_CTGRY.VSN_SRVC_CTGRY_1_RLUP_CD = 'CONTACTS' OR DIM_VSN_SRVC_CTGRY.VSN_SRVC_CTGRY_2_RLUP_CD = 'EYEWEAR') THEN fact.CLM_NBR END) AS MTRL_CNT,
	            SUM(CASE WHEN DIM_VSN_SRVC_CTGRY.VSN_SRVC_CTGRY_2_RLUP_CD IN ('EYEWEAR','CONTACTS')  THEN fact.ACCT_PAID_AMT END) AS MTRL_ACCT_PD_AMT,
	            COUNT(DISTINCT CASE WHEN fact.WKND_CLM_IND = 'Y' THEN fact.CLM_NBR END) AS WKND_CNT 
				FROM ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact
				JOIN  (SELECT DISTINCT 
						AS_OF_YEAR_MNTH_NBR
						,ACCT_ID
						,AGRGT_ACCT_ID
						,SRC_FLTR_ID
						,AGRGT_SRC_FLTR_ID
						,TM_PRD_TYPE_CD
						,INCRD_PAID_CD
                        ,ACCT_SGMNTN_TYPE_NM
                        ,YEAR_ID
						,SGMNTN_DIM_KEY
                        ,SRVC_STRT_MNTH_NBR
						,SRVC_END_MNTH_NBR
						,PAID_STRT_MNTH_NBR
						,PAID_END_MNTH_NBR
						,RPT_RUN_ID
						,BNCHMRK_ID
						,CII_SR_ACCT_SGMNTN_TM_PRD_PARM.SCRTY_LVL_CD
						FROM ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM
					    JOIN  ${aciisst_adhoc_schema_name}.cii_run_prd PRD ON PRD.RUN_YEAR_MNTH_NBR=AS_OF_YEAR_MNTH_NBR
						where YEAR_ID <= 2 and RPT_SHRT_NM in ('VIS-03','BNCHMRK') 
						AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd})) 
						AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
					  	AND RPT_SPRSN_IND = 'N'
                                              
		               )  amstp ON fact.RPTG_PAID_YEAR_MNTH_NBR between  amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
						AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
						AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY 
						AND fact.ACCT_ID = amstp.ACCT_ID 
				JOIN ${aciisst_adhoc_schema_name}.DIM_VSN_SRVC_CTGRY ON fact.VSN_SRVC_CTGRY_CD = DIM_VSN_SRVC_CTGRY.VSN_SRVC_CTGRY_CD
				WHERE fact.MBR_CVRG_TYPE_CD = '104'
				AND fact.NTWK_DTL_CD IN ('In Network - Independent','In Network - Retail','Out of Network')
		   			AND BK_FILL_IND = 'N'
				GROUP BY amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD, amstp.TM_PRD_TYPE_CD,
				amstp.AGRGT_SRC_FLTR_ID, amstp.AGRGT_ACCT_ID, amstp.ACCT_SGMNTN_TYPE_NM, amstp.BNCHMRK_ID, amstp.YEAR_ID, 
			    fact.NTWK_DTL_CD, fact.VSN_RETAILER_CD 
			) fact

		   	LEFT JOIN  (SELECT DISTINCT AS_OF_YEAR_MNTH_NBR, INCRD_PAID_CD, TM_PRD_TYPE_CD,
						SRC_FLTR_ID, ACCT_ID, ACCT_SGMNTN_TYPE_NM, BNCHMRK_ID,
			    		NTWK_DTL_CD, RETAILER_CD, PD_ROW AS SORT_ORDER, RETAILER_NM
						FROM (
						
						SELECT	 amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD, amstp.TM_PRD_TYPE_CD,
								amstp.AGRGT_SRC_FLTR_ID as SRC_FLTR_ID, amstp.AGRGT_ACCT_ID as ACCT_ID, amstp.ACCT_SGMNTN_TYPE_NM, amstp.BNCHMRK_ID, 
									DIM_RETAILER.RETAILER_CD AS RETAILER_CD, DIM_RETAILER.RETAILER_NM as RETAILER_NM,
		                            fact.NTWK_DTL_CD,                          
									ROW_NUMBER() OVER( PARTITION BY amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD, amstp.TM_PRD_TYPE_CD,
										amstp.AGRGT_SRC_FLTR_ID, amstp.AGRGT_ACCT_ID, amstp.ACCT_SGMNTN_TYPE_NM, amstp.BNCHMRK_ID
										,fact.NTWK_DTL_CD 
										ORDER BY SUM(fact.ACCT_PAID_AMT) DESC, DIM_RETAILER.RETAILER_CD ASC ) as PD_ROW
									FROM ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact
									JOIN  (SELECT DISTINCT 
											AS_OF_YEAR_MNTH_NBR
											,ACCT_ID
											,AGRGT_ACCT_ID
											,SRC_FLTR_ID
											,AGRGT_SRC_FLTR_ID
											,TM_PRD_TYPE_CD
											,INCRD_PAID_CD
                                            ,ACCT_SGMNTN_TYPE_NM
                                            ,YEAR_ID
											,SGMNTN_DIM_KEY
											,SRVC_STRT_MNTH_NBR
											,SRVC_END_MNTH_NBR
											,PAID_STRT_MNTH_NBR
											,PAID_END_MNTH_NBR
											,RPT_RUN_ID
											,BNCHMRK_ID
											,CII_SR_ACCT_SGMNTN_TM_PRD_PARM.SCRTY_LVL_CD
											FROM ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM
										    JOIN  ${aciisst_adhoc_schema_name}.cii_run_prd PRD ON PRD.RUN_YEAR_MNTH_NBR=AS_OF_YEAR_MNTH_NBR
											where YEAR_ID <= 1 and RPT_SHRT_NM in ('VIS-03','BNCHMRK')
											AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd})) 
											AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
										  	AND RPT_SPRSN_IND = 'N'
                                                                                      
							        )  amstp ON fact.RPTG_PAID_YEAR_MNTH_NBR between  amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
										AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
										AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY AND fact.ACCT_ID = amstp.ACCT_ID
                          INNER JOIN ${aciisst_adhoc_schema_name}.DIM_RETAILER ON TRIM(fact.VSN_RETAILER_CD) = TRIM(DIM_RETAILER.RETAILER_CD)
									
									WHERE fact.MBR_CVRG_TYPE_CD  IN ('104')  				
		                            AND fact.NTWK_DTL_CD IN ('In Network - Independent','In Network - Retail')
									AND BK_FILL_IND = 'N'
									GROUP BY amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD, amstp.TM_PRD_TYPE_CD,
									amstp.AGRGT_SRC_FLTR_ID, amstp.AGRGT_ACCT_ID, amstp.ACCT_SGMNTN_TYPE_NM, amstp.BNCHMRK_ID,
		                            fact.NTWK_DTL_CD, DIM_RETAILER.RETAILER_CD, DIM_RETAILER.RETAILER_NM
									) RNK_PERMS
						WHERE RNK_PERMS.PD_ROW <=5
						)  TOP5
						ON  fact.ACCT_ID = TOP5.ACCT_ID
						AND fact.SRC_FLTR_ID = TOP5.SRC_FLTR_ID
						AND fact.TM_PRD_TYPE_CD = TOP5.TM_PRD_TYPE_CD
						AND fact.INCRD_PAID_CD = TOP5.INCRD_PAID_CD
						AND fact.AS_OF_YEAR_MNTH_NBR = TOP5.AS_OF_YEAR_MNTH_NBR
						AND fact.NTWK_DTL_CD = TOP5.NTWK_DTL_CD
						AND fact.RETAILER_CD = TOP5.RETAILER_CD	
                        AND fact.BNCHMRK_ID = TOP5.BNCHMRK_ID	
			
) CLMS ON PERMS.ACCT_ID = CLMS.ACCT_ID 
		AND PERMS.SRC_FLTR_ID = CLMS.SRC_FLTR_ID
		AND PERMS.TM_PRD_TYPE_CD = CLMS.TM_PRD_TYPE_CD
		AND PERMS.INCRD_PAID_CD = CLMS.INCRD_PAID_CD
		AND PERMS.AS_OF_YEAR_MNTH_NBR = CLMS.AS_OF_YEAR_MNTH_NBR
		AND PERMS.NTWK_DTL_CD = CLMS.NTWK_DTL_CD
        AND PERMS.BNCHMRK_ID = CLMS.BNCHMRK_ID

WHERE 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_VSN_VSN03_DTL
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR)

group by
PERMS.AS_OF_YEAR_MNTH_NBR
		,PERMS.INCRD_PAID_CD
		,PERMS.SRC_FLTR_ID
		,PERMS.ACCT_ID
		,PERMS.TM_PRD_TYPE_CD
		,PERMS.RPT_RUN_ID
		,PERMS.RPT_INSTNC_MTDTA_ID
		,PERMS.ACCT_SGMNTN_TYPE_NM
		,PERMS.BNCHMRK_ID
        ,PERMS.NTWRK_SORT
		,PERMS.NTWK_DTL_CD
		,COALESCE(CLMS.RETAILER_CD,'All Others')
		,COALESCE(CLMS.RETAILER_NM,'All Others')
		,COALESCE(CLMS.SORT_ORDER, 999)
        ,PERMS.SCRTY_LVL_CD
;
