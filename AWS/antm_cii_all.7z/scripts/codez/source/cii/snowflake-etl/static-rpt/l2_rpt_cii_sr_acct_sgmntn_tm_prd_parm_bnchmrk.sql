 /*************************************************************************************************************
 # TITLE           : TABLE CII_SR_ACCT_SGMNTN_TM_PRD_PARM
 # FILENAME        : l2_rpt_cii_sr_acct_sgmntn_tm_prd_parm.sql
 # DESCRIPTION     : THIS SCRIPT LOADS CII_SR_ACCT_SGMNTN_TM_PRD_PARM table for each request/rpt_run_id coming from UI/Middleware for L2 Reporting - For Benchmark Alone
 # DEVELOPER       : LEGATO
 # CREATED ON      : 06-09-2022
 # LOGIC           : LOAD TARGET TABLE
 # VERSION         : 1.0
 ***************************************************************************************************************/
 
delete from CII_EVOLVE.CII_SR_ACCT_SGMNTN_TM_PRD_PARM WHERE ('YES' = ${re_run} AND RPT_RUN_ID in (${rpt_run_id}) AND (RPT_SHRT_NM in (${rpt_shrt_nm}) OR 'ALL' in (${rpt_shrt_nm}))); 

insert into CII_EVOLVE.CII_SR_ACCT_SGMNTN_TM_PRD_PARM

WITH RQST_TM_PRD_DTL AS (SELECT * FROM (${rqst_tm_prd_dtl}) WHERE RPT_SHRT_NM = 'BNCHMRK')

select distinct
trim(datp.AS_OF_MNTH_NBR) AS AS_OF_YEAR_MNTH_NBR,
trim(brdg.ACCT_ID) AS ACCT_ID,
trim(brdg.SRC_FLTR_ID) AS SRC_FLTR_ID,
'BNCHMRK' as RPT_SHRT_NM,
case when lower(trim(datp.TM_PRD_TYPE_CD)) = 'custom' then cast(datp.RPT_RUN_ID as string) else datp.TM_PRD_TYPE_CD END AS TM_PRD_TYPE_CD,
datp.HCC_THRSHLD_AMT AS HCC_THRSHLD_AMT,
trim(datp.INCRD_PAID_CD) AS INCRD_PAID_CD,
brdg.sgmntn_dim_key AS SGMNTN_DIM_KEY,
'NA' as DFLT_CNTRCT_TYPE_CD,
'NA' AS CLNT_PRTY_GRP_CD,
datp.STRT_MNTH_NBR AS STRT_MNTH_NBR,
datp.END_MNTH_NBR AS END_MNTH_NBR,
datp.SRVC_STRT_MNTH_NBR AS SRVC_STRT_MNTH_NBR,
datp.SRVC_END_MNTH_NBR AS SRVC_END_MNTH_NBR,
datp.PAID_STRT_MNTH_NBR AS PAID_STRT_MNTH_NBR,
datp.PAID_END_MNTH_NBR AS PAID_END_MNTH_NBR,
'B9999999' as AGRGT_ACCT_ID,
'B9999999-00001' as AGRGT_SRC_FLTR_ID,
datp.YEAR_ID AS YEAR_ID,
'Benchmark' as BNCHMRK_RUN_TYPE_CD,
datp.RPT_RUN_ID AS RPT_RUN_ID,
'-1' as RPT_INSTNC_MTDTA_ID,
Case when brdg.GRS_IND='Y' then '2' else '1' end as BNCHMRK_ID,
Case when brdg.GRS_IND='Y' then 'GRS' else 'STD' end as ACCT_SGMNTN_TYPE_NM,
'N' as RPT_SPRSN_IND ,
1 as RPT_ID,
'N' as SCRTY_LVL_CD,
Current_timestamp as LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY,
trim(datp.UI_AS_OF_YEAR_MNTH_NBR) as UI_AS_OF_YEAR_MNTH_NBR,
trim(datp.UI_TM_PRD_TYPE_CD) as UI_TM_PRD_TYPE_CD
from (SELECT SGMNTN_DIM_KEY, max(SCD.ACCT_ID) as ACCT_ID ,max(SRC_FLTR_ID) as SRC_FLTR_ID,
      MAX(GRS_IND) as GRS_IND
      from ${aciisst_schema_name}.ACIISST_SGMNTN_BRDG_SCD SCD 
        JOIN ${aciisst_schema_name}.ACIISST_ACCT_PRFL AAP
        ON AAP.ACCT_ID=SCD.ACCT_ID
        WHERE FLTR_SRC_NM = 'ERSU' GROUP BY  SGMNTN_DIM_KEY) brdg
JOIN RQST_TM_PRD_DTL datp
where datp.YEAR_ID<3;