 /*************************************************************************************************************
 # TITLE           : cii_bnchmrk_rpt_run_id_parm
 # FILENAME        : cii_bnchmrk_rpt_run_id_parm.sql
 # DESCRIPTION     : THIS SCRIPT LOADS cii_bnchmrk_rpt_run_id_parm Table
 # DEVELOPER       : LEGATO
 # CREATED ON      : 07/04/2022
 # LOGIC           : TRUNCATE AND RELOAD TARGET TABLE
 # VERSION         : 1.0
 ***************************************************************************************************************/
 

INSERT overwrite INTO CII_EVOLVE.CII_BNCHMRK_PARM
SELECT
DISTINCT
INCRD_PAID_CD
,TM_PRD_TYPE_CD
,RPT_RUN_ID
,0 AS HCC_THRSHLD_AMT
,LOAD_DTM
,LOAD_LOG_KEY
FROM (SELECT
DISTINCT TM_PRD_TYPE_CD
,INCRD_PAID_CD
,(1 + RPT_RUN_NUM) AS RPT_RUN_ID
,current_timestamp as LOAD_DTM
,MD5(current_timestamp) as LOAD_LOG_KEY
FROM
(SELECT TM_PRD_TYPE_CD, INCRD_PAID_CD, ROW_NUMBER() OVER (ORDER BY TM_PRD_TYPE_CD, INCRD_PAID_CD) AS RPT_RUN_NUM 
FROM (select distinct dtp.TM_PRD_TYPE_CD,dtp.INCRD_PAID_CD
FROM ${aciisst_adhoc_schema_name}.DIM_TM_PRD DTP))) DTP_TEMP ;
