 /*************************************************************************************************************
 # TITLE           : WORK TABLE CII_SR_FNCL_FIN01P_SMRY
 # FILENAME        : CII_SR_FNCL_FIN01P_SMRY.sql
 # DESCRIPTION     : THIS SCRIPT LOADS CII_SR_FNCL_FIN01P_SMRY table
 # DEVELOPER       : LEGATO
 # CREATED ON      : 07/07/2022
 # LOGIC           : Append Data to Target Table, SQLs runs in Asynchronous Mode.
 # VERSION         : 1.0
 ***************************************************************************************************************/

delete from cii_evolve.CII_SR_FNCL_FIN01P_SMRY WHERE (AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD) AND 'YES' = ${re_run} AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})));

insert  into cii_evolve.CII_SR_FNCL_FIN01P_SMRY
SELECT  distinct
PERMS.AS_OF_YEAR_MNTH_NBR,
PERMS.INCRD_PAID_CD,
PERMS.SRC_FLTR_ID,
PERMS.ACCT_ID,
PERMS.TM_PRD_TYPE_CD,
PERMS.YEAR_ID,
PERMS.RPT_RUN_ID,
PERMS.RPT_INSTNC_MTDTA_ID,
PERMS.ACCT_SGMNTN_TYPE_NM,
PERMS.BNCHMRK_ID,
PERMS.YEAR_MNTH_NBR,
PERMS.QTR_YEAR_NBR,
COALESCE(MDCL_PAID_AMT,0) as MDCL_PAID_AMT,
COALESCE(DNTL_PAID_AMT,0) as DNTL_PAID_AMT,
COALESCE(RX_PAID_AMT,0) as RX_PAID_AMT,
COALESCE(VSN_PAID_AMT,0) as VSN_PAID_AMT,
0 as UNKNWN_PAID_AMT,
PERMS.SCRTY_LVL_CD,
current_timestamp as LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY
from
(
SELECT DISTINCT AS_OF_YEAR_MNTH_NBR, INCRD_PAID_CD,
AGRGT_ACCT_ID as ACCT_ID , AGRGT_SRC_FLTR_ID as SRC_FLTR_ID,ACCT_SGMNTN_TYPE_NM,
YEAR_MNTH_NBR AS YEAR_MNTH_NBR, QTR_YEAR_NBR,TM_PRD_TYPE_CD,YEAR_ID,amstp.SCRTY_LVL_CD,RPT_INSTNC_MTDTA_ID,BNCHMRK_ID,RPT_RUN_ID
FROM (
SELECT DISTINCT AS_OF_YEAR_MNTH_NBR,
				INCRD_PAID_CD,
				SRC_FLTR_ID,
				AGRGT_SRC_FLTR_ID,
				ACCT_ID,
				AGRGT_ACCT_ID,
	            TM_PRD_TYPE_CD,
	            YEAR_ID,
	            RPT_INSTNC_MTDTA_ID,
	            amstp.SCRTY_LVL_CD,
	            BNCHMRK_ID,
	            ACCT_SGMNTN_TYPE_NM,
	            RPT_RUN_ID,
	            STRT_MNTH_NBR,
				END_MNTH_NBR	
			FROM ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM amstp 
			JOIN ${aciisst_adhoc_schema_name}.CII_RUN_PRD PRD
			ON TRIM(PRD.RUN_YEAR_MNTH_NBR)=TRIM(amstp.AS_OF_YEAR_MNTH_NBR)
	WHERE 
				amstp.YEAR_ID  <= 3 and amstp.RPT_SHRT_NM in ('FIN-01P')
  				AND (amstp.CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}) OR amstp.CLNT_PRTY_GRP_CD like '${clnt_prty_grp_cd_bnchmrk}')
				AND (amstp.RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
				AND amstp.RPT_SPRSN_IND = 'N') amstp
		
JOIN 
(
  SELECT YEAR_MNTH_NBR, 
  CASE 
      WHEN mod(YEAR_MNTH_NBR,100) BETWEEN 1 AND 3 THEN (YEAR_NBR*10) + 1 
      WHEN mod(YEAR_MNTH_NBR,100) BETWEEN 4 AND 6 THEN (YEAR_NBR*10) + 2 
      WHEN mod(YEAR_MNTH_NBR,100) BETWEEN 7 AND 9 THEN (YEAR_NBR*10) + 3
      WHEN mod(YEAR_MNTH_NBR,100) BETWEEN 10 AND 12 THEN (YEAR_NBR*10) + 4
  END AS QTR_YEAR_NBR
  from ${aciisst_adhoc_schema_name}.DIM_MNTH DM
)dm ON  dm.YEAR_MNTH_NBR between amstp.STRT_MNTH_NBR and amstp.END_MNTH_NBR
)perms
		
left join ( select AS_OF_YEAR_MNTH_NBR,INCRD_PAID_CD, SRC_FLTR_ID, ACCT_ID, RPTG_YEAR_MNTH_NBR,YEAR_ID,BNCHMRK_ID,TM_PRD_TYPE_CD,
SUM(CASE WHEN MBR_CVRG_TYPE_CD = '001' THEN RVNU_AMT ELSE 0 END) as MDCL_PAID_AMT,
SUM(CASE WHEN MBR_CVRG_TYPE_CD = '102' THEN RVNU_AMT ELSE 0 END) as RX_PAID_AMT,
SUM(CASE WHEN MBR_CVRG_TYPE_CD = '103' THEN RVNU_AMT ELSE 0 END) as DNTL_PAID_AMT,
SUM(CASE WHEN MBR_CVRG_TYPE_CD = '104' THEN RVNU_AMT ELSE 0 END) as VSN_PAID_AMT,
0 as UNK_PAID_AMT
from(
select amstp.AS_OF_YEAR_MNTH_NBR ,amstp.INCRD_PAID_CD,amstp.YEAR_ID,amstp.BNCHMRK_ID,amstp.TM_PRD_TYPE_CD,          
                amstp.AGRGT_SRC_FLTR_ID as SRC_FLTR_ID,
                amstp.AGRGT_ACCT_ID AS ACCT_ID, 
				MBR_CVRG_TYPE_CD,sum(RVNU_AMT) as RVNU_AMT,RPTG_YEAR_MNTH_NBR
				from ${aciisst_adhoc_schema_name}.CII_FACT_RVNU fact
INNER JOIN (
			SELECT DISTINCT 
							 amstp.AS_OF_YEAR_MNTH_NBR
							,amstp.INCRD_PAID_CD
							,amstp.AGRGT_SRC_FLTR_ID
							,amstp.AGRGT_ACCT_ID
							,amstp.SRC_FLTR_ID
							,amstp.ACCT_ID
							,amstp.STRT_MNTH_NBR
							,amstp.END_MNTH_NBR
							,amstp.SRVC_STRT_MNTH_NBR
							,amstp.SRVC_END_MNTH_NBR
							,amstp.SGMNTN_DIM_KEY
							,PAID_STRT_MNTH_NBR
							,PAID_END_MNTH_NBR
							,amstp.TM_PRD_TYPE_CD
							,amstp.YEAR_ID
							,amstp.RPT_RUN_ID
							,amstp.RPT_INSTNC_MTDTA_ID
							,amstp.BNCHMRK_ID
							,amstp.ACCT_SGMNTN_TYPE_NM
							,amstp.SCRTY_LVL_CD
                                       FROM ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM amstp
	                                   JOIN ${aciisst_adhoc_schema_name}.CII_RUN_PRD PRD ON PRD.RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR
                                       WHERE amstp.YEAR_ID  <= 3
		AND amstp.RPT_SHRT_NM in ('FIN-01P')
		AND (amstp.CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
		AND (amstp.RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
		AND amstp.RPT_SPRSN_IND = 'N') amstp 
		on   fact.acct_id = amstp.acct_id
		  AND fact.RPTG_YEAR_MNTH_NBR  BETWEEN amstp.STRT_MNTH_NBR and amstp.END_MNTH_NBR
		  	AND fact.RPTG_YEAR_MNTH_NBR between  amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
			AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY
where RPTG_RVNU_TYPE_CD='22'
		GROUP BY amstp.AS_OF_YEAR_MNTH_NBR,amstp.INCRD_PAID_CD,					
				amstp.AGRGT_SRC_FLTR_ID,
	            amstp.AGRGT_ACCT_ID ,					
	            fact.RPTG_YEAR_MNTH_NBR,					
	            fact.MBR_CVRG_TYPE_CD,
				amstp.YEAR_ID,
                amstp.BNCHMRK_ID,
                amstp.TM_PRD_TYPE_CD) clms_sub
GROUP BY AS_OF_YEAR_MNTH_NBR,INCRD_PAID_CD, SRC_FLTR_ID ,ACCT_ID, RPTG_YEAR_MNTH_NBR, YEAR_ID, BNCHMRK_ID, TM_PRD_TYPE_CD
)clms
ON TRIM(PERMS.AS_OF_YEAR_MNTH_NBR) = TRIM(clms.AS_OF_YEAR_MNTH_NBR)
AND TRIM(PERMS.INCRD_PAID_CD) = TRIM(clms.INCRD_PAID_CD)
AND TRIM(PERMS.SRC_FLTR_ID) = TRIM(clms.SRC_FLTR_ID)
AND TRIM(PERMS.ACCT_ID) = TRIM(clms.ACCT_ID)
AND TRIM(PERMS.YEAR_MNTH_NBR) = TRIM(clms.RPTG_YEAR_MNTH_NBR)
AND TRIM(PERMS.YEAR_ID) = TRIM(clms.YEAR_ID)
AND TRIM(PERMS.BNCHMRK_ID) = TRIM(clms.BNCHMRK_ID)
AND TRIM(PERMS.TM_PRD_TYPE_CD) = TRIM(clms.TM_PRD_TYPE_CD)

WHERE 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_FNCL_FIN01P_SMRY 
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR);
