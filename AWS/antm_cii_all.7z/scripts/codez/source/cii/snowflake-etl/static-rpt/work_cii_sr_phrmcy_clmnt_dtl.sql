/*************************************************************************************************************
 # TITLE              : Work Table cii_sr_phrmcy_clmnt_dtl 
 # FILENAME           : work_cii_sr_phrmcy_clmnt_dtl.sql
 # DESCRIPTION        : THIS SCRIPT LOADS CII_SR_PHRMCY_CLMNT_DTL  table
 # DEVELOPER          : LEGATO
 # CREATED ON         : 5/11/2022
 # LOGIC              : Append Data to Target Table, SQLs runs in Asynchronous Mode.
 # VERSION            : 1.0
 # VERSION DESCRIPTION: Initial Version
***************************************************************************************************************/

delete from CII_EVOLVE.CII_SR_PHRMCY_CLMNT_DTL WHERE (AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.cii_run_prd) AND 'YES' = ${re_run} AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})));

INSERT INTO CII_EVOLVE.CII_SR_PHRMCY_CLMNT_DTL 
SELECT
AS_OF_YEAR_MNTH_NBR,
INCRD_PAID_CD,
SRC_FLTR_ID,
ACCT_ID,
TM_PRD_TYPE_CD,
YEAR_ID,
RPT_RUN_ID,
RPT_INSTNC_MTDTA_ID,
ACCT_SGMNTN_TYPE_NM,
BNCHMRK_ID,
CLMNT_CNT_TYPE_CD,
DIM1 AS RPTG_SRVC_PHRMCY_DESC,
DIM2 AS RPTG_SRVC_CTGRY_PHRMCY_DESC,
CLMNT_1_CNT,
CLMNT_2_CNT,
CLMNT_3_CNT,
SCRTY_LVL_CD,
current_timestamp as LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY
	FROM (
SELECT	amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID as SRC_FLTR_ID, amstp.AGRGT_ACCT_ID as ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		'TTL_CLMNT_RX' as CLMNT_CNT_TYPE_CD,
		'NA' as DIM1, 
		'NA' as DIM2,
		'NA' as DIM3,			
		COUNT(DISTINCT fact.MCID) AS CLMNT_1_CNT,
		CAST(0 as INTEGER) as CLMNT_2_CNT,
		CAST(0 as INTEGER) as CLMNT_3_CNT,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD				
	FROM    ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact
	INNER JOIN (SELECT DISTINCT ACCT_ID, SGMNTN_DIM_KEY, AGRGT_SRC_FLTR_ID, SRC_FLTR_ID, AGRGT_ACCT_ID, PAID_STRT_MNTH_NBR, PAID_END_MNTH_NBR, SRVC_STRT_MNTH_NBR, SRVC_END_MNTH_NBR, TM_PRD_TYPE_CD, YEAR_ID, 
INCRD_PAID_CD, AS_OF_YEAR_MNTH_NBR,RPT_RUN_ID, -1 AS RPT_INSTNC_MTDTA_ID, ACCT_SGMNTN_TYPE_NM,SCRTY_LVL_CD, BNCHMRK_ID
from ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM 
WHERE RPT_SHRT_NM in ('RX-02','RX-01','RX-04','RX-05')
AND YEAR_ID <= 3 
 AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
AND RPT_SPRSN_IND = 'N' 
) amstp 
		ON fact.acct_id = amstp.acct_id
		AND fact.RPTG_PAID_YEAR_MNTH_NBR between  amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
		AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
		AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY
	JOIN ${aciisst_adhoc_schema_name}.cii_run_prd PRD
		ON PRD.RUN_YEAR_MNTH_NBR=amstp.AS_OF_YEAR_MNTH_NBR
		WHERE fact.MBR_CVRG_TYPE_CD = '102' AND fact.BK_FILL_IND = 'N'
		GROUP BY amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID, amstp.AGRGT_ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD )
        
WHERE 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_PHRMCY_CLMNT_DTL
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR)

UNION ALL
SELECT
AS_OF_YEAR_MNTH_NBR,
INCRD_PAID_CD,
SRC_FLTR_ID,
ACCT_ID,
TM_PRD_TYPE_CD,
YEAR_ID,
RPT_RUN_ID,
RPT_INSTNC_MTDTA_ID,
ACCT_SGMNTN_TYPE_NM,
BNCHMRK_ID,
CLMNT_CNT_TYPE_CD,
DIM1 AS RPTG_SRVC_PHRMCY_DESC,
DIM2 AS RPTG_SRVC_CTGRY_PHRMCY_DESC,
CLMNT_1_CNT,
CLMNT_2_CNT,
CLMNT_3_CNT,
SCRTY_LVL_CD,
current_timestamp as LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY
	FROM (
SELECT	amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID as SRC_FLTR_ID, amstp.AGRGT_ACCT_ID as ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		'THRPC_CTRY_CLMNT' as CLMNT_CNT_TYPE_CD,
		DIM_NDC.GPI_02_GRP_DESC as DIM1, 
		'NA' as DIM2,
		'NA' as DIM3,			
		COUNT(DISTINCT fact.MCID) AS CLMNT_1_CNT,
		CAST(0 as INTEGER) as CLMNT_2_CNT,
		CAST(0 as INTEGER) as CLMNT_3_CNT,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD				
	FROM    ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact
	INNER JOIN (SELECT DISTINCT ACCT_ID, SGMNTN_DIM_KEY, AGRGT_SRC_FLTR_ID, SRC_FLTR_ID, AGRGT_ACCT_ID, PAID_STRT_MNTH_NBR, PAID_END_MNTH_NBR, SRVC_STRT_MNTH_NBR, SRVC_END_MNTH_NBR, TM_PRD_TYPE_CD, YEAR_ID, 
INCRD_PAID_CD, AS_OF_YEAR_MNTH_NBR,RPT_RUN_ID, -1 AS RPT_INSTNC_MTDTA_ID, ACCT_SGMNTN_TYPE_NM,SCRTY_LVL_CD, BNCHMRK_ID
from ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM 
WHERE RPT_SHRT_NM in ('RX-01')
AND YEAR_ID = 1
 AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
AND RPT_SPRSN_IND = 'N') amstp 
		ON fact.acct_id = amstp.acct_id
		AND fact.RPTG_PAID_YEAR_MNTH_NBR between  amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
		AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
		AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY
JOIN ${aciisst_adhoc_schema_name}.DIM_NDC  on fact.NDC = DIM_NDC.NDC  
JOIN ${aciisst_adhoc_schema_name}.cii_run_prd PRD
		ON PRD.RUN_YEAR_MNTH_NBR=amstp.AS_OF_YEAR_MNTH_NBR
		WHERE fact.MBR_CVRG_TYPE_CD = '102' AND fact.BK_FILL_IND = 'N' 
		GROUP BY amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID, amstp.AGRGT_ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		DIM_NDC.GPI_02_GRP_DESC,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD )
        
WHERE 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_PHRMCY_CLMNT_DTL
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR)
		
UNION ALL
SELECT
AS_OF_YEAR_MNTH_NBR,
INCRD_PAID_CD,
SRC_FLTR_ID,
ACCT_ID,
TM_PRD_TYPE_CD,
YEAR_ID,
RPT_RUN_ID,
RPT_INSTNC_MTDTA_ID,
ACCT_SGMNTN_TYPE_NM,
BNCHMRK_ID,
CLMNT_CNT_TYPE_CD,
DIM1 AS RPTG_SRVC_PHRMCY_DESC,
DIM2 AS RPTG_SRVC_CTGRY_PHRMCY_DESC,
CLMNT_1_CNT,
CLMNT_2_CNT,
CLMNT_3_CNT,
SCRTY_LVL_CD,
current_timestamp as LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY
	FROM (
SELECT	amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID as SRC_FLTR_ID, amstp.AGRGT_ACCT_ID as ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		'TOP10_THRPC_CLMNT' as CLMNT_CNT_TYPE_CD,
		CASE WHEN HC_PD_RNK <= 10 THEN 'Top10' Else 'All Other' END as DIM1, 
		'' as DIM2,
		''  as DIM3,			
		COUNT(DISTINCT fact.MCID) AS CLMNT_1_CNT,
		CAST(0 as INTEGER) as CLMNT_2_CNT,
		CAST(0 as INTEGER) as CLMNT_3_CNT,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD				
	FROM    ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact
	INNER JOIN (SELECT DISTINCT ACCT_ID, SGMNTN_DIM_KEY, AGRGT_SRC_FLTR_ID, SRC_FLTR_ID, AGRGT_ACCT_ID, PAID_STRT_MNTH_NBR, PAID_END_MNTH_NBR, SRVC_STRT_MNTH_NBR, SRVC_END_MNTH_NBR, TM_PRD_TYPE_CD, YEAR_ID, 
INCRD_PAID_CD, AS_OF_YEAR_MNTH_NBR,RPT_RUN_ID, -1 AS RPT_INSTNC_MTDTA_ID, ACCT_SGMNTN_TYPE_NM,SCRTY_LVL_CD, BNCHMRK_ID
from ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM 
WHERE RPT_SHRT_NM in ('RX-01')
AND YEAR_ID = 1
 AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
AND RPT_SPRSN_IND = 'N') amstp 
		ON fact.acct_id = amstp.acct_id
		AND fact.RPTG_PAID_YEAR_MNTH_NBR between  amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
		AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
		AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY
	INNER JOIN ${aciisst_adhoc_schema_name}.DIM_NDC dim
										ON fact.NDC = dim.NDC
	JOIN ${aciisst_adhoc_schema_name}.cii_run_prd PRD ON PRD.RUN_YEAR_MNTH_NBR=amstp.AS_OF_YEAR_MNTH_NBR	
	LEFT JOIN ( 

		SELECT amstp.AGRGT_SRC_FLTR_ID as SRC_FLTR_ID, amstp.AGRGT_ACCT_ID as ACCT_ID, 
		amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD, amstp.TM_PRD_TYPE_CD, amstp.YEAR_ID, 
		dim.GPI_02_GRP_DESC ,
		ROW_NUMBER() OVER( PARTITION BY amstp.AGRGT_SRC_FLTR_ID , amstp.AGRGT_ACCT_ID, 
					amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD
					ORDER BY SUM(fact.ACCT_PAID_AMT) DESC,dim.GPI_02_GRP_DESC ASC ) as HC_PD_RNK
		FROM	(select SGMNTN_DIM_KEY, ACCT_ID, CLM_SRVC_YEAR_MNTH_NBR, RPTG_PAID_YEAR_MNTH_NBR 
				,ACCT_PAID_AMT ,NDC
				FROM ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD WHERE MBR_CVRG_TYPE_CD = '102' AND BK_FILL_IND = 'N' ) fact
      INNER JOIN ${aciisst_adhoc_schema_name}.DIM_NDC dim
										ON fact.NDC = dim.NDC
		JOIN ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM amstp 
		ON 	fact.acct_id = amstp.acct_id
			AND fact.RPTG_PAID_YEAR_MNTH_NBR between  PAID_STRT_MNTH_NBR and PAID_END_MNTH_NBR
			AND fact.CLM_SRVC_YEAR_MNTH_NBR between SRVC_STRT_MNTH_NBR and SRVC_END_MNTH_NBR
			AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY 
		JOIN ${aciisst_adhoc_schema_name}.cii_run_prd PRD
					ON PRD.RUN_YEAR_MNTH_NBR=amstp.AS_OF_YEAR_MNTH_NBR			
		WHERE  dim.BRND_NM NOT IN ('NA','UNKNOWN') and YEAR_ID = 1
        AND RPT_SHRT_NM in ('RX-01')
        AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
        AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
        AND RPT_SPRSN_IND = 'N'
		GROUP BY amstp.AGRGT_SRC_FLTR_ID, amstp.AGRGT_ACCT_ID, 
		amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD, amstp.TM_PRD_TYPE_CD,amstp.YEAR_ID,
		dim.GPI_02_GRP_DESC

		)HC_RNK
		ON amstp.AGRGT_SRC_FLTR_ID = HC_RNK.SRC_FLTR_ID
		AND amstp.AGRGT_ACCT_ID = HC_RNK.ACCT_ID
		AND amstp.AS_OF_YEAR_MNTH_NBR = HC_RNK.AS_OF_YEAR_MNTH_NBR
		AND amstp.INCRD_PAID_CD = HC_RNK.INCRD_PAID_CD
		AND amstp.TM_PRD_TYPE_CD = HC_RNK.TM_PRD_TYPE_CD
		AND DIM.GPI_02_GRP_DESC = HC_RNK.GPI_02_GRP_DESC

 
		WHERE fact.MBR_CVRG_TYPE_CD = '102' AND fact.BK_FILL_IND = 'N'
		GROUP BY amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID, amstp.AGRGT_ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		CASE WHEN HC_PD_RNK <= 10 THEN 'Top10' Else 'All Other' END, 
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD )
        
WHERE 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_PHRMCY_CLMNT_DTL
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR)		
		
UNION ALL

SELECT
AS_OF_YEAR_MNTH_NBR,
INCRD_PAID_CD,
SRC_FLTR_ID,
ACCT_ID,
TM_PRD_TYPE_CD,
YEAR_ID,
RPT_RUN_ID,
RPT_INSTNC_MTDTA_ID,
ACCT_SGMNTN_TYPE_NM,
BNCHMRK_ID,
CLMNT_CNT_TYPE_CD,
DIM1 AS RPTG_SRVC_PHRMCY_DESC,
DIM2 AS RPTG_SRVC_CTGRY_PHRMCY_DESC,
CLMNT_1_CNT,
CLMNT_2_CNT,
CLMNT_3_CNT,
SCRTY_LVL_CD,
current_timestamp as LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY
	FROM (
SELECT	amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID as SRC_FLTR_ID, amstp.AGRGT_ACCT_ID as ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		'DRG_CLMNT' as CLMNT_CNT_TYPE_CD,
		DIM_NDC.BRND_NM as DIM1, 
		GPI_02_GRP_DESC as DIM2,
		'NA' as DIM3,			
		COUNT(DISTINCT fact.MCID) AS CLMNT_1_CNT,
		CAST(0 as INTEGER) as CLMNT_2_CNT,
		CAST(0 as INTEGER) as CLMNT_3_CNT,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD				
	FROM    ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact
	INNER JOIN (SELECT DISTINCT ACCT_ID, SGMNTN_DIM_KEY, AGRGT_SRC_FLTR_ID, SRC_FLTR_ID, AGRGT_ACCT_ID, PAID_STRT_MNTH_NBR, PAID_END_MNTH_NBR, SRVC_STRT_MNTH_NBR, SRVC_END_MNTH_NBR, TM_PRD_TYPE_CD, YEAR_ID, 
INCRD_PAID_CD, AS_OF_YEAR_MNTH_NBR,RPT_RUN_ID, -1 AS RPT_INSTNC_MTDTA_ID, ACCT_SGMNTN_TYPE_NM,SCRTY_LVL_CD, BNCHMRK_ID
from ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM 
WHERE RPT_SHRT_NM in ('RX-01','RX-05')
AND YEAR_ID = 1
 AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) 
AND RPT_SPRSN_IND = 'N') amstp 
		ON fact.acct_id = amstp.acct_id
		AND fact.RPTG_PAID_YEAR_MNTH_NBR between  amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
		AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
		AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY
JOIN ${aciisst_adhoc_schema_name}.DIM_NDC   on fact.NDC = DIM_NDC.NDC  
JOIN ${aciisst_adhoc_schema_name}.cii_run_prd PRD
		ON PRD.RUN_YEAR_MNTH_NBR=amstp.AS_OF_YEAR_MNTH_NBR
		WHERE fact.MBR_CVRG_TYPE_CD = '102' AND fact.BK_FILL_IND = 'N'
		GROUP BY amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID, amstp.AGRGT_ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		DIM_NDC.BRND_NM,
		GPI_02_GRP_DESC,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD )
		
WHERE 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_PHRMCY_CLMNT_DTL
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR)

UNION ALL
	
SELECT
AS_OF_YEAR_MNTH_NBR,
INCRD_PAID_CD,
SRC_FLTR_ID,
ACCT_ID,
TM_PRD_TYPE_CD,
YEAR_ID,
RPT_RUN_ID,
RPT_INSTNC_MTDTA_ID,
ACCT_SGMNTN_TYPE_NM,
BNCHMRK_ID,
CLMNT_CNT_TYPE_CD,
DIM1 AS RPTG_SRVC_PHRMCY_DESC,
DIM2 AS RPTG_SRVC_CTGRY_PHRMCY_DESC,
CLMNT_1_CNT,
CLMNT_2_CNT,
CLMNT_3_CNT,
SCRTY_LVL_CD,
current_timestamp as LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY
	FROM (
SELECT	amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID as SRC_FLTR_ID, amstp.AGRGT_ACCT_ID as ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		'TOP3_DRG_CLMNT' as CLMNT_CNT_TYPE_CD,
		CASE WHEN HC_PD_RNK <= 3 THEN 'TOP3' else 'All Other'  END as DIM1, 
		 dim.GPI_02_GRP_DESC as DIM2,
		'NA' as DIM3,			
		COUNT(DISTINCT fact.MCID) AS CLMNT_1_CNT,
		CAST(0 as INTEGER) as CLMNT_2_CNT,
		CAST(0 as INTEGER) as CLMNT_3_CNT,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD				
	FROM    ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact
	INNER JOIN (SELECT DISTINCT ACCT_ID, SGMNTN_DIM_KEY, AGRGT_SRC_FLTR_ID, SRC_FLTR_ID, AGRGT_ACCT_ID, PAID_STRT_MNTH_NBR, PAID_END_MNTH_NBR, SRVC_STRT_MNTH_NBR, SRVC_END_MNTH_NBR, TM_PRD_TYPE_CD, YEAR_ID, 
INCRD_PAID_CD, AS_OF_YEAR_MNTH_NBR,RPT_RUN_ID, -1 AS RPT_INSTNC_MTDTA_ID, ACCT_SGMNTN_TYPE_NM,SCRTY_LVL_CD, BNCHMRK_ID
from ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM 
WHERE RPT_SHRT_NM in ('RX-01')
AND YEAR_ID = 1
 AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) 
AND RPT_SPRSN_IND = 'N') amstp 
		ON fact.acct_id = amstp.acct_id
		AND fact.RPTG_PAID_YEAR_MNTH_NBR between  amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
		AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
		AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY
JOIN ${aciisst_adhoc_schema_name}.DIM_NDC dim on fact.NDC = dim.NDC 

left join(	SELECT amstp.AGRGT_SRC_FLTR_ID as SRC_FLTR_ID, amstp.AGRGT_ACCT_ID as ACCT_ID, 
		amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD, amstp.TM_PRD_TYPE_CD, amstp.YEAR_ID, 
		dim.GPI_02_GRP_DESC ,
		ROW_NUMBER() OVER( PARTITION BY amstp.AGRGT_SRC_FLTR_ID , amstp.AGRGT_ACCT_ID, 
					amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD
					ORDER BY SUM(fact.ACCT_PAID_AMT) DESC,dim.GPI_02_GRP_DESC ASC ) as HC_PD_RNK
		FROM	(select SGMNTN_DIM_KEY, ACCT_ID, CLM_SRVC_YEAR_MNTH_NBR, RPTG_PAID_YEAR_MNTH_NBR 
				,ACCT_PAID_AMT ,NDC
				FROM ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD WHERE MBR_CVRG_TYPE_CD = '102' AND BK_FILL_IND = 'N' ) fact
      INNER JOIN ${aciisst_adhoc_schema_name}.DIM_NDC dim
										ON fact.NDC = dim.NDC
		JOIN ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM amstp 
		ON 	fact.acct_id = amstp.acct_id
			AND fact.RPTG_PAID_YEAR_MNTH_NBR between  PAID_STRT_MNTH_NBR and PAID_END_MNTH_NBR
			AND fact.CLM_SRVC_YEAR_MNTH_NBR between SRVC_STRT_MNTH_NBR and SRVC_END_MNTH_NBR
			AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY 
		JOIN ${aciisst_adhoc_schema_name}.cii_run_prd PRD
					ON PRD.RUN_YEAR_MNTH_NBR=amstp.AS_OF_YEAR_MNTH_NBR			
		WHERE  dim.GPI_02_GRP_DESC NOT IN ('NA','UNKNOWN') and YEAR_ID = 1 
        AND RPT_SHRT_NM in ('RX-01')
        AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
        AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) 
        AND RPT_SPRSN_IND = 'N'
		GROUP BY amstp.AGRGT_SRC_FLTR_ID, amstp.AGRGT_ACCT_ID, 
		amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD, amstp.TM_PRD_TYPE_CD,amstp.YEAR_ID,
		dim.GPI_02_GRP_DESC

		)HC_RNK
		ON amstp.AGRGT_SRC_FLTR_ID = HC_RNK.SRC_FLTR_ID
		AND amstp.AGRGT_ACCT_ID = HC_RNK.ACCT_ID
		AND amstp.AS_OF_YEAR_MNTH_NBR = HC_RNK.AS_OF_YEAR_MNTH_NBR
		AND amstp.INCRD_PAID_CD = HC_RNK.INCRD_PAID_CD
		AND amstp.TM_PRD_TYPE_CD = HC_RNK.TM_PRD_TYPE_CD
		AND DIM.GPI_02_GRP_DESC = HC_RNK.GPI_02_GRP_DESC

JOIN ${aciisst_adhoc_schema_name}.cii_run_prd PRD
		ON PRD.RUN_YEAR_MNTH_NBR=amstp.AS_OF_YEAR_MNTH_NBR
		WHERE fact.MBR_CVRG_TYPE_CD = '102' AND fact.BK_FILL_IND = 'N'
		GROUP BY amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID, amstp.AGRGT_ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		CASE WHEN HC_PD_RNK <= 3 THEN 'TOP3' else 'All Other' END ,
        dim.GPI_02_GRP_DESC,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD )
		
WHERE 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_PHRMCY_CLMNT_DTL
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR)

UNION ALL

SELECT
AS_OF_YEAR_MNTH_NBR,
INCRD_PAID_CD,
SRC_FLTR_ID,
ACCT_ID,
TM_PRD_TYPE_CD,
YEAR_ID,
RPT_RUN_ID,
RPT_INSTNC_MTDTA_ID,
ACCT_SGMNTN_TYPE_NM,
BNCHMRK_ID,
CLMNT_CNT_TYPE_CD,
DIM1 AS RPTG_SRVC_PHRMCY_DESC,
DIM2 AS RPTG_SRVC_CTGRY_PHRMCY_DESC,
CLMNT_1_CNT,
CLMNT_2_CNT,
CLMNT_3_CNT,
SCRTY_LVL_CD,
current_timestamp as LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY
	FROM (
SELECT	amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID as SRC_FLTR_ID, amstp.AGRGT_ACCT_ID as ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		'MO_CLMNT' as CLMNT_CNT_TYPE_CD,
		 fact.RPTG_MO_IND as DIM1, 
		'NA' as DIM2,
		'NA' as DIM3,			
		COUNT(DISTINCT fact.MCID) AS CLMNT_1_CNT,
		CAST(0 as INTEGER) as CLMNT_2_CNT,
		CAST(0 as INTEGER) as CLMNT_3_CNT,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD				
	FROM    ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact
	INNER JOIN (SELECT DISTINCT ACCT_ID, SGMNTN_DIM_KEY, AGRGT_SRC_FLTR_ID, SRC_FLTR_ID, AGRGT_ACCT_ID, PAID_STRT_MNTH_NBR, PAID_END_MNTH_NBR, SRVC_STRT_MNTH_NBR, SRVC_END_MNTH_NBR, TM_PRD_TYPE_CD, YEAR_ID, 
INCRD_PAID_CD, AS_OF_YEAR_MNTH_NBR,RPT_RUN_ID, -1 AS RPT_INSTNC_MTDTA_ID, ACCT_SGMNTN_TYPE_NM,SCRTY_LVL_CD, BNCHMRK_ID
from ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM 
WHERE RPT_SHRT_NM in ('RX-02','RX-04')
AND YEAR_ID <= 3
 AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) 
AND RPT_SPRSN_IND = 'N') amstp 
		ON fact.acct_id = amstp.acct_id
		AND fact.RPTG_PAID_YEAR_MNTH_NBR between  amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
		AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
		AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY
JOIN ${aciisst_adhoc_schema_name}.cii_run_prd PRD
		ON PRD.RUN_YEAR_MNTH_NBR=amstp.AS_OF_YEAR_MNTH_NBR
		WHERE fact.MBR_CVRG_TYPE_CD = '102' AND fact.BK_FILL_IND = 'N'
		GROUP BY amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID, amstp.AGRGT_ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		fact.RPTG_MO_IND,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD )
		
WHERE 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_PHRMCY_CLMNT_DTL
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR)

UNION ALL

SELECT
AS_OF_YEAR_MNTH_NBR,
INCRD_PAID_CD,
SRC_FLTR_ID,
ACCT_ID,
TM_PRD_TYPE_CD,
YEAR_ID,
RPT_RUN_ID,
RPT_INSTNC_MTDTA_ID,
ACCT_SGMNTN_TYPE_NM,
BNCHMRK_ID,
CLMNT_CNT_TYPE_CD,
DIM1 AS RPTG_SRVC_PHRMCY_DESC,
DIM2 AS RPTG_SRVC_CTGRY_PHRMCY_DESC,
CLMNT_1_CNT,
CLMNT_2_CNT,
CLMNT_3_CNT,
SCRTY_LVL_CD,
current_timestamp as LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY
	FROM (
SELECT	amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID as SRC_FLTR_ID, amstp.AGRGT_ACCT_ID as ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		'MO_BRND_CLMNT' as CLMNT_CNT_TYPE_CD,
		RPTG_MO_IND as DIM1, 
		BRND_DRG_IND as DIM2,
		'NA' as DIM3,			
		COUNT(DISTINCT fact.MCID) AS CLMNT_1_CNT,
		CAST(0 as INTEGER) as CLMNT_2_CNT,
		CAST(0 as INTEGER) as CLMNT_3_CNT,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD				
	FROM    ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact
	INNER JOIN (SELECT DISTINCT ACCT_ID, SGMNTN_DIM_KEY, AGRGT_SRC_FLTR_ID, SRC_FLTR_ID, AGRGT_ACCT_ID, PAID_STRT_MNTH_NBR, PAID_END_MNTH_NBR, SRVC_STRT_MNTH_NBR, SRVC_END_MNTH_NBR, TM_PRD_TYPE_CD, YEAR_ID, 
INCRD_PAID_CD, AS_OF_YEAR_MNTH_NBR,RPT_RUN_ID, -1 AS RPT_INSTNC_MTDTA_ID, ACCT_SGMNTN_TYPE_NM,SCRTY_LVL_CD, BNCHMRK_ID
from ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM 
WHERE RPT_SHRT_NM in ('RX-02')
AND YEAR_ID <= 3
 AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
AND RPT_SPRSN_IND = 'N') amstp 
		ON fact.acct_id = amstp.acct_id
		AND fact.RPTG_PAID_YEAR_MNTH_NBR between  amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
		AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
		AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY
JOIN ${aciisst_adhoc_schema_name}.cii_run_prd PRD
		ON PRD.RUN_YEAR_MNTH_NBR=amstp.AS_OF_YEAR_MNTH_NBR
		WHERE fact.MBR_CVRG_TYPE_CD = '102' AND fact.BK_FILL_IND = 'N'
		GROUP BY amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID, amstp.AGRGT_ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		fact.RPTG_MO_IND,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD,
		fact.BRND_DRG_IND )
		
WHERE 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_PHRMCY_CLMNT_DTL
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR)
		
UNION ALL

SELECT
AS_OF_YEAR_MNTH_NBR,
INCRD_PAID_CD,
SRC_FLTR_ID,
ACCT_ID,
TM_PRD_TYPE_CD,
YEAR_ID,
RPT_RUN_ID,
RPT_INSTNC_MTDTA_ID,
ACCT_SGMNTN_TYPE_NM,
BNCHMRK_ID,
CLMNT_CNT_TYPE_CD,
DIM1 AS RPTG_SRVC_PHRMCY_DESC,
DIM2 AS RPTG_SRVC_CTGRY_PHRMCY_DESC,
CLMNT_1_CNT,
CLMNT_2_CNT,
CLMNT_3_CNT,
SCRTY_LVL_CD,
current_timestamp as LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY
	FROM (
SELECT	amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID as SRC_FLTR_ID, amstp.AGRGT_ACCT_ID as ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		'BRND_CLMNT' as CLMNT_CNT_TYPE_CD,
		BRND_DRG_IND as DIM1, 
		'NA' as DIM2,
		'NA' as DIM3,			
		COUNT(DISTINCT fact.MCID) AS CLMNT_1_CNT,
		CAST(0 as INTEGER) as CLMNT_2_CNT,
		CAST(0 as INTEGER) as CLMNT_3_CNT,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD				
	FROM  ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact
	INNER JOIN (SELECT DISTINCT ACCT_ID, SGMNTN_DIM_KEY, AGRGT_SRC_FLTR_ID, SRC_FLTR_ID, AGRGT_ACCT_ID, PAID_STRT_MNTH_NBR, PAID_END_MNTH_NBR, SRVC_STRT_MNTH_NBR, SRVC_END_MNTH_NBR, TM_PRD_TYPE_CD, YEAR_ID, 
INCRD_PAID_CD, AS_OF_YEAR_MNTH_NBR,RPT_RUN_ID, -1 AS RPT_INSTNC_MTDTA_ID, ACCT_SGMNTN_TYPE_NM,SCRTY_LVL_CD, BNCHMRK_ID
from ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM 
WHERE RPT_SHRT_NM in ('RX-02')
AND YEAR_ID <= 3
 AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
AND RPT_SPRSN_IND = 'N') amstp 
		ON fact.acct_id = amstp.acct_id
		AND fact.RPTG_PAID_YEAR_MNTH_NBR between  amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
		AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
		AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY
JOIN ${aciisst_adhoc_schema_name}.cii_run_prd PRD
		ON PRD.RUN_YEAR_MNTH_NBR=amstp.AS_OF_YEAR_MNTH_NBR
		WHERE fact.MBR_CVRG_TYPE_CD = '102' AND fact.BK_FILL_IND = 'N'
		GROUP BY amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID, amstp.AGRGT_ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		fact.BRND_DRG_IND,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD)
		
WHERE 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_PHRMCY_CLMNT_DTL
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR)

UNION ALL

SELECT
AS_OF_YEAR_MNTH_NBR,
INCRD_PAID_CD,
SRC_FLTR_ID,
ACCT_ID,
TM_PRD_TYPE_CD,
YEAR_ID,
RPT_RUN_ID,
RPT_INSTNC_MTDTA_ID,
ACCT_SGMNTN_TYPE_NM,
BNCHMRK_ID,
CLMNT_CNT_TYPE_CD,
DIM1 AS RPTG_SRVC_PHRMCY_DESC,
DIM2 AS RPTG_SRVC_CTGRY_PHRMCY_DESC,
CLMNT_1_CNT,
CLMNT_2_CNT,
CLMNT_3_CNT,
SCRTY_LVL_CD,
current_timestamp as LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY
	FROM (
SELECT	amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID as SRC_FLTR_ID, amstp.AGRGT_ACCT_ID as ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		'MO_FRMLRY_CLMNT' as CLMNT_CNT_TYPE_CD,
		RPTG_FRMLRY_IND as DIM1, 
		RPTG_MO_IND as DIM2,
		'NA' as DIM3,			
		COUNT(DISTINCT fact.MCID) AS CLMNT_1_CNT,
		CAST(0 as INTEGER) as CLMNT_2_CNT,
		CAST(0 as INTEGER) as CLMNT_3_CNT,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD				
	FROM    ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact
	INNER JOIN (SELECT DISTINCT ACCT_ID, SGMNTN_DIM_KEY, AGRGT_SRC_FLTR_ID, SRC_FLTR_ID, AGRGT_ACCT_ID, PAID_STRT_MNTH_NBR, PAID_END_MNTH_NBR, SRVC_STRT_MNTH_NBR, SRVC_END_MNTH_NBR, TM_PRD_TYPE_CD, YEAR_ID, 
INCRD_PAID_CD, AS_OF_YEAR_MNTH_NBR,RPT_RUN_ID, -1 AS RPT_INSTNC_MTDTA_ID, ACCT_SGMNTN_TYPE_NM,SCRTY_LVL_CD, BNCHMRK_ID
from ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM 
WHERE RPT_SHRT_NM in ('RX-02')
AND YEAR_ID <= 3
 AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) 
AND RPT_SPRSN_IND = 'N') amstp 
		ON fact.acct_id = amstp.acct_id
		AND fact.RPTG_PAID_YEAR_MNTH_NBR between  amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
		AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
		AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY
JOIN ${aciisst_adhoc_schema_name}.cii_run_prd PRD
		ON PRD.RUN_YEAR_MNTH_NBR=amstp.AS_OF_YEAR_MNTH_NBR
		WHERE fact.MBR_CVRG_TYPE_CD = '102' AND fact.BK_FILL_IND = 'N'
		GROUP BY amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID, amstp.AGRGT_ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		fact.RPTG_FRMLRY_IND,
		fact.RPTG_MO_IND,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD)
		
WHERE 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_PHRMCY_CLMNT_DTL
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR)

UNION ALL

SELECT
AS_OF_YEAR_MNTH_NBR,
INCRD_PAID_CD,
SRC_FLTR_ID,
ACCT_ID,
TM_PRD_TYPE_CD,
YEAR_ID,
RPT_RUN_ID,
RPT_INSTNC_MTDTA_ID,
ACCT_SGMNTN_TYPE_NM,
BNCHMRK_ID,
CLMNT_CNT_TYPE_CD,
DIM1 AS RPTG_SRVC_PHRMCY_DESC,
DIM2 AS RPTG_SRVC_CTGRY_PHRMCY_DESC,
CLMNT_1_CNT,
CLMNT_2_CNT,
CLMNT_3_CNT,
SCRTY_LVL_CD,
current_timestamp as LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY
	FROM (
SELECT	amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID as SRC_FLTR_ID, amstp.AGRGT_ACCT_ID as ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		'FRMLRY_CLMNT' as CLMNT_CNT_TYPE_CD,
		RPTG_FRMLRY_IND as DIM1, 
		'NA' as DIM2,
		'NA' as DIM3,			
		COUNT(DISTINCT fact.MCID) AS CLMNT_1_CNT,
		CAST(0 as INTEGER) as CLMNT_2_CNT,
		CAST(0 as INTEGER) as CLMNT_3_CNT,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD				
	FROM    ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact
	INNER JOIN (SELECT DISTINCT ACCT_ID, SGMNTN_DIM_KEY, AGRGT_SRC_FLTR_ID, SRC_FLTR_ID, AGRGT_ACCT_ID, PAID_STRT_MNTH_NBR, PAID_END_MNTH_NBR, SRVC_STRT_MNTH_NBR, SRVC_END_MNTH_NBR, TM_PRD_TYPE_CD, YEAR_ID, 
INCRD_PAID_CD, AS_OF_YEAR_MNTH_NBR,RPT_RUN_ID, -1 AS RPT_INSTNC_MTDTA_ID, ACCT_SGMNTN_TYPE_NM,SCRTY_LVL_CD, BNCHMRK_ID
from ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM 
WHERE RPT_SHRT_NM in ('RX-02')
AND YEAR_ID <= 3
 AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) 
AND RPT_SPRSN_IND = 'N') amstp 
		ON fact.acct_id = amstp.acct_id
		AND fact.RPTG_PAID_YEAR_MNTH_NBR between  amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
		AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
		AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY
JOIN ${aciisst_adhoc_schema_name}.cii_run_prd PRD
		ON PRD.RUN_YEAR_MNTH_NBR=amstp.AS_OF_YEAR_MNTH_NBR
		WHERE fact.MBR_CVRG_TYPE_CD = '102' AND fact.BK_FILL_IND = 'N'
		GROUP BY amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID, amstp.AGRGT_ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		fact.RPTG_FRMLRY_IND,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD)
		
WHERE 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_PHRMCY_CLMNT_DTL
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR)

UNION ALL

SELECT
AS_OF_YEAR_MNTH_NBR,
INCRD_PAID_CD,
SRC_FLTR_ID,
ACCT_ID,
TM_PRD_TYPE_CD,
YEAR_ID,
RPT_RUN_ID,
RPT_INSTNC_MTDTA_ID,
ACCT_SGMNTN_TYPE_NM,
BNCHMRK_ID,
CLMNT_CNT_TYPE_CD,
DIM1 AS RPTG_SRVC_PHRMCY_DESC,
DIM2 AS RPTG_SRVC_CTGRY_PHRMCY_DESC,
CLMNT_1_CNT,
CLMNT_2_CNT,
CLMNT_3_CNT,
SCRTY_LVL_CD,
current_timestamp as LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY
	FROM (
SELECT	amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID as SRC_FLTR_ID, amstp.AGRGT_ACCT_ID as ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		'MO_DRGSRC_CLMNT' as CLMNT_CNT_TYPE_CD,
		 fact.DRUG_SRC_CD as DIM1, 
		RPTG_MO_IND as DIM2,
		'NA' as DIM3,			
		COUNT(DISTINCT fact.MCID) AS CLMNT_1_CNT,
		CAST(0 as INTEGER) as CLMNT_2_CNT,
		CAST(0 as INTEGER) as CLMNT_3_CNT,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD				
	FROM    ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact
	INNER JOIN (SELECT DISTINCT ACCT_ID, SGMNTN_DIM_KEY, AGRGT_SRC_FLTR_ID, SRC_FLTR_ID, AGRGT_ACCT_ID, PAID_STRT_MNTH_NBR, PAID_END_MNTH_NBR, SRVC_STRT_MNTH_NBR, SRVC_END_MNTH_NBR, TM_PRD_TYPE_CD, YEAR_ID, 
INCRD_PAID_CD, AS_OF_YEAR_MNTH_NBR,RPT_RUN_ID, -1 AS RPT_INSTNC_MTDTA_ID, ACCT_SGMNTN_TYPE_NM,SCRTY_LVL_CD, BNCHMRK_ID
from ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM 
WHERE RPT_SHRT_NM in ('RX-04')
AND YEAR_ID <= 3
 AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
AND RPT_SPRSN_IND = 'N') amstp 
		ON fact.acct_id = amstp.acct_id
		AND fact.RPTG_PAID_YEAR_MNTH_NBR between  amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
		AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
		AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY
JOIN ${aciisst_adhoc_schema_name}.DIM_DRUG_SRC  drg on fact.DRUG_SRC_CD = drg.DRUG_SRC_CD
JOIN ${aciisst_adhoc_schema_name}.cii_run_prd PRD
		ON PRD.RUN_YEAR_MNTH_NBR=amstp.AS_OF_YEAR_MNTH_NBR
		WHERE fact.MBR_CVRG_TYPE_CD = '102' AND fact.BK_FILL_IND = 'N'
		GROUP BY amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID, amstp.AGRGT_ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		fact.DRUG_SRC_CD,
		fact.RPTG_MO_IND,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD )
		
WHERE 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_PHRMCY_CLMNT_DTL
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR)

UNION ALL

SELECT
AS_OF_YEAR_MNTH_NBR,
INCRD_PAID_CD,
SRC_FLTR_ID,
ACCT_ID,
TM_PRD_TYPE_CD,
YEAR_ID,
RPT_RUN_ID,
RPT_INSTNC_MTDTA_ID,
ACCT_SGMNTN_TYPE_NM,
BNCHMRK_ID,
CLMNT_CNT_TYPE_CD,
DIM1 AS RPTG_SRVC_PHRMCY_DESC,
DIM2 AS RPTG_SRVC_CTGRY_PHRMCY_DESC,
CLMNT_1_CNT,
CLMNT_2_CNT,
CLMNT_3_CNT,
SCRTY_LVL_CD,
current_timestamp as LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY
	FROM (
SELECT	amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID as SRC_FLTR_ID, amstp.AGRGT_ACCT_ID as ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		'DRGSRC_CLMNT' as CLMNT_CNT_TYPE_CD,
		 fact.DRUG_SRC_CD as DIM1, 
		'NA' as DIM2,
		'NA' as DIM3,			
		COUNT(DISTINCT fact.MCID) AS CLMNT_1_CNT,
		CAST(0 as INTEGER) as CLMNT_2_CNT,
		CAST(0 as INTEGER) as CLMNT_3_CNT,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD				
	FROM    ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact
	INNER JOIN (SELECT DISTINCT ACCT_ID, SGMNTN_DIM_KEY, AGRGT_SRC_FLTR_ID, SRC_FLTR_ID, AGRGT_ACCT_ID, PAID_STRT_MNTH_NBR, PAID_END_MNTH_NBR, SRVC_STRT_MNTH_NBR, SRVC_END_MNTH_NBR, TM_PRD_TYPE_CD, YEAR_ID, 
INCRD_PAID_CD, AS_OF_YEAR_MNTH_NBR,RPT_RUN_ID, -1 AS RPT_INSTNC_MTDTA_ID, ACCT_SGMNTN_TYPE_NM,SCRTY_LVL_CD, BNCHMRK_ID
from ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM 
WHERE RPT_SHRT_NM in ('RX-04')
AND YEAR_ID <= 3
 AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) 
AND RPT_SPRSN_IND = 'N') amstp 
		ON fact.acct_id = amstp.acct_id
		AND fact.RPTG_PAID_YEAR_MNTH_NBR between  amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
		AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
		AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY
JOIN ${aciisst_adhoc_schema_name}.DIM_DRUG_SRC  drg on fact.DRUG_SRC_CD = drg.DRUG_SRC_CD
JOIN ${aciisst_adhoc_schema_name}.cii_run_prd PRD
		ON PRD.RUN_YEAR_MNTH_NBR=amstp.AS_OF_YEAR_MNTH_NBR
		WHERE fact.MBR_CVRG_TYPE_CD = '102' AND fact.BK_FILL_IND = 'N' 
		GROUP BY amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID, amstp.AGRGT_ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		fact.DRUG_SRC_CD,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD )
		
WHERE 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_PHRMCY_CLMNT_DTL
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR)

UNION ALL

SELECT
AS_OF_YEAR_MNTH_NBR,
INCRD_PAID_CD,
SRC_FLTR_ID,
ACCT_ID,
TM_PRD_TYPE_CD,
YEAR_ID,
RPT_RUN_ID,
RPT_INSTNC_MTDTA_ID,
ACCT_SGMNTN_TYPE_NM,
BNCHMRK_ID,
CLMNT_CNT_TYPE_CD,
DIM1 AS RPTG_SRVC_PHRMCY_DESC,
DIM2 AS RPTG_SRVC_CTGRY_PHRMCY_DESC,
CLMNT_1_CNT,
CLMNT_2_CNT,
CLMNT_3_CNT,
SCRTY_LVL_CD,
current_timestamp as LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY
	FROM (
SELECT	amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID as SRC_FLTR_ID, amstp.AGRGT_ACCT_ID as ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		'TOP25_DRG_CLMNT' as CLMNT_CNT_TYPE_CD,
		CASE WHEN HC_PD_RNK <= 25 THEN 'Top25' Else 'All Other' END as DIM1, 
		'' as DIM2,
		''  as DIM3,			
		COUNT(DISTINCT fact.MCID) AS CLMNT_1_CNT,
		CAST(0 as INTEGER) as CLMNT_2_CNT,
		CAST(0 as INTEGER) as CLMNT_3_CNT,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD				
	FROM    ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact
	INNER JOIN (SELECT DISTINCT ACCT_ID, SGMNTN_DIM_KEY, AGRGT_SRC_FLTR_ID, SRC_FLTR_ID, AGRGT_ACCT_ID, PAID_STRT_MNTH_NBR, PAID_END_MNTH_NBR, SRVC_STRT_MNTH_NBR, SRVC_END_MNTH_NBR, TM_PRD_TYPE_CD, YEAR_ID, 
INCRD_PAID_CD, AS_OF_YEAR_MNTH_NBR,RPT_RUN_ID, -1 AS RPT_INSTNC_MTDTA_ID, ACCT_SGMNTN_TYPE_NM,SCRTY_LVL_CD, BNCHMRK_ID
from ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM 
WHERE RPT_SHRT_NM in ('RX-05')
AND YEAR_ID = 1
 AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
AND RPT_SPRSN_IND = 'N') amstp 
		ON fact.acct_id = amstp.acct_id
		AND fact.RPTG_PAID_YEAR_MNTH_NBR between  amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
		AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
		AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY
	LEFT JOIN ${aciisst_adhoc_schema_name}.DIM_NDC dim
										ON fact.NDC = dim.NDC
	JOIN ${aciisst_adhoc_schema_name}.cii_run_prd PRD ON PRD.RUN_YEAR_MNTH_NBR=amstp.AS_OF_YEAR_MNTH_NBR	
	LEFT JOIN ( 

		SELECT amstp.AGRGT_SRC_FLTR_ID as SRC_FLTR_ID, amstp.AGRGT_ACCT_ID as ACCT_ID, 
		amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD, amstp.TM_PRD_TYPE_CD, amstp.YEAR_ID, 
		dim.BRND_NM ,
		ROW_NUMBER() OVER( PARTITION BY amstp.AGRGT_SRC_FLTR_ID , amstp.AGRGT_ACCT_ID, 
					amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD
					ORDER BY SUM(fact.ACCT_PAID_AMT) DESC,dim.BRND_NM ASC ) as HC_PD_RNK
		FROM	(select SGMNTN_DIM_KEY, ACCT_ID, CLM_SRVC_YEAR_MNTH_NBR, RPTG_PAID_YEAR_MNTH_NBR 
				,ACCT_PAID_AMT ,NDC
				FROM ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD WHERE MBR_CVRG_TYPE_CD = '102' AND BK_FILL_IND = 'N' ) fact
      LEFT JOIN ${aciisst_adhoc_schema_name}.DIM_NDC dim
										ON fact.NDC = dim.NDC
		JOIN ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM amstp 
		ON 	fact.acct_id = amstp.acct_id
			AND fact.RPTG_PAID_YEAR_MNTH_NBR between  PAID_STRT_MNTH_NBR and PAID_END_MNTH_NBR
			AND fact.CLM_SRVC_YEAR_MNTH_NBR between SRVC_STRT_MNTH_NBR and SRVC_END_MNTH_NBR
			AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY
            AND YEAR_ID = 1 and RPT_SHRT_NM in ('RX-05') 
            AND RPT_SPRSN_IND = 'N'
      
		JOIN ${aciisst_adhoc_schema_name}.cii_run_prd PRD
					ON PRD.RUN_YEAR_MNTH_NBR=amstp.AS_OF_YEAR_MNTH_NBR			
		WHERE  dim.BRND_NM NOT IN ('NA','UNKNOWN') and YEAR_ID = 1
          AND RPT_SHRT_NM in ('RX-05')
          AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
          AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
          AND RPT_SPRSN_IND = 'N'
		GROUP BY amstp.AGRGT_SRC_FLTR_ID, amstp.AGRGT_ACCT_ID, 
		amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD, amstp.TM_PRD_TYPE_CD,amstp.YEAR_ID,
		dim.BRND_NM

		)HC_RNK
		ON amstp.AGRGT_SRC_FLTR_ID = HC_RNK.SRC_FLTR_ID
		AND amstp.AGRGT_ACCT_ID = HC_RNK.ACCT_ID
		AND amstp.AS_OF_YEAR_MNTH_NBR = HC_RNK.AS_OF_YEAR_MNTH_NBR
		AND amstp.INCRD_PAID_CD = HC_RNK.INCRD_PAID_CD
		AND amstp.TM_PRD_TYPE_CD = HC_RNK.TM_PRD_TYPE_CD
		AND DIM.BRND_NM = HC_RNK.BRND_NM

 
		WHERE fact.MBR_CVRG_TYPE_CD = '102' AND fact.BK_FILL_IND = 'N'
		GROUP BY amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID, amstp.AGRGT_ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		CASE WHEN HC_PD_RNK <= 25 THEN 'Top25' Else 'All Other' END, 
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD )
		
WHERE 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_PHRMCY_CLMNT_DTL
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR)

UNION ALL

SELECT
AS_OF_YEAR_MNTH_NBR,
INCRD_PAID_CD,
SRC_FLTR_ID,
ACCT_ID,
TM_PRD_TYPE_CD,
YEAR_ID,
RPT_RUN_ID,
RPT_INSTNC_MTDTA_ID,
ACCT_SGMNTN_TYPE_NM,
BNCHMRK_ID,
CLMNT_CNT_TYPE_CD,
DIM1 AS RPTG_SRVC_PHRMCY_DESC,
DIM2 AS RPTG_SRVC_CTGRY_PHRMCY_DESC,
CLMNT_1_CNT,
CLMNT_2_CNT,
CLMNT_3_CNT,
SCRTY_LVL_CD,
current_timestamp as LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY
	FROM (
SELECT	amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID as SRC_FLTR_ID, amstp.AGRGT_ACCT_ID as ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		'SPEC_DRG_CLMNT' as CLMNT_CNT_TYPE_CD,
		DIM_NDC.BRND_NM as DIM1, 
		GPI_02_GRP_DESC as DIM2,
		'NA' as DIM3,			
		COUNT(DISTINCT fact.MCID) AS CLMNT_1_CNT,
		CAST(0 as INTEGER) as CLMNT_2_CNT,
		CAST(0 as INTEGER) as CLMNT_3_CNT,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD				
	FROM    ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact
	INNER JOIN (SELECT DISTINCT ACCT_ID, SGMNTN_DIM_KEY, AGRGT_SRC_FLTR_ID, SRC_FLTR_ID, AGRGT_ACCT_ID, PAID_STRT_MNTH_NBR, PAID_END_MNTH_NBR, SRVC_STRT_MNTH_NBR, SRVC_END_MNTH_NBR, TM_PRD_TYPE_CD, YEAR_ID, 
INCRD_PAID_CD, AS_OF_YEAR_MNTH_NBR,RPT_RUN_ID, -1 AS RPT_INSTNC_MTDTA_ID, ACCT_SGMNTN_TYPE_NM,SCRTY_LVL_CD, BNCHMRK_ID
from ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM 
WHERE RPT_SHRT_NM in ('RX-06')
AND YEAR_ID = 1
 AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) 
AND RPT_SPRSN_IND = 'N') amstp 
		ON fact.acct_id = amstp.acct_id
		AND fact.RPTG_PAID_YEAR_MNTH_NBR between  amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
		AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
		AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY
JOIN ${aciisst_adhoc_schema_name}.DIM_NDC   on fact.NDC = DIM_NDC.NDC  
JOIN ${aciisst_adhoc_schema_name}.cii_run_prd PRD
		ON PRD.RUN_YEAR_MNTH_NBR=amstp.AS_OF_YEAR_MNTH_NBR
		WHERE fact.MBR_CVRG_TYPE_CD = '102' AND fact.BK_FILL_IND = 'N' and fact.SPCLTY_DRG_IND = 'Y'
		GROUP BY amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID, amstp.AGRGT_ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		DIM_NDC.BRND_NM,
		GPI_02_GRP_DESC,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD )
		
WHERE 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_PHRMCY_CLMNT_DTL
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR)

UNION ALL

SELECT
AS_OF_YEAR_MNTH_NBR,
INCRD_PAID_CD,
SRC_FLTR_ID,
ACCT_ID,
TM_PRD_TYPE_CD,
YEAR_ID,
RPT_RUN_ID,
RPT_INSTNC_MTDTA_ID,
ACCT_SGMNTN_TYPE_NM,
BNCHMRK_ID,
CLMNT_CNT_TYPE_CD,
DIM1 AS RPTG_SRVC_PHRMCY_DESC,
DIM2 AS RPTG_SRVC_CTGRY_PHRMCY_DESC,
CLMNT_1_CNT,
CLMNT_2_CNT,
CLMNT_3_CNT,
SCRTY_LVL_CD,
current_timestamp as LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY
	FROM (
SELECT	amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID as SRC_FLTR_ID, amstp.AGRGT_ACCT_ID as ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		'TOP25_SPEC_DRG_CLMNT' as CLMNT_CNT_TYPE_CD,
		CASE WHEN HC_PD_RNK <= 25 THEN 'Top25' Else 'All Other' END as DIM1, 
		'' as DIM2,
		''  as DIM3,			
		COUNT(DISTINCT fact.MCID) AS CLMNT_1_CNT,
		CAST(0 as INTEGER) as CLMNT_2_CNT,
		CAST(0 as INTEGER) as CLMNT_3_CNT,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD				
	FROM    ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact
	INNER JOIN (SELECT DISTINCT ACCT_ID, SGMNTN_DIM_KEY, AGRGT_SRC_FLTR_ID, SRC_FLTR_ID, AGRGT_ACCT_ID, PAID_STRT_MNTH_NBR, PAID_END_MNTH_NBR, SRVC_STRT_MNTH_NBR, SRVC_END_MNTH_NBR, TM_PRD_TYPE_CD, YEAR_ID, 
INCRD_PAID_CD, AS_OF_YEAR_MNTH_NBR,RPT_RUN_ID, -1 AS RPT_INSTNC_MTDTA_ID, ACCT_SGMNTN_TYPE_NM,SCRTY_LVL_CD, BNCHMRK_ID
from ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM 
WHERE RPT_SHRT_NM in ('RX-06')
AND YEAR_ID = 1
 AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) 
AND RPT_SPRSN_IND = 'N') amstp 
		ON fact.acct_id = amstp.acct_id
		AND fact.RPTG_PAID_YEAR_MNTH_NBR between  amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
		AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
		AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY
	INNER JOIN ${aciisst_adhoc_schema_name}.DIM_NDC dim
										ON fact.NDC = dim.NDC
	JOIN ${aciisst_adhoc_schema_name}.cii_run_prd PRD ON PRD.RUN_YEAR_MNTH_NBR=amstp.AS_OF_YEAR_MNTH_NBR	
	LEFT JOIN ( 

		SELECT amstp.AGRGT_SRC_FLTR_ID as SRC_FLTR_ID, amstp.AGRGT_ACCT_ID as ACCT_ID, 
		amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD, amstp.TM_PRD_TYPE_CD, amstp.YEAR_ID, 
		dim.BRND_NM ,
		ROW_NUMBER() OVER( PARTITION BY amstp.AGRGT_SRC_FLTR_ID , amstp.AGRGT_ACCT_ID, 
					amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD
					ORDER BY SUM(fact.ACCT_PAID_AMT) DESC,dim.BRND_NM ASC ) as HC_PD_RNK
		FROM	(select SGMNTN_DIM_KEY, ACCT_ID, CLM_SRVC_YEAR_MNTH_NBR, RPTG_PAID_YEAR_MNTH_NBR 
				,ACCT_PAID_AMT ,NDC
				FROM ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD WHERE MBR_CVRG_TYPE_CD = '102' AND BK_FILL_IND = 'N' and  SPCLTY_DRG_IND = 'Y' ) fact
      INNER JOIN ${aciisst_adhoc_schema_name}.DIM_NDC dim
										ON fact.NDC = dim.NDC
		JOIN ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM amstp 
		ON 	fact.acct_id = amstp.acct_id
			AND fact.RPTG_PAID_YEAR_MNTH_NBR between  PAID_STRT_MNTH_NBR and PAID_END_MNTH_NBR
			AND fact.CLM_SRVC_YEAR_MNTH_NBR between SRVC_STRT_MNTH_NBR and SRVC_END_MNTH_NBR
			AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY 
		JOIN ${aciisst_adhoc_schema_name}.cii_run_prd PRD
					ON PRD.RUN_YEAR_MNTH_NBR=amstp.AS_OF_YEAR_MNTH_NBR			
		WHERE  dim.BRND_NM NOT IN ('NA','UNKNOWN') and YEAR_ID = 1
          AND RPT_SHRT_NM in ('RX-06')
          AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
          AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) 
          AND RPT_SPRSN_IND = 'N'
		GROUP BY amstp.AGRGT_SRC_FLTR_ID, amstp.AGRGT_ACCT_ID, 
		amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD, amstp.TM_PRD_TYPE_CD,amstp.YEAR_ID,
		dim.BRND_NM

		)HC_RNK
		ON amstp.AGRGT_SRC_FLTR_ID = HC_RNK.SRC_FLTR_ID
		AND amstp.AGRGT_ACCT_ID = HC_RNK.ACCT_ID
		AND amstp.AS_OF_YEAR_MNTH_NBR = HC_RNK.AS_OF_YEAR_MNTH_NBR
		AND amstp.INCRD_PAID_CD = HC_RNK.INCRD_PAID_CD
		AND amstp.TM_PRD_TYPE_CD = HC_RNK.TM_PRD_TYPE_CD
		AND DIM.BRND_NM = HC_RNK.BRND_NM

 
		WHERE fact.MBR_CVRG_TYPE_CD = '102' AND fact.BK_FILL_IND = 'N' and fact.SPCLTY_DRG_IND = 'Y'
		GROUP BY amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID, amstp.AGRGT_ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		CASE WHEN HC_PD_RNK <= 25 THEN 'Top25' Else 'All Other' END, 
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD )
		
WHERE 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_PHRMCY_CLMNT_DTL
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR)

UNION ALL

SELECT
AS_OF_YEAR_MNTH_NBR,
INCRD_PAID_CD,
SRC_FLTR_ID,
ACCT_ID,
TM_PRD_TYPE_CD,
YEAR_ID,
RPT_RUN_ID,
RPT_INSTNC_MTDTA_ID,
ACCT_SGMNTN_TYPE_NM,
BNCHMRK_ID,
CLMNT_CNT_TYPE_CD,
DIM1 AS RPTG_SRVC_PHRMCY_DESC,
DIM2 AS RPTG_SRVC_CTGRY_PHRMCY_DESC,
CLMNT_1_CNT,
CLMNT_2_CNT,
CLMNT_3_CNT,
SCRTY_LVL_CD,
current_timestamp as LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY
	FROM (
SELECT	amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID as SRC_FLTR_ID, amstp.AGRGT_ACCT_ID as ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		'JCODE_CLMNT' as CLMNT_CNT_TYPE_CD,
		fact.HLTH_SRVC_CD as DIM1, 
		'NA' as DIM2,
		'NA' as DIM3,			
		COUNT(DISTINCT fact.MCID) AS CLMNT_1_CNT,
		CAST(0 as INTEGER) as CLMNT_2_CNT,
		CAST(0 as INTEGER) as CLMNT_3_CNT,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD				
	FROM    ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact
	INNER JOIN (SELECT DISTINCT ACCT_ID, SGMNTN_DIM_KEY, AGRGT_SRC_FLTR_ID, SRC_FLTR_ID, AGRGT_ACCT_ID, PAID_STRT_MNTH_NBR, PAID_END_MNTH_NBR, SRVC_STRT_MNTH_NBR, SRVC_END_MNTH_NBR, TM_PRD_TYPE_CD, YEAR_ID, 
INCRD_PAID_CD, AS_OF_YEAR_MNTH_NBR,RPT_RUN_ID, -1 AS RPT_INSTNC_MTDTA_ID, ACCT_SGMNTN_TYPE_NM,SCRTY_LVL_CD, BNCHMRK_ID
from ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM 
WHERE RPT_SHRT_NM in ('RX-06')
AND YEAR_ID = 1 
 AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) 
AND RPT_SPRSN_IND = 'N') amstp 
		ON fact.acct_id = amstp.acct_id
		AND fact.RPTG_PAID_YEAR_MNTH_NBR between  amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
		AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
		AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY
JOIN ${aciisst_adhoc_schema_name}.DIM_HLTH_SRVC  dim on fact.HLTH_SRVC_CD = dim.HLTH_SRVC_CD 
JOIN ${aciisst_adhoc_schema_name}.cii_run_prd PRD
		ON PRD.RUN_YEAR_MNTH_NBR=amstp.AS_OF_YEAR_MNTH_NBR
		WHERE fact.MBR_CVRG_TYPE_CD = '001' AND fact.BK_FILL_IND = 'N' and SPCLTY_DRG_IND = 'Y' 
		GROUP BY amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID, amstp.AGRGT_ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		fact.HLTH_SRVC_CD,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD )
		
WHERE 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_PHRMCY_CLMNT_DTL
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR)

UNION ALL

SELECT
AS_OF_YEAR_MNTH_NBR,
INCRD_PAID_CD,
SRC_FLTR_ID,
ACCT_ID,
TM_PRD_TYPE_CD,
YEAR_ID,
RPT_RUN_ID,
RPT_INSTNC_MTDTA_ID,
ACCT_SGMNTN_TYPE_NM,
BNCHMRK_ID,
CLMNT_CNT_TYPE_CD,
DIM1 AS RPTG_SRVC_PHRMCY_DESC,
DIM2 AS RPTG_SRVC_CTGRY_PHRMCY_DESC,
CLMNT_1_CNT,
CLMNT_2_CNT,
CLMNT_3_CNT,
SCRTY_LVL_CD,
current_timestamp as LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY
	FROM (
SELECT	amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID as SRC_FLTR_ID, amstp.AGRGT_ACCT_ID as ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		'JCD_DIAG_CLMNT' as CLMNT_CNT_TYPE_CD,
	    fact.HLTH_SRVC_CD as DIM1, 
		DIM_DIAG.SHRT_CD_DEFN_TXT as DIM2,
		'NA' as DIM3,			
		COUNT(DISTINCT fact.MCID) AS CLMNT_1_CNT,
		CAST(0 as INTEGER) as CLMNT_2_CNT,
		CAST(0 as INTEGER) as CLMNT_3_CNT,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD				
	FROM    ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact 
	INNER JOIN (SELECT DISTINCT ACCT_ID, SGMNTN_DIM_KEY, AGRGT_SRC_FLTR_ID, SRC_FLTR_ID, AGRGT_ACCT_ID, PAID_STRT_MNTH_NBR, PAID_END_MNTH_NBR, SRVC_STRT_MNTH_NBR, SRVC_END_MNTH_NBR, TM_PRD_TYPE_CD, YEAR_ID, 
INCRD_PAID_CD, AS_OF_YEAR_MNTH_NBR,RPT_RUN_ID, -1 AS RPT_INSTNC_MTDTA_ID, ACCT_SGMNTN_TYPE_NM,SCRTY_LVL_CD, BNCHMRK_ID
from ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM 
WHERE RPT_SHRT_NM in ('RX-06')
AND YEAR_ID = 1
 AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
AND RPT_SPRSN_IND = 'N') amstp 
		ON fact.acct_id = amstp.acct_id
		AND fact.RPTG_PAID_YEAR_MNTH_NBR between  amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
		AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
		AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY
		JOIN ${aciisst_adhoc_schema_name}.DIM_HLTH_SRVC dim  on fact.HLTH_SRVC_CD = dim.HLTH_SRVC_CD 
      and fact.HLTH_SRVC_TYPE_CD = dim.HLTH_SRVC_TYPE_CD
		INNER JOIN ${aciisst_adhoc_schema_name}.DIM_DIAG 
							ON fact.RPTG_PRNCPAL_DIAG_KEY = DIM_DIAG.DIAG_KEY
		
JOIN ${aciisst_adhoc_schema_name}.cii_run_prd PRD
		ON PRD.RUN_YEAR_MNTH_NBR=amstp.AS_OF_YEAR_MNTH_NBR
		WHERE fact.MBR_CVRG_TYPE_CD = '001' AND fact.BK_FILL_IND = 'N' and SPCLTY_DRG_IND = 'Y' 
		GROUP BY amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID, amstp.AGRGT_ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		fact.HLTH_SRVC_CD,
      	DIM_DIAG.SHRT_CD_DEFN_TXT,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD)
		
WHERE 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_PHRMCY_CLMNT_DTL
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR)

UNION ALL

SELECT
AS_OF_YEAR_MNTH_NBR,
INCRD_PAID_CD,
SRC_FLTR_ID,
ACCT_ID,
TM_PRD_TYPE_CD,
YEAR_ID,
RPT_RUN_ID,
RPT_INSTNC_MTDTA_ID,
ACCT_SGMNTN_TYPE_NM,
BNCHMRK_ID,
CLMNT_CNT_TYPE_CD,
DIM1 AS RPTG_SRVC_PHRMCY_DESC,
DIM2 AS RPTG_SRVC_CTGRY_PHRMCY_DESC,
CLMNT_1_CNT,
CLMNT_2_CNT,
CLMNT_3_CNT,
SCRTY_LVL_CD,
current_timestamp as LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY
	FROM (
SELECT	amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID as SRC_FLTR_ID, amstp.AGRGT_ACCT_ID as ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		'TOP5_DIAG_CLMNT' as CLMNT_CNT_TYPE_CD,
        CASE WHEN HC_PD_RNK <= 5 THEN 'TOP5' else 'All Other' END  as DIM1, 
	    fact.HLTH_SRVC_CD  as DIM2,
		'NA' as DIM3,			
		COUNT(DISTINCT fact.MCID) AS CLMNT_1_CNT,
		CAST(0 as INTEGER) as CLMNT_2_CNT,
		CAST(0 as INTEGER) as CLMNT_3_CNT,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD				
   FROM ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact 
	INNER JOIN (SELECT DISTINCT ACCT_ID, SGMNTN_DIM_KEY, AGRGT_SRC_FLTR_ID, SRC_FLTR_ID, AGRGT_ACCT_ID, 
                PAID_STRT_MNTH_NBR, PAID_END_MNTH_NBR, SRVC_STRT_MNTH_NBR, SRVC_END_MNTH_NBR, TM_PRD_TYPE_CD, YEAR_ID, 
INCRD_PAID_CD, AS_OF_YEAR_MNTH_NBR,RPT_RUN_ID, -1 AS RPT_INSTNC_MTDTA_ID, ACCT_SGMNTN_TYPE_NM,SCRTY_LVL_CD, BNCHMRK_ID
from ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM 
WHERE RPT_SHRT_NM in ('RX-06')
AND YEAR_ID = 1
 AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
AND RPT_SPRSN_IND = 'N') amstp 
		ON fact.acct_id = amstp.acct_id
		AND fact.RPTG_PAID_YEAR_MNTH_NBR between amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
		AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
		AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY
		
      JOIN ${aciisst_adhoc_schema_name}.DIM_HLTH_SRVC dim on fact.HLTH_SRVC_CD = dim.HLTH_SRVC_CD AND fact.HLTH_SRVC_TYPE_CD = dim.HLTH_SRVC_TYPE_CD
      
		INNER JOIN ${aciisst_adhoc_schema_name}.DIM_DIAG 
							ON fact.RPTG_PRNCPAL_DIAG_KEY = DIM_DIAG.DIAG_KEY
      
      JOIN ${aciisst_adhoc_schema_name}.cii_run_prd PRD
					ON PRD.RUN_YEAR_MNTH_NBR=amstp.AS_OF_YEAR_MNTH_NBR
 left join (	
        SELECT amstp.AGRGT_SRC_FLTR_ID as SRC_FLTR_ID, amstp.AGRGT_ACCT_ID as ACCT_ID, 
		amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD, amstp.TM_PRD_TYPE_CD, amstp.YEAR_ID,fact.HLTH_SRVC_CD , DIM_DIAG.SHRT_CD_DEFN_TXT,amstp.BNCHMRK_ID,
		ROW_NUMBER() OVER( PARTITION BY amstp.AGRGT_SRC_FLTR_ID , amstp.AGRGT_ACCT_ID, 
					amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD, fact.HLTH_SRVC_CD
					ORDER BY SUM(fact.ACCT_PAID_AMT) DESC, fact.HLTH_SRVC_CD ASC,DIM_DIAG.SHRT_CD_DEFN_TXT ASC ) as HC_PD_RNK
		FROM	(select SGMNTN_DIM_KEY, ACCT_ID, CLM_SRVC_YEAR_MNTH_NBR, RPTG_PAID_YEAR_MNTH_NBR 
				,ACCT_PAID_AMT,HLTH_SRVC_CD, HLTH_SRVC_TYPE_CD, RPTG_PRNCPAL_DIAG_KEY
				FROM ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact WHERE MBR_CVRG_TYPE_CD = '001'
                 AND BK_FILL_IND = 'N' and SPCLTY_DRG_IND = 'Y' ) fact
  
		JOIN ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM amstp 
		ON 	fact.acct_id = amstp.acct_id
			AND fact.RPTG_PAID_YEAR_MNTH_NBR between  PAID_STRT_MNTH_NBR and PAID_END_MNTH_NBR
			AND fact.CLM_SRVC_YEAR_MNTH_NBR between SRVC_STRT_MNTH_NBR and SRVC_END_MNTH_NBR
			AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY 
   		    AND RPT_SHRT_NM in ('RX-06') 
             AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
            AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
            AND RPT_SPRSN_IND = 'N'
   
		JOIN ${aciisst_adhoc_schema_name}.cii_run_prd PRD
					ON PRD.RUN_YEAR_MNTH_NBR=amstp.AS_OF_YEAR_MNTH_NBR
       
   
   INNER JOIN ${aciisst_adhoc_schema_name}.DIM_HLTH_SRVC ON fact.HLTH_SRVC_CD = DIM_HLTH_SRVC.HLTH_SRVC_CD
                AND fact.HLTH_SRVC_TYPE_CD = DIM_HLTH_SRVC.HLTH_SRVC_TYPE_CD
   
       INNER JOIN ${aciisst_adhoc_schema_name}.DIM_DIAG 
							ON fact.RPTG_PRNCPAL_DIAG_KEY = DIM_DIAG.DIAG_KEY
                
		WHERE YEAR_ID = 1 
                
		GROUP BY amstp.AGRGT_SRC_FLTR_ID, amstp.AGRGT_ACCT_ID, 
		amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD, amstp.TM_PRD_TYPE_CD,amstp.YEAR_ID,
		fact.HLTH_SRVC_CD, DIM_DIAG.SHRT_CD_DEFN_TXT, amstp.BNCHMRK_ID

		)HC_RNK
		ON amstp.AGRGT_SRC_FLTR_ID = HC_RNK.SRC_FLTR_ID
		AND amstp.AGRGT_ACCT_ID = HC_RNK.ACCT_ID
		AND amstp.AS_OF_YEAR_MNTH_NBR = HC_RNK.AS_OF_YEAR_MNTH_NBR
		AND amstp.INCRD_PAID_CD = HC_RNK.INCRD_PAID_CD
		AND amstp.TM_PRD_TYPE_CD = HC_RNK.TM_PRD_TYPE_CD
		AND fact.HLTH_SRVC_CD = HC_RNK.HLTH_SRVC_CD
        AND DIM_DIAG.SHRT_CD_DEFN_TXT = HC_RNK.SHRT_CD_DEFN_TXT
      

		GROUP BY amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID, amstp.AGRGT_ACCT_ID,
      amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
      CASE WHEN HC_PD_RNK <= 5 THEN 'TOP5' else 'All Other' END,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID, fact.HLTH_SRVC_CD,
		amstp.SCRTY_LVL_CD)
		
WHERE 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_PHRMCY_CLMNT_DTL
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR)

UNION ALL

SELECT
AS_OF_YEAR_MNTH_NBR,
INCRD_PAID_CD,
SRC_FLTR_ID,
ACCT_ID,
TM_PRD_TYPE_CD,
YEAR_ID,
RPT_RUN_ID,
RPT_INSTNC_MTDTA_ID,
ACCT_SGMNTN_TYPE_NM,
BNCHMRK_ID,
CLMNT_CNT_TYPE_CD,
DIM1 AS RPTG_SRVC_PHRMCY_DESC,
DIM2 AS RPTG_SRVC_CTGRY_PHRMCY_DESC,
CLMNT_1_CNT,
CLMNT_2_CNT,
CLMNT_3_CNT,
SCRTY_LVL_CD,
current_timestamp as LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY
	FROM (
SELECT	amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID as SRC_FLTR_ID, amstp.AGRGT_ACCT_ID as ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		'JCD_TTL_CLMNT' as CLMNT_CNT_TYPE_CD,
		'NA' as DIM1, 
		'NA' as DIM2,
		'NA' as DIM3,			
		COUNT(DISTINCT fact.MCID) AS CLMNT_1_CNT,
		CAST(0 as INTEGER) as CLMNT_2_CNT,
		CAST(0 as INTEGER) as CLMNT_3_CNT,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD				
	FROM    ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact
	INNER JOIN (SELECT DISTINCT ACCT_ID, SGMNTN_DIM_KEY, AGRGT_SRC_FLTR_ID, SRC_FLTR_ID, AGRGT_ACCT_ID, PAID_STRT_MNTH_NBR, PAID_END_MNTH_NBR, SRVC_STRT_MNTH_NBR, SRVC_END_MNTH_NBR, TM_PRD_TYPE_CD, YEAR_ID, 
INCRD_PAID_CD, AS_OF_YEAR_MNTH_NBR,RPT_RUN_ID, -1 AS RPT_INSTNC_MTDTA_ID, ACCT_SGMNTN_TYPE_NM,SCRTY_LVL_CD, BNCHMRK_ID
from ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM 
WHERE RPT_SHRT_NM in ('RX-06')
AND YEAR_ID = 1 
 AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
AND RPT_SPRSN_IND = 'N' 
) amstp 
		ON fact.acct_id = amstp.acct_id
		AND fact.RPTG_PAID_YEAR_MNTH_NBR between  amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
		AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
		AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY
	JOIN ${aciisst_adhoc_schema_name}.cii_run_prd PRD
		ON PRD.RUN_YEAR_MNTH_NBR=amstp.AS_OF_YEAR_MNTH_NBR
		WHERE fact.MBR_CVRG_TYPE_CD = '001' AND fact.BK_FILL_IND = 'N' and SPCLTY_DRG_IND = 'Y'
		GROUP BY amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID, amstp.AGRGT_ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD )
		
WHERE 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_PHRMCY_CLMNT_DTL
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR)

UNION ALL

SELECT
AS_OF_YEAR_MNTH_NBR,
INCRD_PAID_CD,
SRC_FLTR_ID,
ACCT_ID,
TM_PRD_TYPE_CD,
YEAR_ID,
RPT_RUN_ID,
RPT_INSTNC_MTDTA_ID,
ACCT_SGMNTN_TYPE_NM,
BNCHMRK_ID,
CLMNT_CNT_TYPE_CD,
DIM1 AS RPTG_SRVC_PHRMCY_DESC,
DIM2 AS RPTG_SRVC_CTGRY_PHRMCY_DESC,
CLMNT_1_CNT,
CLMNT_2_CNT,
CLMNT_3_CNT,
SCRTY_LVL_CD,
current_timestamp as LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY
	FROM (
SELECT	amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID as SRC_FLTR_ID, amstp.AGRGT_ACCT_ID as ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		'NON_SPEC_DRG_CLMNT' as CLMNT_CNT_TYPE_CD,
		'NA' as DIM1, 
		'NA' as DIM2,
		'NA' as DIM3,			
		COUNT(DISTINCT fact.MCID) AS CLMNT_1_CNT,
		CAST(0 as INTEGER) as CLMNT_2_CNT,
		CAST(0 as INTEGER) as CLMNT_3_CNT,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD				
   FROM ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact
	INNER JOIN (SELECT DISTINCT ACCT_ID, SGMNTN_DIM_KEY, AGRGT_SRC_FLTR_ID, SRC_FLTR_ID, AGRGT_ACCT_ID, PAID_STRT_MNTH_NBR, PAID_END_MNTH_NBR, SRVC_STRT_MNTH_NBR, SRVC_END_MNTH_NBR, TM_PRD_TYPE_CD, YEAR_ID, 
INCRD_PAID_CD, AS_OF_YEAR_MNTH_NBR,RPT_RUN_ID, -1 AS RPT_INSTNC_MTDTA_ID, ACCT_SGMNTN_TYPE_NM,SCRTY_LVL_CD, BNCHMRK_ID
from ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM 
WHERE RPT_SHRT_NM in ('RX-06')
AND YEAR_ID = 1
AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) 
AND RPT_SPRSN_IND = 'N') amstp 
		ON fact.acct_id = amstp.acct_id
		AND fact.RPTG_PAID_YEAR_MNTH_NBR between  amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
		AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
		AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY

JOIN ${aciisst_adhoc_schema_name}.cii_run_prd PRD
		ON PRD.RUN_YEAR_MNTH_NBR=amstp.AS_OF_YEAR_MNTH_NBR
		WHERE fact.MBR_CVRG_TYPE_CD = '102' AND fact.BK_FILL_IND = 'N' and fact.SPCLTY_DRG_IND = 'N'
		GROUP BY amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID, amstp.AGRGT_ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD)
		
WHERE 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_PHRMCY_CLMNT_DTL
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR)

UNION ALL

SELECT
AS_OF_YEAR_MNTH_NBR,
INCRD_PAID_CD,
SRC_FLTR_ID,
ACCT_ID,
TM_PRD_TYPE_CD,
YEAR_ID,
RPT_RUN_ID,
RPT_INSTNC_MTDTA_ID,
ACCT_SGMNTN_TYPE_NM,
BNCHMRK_ID,
CLMNT_CNT_TYPE_CD,
DIM1 AS RPTG_SRVC_PHRMCY_DESC,
DIM2 AS RPTG_SRVC_CTGRY_PHRMCY_DESC,
CLMNT_1_CNT,
CLMNT_2_CNT,
CLMNT_3_CNT,
SCRTY_LVL_CD,
current_timestamp as LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY
	FROM (
SELECT	amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID as SRC_FLTR_ID, amstp.AGRGT_ACCT_ID as ACCT_ID, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
		'TOP25_JCODE_CLMNT' as CLMNT_CNT_TYPE_CD,
     CASE WHEN HC_PD_RNK <= 25 THEN 'TOP25' else 'All Other' END  as DIM1, 
	  'NA'  as DIM2,
		'NA' as DIM3,			
		COUNT(DISTINCT fact.MCID) AS CLMNT_1_CNT,
		CAST(0 as INTEGER) as CLMNT_2_CNT,
		CAST(0 as INTEGER) as CLMNT_3_CNT,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD				
	FROM    ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact 
	INNER JOIN (SELECT DISTINCT ACCT_ID, SGMNTN_DIM_KEY, AGRGT_SRC_FLTR_ID, SRC_FLTR_ID, AGRGT_ACCT_ID, 
                PAID_STRT_MNTH_NBR, PAID_END_MNTH_NBR, SRVC_STRT_MNTH_NBR, SRVC_END_MNTH_NBR, TM_PRD_TYPE_CD, YEAR_ID, 
INCRD_PAID_CD, AS_OF_YEAR_MNTH_NBR,RPT_RUN_ID, -1 AS RPT_INSTNC_MTDTA_ID, ACCT_SGMNTN_TYPE_NM,SCRTY_LVL_CD, BNCHMRK_ID
from ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM 
WHERE RPT_SHRT_NM in ('RX-06')
AND YEAR_ID = 1
AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
AND RPT_SPRSN_IND = 'N') amstp 
		ON fact.acct_id = amstp.acct_id
		AND fact.RPTG_PAID_YEAR_MNTH_NBR between amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
		AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
		AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY
		JOIN ${aciisst_adhoc_schema_name}.DIM_HLTH_SRVC dim  on fact.HLTH_SRVC_CD = dim.HLTH_SRVC_CD 
		INNER JOIN ${aciisst_adhoc_schema_name}.DIM_DIAG 
							ON fact.RPTG_PRNCPAL_DIAG_KEY = DIM_DIAG.DIAG_KEY
 left join (	
        SELECT amstp.AGRGT_SRC_FLTR_ID as SRC_FLTR_ID, amstp.AGRGT_ACCT_ID as ACCT_ID, 
		amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD, amstp.TM_PRD_TYPE_CD, amstp.YEAR_ID,fact.HLTH_SRVC_CD,
		ROW_NUMBER() OVER( PARTITION BY amstp.AGRGT_SRC_FLTR_ID , amstp.AGRGT_ACCT_ID, 
					amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD, amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD
					ORDER BY SUM(fact.ACCT_PAID_AMT) DESC, fact.HLTH_SRVC_CD ASC ) as HC_PD_RNK
		FROM	(select SGMNTN_DIM_KEY, ACCT_ID, CLM_SRVC_YEAR_MNTH_NBR, RPTG_PAID_YEAR_MNTH_NBR 
				,ACCT_PAID_AMT,HLTH_SRVC_CD
				FROM ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD  fact WHERE MBR_CVRG_TYPE_CD = '001'
                 AND BK_FILL_IND = 'N' and SPCLTY_DRG_IND = 'Y' ) fact
  
		JOIN ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM amstp 
		ON 	fact.acct_id = amstp.acct_id
			AND fact.RPTG_PAID_YEAR_MNTH_NBR between PAID_STRT_MNTH_NBR and PAID_END_MNTH_NBR
			AND fact.CLM_SRVC_YEAR_MNTH_NBR between SRVC_STRT_MNTH_NBR and SRVC_END_MNTH_NBR
			AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY 
		JOIN ${aciisst_adhoc_schema_name}.cii_run_prd PRD
					ON PRD.RUN_YEAR_MNTH_NBR=amstp.AS_OF_YEAR_MNTH_NBR
        WHERE  fact.HLTH_SRVC_CD NOT IN ('NA','UNKNOWN') and YEAR_ID = 1
          AND RPT_SHRT_NM in ('RX-06')
          AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
          AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))
          AND RPT_SPRSN_IND = 'N'
                
		GROUP BY amstp.AGRGT_SRC_FLTR_ID, amstp.AGRGT_ACCT_ID, 
		amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD, amstp.TM_PRD_TYPE_CD,amstp.YEAR_ID,
		fact.HLTH_SRVC_CD

		)HC_RNK
		ON amstp.AGRGT_SRC_FLTR_ID = HC_RNK.SRC_FLTR_ID
		AND amstp.AGRGT_ACCT_ID = HC_RNK.ACCT_ID
		AND amstp.AS_OF_YEAR_MNTH_NBR = HC_RNK.AS_OF_YEAR_MNTH_NBR
		AND amstp.INCRD_PAID_CD = HC_RNK.INCRD_PAID_CD
		AND amstp.TM_PRD_TYPE_CD = HC_RNK.TM_PRD_TYPE_CD
		AND fact.HLTH_SRVC_CD = HC_RNK.HLTH_SRVC_CD
          
JOIN ${aciisst_adhoc_schema_name}.cii_run_prd PRD
		ON PRD.RUN_YEAR_MNTH_NBR=amstp.AS_OF_YEAR_MNTH_NBR
		
WHERE fact.MBR_CVRG_TYPE_CD = '001' AND fact.BK_FILL_IND = 'N' and SPCLTY_DRG_IND = 'Y'
		GROUP BY amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,amstp.AGRGT_SRC_FLTR_ID, amstp.AGRGT_ACCT_ID,
      amstp.YEAR_ID, amstp.TM_PRD_TYPE_CD,
      CASE WHEN HC_PD_RNK <= 25 THEN 'TOP25' else 'All Other' END,
		amstp.RPT_RUN_ID,
		amstp.RPT_INSTNC_MTDTA_ID,
		amstp.ACCT_SGMNTN_TYPE_NM,
		amstp.BNCHMRK_ID,
		amstp.SCRTY_LVL_CD)
        
WHERE 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_PHRMCY_CLMNT_DTL
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR);

