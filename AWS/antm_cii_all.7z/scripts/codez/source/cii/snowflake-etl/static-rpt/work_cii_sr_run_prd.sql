-----------------------------------------------------------------------------------------------------------------
-- TITLE              : CII_SR_RUN_PRD
-- FILENAME           : work_cii_sr_run_prd.sql
-- DESCRIPTION        : THIS SCRIPT LOADS CII_SR_RUN_PRD table
-- DEVELOPER          : LEGATO
-- CREATED ON         : 03-08-2022 (MM-DD-YYYY)
-- LOGIC              : INsert Overwrite in each run
-- VERSION            : 1.0
-- VERSION DESCRIPTION: Initial Version
-----------------------------------------------------------------------------------------------------------------

INSERT overwrite INTO  ACIISST_ADHOC_VLDTN.CII_RUN_PRD

select max(ELGBLTY_CY_MNTH_END_NBR) AS RUN_YEAR_MNTH_NBR
,concat(substr(add_months(to_date(concat(substr(max(ELGBLTY_CY_MNTH_END_NBR),1,4),'-',substr(max(ELGBLTY_CY_MNTH_END_NBR),5,2),'-','01')),-12),1,4),substr(add_months(to_date(concat(substr(max(ELGBLTY_CY_MNTH_END_NBR),1,4),'-',substr(max(ELGBLTY_CY_MNTH_END_NBR),5,2),'-','01')),-12),6,2)) AS PRIOR_RUN_YEAR_MNTH_NBR
,'N' AS SCRTY_LVL_CD
,current_timestamp as LOAD_DTM
,MD5(current_timestamp) as LOAD_LOG_KEY
from ${aciisst_adhoc_schema_name}.CII_FACT_MBRSHP_CNSLDTD
WHERE ELGBLTY_CY_MNTH_END_NBR < cast(concat(substr(current_date,1,4),substr(current_date,6,2)) as INT)
AND BK_FILL_IND = 'N';
