 /*************************************************************************************************************
 # TITLE           : TABLE CII_SR_ACCT_SGMNTN_TM_PRD_PARM
 # FILENAME        : l2_rpt_cii_sr_acct_sgmntn_tm_prd_parm.sql
 # DESCRIPTION     : THIS SCRIPT LOADS CII_SR_ACCT_SGMNTN_TM_PRD_PARM table for each request/rpt_run_id coming from UI/Middleware for L2 Reporting
 # DEVELOPER       : LEGATO
 # CREATED ON      : 06-09-2022
 # LOGIC           : LOAD TARGET TABLE
 # VERSION         : 1.0
 ***************************************************************************************************************/

delete from CII_EVOLVE.CII_SR_ACCT_SGMNTN_TM_PRD_PARM WHERE ('YES' = ${re_run} AND RPT_RUN_ID in (${rpt_run_id}) AND (RPT_SHRT_NM in (${rpt_shrt_nm}) OR 'ALL' in (${rpt_shrt_nm}))); 

insert into CII_EVOLVE.CII_SR_ACCT_SGMNTN_TM_PRD_PARM

WITH RQST_TM_PRD_DTL AS (SELECT * FROM (${rqst_tm_prd_dtl}) WHERE RPT_SHRT_NM <> 'BNCHMRK')

select distinct
trim(dtp.AS_OF_MNTH_NBR) AS AS_OF_YEAR_MNTH_NBR,
trim(brdg.ACCT_ID) AS ACCT_ID,
trim(brdg.SRC_FLTR_ID) AS SRC_FLTR_ID,
trim(dtp.RPT_SHRT_NM)  as RPT_SHRT_NM,
case when lower(trim(dtp.TM_PRD_TYPE_CD)) = 'custom' then cast(dtp.RPT_RUN_ID as string) else dtp.TM_PRD_TYPE_CD END AS TM_PRD_TYPE_CD,
trim(dtp.HCC_THRSHLD_AMT) AS HCC_THRSHLD_AMT,
trim(dtp.INCRD_PAID_CD) AS INCRD_PAID_CD,
brdg.sgmntn_dim_key AS SGMNTN_DIM_KEY,
'NA' as DFLT_CNTRCT_TYPE_CD,
'NA' AS CLNT_PRTY_GRP_CD,
dtp.STRT_MNTH_NBR,
dtp.END_MNTH_NBR,
dtp.SRVC_STRT_MNTH_NBR,
dtp.SRVC_END_MNTH_NBR,
dtp.PAID_STRT_MNTH_NBR,
dtp.PAID_END_MNTH_NBR,
brdg.ACCT_ID as AGRGT_ACCT_ID,
brdg.SRC_FLTR_ID as AGRGT_SRC_FLTR_ID,
dtp.YEAR_ID AS YEAR_ID,
'Client' as BNCHMRK_RUN_TYPE_CD,
dtp.RPT_RUN_ID as RPT_RUN_ID,
md5_number_lower64(dtp.AS_OF_MNTH_NBR||brdg.SRC_FLTR_ID||dtp.RPT_SHRT_NM||dtp.TM_PRD_TYPE_CD||dtp.HCC_THRSHLD_AMT||dtp.INCRD_PAID_CD||dtp.RPT_RUN_ID) as RPT_INSTNC_MTDTA_ID,
parm.BNCHMRK_ID as BNCHMRK_ID,
parm.ACCT_SGMNTN_TYPE_NM as ACCT_SGMNTN_TYPE_NM,
'N' as RPT_SPRSN_IND,
parm.RPT_ID as RPT_ID,
'N' as SCRTY_LVL_CD,
current_timestamp LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY,
trim(dtp.UI_AS_OF_YEAR_MNTH_NBR) as UI_AS_OF_YEAR_MNTH_NBR,
trim(dtp.UI_TM_PRD_TYPE_CD) as UI_TM_PRD_TYPE_CD
from  RQST_TM_PRD_DTL dtp
join ( select DISTINCT SRC_FLTR_ID,RPT_SHRT_NM,RPT_ID,BNCHMRK_ID,ACCT_SGMNTN_TYPE_NM from  ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_PARM where SRC_FLTR_ID in (${src_fltr_id}) ) parm 
ON dtp.SRC_FLTR_ID = parm.SRC_FLTR_ID
AND dtp.RPT_SHRT_NM = parm.RPT_SHRT_NM
JOIN ${aciisst_schema_name}.ACIISST_SGMNTN_BRDG_SCD brdg
ON brdg.acct_id = dtp.acct_id
and brdg.SRC_FLTR_ID= dtp.SRC_FLTR_ID
WHERE brdg.FLTR_SRC_NM = 'ERSU';