 /*************************************************************************************************************
 # TITLE           : cii_sr_acct_sgmntn_tm_prd_parm
 # FILENAME        : cii_sr_acct_sgmntn_tm_prd_parm.sql
 # DESCRIPTION     : THIS SCRIPT LOADS cii_sr_acct_sgmntn_tm_prd_parm table
 # DEVELOPER       : LEGATO
 # CREATED ON      : 2/21/2022
 # LOGIC           : TRUNCATE AND RELOAD TARGET TABLE
 # VERSION         : 1.0
 ***************************************************************************************************************/
 
delete from CII_EVOLVE.CII_SR_ACCT_SGMNTN_TM_PRD_PARM WHERE (AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD) AND 'YES' = ${re_run} AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max}))) AND (RPT_SHRT_NM in (${rpt_shrt_nm}) OR 'ALL' in (${rpt_shrt_nm}));

insert into CII_EVOLVE.CII_SR_ACCT_SGMNTN_TM_PRD_PARM
select distinct
trim(datp.AS_OF_MNTH_NBR) AS AS_OF_YEAR_MNTH_NBR,
trim(brdg.ACCT_ID) AS ACCT_ID,
trim(brdg.SRC_FLTR_ID) AS SRC_FLTR_ID,
'BNCHMRK' as RPT_SHRT_NM,
trim(datp.TM_PRD_TYPE_CD) AS TM_PRD_TYPE_CD,
datp.HCC_THRSHLD_AMT AS HCC_THRSHLD_AMT,
trim(datp.INCRD_PAID_CD) AS INCRD_PAID_CD,
brdg.sgmntn_dim_key AS SGMNTN_DIM_KEY,
'NA' as DFLT_CNTRCT_TYPE_CD,
'PGB'||MOD(datp.RPT_RUN_ID,10) AS CLNT_PRTY_GRP_CD,
STRT_MNTH_NBR AS STRT_MNTH_NBR,
END_MNTH_NBR AS END_MNTH_NBR,
SRVC_STRT_MNTH_NBR AS SRVC_STRT_MNTH_NBR,
SRVC_END_MNTH_NBR AS SRVC_END_MNTH_NBR,
PAID_STRT_MNTH_NBR AS PAID_STRT_MNTH_NBR,
PAID_END_MNTH_NBR AS PAID_END_MNTH_NBR,
'B9999999' as AGRGT_ACCT_ID,
'B9999999-00001' as AGRGT_SRC_FLTR_ID,
datp.YEAR_ID AS YEAR_ID,
'Benchmark' as BNCHMRK_RUN_TYPE_CD,
datp.RPT_RUN_ID AS RPT_RUN_ID,
'-1' as RPT_INSTNC_MTDTA_ID,
Case when brdg.GRS_IND='Y' then '2' else '1' end as BNCHMRK_ID,
Case when brdg.GRS_IND='Y' then 'GRS' else 'STD' end as ACCT_SGMNTN_TYPE_NM,
'N' as RPT_SPRSN_IND ,
1 as RPT_ID,
'N' as SCRTY_LVL_CD,
Current_timestamp as LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY,
trim(datp.AS_OF_MNTH_NBR) AS UI_AS_OF_YEAR_MNTH_NBR,
case when trim(datp.TM_PRD_TYPE_CD) in('1','2','3','4','5','6','7','8','9','10','11','12')  then 'pytd' else trim(datp.TM_PRD_TYPE_CD) end AS UI_TM_PRD_TYPE_CD
from (SELECT SGMNTN_DIM_KEY, max(SCD.ACCT_ID) as ACCT_ID ,max(SRC_FLTR_ID) as SRC_FLTR_ID,
      MAX(GRS_IND) as GRS_IND
      from ${aciisst_schema_name}.ACIISST_SGMNTN_BRDG_SCD SCD 
        JOIN ${aciisst_schema_name}.ACIISST_ACCT_PRFL AAP
        ON AAP.ACCT_ID=SCD.ACCT_ID
        WHERE FLTR_SRC_NM = 'ERSU' GROUP BY  SGMNTN_DIM_KEY) brdg
JOIN
(select distinct dtp.TM_PRD_TYPE_CD,dtp.INCRD_PAID_CD,BNCHMRK.HCC_THRSHLD_AMT,DTP.AS_OF_MNTH_NBR,
STRT_MNTH_NBR,END_MNTH_NBR,SRVC_STRT_MNTH_NBR,SRVC_END_MNTH_NBR,PAID_STRT_MNTH_NBR,
PAID_END_MNTH_NBR,YEAR_ID,BNCHMRK.RPT_RUN_ID
FROM ${aciisst_adhoc_schema_name}.DIM_TM_PRD DTP
JOIN ${aciisst_adhoc_schema_name}.CII_RUN_PRD CRRP
on DTP.AS_OF_MNTH_NBR = CRRP.RUN_YEAR_MNTH_NBR 
INNER JOIN 
(SELECT 
DISTINCT TM_PRD_TYPE_CD
,INCRD_PAID_CD
,0 as HCC_THRSHLD_AMT
,RPT_RUN_ID
FROM ${evolve_schema_name}.CII_BNCHMRK_PARM) BNCHMRK
on DTP.TM_PRD_TYPE_CD = BNCHMRK.TM_PRD_TYPE_CD 
AND DTP.INCRD_PAID_CD = BNCHMRK.INCRD_PAID_CD 
)datp
where datp.YEAR_ID<3
  AND 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) 
  AND (RPT_SHRT_NM in (${rpt_shrt_nm}) OR 'ALL' in (${rpt_shrt_nm}))
  AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
   ON RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR)
;
