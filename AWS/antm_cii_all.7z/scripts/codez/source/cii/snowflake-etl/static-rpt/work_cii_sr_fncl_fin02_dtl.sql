/*************************************************************************************************************
 # TITLE           : REPORT F02 SMRY
 # FILENAME        : cii_sr_fncl_fin02_dtl.SQL
 # DESCRIPTION     : THIS SCRIPT LOADS CII_SR_FNCL_FIN02_DTL table
 # DEVELOPER       : LEGATO
 # CREATED ON      : 2/17/2022
 # LOGIC           : APPEND TARGET TABLE
 # VERSION         : 1.0
 ***************************************************************************************************************/
 
delete from CII_EVOLVE.CII_SR_FNCL_FIN02_DTL WHERE (AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD) AND 'YES' = ${re_run} AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})));

insert into CII_EVOLVE.CII_SR_FNCL_FIN02_DTL
SELECT DISTINCT PERMS.AS_OF_YEAR_MNTH_NBR,
PERMS.ACCT_ID,
PERMS.SRC_FLTR_ID,
PERMS.TM_PRD_TYPE_CD,
PERMS.INCRD_PAID_CD,
PERMS.YEAR_ID,
PERMS.RPT_INSTNC_MTDTA_ID,
PERMS.RPT_RUN_ID,	
COALESCE(CLMS.MCID_CNT,0) as MCID_CNT ,	
PERMS.ACCT_SGMNTN_TYPE_NM,
PERMS.BNCHMRK_ID,
COALESCE(CLMS.ACCT_PAID_AMT,0) as ACCT_PAID_AMT,
PERMS.HCC_THRSHLD_AMT,
PERMS.RPTG_AMT_TIER_CD,
PERMS.RPTG_AMT_TIER_DESC,
PERMS.RPTG_AMT_TIER_MIN_NBR,
PERMS.SCRTY_LVL_CD,		
current_timestamp as LOAD_DTM,
MD5(current_timestamp) as LOAD_LOG_KEY

 from 
(SELECT DISTINCT AS_OF_YEAR_MNTH_NBR,
		INCRD_PAID_CD,
		amstp.AGRGT_SRC_FLTR_ID as SRC_FLTR_ID,
		amstp.AGRGT_ACCT_ID as ACCT_ID,
		TM_PRD_TYPE_CD, YEAR_ID,
		BNCHMRK_ID,
 		ACCT_SGMNTN_TYPE_NM,
		amstp.RPT_INSTNC_MTDTA_ID,
		HCC_THRSHLD_AMT,
		amstp.SCRTY_LVL_CD,
		dpt.RPTG_AMT_TIER_CD,
		dpt.RPTG_AMT_TIER_DESC,
		dpt.RPTG_MIN_TIER_AMT as RPTG_AMT_TIER_MIN_NBR,
		RPT_RUN_ID
			FROM ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM amstp 
			CROSS JOIN ${aciisst_adhoc_schema_name}.DIM_RPTG_AMT_TIER dpt
			JOIN ${aciisst_adhoc_schema_name}.CII_RUN_PRD PRD 
			ON TRIM(PRD.RUN_YEAR_MNTH_NBR)=TRIM(amstp.AS_OF_YEAR_MNTH_NBR)
		WHERE 
				amstp.YEAR_ID <= 2 and amstp.RPT_SHRT_NM in ('FIN-02','BNCHMRK')

   AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
   AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (2 >= ${rpt_run_id_bnchmrk_min} AND 1000<= ${rpt_run_id_bnchmrk_max}))
        AND RPT_SPRSN_IND = 'N'

)PERMS 
LEFT JOIN
(SELECT AS_OF_YEAR_MNTH_NBR,
		INCRD_PAID_CD,
		SRC_FLTR_ID,
		ACCT_ID,
		TM_PRD_TYPE_CD,
		YEAR_ID,
		BNCHMRK_ID,
		dpt.RPTG_AMT_TIER_CD,
		HCC_THRSHLD_AMT,
		SUM(ACCT_PAID_AMT) AS ACCT_PAID_AMT,
	COUNT(DISTINCT MCID) as MCID_CNT
FROM
(SELECT  amstp.AS_OF_YEAR_MNTH_NBR,
		amstp.INCRD_PAID_CD,
		amstp.TM_PRD_TYPE_CD,
		amstp.YEAR_ID,
		amstp.AGRGT_SRC_FLTR_ID as SRC_FLTR_ID,
		amstp.BNCHMRK_ID AS BNCHMRK_ID,
		amstp.AGRGT_ACCT_ID as ACCT_ID,
		fact.MCID,	HCC_THRSHLD_AMT,
		SUM(fact.ACCT_PAID_AMT) AS ACCT_PAID_AMT

FROM ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact
INNER JOIN ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM amstp
ON fact.acct_id = amstp.acct_id
AND fact.RPTG_PAID_YEAR_MNTH_NBR between  amstp.PAID_STRT_MNTH_NBR and amstp.PAID_END_MNTH_NBR
AND fact.CLM_SRVC_YEAR_MNTH_NBR between amstp.SRVC_STRT_MNTH_NBR and amstp.SRVC_END_MNTH_NBR
AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY
JOIN ${aciisst_adhoc_schema_name}.CII_RUN_PRD PRD
ON TRIM(PRD.RUN_YEAR_MNTH_NBR)=TRIM(amstp.AS_OF_YEAR_MNTH_NBR)
WHERE fact.MBR_CVRG_TYPE_CD = '001'
AND amstp.RPT_SHRT_NM in  ('FIN-02','BNCHMRK') and  fact.BK_FILL_IND = 'N'

AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (2 >= ${rpt_run_id_bnchmrk_min} AND 1000<= ${rpt_run_id_bnchmrk_max}))
AND RPT_SPRSN_IND = 'N'

GROUP BY amstp.AS_OF_YEAR_MNTH_NBR, amstp.INCRD_PAID_CD,	amstp.TM_PRD_TYPE_CD, amstp.YEAR_ID,
amstp.AGRGT_SRC_FLTR_ID,
amstp.AGRGT_ACCT_ID,
MCID,BNCHMRK_ID,HCC_THRSHLD_AMT
)CLMS_SUB

JOIN ${aciisst_adhoc_schema_name}.DIM_RPTG_AMT_TIER dpt ON CLMS_SUB.ACCT_PAID_AMT >= dpt.RPTG_MIN_TIER_AMT
and CLMS_SUB.ACCT_PAID_AMT < dpt.RPTG_MAX_TIER_AMT
GROUP BY AS_OF_YEAR_MNTH_NBR, INCRD_PAID_CD, TM_PRD_TYPE_CD, YEAR_ID, SRC_FLTR_ID, ACCT_ID, dpt.RPTG_AMT_TIER_CD,BNCHMRK_ID,HCC_THRSHLD_AMT
) CLMS
	ON trim(PERMS.AS_OF_YEAR_MNTH_NBR) = trim(CLMS.AS_OF_YEAR_MNTH_NBR)
	AND trim(PERMS.INCRD_PAID_CD) = trim(CLMS.INCRD_PAID_CD)
	AND trim(PERMS.SRC_FLTR_ID) = trim(CLMS.SRC_FLTR_ID)
	AND trim(PERMS.ACCT_ID) = trim(CLMS.ACCT_ID)
	AND trim(PERMS.YEAR_ID) = trim(CLMS.YEAR_ID)
	AND trim(PERMS.TM_PRD_TYPE_CD) = trim(CLMS.TM_PRD_TYPE_CD)
	AND trim(PERMS.RPTG_AMT_TIER_CD) = trim(CLMS.RPTG_AMT_TIER_CD)
	AND trim(PERMS.BNCHMRK_ID) = trim(CLMS.BNCHMRK_ID)
    AND trim(PERMS.HCC_THRSHLD_AMT)=trim(CLMS.HCC_THRSHLD_AMT)
    
WHERE 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_FNCL_FIN02_DTL
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR)
