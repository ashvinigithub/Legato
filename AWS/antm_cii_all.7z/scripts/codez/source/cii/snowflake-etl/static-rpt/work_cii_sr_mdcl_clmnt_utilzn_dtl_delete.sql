-----------------------------------------------------------------------------------------------------------------
-- TITLE              : CII_SR_MDCL_CLMNT_UTILZN_DTL
-- FILENAME           : work_cii_sr_mdcl_clmnt_utilzn_dtl.sql (Should be in small case)
-- DESCRIPTION        : THIS SCRIPT Tries to delete the data in the table on the basis of as of month number
-- DEVELOPER          : LEGATO
-- CREATED ON         : 04-14-2022 (MM-DD-YYYY)
-- LOGIC              : Append Data to Target Table, Overwrite only for first time Load.
-- VERSION            : 1.0
-- VERSION DESCRIPTION: Initial Version
-----------------------------------------------------------------------------------------------------------------

delete from CII_EVOLVE.CII_SR_MDCL_CLMNT_UTILZN_DTL WHERE (AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${evolve_schema_name}.cii_sr_run_prd) AND 'YES' = ${re_run});