-----------------------------------------------------------------------------------------------------------------
-- TITLE              : CII_SR_MDCL_HCC01_SMRY
-- FILENAME           : cii_sr_mdcl_hcc01_smry_delete.sql
-- DESCRIPTION        : THIS SCRIPT Tries to delete the data in the table on the basis of as of month number
-- DEVELOPER          : LEGATO
-- CREATED ON         : 04-18-2022 (MM-DD-YYYY)
-- LOGIC              : Delete SQL.
-- VERSION            : 1.0
-- VERSION DESCRIPTION: Initial Version
-----------------------------------------------------------------------------------------------------------------



delete from CII_EVOLVE.CII_SR_MDCL_HCC01_SMRY WHERE (AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${evolve_schema_name}.cii_sr_run_prd) AND 'YES' = ${re_run});
