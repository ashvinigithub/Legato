/*************************************************************************************************************
 # TITLE           : HCC MCID WORK TABLE 
 # FILENAME        : WORK_CII_SR_MDCL_HCC_MCID_LIST.sql
 # DESCRIPTION     : THIS SCRIPT LOADS CII_SR_MDCL_HCC_MCID_LIST table
 # DEVELOPER       : LEGATO
 # CREATED ON      : 3/15/2022
 # LOGIC           : APPEND TARGET TABLE
 # VERSION         : 1.0
 ***************************************************************************************************************/

delete from CII_EVOLVE.CII_SR_MDCL_HCC_MCID_LIST WHERE (AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD) AND 'YES' = ${re_run} AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})));

INSERT INTO CII_EVOLVE.CII_SR_MDCL_HCC_MCID_LIST

SELECT amstp.AS_OF_YEAR_MNTH_NBR
	,amstp.INCRD_PAID_CD
	,amstp.AGRGT_SRC_FLTR_ID AS SRC_FLTR_ID	
	,amstp.AGRGT_ACCT_ID AS ACCT_ID
	,amstp.TM_PRD_TYPE_CD
	,amstp.YEAR_ID
	,amstp.RPT_RUN_ID
	,-1 AS RPT_INSTNC_MTDTA_ID
	,amstp.ACCT_SGMNTN_TYPE_NM
	,amstp.BNCHMRK_ID
	,sum(ACCT_ALWD_AMT) AS ACCT_ALWD_AMT
	,sum(ACCT_PAID_AMT) AS ACCT_PAID_AMT
	,MCID
	,amstp.SCRTY_LVL_CD
	,CURRENT_TIMESTAMP AS LOAD_DTM 
	,MD5(current_timestamp) as LOAD_LOG_KEY
	FROM ${aciisst_adhoc_schema_name}.CII_FACT_CLM_LINE_CNSLDTD fact
INNER JOIN (
	SELECT DISTINCT ACCT_ID
		,SGMNTN_DIM_KEY
		,AGRGT_SRC_FLTR_ID
		,SRC_FLTR_ID
		,AGRGT_ACCT_ID
		,PAID_STRT_MNTH_NBR
		,PAID_END_MNTH_NBR
		,SRVC_STRT_MNTH_NBR
		,SRVC_END_MNTH_NBR
		,TM_PRD_TYPE_CD
		,YEAR_ID
		,INCRD_PAID_CD
		,AS_OF_YEAR_MNTH_NBR
		,RPT_RUN_ID
		,- 1 AS RPT_INSTNC_MTDTA_ID
		,ACCT_SGMNTN_TYPE_NM
		,CII_SR_ACCT_SGMNTN_TM_PRD_PARM.SCRTY_LVL_CD
		,HCC_THRSHLD_AMT
		,BNCHMRK_ID
	FROM ${evolve_schema_name}.CII_SR_ACCT_SGMNTN_TM_PRD_PARM
	JOIN ${aciisst_adhoc_schema_name}.CII_RUN_PRD PRD ON PRD.RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR
	WHERE RPT_SHRT_NM IN ('HCC-01','HCC-01PHI','HCC-02')
		AND YEAR_ID <= 3
		and RPT_SPRSN_IND ='N'
		AND (CLNT_PRTY_GRP_CD in (${clnt_prty_grp_cd}) OR 'ALL' in (${clnt_prty_grp_cd}))
		AND (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) 
		) amstp ON fact.acct_id = amstp.acct_id
	AND fact.RPTG_PAID_YEAR_MNTH_NBR BETWEEN PAID_STRT_MNTH_NBR
		AND PAID_END_MNTH_NBR
	AND fact.CLM_SRVC_YEAR_MNTH_NBR BETWEEN SRVC_STRT_MNTH_NBR
		AND SRVC_END_MNTH_NBR
	AND fact.SGMNTN_DIM_KEY = amstp.SGMNTN_DIM_KEY

WHERE MBR_CVRG_TYPE_CD IN ('001','102') and BK_FILL_IND = 'N'
  AND 1 = (SELECT case when AS_OF_YEAR_MNTH_NBR is not null and 'NO' = ${re_run} then 0
       when AS_OF_YEAR_MNTH_NBR is not null and 'YES' = ${re_run} THEN 0
       when AS_OF_YEAR_MNTH_NBR is null and 'NO' = ${re_run} THEN 1
       when AS_OF_YEAR_MNTH_NBR is null and 'YES' = ${re_run} THEN 1 ELSE 1 END AS RESULT
FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD 
LEFT JOIN (SELECT max(AS_OF_YEAR_MNTH_NBR) as AS_OF_YEAR_MNTH_NBR FROM ${evolve_schema_name}.CII_SR_MDCL_HCC_MCID_LIST
 WHERE (RPT_RUN_ID in (${rpt_run_id_bnchmrk}) OR (RPT_RUN_ID BETWEEN ${rpt_run_id_bnchmrk_min} AND ${rpt_run_id_bnchmrk_max})) AND AS_OF_YEAR_MNTH_NBR = (SELECT MAX(RUN_YEAR_MNTH_NBR) FROM ${aciisst_adhoc_schema_name}.CII_RUN_PRD))
on RUN_YEAR_MNTH_NBR = AS_OF_YEAR_MNTH_NBR)

GROUP BY amstp.AGRGT_SRC_FLTR_ID
	,amstp.AGRGT_ACCT_ID
	,amstp.AS_OF_YEAR_MNTH_NBR
	,amstp.INCRD_PAID_CD
	,amstp.YEAR_ID
	,amstp.TM_PRD_TYPE_CD
	,MCID
	,amstp.RPT_RUN_ID
	,amstp.ACCT_SGMNTN_TYPE_NM
	,amstp.BNCHMRK_ID
	,amstp.SCRTY_LVL_CD
	,CURRENT_TIMESTAMP
	,MD5(current_timestamp)
HAVING sum(ACCT_PAID_AMT) >= max(amstp.HCC_THRSHLD_AMT);
