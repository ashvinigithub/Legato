 /*************************************************************************************************************
 # TITLE           : work_cii_ddim_plan_ref load
 # FILENAME        : work_cii_ddim_plan_ref.sql
 # DESCRIPTION     : THIS SCRIPT LOADS work_cpttn table
 # DEVELOPER       : LEGATO
 # CREATED ON      : 07/28/2022
 # LOGIC           : TRUNCATE AND RELOAD TARGET TABLE
 # VERSION         : 1.0
 ***************************************************************************************************************/

INSERT OVERWRITE INTO CII_EVOLVE_STG.WORK_CII_DDIM_PLAN_REF
WITH cii_ddim_plan_ref as 
(SELECT 823 AS SOR_CD,' ' AS BNFT_PKG_ID_IND,'Y' AS PKG_NUM_IND
 UNION
 SELECT 824 AS SOR_CD,' ' AS BNFT_PKG_ID_IND,'Y' AS PKG_NUM_IND
 UNION
 SELECT 867 AS SOR_CD,'Y' AS BNFT_PKG_ID_IND,' ' AS PKG_NUM_IND
 UNION 
 SELECT 1104 AS SOR_CD,'Y' AS BNFT_PKG_ID_IND,' ' AS PKG_NUM_IND
 UNION
 SELECT 808 AS SOR_CD,'Y' AS BNFT_PKG_ID_IND,' ' AS PKG_NUM_IND
 UNION
 SELECT 868 AS SOR_CD,' ' AS BNFT_PKG_ID_IND,'Y' AS PKG_NUM_IND
  UNION	
 SELECT 886 AS SOR_CD,' ' AS BNFT_PKG_ID_IND,'Y' AS PKG_NUM_IND
 UNION
 SELECT 892 AS SOR_CD,'Y' AS BNFT_PKG_ID_IND,' ' AS PKG_NUM_IND
  UNION
 SELECT 809 AS SOR_CD,' ' AS BNFT_PKG_ID_IND,'Y' AS PKG_NUM_IND
  UNION
 SELECT 815 AS SOR_CD,'Y' AS BNFT_PKG_ID_IND,' ' AS PKG_NUM_IND
   UNION
 SELECT 822 AS SOR_CD,' ' AS BNFT_PKG_ID_IND,'Y' AS PKG_NUM_IND
 )
 SELECT SOR_CD,
		BNFT_PKG_ID_IND,
		PKG_NUM_IND
	FROM cii_ddim_plan_ref

