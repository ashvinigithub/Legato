from pyspark.sql import *
import time 
spark=SparkSession.builder.appName("test").getOrCreate()
print(1)
time.sleep(100)