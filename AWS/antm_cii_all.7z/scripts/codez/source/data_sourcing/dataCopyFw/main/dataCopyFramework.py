# -------------------------------------------------------------------------------------------------------------
#
#  Program Name : dataCopyFramework.py
#  Description  : This Framework Helps in copying data from One S3 location to Another S3 in Bulk.
# --------------------------------------------------------------------------------------------------------------
try:
    import subprocess
    import logging
    import logging.config
    import argparse
    import boto3
    import json
except Exception as e:
    raise Exception(e)

# Define boto3 Objects
s3r = boto3.resource('s3')

# Logger
LOGGER = logging.getLogger("Data Copy Framework")
LOGGER.setLevel(logging.DEBUG)
LOGGER.addHandler(logging.StreamHandler())

def get_size(s3_path):
    """
    Function to fetch the size of s3 folder
    :param s3_path: S3 object full path
    :return: Size of folder
    """
    bucket = s3_path.split("//")[1].split("/")[0]
    key = "/".join(s3_path.replace("//", "").split("/")[1:])

    total_size = 0
    try:
        bucket = s3r.Bucket(bucket)
        for obj in bucket.objects.filter(Prefix=key):
            total_size = total_size + obj.size
    except Exception as err:
        raise Exception(err)

    return total_size


def delete_s3_objects(s3_path):
    """
    Function to delete objects from s3 path
    :param s3_path: S3 object full path
    :return: True (If Delete is successfull)
    """
    bucket = s3_path.split("//")[1].split("/")[0]
    key = "/".join(s3_path.replace("//", "").split("/")[1:])
    
    LOGGER.info(f"Deleting S3 objects from Bucket => {bucket}, Key => {key}")
    try:
        bucket = s3r.Bucket(bucket)
        bucket.objects.filter(Prefix=key).delete()
    except Exception as err:
        raise Exception(err)

    return True


def read_s3_object(s3_path):
    """
    Function to read object from s3 path
    :param s3_path: S3 object full path
    :return: object
    """
    bucket = s3_path.split("//")[1].split("/")[0]
    key = "/".join(s3_path.replace("//", "").split("/")[1:])
    
    LOGGER.info(f"Reading S3 obj from Bucket => {bucket}, Key => {key}")
    try:
        obj = s3r.Object(bucket, key)
    except Exception as err:
        raise Exception(err)

    return obj


# Runs a Shell command
def run_command(command):
    """
    Function to execute a subprocess.run command
    :param command: Command in the form of List
    :return: True if successful
    """
    LOGGER.info(f"Command: {command}")
    process = subprocess.Popen(command,
                    stdout=subprocess.PIPE, 
                    stderr=subprocess.PIPE)
    stdout, stderr = process.communicate()

    LOGGER.info(f"stdout: {stdout}")

    if len(stderr) > 0:
        LOGGER.exception(stderr)
        raise Exception(stderr)

    return stdout


# Main Processing Function
def main(args_dict):
    """
    Main Processing Function
    """
    # Intialize Arguements
    env = args_dict.get('env', None)
    jobset = args_dict.get('jobset', None)
    s3_config_name = args_dict.get('s3_config_name', None)
    s3_config_path = f"s3://antm-cii-{env}-codez-nogbd-nophi-useast1/data_sourcing/dataCopyFw/config/{s3_config_name}"

    # Validate Input Args
    if env is None:
        raise ValueError("*** Please provide valid Environemt for --env ***")

    if jobset is None:
        raise ValueError("*** Please provide valid value for --jobset ***")

    if s3_config_name is None:
        raise ValueError("*** Please provide valid value for --s3_config_name ***")

    # Read S3 Config for S3 Paths Information.
    s3_path_parms = json.loads(read_s3_object(s3_config_path).get()['Body'].read().decode('utf-8'))

    if jobset not in s3_path_parms.keys():
        raise KeyError(f"*** Please Provide Valid Key as Jobset. Key {jobset} is not present in {s3_config_path} ***")

    if len(s3_path_parms[jobset]) == 0:
        raise ValueError(f"*** Given Config File {s3_config_path} is empty. Please provide atleast one path-set for data copy ***")

    for pathset in s3_path_parms[jobset]:

        if len(pathset.split(",")) != 2:
            raise Exception(f"*** Please provide Source S3, Target S3 locations in Config File located at {s3_config_path} ***")

        srcLoc = pathset.split(",")[0]
        destLoc = pathset.split(",")[1]

        LOGGER.info("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")

        source_stats = get_size(srcLoc)
        try:
            delete_s3_objects(destLoc)
        except Exception as err:
            raise Exception(err)
        
        cp_command = f"s3-dist-cp --src {srcLoc} --dest {destLoc}"
        try:
            run_command(cp_command.split(" "))
        except Exception as err:
            raise Exception(err)
        
        target_stats = get_size(destLoc)

        if int(source_stats) != int(target_stats):
            LOGGER.exception(f"*** Copy Failed for S3 Location => {pathset} ***")
        else:
            LOGGER.info(f"*** Copy Successfull : {pathset} ***")


if __name__ == '__main__':

    parser = argparse.ArgumentParser(description='Data Copy Framework')

    parser.add_argument('--env', required=True, dest='env', default=None, metavar='<env>',
            help='Environment name. eg: prod')
    parser.add_argument('--s3_config_name', required=True, dest='s3_config_name', default=None, metavar='<s3_config_name>',
            help='Config File Name which has list of S3 paths for Data Copy.')
    parser.add_argument('--jobset', required=True, dest='jobset', default=None, metavar='<jobset>',
            help='Json Key of the Data Copy Config File')

    LOGGER.info("*** Initializing arguements ***")
    args = parser.parse_args()
    args_dict = vars(args)

    main(args_dict)
