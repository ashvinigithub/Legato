#!/bin/bash
#===============================================================================
# Title            : s3 to s3 parallel data Copy
# Filename         : dataCopy.sh
# Description      : Based on the source and destination passed in tableListFile , It will trigger the step on EMR to copy data from source location to destination location parallely.
# Source Tables    : 
# Target Tables    : 
# Caution		   : This script will overwrite the data into target location. So existing data will be lost.
# Key Columns      :
# Developer        : Pulkit Kumar Pansari
# Created on       : 06/22/2021.
# Location         :
# Parameters       : 
# Date       Ver#  Modified By(Name)                Change and Reason for Change
# ---------- ----- ---------------------------- --------------------------------------------
####
#===============================================================================
source ~/.bash_profile
 
export tableListFile=(
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/clncl/edw/um_srvc/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/um_srvc/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/clncl/edw/um_srvc_hlth_advsr/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/um_srvc_hlth_advsr/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/clncl/edw/um_srvc_prov/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/um_srvc_prov/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/clncl/edw/um_srvc_stts/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/um_srvc_stts/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/coa/edw/gl_cf_mbu_cbe_vrtcl_hrchy/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/gl_cf_mbu_cbe_vrtcl_hrchy/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/coa/edw/gl_cf_mbu_vrtcl_hrchy/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/gl_cf_mbu_vrtcl_hrchy/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/grpr/edw/dcg/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/dcg/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/grpr/edw/dcg_outpt/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/dcg_outpt/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/grpr/edw/drg/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/drg/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/grpr/edw/drg_case_grpr/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/drg_case_grpr/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/grpr/edw/drg_grpr/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/drg_grpr/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/hra/edw/webmd_ha/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/webmd_ha/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/mbr/edw/clncl_mbr_enrld_enhncd_bnfts/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/clncl_mbr_enrld_enhncd_bnfts/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/mbr/edw/emplymnt/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/emplymnt/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/mbr/edw/hlth_pgm_bnft_pkg/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/hlth_pgm_bnft_pkg/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/mbr/edw/mbr_adrs/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/mbr_adrs/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/mbr/edw/mbr_adrs_hist/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/mbr_adrs_hist/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/mbr/edw/mbr_coa_bnft_pkg_mix/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/mbr_coa_bnft_pkg_mix/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/mbr/edw/mbr_cob/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/mbr_cob/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/mbr/edw/mbr_prod_enrlmnt/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/mbr_prod_enrlmnt/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/mbr/edw/medcr_anlytc_padrs_xwalk/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/medcr_anlytc_padrs_xwalk/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/mbr/edw/prchsr_org_pgm_parn/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/prchsr_org_pgm_parn/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/mbr/edw/prchsr_org_rltnshp/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/prchsr_org_rltnshp/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/mbr/edw/prod_ofrg/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/prod_ofrg/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/mbr/edw/prod_ofrg_bcv/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/prod_ofrg_bcv/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/mbr/edw/prod_ofrg_bnft/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/prod_ofrg_bnft/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/mbr/edw/rsttd_mbrshp_mnth_cnt/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/rsttd_mbrshp_mnth_cnt/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/prod/edw/bnft_pkg/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/bnft_pkg/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/prod/edw/bnft_pkg_addnl/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/bnft_pkg_addnl/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/prod/edw/bnft_pkg_prcp/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/bnft_pkg_prcp/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/clncl/edw/rule_rslt/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/rule_rslt/"
)

#list_in_param_file=$1 
tableList=("${tableListFile[@]}")
#logLocation="s3://antm-cii-dev-cnfz-nogbd-phi-useast1/cii/laddered_jars/"
#echo "Logging :" ${logLocation}logFile.log
#exec 1> ${logLocation}logFile.log 2>&1
#PROP_FILE=$1
#source $PROP_FILE
aws configure set default.s3.max_concurrent_requests 20
aws configure set default.s3.max_queue_size 10000
aws configure set default.s3.multipart_threshold 64MB
aws configure set default.s3.multipart_chunksize 16MB
aws configure set default.s3.max_bandwidth 50MB/s
aws configure set default.s3.use_accelerate_endpoint true
aws configure set default.s3.addressing_style path
tableListlength=${#tableList[@]}
for (( i=0; i<${tableListlength}; i++ ));
do
  echo  "................$i  : "  ${tableList[$i]} "  ................................." 

	srcLoc=` echo ${tableList[$i]} | cut -f 1 -d ',' `
	destLoc=` echo ${tableList[$i]} | cut -f 2 -d ',' `
#	logFileName=` echo ${srcLoc} | rev | cut -f 1 -d '/' | rev `
#	logFile=${logFileName}_$(date +"%Y%m%d_%H%M%S").log
#logFile= touch ${logLocation}${logFileName}_$(date +"%Y%m%d_%H%M%S").log
#	echo "************* ${logFile} **************"
#  sudo su hadoop
#  sudo touch ${logFile}
  echo  "................aws s3 rm --recursive ${destLoc}"
  aws s3 rm --recursive ${destLoc}
  echo  "................s3-dist-cp --recursive --src  ${srcLoc}   --dest ${destLoc}"
  s3-dist-cp --src ${srcLoc} --dest ${destLoc} &
#echo "${copy_Script} ${srcLoc} ${destLoc} ${logFile}"
#sh ${copyScript} ${srcLoc} ${destLoc} ${logFile}
done
