#!/bin/bash
#===============================================================================
# Title            : s3 to s3 parallel data Copy
# Filename         : dataCopy.sh
# Description      : Based on the source and destination passed in tableListFile , It will trigger the step on EMR to copy data from source location to destination location parallely.
# Source Tables    : 
# Target Tables    : 
# Caution		   : This script will overwrite the data into target location. So existing data will be lost.
# Key Columns      :
# Developer        : Pulkit Kumar Pansari
# Created on       : 06/22/2021.
# Location         :
# Parameters       : 
# Date       Ver#  Modified By(Name)                Change and Reason for Change
# ---------- ----- ---------------------------- --------------------------------------------
##
#===============================================================================
source ~/.bash_profile
 
export tableListFile=(
"s3://antm-sf-prod-dataz-gbd-phi-useast1/rawz/edl/bdf/intrct_sc_antm_cs_wgs_work/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/intrct_sc_antm_cs_wgs_work/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/rdm/edw/diag_icd_clsfctn/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/diag_icd_clsfctn/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/rawz/edl/bdf/clncl_hrs_caseconditioninstance/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/clncl_hrs_caseconditioninstance/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/intrct/bdf/intrct_eda_digitalregistrations_exploded/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/intrct_eda_digitalregistrations_exploded/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/rawz/edl/bdf/intrct_adbe_interaction/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/intrct_adbe_interaction/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/rawz/edl/bdf/intrct_sc_work_ahgguideddecisionsupp/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/intrct_sc_work_ahgguideddecisionsupp/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/rawz/edl/bdf/intrct_sc_work_referralovrvwlst/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/intrct_sc_work_referralovrvwlst/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/clncl/bdf/mbr_ath_engg_castlight_engage_program/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/mbr_ath_engg_castlight_engage_program/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/clncl/bdf/mbr_ath_engg_castlight_engage_reg_data/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/mbr_ath_engg_castlight_engage_reg_data/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/clncl/bdf/mbr_ath_engg_castlight_engage_rhi_category/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/mbr_ath_engg_castlight_engage_rhi_category/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/rawz/edl/mbr/bdf/mbrshp_prsn_extrct/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/mbrshp_prsn_extrct/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/rdm/edw/mdcl_svrty_drg/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/mdcl_svrty_drg/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/rdm/edw/rvnu_cd/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/rvnu_cd/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/rdm/edw/st_prvnc_cd/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/st_prvnc_cd/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/rdm/edw/tos_lvl_1_cd/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/tos_lvl_1_cd/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/rdm/edw/bnft_paymnt_stts_tier_cd/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/bnft_paymnt_stts_tier_cd/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edm/clm/ddim_etg/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/ddim_etg/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edm/clm/scndry_fact_clm_line_anlytc/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/scndry_fact_clm_line_anlytc/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edm/clm/sfact_clm_line/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/sfact_clm_line/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/clncl/edw/ddim_proc/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/ddim_proc/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edm/prod/edm/ddim_prod/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/ddim_prod/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/sadl/prod/edm/ddim_prda_ntwk/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/ddim_prda_ntwk/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/sadl/prod/edm/fact_prda_mbr_prod_smry/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/fact_prda_mbr_prod_smry/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/clm/edw/clm/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/clm/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/clm/edw/clm_addnl/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/clm_addnl/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/clm/edw/clm_bd/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/clm_bd/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/clm/edw/clm_icd_proc/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/clm_icd_proc/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/clm/edw/clm_line/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/clm_line/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/clm/edw/clm_line_addnl/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/clm_line_addnl/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/clm/edw/clm_line_coa/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/clm_line_coa/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/clm/edw/clm_line_diag/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/clm_line_diag/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/clm/edw/clm_line_hcs_mdfr/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/clm_line_hcs_mdfr/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/clm/edw/clm_line_incrd/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/clm_line_incrd/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/clm/edw/clm_line_prov/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/clm_line_prov/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/clm/edw/clm_line_rdctn/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/clm_line_rdctn/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/clm/edw/clm_line_rdctn_incrd/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/clm_line_rdctn_incrd/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/clm/edw/clm_max_rvsn/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/clm_max_rvsn/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/clm/edw/clm_prov/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/clm_prov/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/clm/edw/fclty_clm/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/fclty_clm/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/clm/edw/medcr_prov_anlytc_patch/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/medcr_prov_anlytc_patch/"
)

#list_in_param_file=$1 
tableList=("${tableListFile[@]}")
#logLocation="s3://antm-cii-dev-cnfz-nogbd-phi-useast1/cii/laddered_jars/"
#echo "Logging :" ${logLocation}logFile.log
#exec 1> ${logLocation}logFile.log 2>&1
#PROP_FILE=$1
#source $PROP_FILE
aws configure set default.s3.max_concurrent_requests 20
aws configure set default.s3.max_queue_size 10000
aws configure set default.s3.multipart_threshold 64MB
aws configure set default.s3.multipart_chunksize 16MB
aws configure set default.s3.max_bandwidth 50MB/s
aws configure set default.s3.use_accelerate_endpoint true
aws configure set default.s3.addressing_style path
tableListlength=${#tableList[@]}
for (( i=0; i<${tableListlength}; i++ ));
do
  echo  "................$i  : "  ${tableList[$i]} "  ................................." 

	srcLoc=` echo ${tableList[$i]} | cut -f 1 -d ',' `
	destLoc=` echo ${tableList[$i]} | cut -f 2 -d ',' `
#	logFileName=` echo ${srcLoc} | rev | cut -f 1 -d '/' | rev `
#	logFile=${logFileName}_$(date +"%Y%m%d_%H%M%S").log
#logFile= touch ${logLocation}${logFileName}_$(date +"%Y%m%d_%H%M%S").log
#	echo "************* ${logFile} **************"
#  sudo su hadoop
#  sudo touch ${logFile}
  echo  "................aws s3 rm --recursive ${destLoc}"
  aws s3 rm --recursive ${destLoc}
  echo  "................s3-dist-cp --recursive --src  ${srcLoc}   --dest ${destLoc}"
  s3-dist-cp --src ${srcLoc} --dest ${destLoc}
#echo "${copy_Script} ${srcLoc} ${destLoc} ${logFile}"
#sh ${copyScript} ${srcLoc} ${destLoc} ${logFile}
done