#!/bin/bash
#===============================================================================
# Title            : s3 to s3 parallel data Copy
# Filename         : dataCopy.sh
# Description      : Based on the source and destination passed in tableListFile , It will trigger the step on EMR to copy data from source location to destination location parallely.
# Source Tables    : 
# Target Tables    : 
# Caution		   : This script will overwrite the data into target location. So existing data will be lost.
# Key Columns      :
# Developer        : Pulkit Kumar Pansari
# Created on       : 06/22/2021.
# Location         :
# Parameters       : 
# Date       Ver#  Modified By(Name)                Change and Reason for Change
# ---------- ----- ---------------------------- --------------------------------------------
##
#===============================================================================
source ~/.bash_profile
 
export tableListFile=(
"s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/archive/"
"s3://antm-cii-preprod-cnfz-nogbd-phi-useast1/cii/source/,s3://antm-cii-preprod-cnfz-nogbd-phi-useast1/archive/"
)

#list_in_param_file=$1 
tableList=("${tableListFile[@]}")
#logLocation="s3://antm-cii-dev-cnfz-nogbd-phi-useast1/cii/laddered_jars/"
#echo "Logging :" ${logLocation}logFile.log
#exec 1> ${logLocation}logFile.log 2>&1
#PROP_FILE=$1
#source $PROP_FILE
aws configure set default.s3.max_concurrent_requests 20
aws configure set default.s3.max_queue_size 10000
aws configure set default.s3.multipart_threshold 64MB
aws configure set default.s3.multipart_chunksize 16MB
aws configure set default.s3.max_bandwidth 50MB/s
aws configure set default.s3.use_accelerate_endpoint true
aws configure set default.s3.addressing_style path
tableListlength=${#tableList[@]}
for (( i=0; i<${tableListlength}; i++ ));
do
  echo  "................$i  : "  ${tableList[$i]} "  ................................." 

	srcLoc=` echo ${tableList[$i]} | cut -f 1 -d ',' `
	destLoc=` echo ${tableList[$i]} | cut -f 2 -d ',' `
#	logFileName=` echo ${srcLoc} | rev | cut -f 1 -d '/' | rev `
#	logFile=${logFileName}_$(date +"%Y%m%d_%H%M%S").log
#logFile= touch ${logLocation}${logFileName}_$(date +"%Y%m%d_%H%M%S").log
#	echo "************* ${logFile} **************"
echo  "................s3-dist-cp --src  ${srcLoc} --dest ${destLoc}"
#  sudo su hadoop
#  sudo touch ${logFile}
#  aws s3 cp ${logFile} ${logLocation}${logFile}  
  s3-dist-cp --src ${srcLoc} --dest ${destLoc}
#echo "${copy_Script} ${srcLoc} ${destLoc} ${logFile}"
#sh ${copyScript} ${srcLoc} ${destLoc} ${logFile}
done