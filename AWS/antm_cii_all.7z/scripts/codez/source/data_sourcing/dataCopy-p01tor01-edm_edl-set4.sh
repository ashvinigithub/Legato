#!/bin/bash
#===============================================================================
# Title            : s3 to s3 parallel data Copy
# Filename         : dataCopy.sh
# Description      : Based on the source and destination passed in tableListFile , It will trigger the step on EMR to copy data from source location to destination location parallely.
# Source Tables    : 
# Target Tables    : 
# Caution		   : This script will overwrite the data into target location. So existing data will be lost.
# Key Columns      :
# Developer        : Pulkit Kumar Pansari
# Created on       : 06/22/2021.
# Location         :
# Parameters       : 
# Date       Ver#  Modified By(Name)                Change and Reason for Change
# ---------- ----- ---------------------------- --------------------------------------------
##
#===============================================================================
source ~/.bash_profile
 
export tableListFile=(
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/clm/edw/ndc/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/ndc/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/clm/edw/ndc_medispan/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/ndc_medispan/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/clm/edw/ndc_medispan_gpi/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/ndc_medispan_gpi/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/clm/edw/phrmcy_clm_line/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/phrmcy_clm_line/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/clm/edw/phrmcy_clm_line_incrd/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/phrmcy_clm_line_incrd/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/rawz/edl/bdf/intrct_sc_work_ahgeducationopps/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/intrct_sc_work_ahgeducationopps/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/rawz/edl/bdf/intrct_sc_work_ahgprmtnlregistrtns/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/intrct_sc_work_ahgprmtnlregistrtns/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/mbr/edw/mbr/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/mbr/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/clncl/edw/hlth_advsr_stf_charstc/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/hlth_advsr_stf_charstc/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/clncl/edw/mdcl_mngmnt_case_mbr_atrb/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/mdcl_mngmnt_case_mbr_atrb/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/clncl/edw/mdcl_mngmnt_mbu/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/mdcl_mngmnt_mbu/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/clncl/edw/mdcl_rvw_case_info/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/mdcl_rvw_case_info/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/clncl/edw/rule/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/rule/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/clncl/edw/rule_rslt/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/rule_rslt/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/clncl/edw/um_inpat_srvc/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/um_inpat_srvc/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/clncl/edw/um_inpat_srvc_stts/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/um_inpat_srvc_stts/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/clncl/edw/um_rqst/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/um_rqst/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/clncl/edw/um_rqst_prov/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/um_rqst_prov/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/rawz/edl/bdf/clncl_hrs_codetable/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/clncl_hrs_codetable/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/rawz/edl/bdf/clncl_hrs_goals/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/clncl_hrs_goals/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/rawz/edl/bdf/clncl_hrs_hacasecontactactivity/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/clncl_hrs_hacasecontactactivity/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/rawz/edl/bdf/clncl_hrs_historyhacase/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/clncl_hrs_historyhacase/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/rawz/edl/bdf/clncl_hrs_historymemberenrollment/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/clncl_hrs_historymemberenrollment/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/rawz/edl/bdf/clncl_hrs_historymembergoals/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/clncl_hrs_historymembergoals/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/rawz/edl/bdf/clncl_hrs_historymemberpolicies/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/clncl_hrs_historymemberpolicies/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/rawz/edl/bdf/clncl_hrs_historymembertrigger/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/clncl_hrs_historymembertrigger/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/rawz/edl/bdf/clncl_hrs_interventions/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/clncl_hrs_interventions/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/rawz/edl/bdf/clncl_hrs_interventiontype/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/clncl_hrs_interventiontype/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/rawz/edl/bdf/clncl_hrs_memberalternateidxref/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/clncl_hrs_memberalternateidxref/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/rawz/edl/bdf/clncl_hrs_memberassessmentresult,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/clncl_hrs_memberassessmentresult/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/rawz/edl/bdf/clncl_hrs_memberassessmentstatus/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/clncl_hrs_memberassessmentstatus/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/rawz/edl/bdf/clncl_hrs_membercase/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/clncl_hrs_membercase/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/rawz/edl/bdf/clncl_hrs_memberdwxref/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/clncl_hrs_memberdwxref/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/rawz/edl/bdf/clncl_hrs_membergoalintervention/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/clncl_hrs_membergoalintervention/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/rawz/edl/bdf/clncl_hrs_membergoals/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/clncl_hrs_membergoals/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/rawz/edl/bdf/clncl_hrs_memberpolicies/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/clncl_hrs_memberpolicies/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/rawz/edl/bdf/clncl_hrs_memberreferral/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/clncl_hrs_memberreferral/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/rawz/edl/bdf/clncl_hrs_membertrigger/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/clncl_hrs_membertrigger/"
"s3://antm-edl-prod-dataz-gbd-phi-useast1/edl/prov/edw/bkbn_tax_id/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/bkbn_tax_id/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/mbr/edw/mdm_ppltn_xwalk/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/mdm_ppltn_xwalk/"
"s3://antm-edl-prod-cnfz-gbd-phi-useast1/edl/clncl/bdf/ddim_disblty_clm_authrzn/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/ddim_disblty_clm_authrzn/"
"s3://antm-edl-prod-cnfz-gbd-phi-useast1/edl/clncl/bdf/ddim_mbr_mcid/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/ddim_mbr_mcid/"
"s3://antm-edl-prod-cnfz-gbd-phi-useast1/edl/clncl/bdf/dim_rptg_clm_line_scndry_stts/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/dim_rptg_clm_line_scndry_stts/"
"s3://antm-edl-prod-cnfz-gbd-phi-useast1/edl/clncl/bdf/dim_spclty_lob_id/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/dim_spclty_lob_id/"
"s3://antm-edl-prod-cnfz-gbd-phi-useast1/edl/clncl/bdf/dim_spclty_plcy_type/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/dim_spclty_plcy_type/"
"s3://antm-edl-prod-cnfz-gbd-phi-useast1/edl/clncl/bdf/fact_non_mclm_line/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/fact_non_mclm_line/"
"s3://antm-edl-prod-cnfz-gbd-phi-useast1/edl/clncl/bdf/fact_non_mclm_line_smry/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/fact_non_mclm_line_smry/"
"s3://antm-edl-prod-cnfz-gbd-phi-useast1/edl/clncl/bdf/fact_non_mclm_wvr/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/fact_non_mclm_wvr/"
"s3://antm-edl-prod-cnfz-gbd-phi-useast1/edl/clncl/bdf/fact_non_mdcl_bnft_opts/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/fact_non_mdcl_bnft_opts/"
"s3://antm-edl-prod-cnfz-gbd-phi-useast1/edl/clncl/bdf/fact_non_mdcl_prem/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/fact_non_mdcl_prem/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/rdm/edw/coa_wlp_lob/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/coa_wlp_lob/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/clncl/cii/cp_mbr_id_xwalk/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/cp_mbr_id_xwalk/"
"s3://antm-sf-prod-dataz-gbd-phi-useast1/cnfz/edl/mbr/edw/prchsr_org/,s3://antm-cii-preprod-cnfz-gbd-phi-useast1/cii/source/edl/prchsr_org/"
)

#list_in_param_file=$1 
tableList=("${tableListFile[@]}")
#logLocation="s3://antm-cii-dev-cnfz-nogbd-phi-useast1/cii/laddered_jars/"
#echo "Logging :" ${logLocation}logFile.log
#exec 1> ${logLocation}logFile.log 2>&1
#PROP_FILE=$1
#source $PROP_FILE
aws configure set default.s3.max_concurrent_requests 20
aws configure set default.s3.max_queue_size 10000
aws configure set default.s3.multipart_threshold 64MB
aws configure set default.s3.multipart_chunksize 16MB
aws configure set default.s3.max_bandwidth 50MB/s
aws configure set default.s3.use_accelerate_endpoint true
aws configure set default.s3.addressing_style path
tableListlength=${#tableList[@]}
for (( i=0; i<${tableListlength}; i++ ));
do
  echo  "................$i  : "  ${tableList[$i]} "  ................................." 

	srcLoc=` echo ${tableList[$i]} | cut -f 1 -d ',' `
	destLoc=` echo ${tableList[$i]} | cut -f 2 -d ',' `
#	logFileName=` echo ${srcLoc} | rev | cut -f 1 -d '/' | rev `
#	logFile=${logFileName}_$(date +"%Y%m%d_%H%M%S").log
#logFile= touch ${logLocation}${logFileName}_$(date +"%Y%m%d_%H%M%S").log
#	echo "************* ${logFile} **************"
#  sudo su hadoop
#  sudo touch ${logFile}
  echo  "................aws s3 rm --recursive ${destLoc}"
  aws s3 rm --recursive ${destLoc}
  echo  "................s3-dist-cp --recursive --src  ${srcLoc}   --dest ${destLoc}"
  s3-dist-cp --src ${srcLoc} --dest ${destLoc}
#echo "${copy_Script} ${srcLoc} ${destLoc} ${logFile}"
#sh ${copyScript} ${srcLoc} ${destLoc} ${logFile}
done
