"""
DOCSTRING : Glue job to load the table - cii_sgmntn_list, by collecting sgmntn_dim_key's from dashboard and adhoc
"""
## This script requires parameters such as aplctn_cd, snowflake_env,warehouse_size_suffix and env

import re
import logging

LOGGER = logging

#Import Pyspark Modules
from pyspark.sql import SparkSession
from pyspark.context import SparkContext
from pyspark.sql import functions as F
from pyspark.storagelevel import StorageLevel 
from pyspark.sql.types import StructType, StructField, StringType

#Import common Modules
import os
import sys
import json
import uuid
import ast
import boto3
from datetime import *
from botocore.exceptions import ClientError

#---------------------------------------------------------------------------------#
# Creating boto3 client                                                           #
#---------------------------------------------------------------------------------#
client = boto3.client('s3')

#---------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------#
LOGGER.info("Reading Glue Job Parameters... \n")

# Parse Arguments for Glue Job

# Define mandatory params
params = [
    'env'
]

# Parse Arguments for Glue Job
ARGS = sys.argv

ENV = sys.argv[1]
output_path = sys.argv[2]
dashboard_schema = sys.argv[3].upper()
adhoc_schema = sys.argv[4].upper()
load_log_key = uuid.uuid1()
LOGGER.info(f"\n Environment Passed - {ENV}, {output_path}, {dashboard_schema}, {adhoc_schema}")
REGION_NAME = 'us-east-1'

#---------------------------------------------------------------------------------#
#          Deciding the Schema Prefix                                             #
#---------------------------------------------------------------------------------#
if(ENV=='dev'):
    ENV='dev'
elif(ENV=='sit'):
    ENV='sit'
elif(ENV=='preprod'):
    ENV='preprod'
elif(ENV=='prod'):
    ENV='prod'
elif(ENV=='uat'):
    ENV='uat'
else:
    LOGGER.info(f"\n Invalid Environment Passed - {ENV}, exit(1) \n")
    exit(1)


#---------------------------------------------------------------------------------#
# Function to Generate Union Query                                                #
#---------------------------------------------------------------------------------#
def generateUnionQuery(LOGGER, snowflake_result, schema):
    try:
        union_query = ''
        tables = []
        for table in snowflake_result:
            tables.append(table[0])
        LOGGER.info(f'*** Tables for processing are : {tables} ***')
        counter=0
        for table in tables:
            counter = counter + 1
            if(counter == len(tables)):
                union_query = union_query + f"select sgmntn_dim_key from {schema}.{table}"
            else:
                union_query = union_query + f"select sgmntn_dim_key from {schema}.{table} union all "
      
        return union_query
    
    except sf.ProgrammingError as GenericSnowflakeException:
        LOGGER.critical('*** ERROR: While executing the query for Schema - {schema}***')
        LOGGER.critical(GenericSnowflakeException)
        raise GenericSnowflakeException

#---------------------------------------------------------------------------------#
# Function to get the secret                                                      #
#---------------------------------------------------------------------------------#
def get_secret_value(secretkey):
    import boto3
    session= boto3.session.Session()
    client=session.client(service_name='secretsmanager',region_name='us-east-1')
    secretResponse=client.get_secret_value(SecretId=secretkey)
    secret=ast.literal_eval(secretResponse['SecretString'])
    return secret
#---------------------------------------------------------------------------------#
#                      Business Logic                                             #
#---------------------------------------------------------------------------------#	
try:
    secret = get_secret_value(f"{ENV}/snowflake/spark/ciiapp")
    options_dashboard = {"sfURL" : secret["account"] + ".snowflakecomputing.com", "sfUser" : secret["cii_user"], "sfPassword" : secret["cii_password"], "sfDatabase" : secret["cii_database"], "sfWarehouse" :  secret["cii_warehouse"], "sfSchema" : dashboard_schema, "sfRole" : secret["cii_role"]}
    format = "net.snowflake.spark.snowflake"
    spark = SparkSession.builder.appName("ETL").config("spark.sql.catalogImplementation", "hive").config("hive.metastore.connect.retries", 15).config("hive.metastore.client.factory.class", "com.amazonaws.glue.catalog.metastore.AWSGlueDataCatalogHiveClientFactory").enableHiveSupport().getOrCreate()
    result_for_dashboard = spark.read.format(format).options(**options_dashboard).option("query",f"""select distinct t.table_name from information_schema.tables t inner join information_schema.columns c on c.table_schema = t.table_schema and c.table_name = t.table_name where c.column_name = 'SGMNTN_DIM_KEY' and c.table_schema = '{dashboard_schema}' and t.table_name not like '%$B%' and t.table_name not like '%$%' and t.table_name not like '%_STG' and t.table_name not like '%ACIISST_DDIM_SGMNTN%' and t.table_name not like '%_BKP%' order by t.table_name""").load().rdd.collect()
    options_adhoc = {"sfURL" : secret["account"] + ".snowflakecomputing.com", "sfUser" : secret["cii_user"], "sfPassword" : secret["cii_password"], "sfDatabase" : secret["cii_database"], "sfWarehouse" :  secret["cii_warehouse"], "sfSchema" : adhoc_schema, "sfRole" : secret["cii_role"]}
    result_for_adhoc = spark.read.format(format).options(**options_dashboard).option("query",f"""select distinct t.table_name from information_schema.tables t inner join information_schema.columns c on c.table_schema = t.table_schema and c.table_name = t.table_name where c.column_name = 'SGMNTN_DIM_KEY' and c.table_schema = '{adhoc_schema}' and t.table_name not like '%$B%' and t.table_name not like '%$%' and t.table_name not like '%_STG' and t.table_name not like '%ACIISST_DDIM_SGMNTN%' and t.table_name not like '%_BKP%' order by t.table_name""").load().rdd.collect()
    union_query_for_dashboard = ''
    union_query_for_adhoc = ''
    
    #Calling function - generateUnionQuery, for Dashboard tables
    union_query_for_dashboard = generateUnionQuery(LOGGER, result_for_dashboard, dashboard_schema)
    LOGGER.info(f'\n*** Union Query Built for Dashboard Tables is : {union_query_for_dashboard} ***')
    
    #Calling function - generateUnionQuery, for Adhoc tables
    union_query_for_adhoc = generateUnionQuery(LOGGER, result_for_adhoc, adhoc_schema)
    LOGGER.info(f'\n*** Union Query Built for Adhoc Tables is : {union_query_for_adhoc} ***')
    #Concatenating Dashboard and Adhoc Queries to generate final query
    final_query = f"select sgmntn_dim_key, '{load_log_key}' as load_log_key, current_timestamp() as load_dtm from (select distinct sgmntn_dim_key from (" + union_query_for_dashboard + " union all " + union_query_for_adhoc + "))"
    LOGGER.info(f'\n*** Final Union Query Built for Dashboard and Adhoc Tables is : {final_query} ***')
    #Running the final query on snowflake
    final_output = spark.read.format(format).options(**options_dashboard).option("query",final_query).load()
    #writing the output s3
    final_output.write.format('parquet').mode('overwrite').save(output_path)
#---------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------#    		  
except Exception as e:
    raise e