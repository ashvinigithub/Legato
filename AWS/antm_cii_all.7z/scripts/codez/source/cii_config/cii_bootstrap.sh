#!/bin/bash

install_pgp(){
	sudo python3 -m pip install gnupg
	sudo python3 -m pip install boto3
	sudo systemctl enable amazon-ssm-agent
	sudo systemctl start amazon-ssm-agent
	if [ $? -ne 0 ]; then
		echo "Unable to install python libraries"
		exit 1
	fi
}

install_pgp

exit 0

