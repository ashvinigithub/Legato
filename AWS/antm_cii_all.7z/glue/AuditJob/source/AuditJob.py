############################################################################################################## 
# Description   :This is a script to update work_audit_runperiod Table.
# Author        : Legato
# Created       : 16-Sep-2021
# Version       : V1.0
# last Updated  : ##-###-####
############################################################################################################## 

#Import Pyspark Modules
from pyspark.sql import SparkSession
from pyspark.context import SparkContext
from pyspark.sql import functions as F
from pyspark.storagelevel import StorageLevel 
from pyspark.sql.types import StructType, StructField, StringType

#Import GLue modules
from awsglue.utils import getResolvedOptions
from awsglue.dynamicframe import DynamicFrame
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.transforms import *

#Import common Modules
import os
import sys
import json
import uuid
import re
import boto3
from datetime import *
from awsglue.utils import getResolvedOptions
from botocore.exceptions import ClientError
from ReduceReuseRecycle import load_log_config, InvalidStatus

#---------------------------------------------------------------------------------#
# Creating boto3 client for glue, stepfuntion, s3, sns                            #
#---------------------------------------------------------------------------------#
glue = boto3.client('glue')
client = boto3.client('s3')
sns = boto3.client('sns')
sfn = boto3.client('stepfunctions')
LOGGER = load_log_config(glue=True)
#---------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------#
# Define mandatory params
params = ['etl_stp_parms']

# Parse Arguments for Glue Job
ARGS = getResolvedOptions(sys.argv, params)

etl_parms = json.loads(ARGS['etl_stp_parms'])

# read from parmeters
env = etl_parms.get('env').strip().lower()
#---------------------------------------------------------------------------------#
#          Deciding the Schema Prefix                                             #
#---------------------------------------------------------------------------------#
if(env=='dev'):
    schema_prefix='d01'
elif(env=='sit'):
    schema_prefix='t01'
elif(env=='preprod'):
    schema_prefix='r01'
elif(env=='prod'):
    schema_prefix='p01'
elif(env=='uat'):
    schema_prefix='u01'
else:
    LOGGER.info(f"\n Invalid Environment Passed - {env}, exit(1) \n")
    exit(1)
#---------------------------------------------------------------------------------#
table = etl_parms.get('table_name').strip().format(schema_prefix=schema_prefix)
schema_name = table.split(".")[0]
dq_table = table.split(".")[1]
table_path = etl_parms.get('table_path').strip()

#---------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------#

LOGGER.info(f"\n Environment - {env} \n")
LOGGER.info(f"\n Table  Name - {table} \n")
LOGGER.info(f"\n Table  Path - {table_path} \n")

#---------------------------------------------------------------------------------#
#                      Business Logic                                             #
#---------------------------------------------------------------------------------#	

try:
    LOGGER.info(f"\n Started Running the script \n")
    spark = SparkSession.builder.appName("ETL").config("spark.sql.catalogImplementation", "hive").config("hive.metastore.connect.retries", 15).config("hive.metastore.client.factory.class", "com.amazonaws.glue.catalog.metastore.AWSGlueDataCatalogHiveClientFactory").enableHiveSupport().getOrCreate()
    
    spark.sparkContext._jsc.hadoopConfiguration().set("mapred.output.committer.class", "org.apache.hadoop.mapred.FileOutputCommitter")
    glueContext = GlueContext(spark)
    
    run_period = glueContext.create_dynamic_frame.from_catalog(database=schema_name,table_name=dq_table)
    run_period_df = run_period.toDF()
    run_period_df.createOrReplaceTempView("run_period")
    run_period_df1 = spark.sql("select cast(date_format(add_months(to_date(concat(cast(year_mnth as string),'01'),'yyyyMMdd'),1),'yyyyMM') as int) as year_mnth from run_period")
    LOGGER.info(f"\n Data has been queried successfully from the source table - {table} \n")
    run_period_df1.show()
    #writing spark dataframe to output path
    run_period_df1.write.format("parquet").mode("overwrite").save(table_path)
    LOGGER.info(f"\n Updation of latest month has been completed successfully for  {dq_table}\n")

except Exception as e:
    LOGGER.info(f"\n Updation of latest month has been failed for {dq_table}\n")


