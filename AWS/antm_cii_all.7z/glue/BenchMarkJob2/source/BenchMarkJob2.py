############################################################################################################## 
# Description   : This is a re-usable script to run the EMR Jobs for Benchmark Tables.
# Author        : Legato
# Created       : 05-Apr-2021 
# Version       : V1.0
# last Updated  : ##-###-####
############################################################################################################## 

#Import Pyspark Modules
from pyspark.sql import SparkSession
from pyspark.context import SparkContext
from pyspark.sql import functions as F
from pyspark.storagelevel import StorageLevel 
from pyspark.sql.types import StructType, StructField, StringType

#Import GLue modules
from awsglue.utils import getResolvedOptions
from awsglue.dynamicframe import DynamicFrame
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.transforms import *

#Import common Modules
import os
import sys
import json
import re
import uuid
import boto3
from datetime import *
from awsglue.utils import getResolvedOptions
from botocore.exceptions import ClientError
from ReduceReuseRecycle import load_log_config, InvalidStatus

#---------------------------------------------------------------------------------#
# Creating boto3 client for glue, stepfuntion, s3, sns                            #
#---------------------------------------------------------------------------------#
glue = boto3.client('glue')
client = boto3.client('s3')
sns = boto3.client('sns')
sfn = boto3.client('stepfunctions')
LOGGER = load_log_config(glue=True)
#---------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------#
# Define mandatory params
params = ['etl_stp_parms']
 
# Parse Arguments for Glue Job
ARGS = getResolvedOptions(sys.argv, params)
                                    
#print("$$$$ 1st checkpoint")
#set Variables
etl_parms           = json.loads(ARGS['etl_stp_parms'])
                                            
# read from parmeters
env = etl_parms.get('env').strip().lower()
benchmark_type_name = etl_parms.get('benchmark_type_name').strip()
emr_template_path = etl_parms.get('emr_template_path').strip()
emr_job_args_path = etl_parms.get('emr_job_args_path').strip()
emr_config_name = etl_parms.get('emr_config_name').strip()
bnch_type_cd = etl_parms.get('bnch_type_cd').strip().split("|")
timeperiod_list = etl_parms.get('timeperiod_list').strip().split("|")
intermediate_table_path = etl_parms.get('intermediate_table_path').strip()
conf_file_name = etl_parms.get('conf_file_name').strip()
load_log_key = uuid.uuid1()
#---------------------------------------------------------------------------------#
#          Deciding the Schema Prefix                                             #
#---------------------------------------------------------------------------------#
if(env=='dev'):
    schema_prefix='d01'
elif(env=='sit'):
    schema_prefix='t01'
elif(env=='preprod'):
    schema_prefix='r01'
elif(env=='prod'):
    schema_prefix='p01'
elif(env=='uat'):
    schema_prefix='u01'
else:
    LOGGER.info(f"\n Invalid Environment Passed - {env}, exit(1) \n")
    exit(1)

#---------------------------------------------------------------------------------#
load_table_list = etl_parms.get('load_table_list').strip().format(schema_prefix=schema_prefix).split("|")
resource_folder_name = etl_parms.get('resource_folder_name').strip()

#---------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------#
LOGGER.info(f"\n Environment - {env} \n")
LOGGER.info(f"\n Benchmark Type Name - {benchmark_type_name} \n")
LOGGER.info(f"\n EMR Template Path - {emr_template_path} \n")
LOGGER.info(f"\n EMR Job Arguments Path - {emr_job_args_path} \n")
LOGGER.info(f"\n EMR Config Name - {emr_config_name} \n")
LOGGER.info(f"\n Bench Type Code - {bnch_type_cd} \n")
LOGGER.info(f"\n Time Period List - {timeperiod_list} \n")
LOGGER.info(f"\n Intermediate Table Path - {intermediate_table_path} \n")
LOGGER.info(f"\n Conf File Name - {conf_file_name} \n")
LOGGER.info(f"\n Load Table List - {load_table_list} \n")
LOGGER.info(f"\n Resource Folder Name - {resource_folder_name} \n")
#---------------------------------------------------------------------------------#
# Function to read an object in S3                                                #
#---------------------------------------------------------------------------------#
def read_s3_object(s3_path):
    """
    Function to read s3 config path for job processing
    :param s3_path: path to read the s3 file.
    :return: object 
    """
    s3 = boto3.resource('s3')
    bucket = s3_path.split("//")[1].split("/")[0]
    key = "/".join(s3_path.replace("//", "").split("/")[1:])
    
    LOGGER.info("\n Reading s3 object {} \n".format(s3_path))
    obj = s3.Object(bucket, key)
    
    return obj
#---------------------------------------------------------------------------------#
#Fucntion to Upload an object to S3                                               #
#---------------------------------------------------------------------------------#
def upload_s3_object(s3_path, data):
    """
    Function to upload file to s3
    :param bucket_name: Bucket name for s3 upload
    :param object_key: key name for s3 upload
    :param table_nm: Table name for s3 upload
    :return: None
    """
    
    s3 = boto3.resource('s3')
    bucket = s3_path.split("//")[1].split("/")[0]
    key = "/".join(s3_path.replace("//", "").split("/")[1:])
    obj = s3.Object(bucket, key)
    
    LOGGER.info("\n Uploading s3 object {} \n".format(s3_path))
    obj.put(Body=data)
    
    return
#---------------------------------------------------------------------------------#
#Generating parameters for EMR Async                                              #
#---------------------------------------------------------------------------------#  
def emrConfigParameters(env, json_frmt, job_args, table, benchmark_type_name, create_cluster, emr_config_name, terminate_cluster):
    
    json_frmt['clusternm'] = benchmark_type_name
    json_frmt['configfile'] = emr_config_name
    json_frmt['jobargs'][0]['jobname'] = table
    json_frmt['jobargs'][0]['job'] = job_args.format(env=env).split(" ")
    json_frmt['emrenv'] = env
    json_frmt['createcluster'] = create_cluster
    json_frmt['terminateoption'] = terminate_cluster
    json_frmt['logpath'] = json_frmt['logpath'].format(env=env)
                    
    return json_frmt
#---------------------------------------------------------------------------------#
#Class to get the Account Number                                                  #
#---------------------------------------------------------------------------------#
class acc_info:
    sts_function_client=boto3.client('sts')
    def __init__(self):
        acc_details=acc_info.sts_function_client.get_caller_identity()
        self.account=acc_details['Account']
    @property
    def get_account(self):
        return self.account
#---------------------------------------------------------------------------------#
#Function to Invoke EMR Async                                                     #
#---------------------------------------------------------------------------------#        
def callingEMRAsync(LOGGER, env, sfn_json):
    """
    Function to start the Step Function state machine with JSON input
    :param LOGGER: basic log object
    :param env: environment (dev, sit, prod)
    :param region_name: region on aws (us-east-1)
    :param account: aws account number
    :param account_name: aws account name (edl)
    :param sfn: Step functions client
    :param sfn_json: JSON Input for state machine
    :return:
    """

    load_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S').replace('-', '').replace(' ', '-').replace(':', '')
    execution_name = f"CII-RunDt-{load_time}"[:100]
    region_name = os.environ['AWS_DEFAULT_REGION']
    account = acc_info().get_account

    sfn_json = json.dumps(sfn_json)

    # Create Step Function Execution with ARN, Custom Name and Config JSON
    sfn_arn = 'arn:aws:states:' + region_name + ':' + account \
              + ':stateMachine:ANTM-' + 'EDL' + '-' + env + '-Sfn-InvokeEMRAsync'

    try:
        LOGGER.info('\n *** Call Step Function with the following inputs: %s *** \n',
                    sfn_json)
        response = sfn.start_execution(stateMachineArn=sfn_arn,
                                       name=execution_name,
                                       input=sfn_json)
        execution_arn = response.get("executionArn")
        LOGGER.info(f'\n *** Step Function Response ARN: {response.get("executionArn")} \n')
        LOGGER.info(f"\n *** Step Function Execution Name: {execution_name} \n")
        return execution_arn
    except ClientError as sfn_exception:
        LOGGER.critical('\n *** SFN Exception occured: %s \n', sfn_exception)
        LOGGER.critical('\n *** Failed to create SFN *** \n')
        raise sfn_exception
#---------------------------------------------------------------------------------#
#Function to check the Status of the job in EMR Async                             #
#---------------------------------------------------------------------------------#
def checkStatusEMRAsync(executionArn):
	  #Function to check the status of the EMRAsync Excution using executionARN
	  response = sfn.describe_execution(executionArn=executionArn)
	  status = response['status']
	  
	  if(status=='RUNNING'):
	  	LOGGER.info(f'\n Status of the Step Function - {status} \n')
	  	import time
	  	LOGGER.info(f'\n Waiting for 60 Seconds \n')
	  	time.sleep(60)
	  	status=checkStatusEMRAsync(executionArn)
	  elif(status=="SUCCEEDED"):
	    LOGGER.info(f'\n Status of the Step Function - {status} \n')
	  elif(status=="FAILED"):
	    LOGGER.info(f'\n Status of the Step Function - {status} \n')
	  else:
	    LOGGER.info(f'\n Status of the Step Function - {status} \n')
	  
	  
	  return status
#---------------------------------------------------------------------------------#
# Function to Create EMR Cluster                                                  #
#---------------------------------------------------------------------------------#
def createEMRCluster(LOGGER, env, json_tmplt, dummy_job_args, table, benchmark_type_name, create_cluster, emr_config_name, terminate_cluster):
    emr_job_param={}
    emr_job_param['etl_stp_parms']=emrConfigParameters(env, json_tmplt, dummy_job_args, table, benchmark_type_name, create_cluster, emr_config_name, terminate_cluster)
    LOGGER.info(f"\n EMR Async Input Configuration - {emr_job_param} \n")
    executionArn=callingEMRAsync(LOGGER, env, emr_job_param)
    LOGGER.info(f"\n Chekcing the Status of the Cluster Creation \n")
    status=checkStatusEMRAsync(executionArn)
    LOGGER.info(f'\n Status of the Step Function - {status} \n')
    if(status=="SUCCEEDED"):
    	LOGGER.info(f"\n Cluster Created \n")
    else:
    	LOGGER.info(f"\n Cluster Creation Failed \n")
    	exit(1)
    	
#---------------------------------------------------------------------------------#
# Function to Terminate EMR Cluster                                               #
#---------------------------------------------------------------------------------#
def terminateEMRCluster(LOGGER, env, json_tmplt, dummy_job_args, table, benchmark_type_name, create_cluster, emr_config_name, terminate_cluster):
    emr_job_param={}
    emr_job_param['etl_stp_parms']=emrConfigParameters(env, json_tmplt, dummy_job_args, table, benchmark_type_name, create_cluster, emr_config_name, terminate_cluster)
    LOGGER.info(f"\n EMR Async Input Configuration - {emr_job_param} \n")
    executionArn=callingEMRAsync(LOGGER, env, emr_job_param)
    LOGGER.info(f"\n Chekcing the Status of the Cluster Termination \n")
    status=checkStatusEMRAsync(executionArn)
    LOGGER.info(f'\n Status of the Step Function - {status} \n')
    if(status=="SUCCEEDED"):
    	LOGGER.info(f"\n Cluster Terminated \n")
    else:
    	LOGGER.info(f"\n Cluster Termination Failed \n")
    	exit(1)
    	

#---------------------------------------------------------------------------------#
# Function to Send SNS for Success                                                #
#---------------------------------------------------------------------------------#
def snsPublication(LOGGER, subject, message):
    region_name = os.environ['AWS_DEFAULT_REGION']
    account = acc_info().get_account
    sns_arn = 'arn:aws:sns:' \
              + region_name + ':' \
              + account + ':{env}-snsCIIPublication'.format(env=env)
    subject = subject
    LOGGER.info('SNS ARN: %s', sns_arn)
    try:
        formatted_msg = message
        response = sns.publish(TargetArn=sns_arn,
                              Message=formatted_msg,
                              Subject=subject,
                              MessageStructure='string'
                              )
                               
        LOGGER.info('SNS Response: %s', response)
    except ClientError as sns_error:
        LOGGER.critical('*** SNS Message Publication Failed: %s ***', sns_error)
        raise sns_error
    	

#---------------------------------------------------------------------------------#
# Function to Send SNS for Failure                                                #
#---------------------------------------------------------------------------------#
def snsNotification(LOGGER, subject, message):
    region_name = os.environ['AWS_DEFAULT_REGION']
    account = acc_info().get_account
    sns_arn = 'arn:aws:sns:' \
              + region_name + ':' \
              + account + ':{env}-snsCIINotification'.format(env=env)
    subject = subject
    LOGGER.info('SNS ARN: %s', sns_arn)
    try:
        formatted_msg = message
        response = sns.publish(TargetArn=sns_arn,
                              Message=formatted_msg,
                              Subject=subject,
                              MessageStructure='string'
                              )
                               
        LOGGER.info('SNS Response: %s', response)
    except ClientError as sns_error:
        LOGGER.critical('*** SNS Message Notification Failed: %s ***', sns_error)
        raise sns_error
    	

#---------------------------------------------------------------------------------#
#                      Business Logic                                             #
#---------------------------------------------------------------------------------#	
try:
    #create spark session
    create_cluster='YES'
    spark = SparkSession.builder.appName("ETL").config("spark.sql.catalogImplementation", "hive").config("hive.metastore.connect.retries", 15).config("hive.metastore.client.factory.class", "com.amazonaws.glue.catalog.metastore.AWSGlueDataCatalogHiveClientFactory").enableHiveSupport().getOrCreate()
    
    spark.sparkContext._jsc.hadoopConfiguration().set("mapred.output.committer.class", "org.apache.hadoop.mapred.FileOutputCommitter")
    glueContext = GlueContext(spark)
    
    # Read the EMR job template from s3.
    job_tmplt_obj = read_s3_object(emr_template_path)
    json_tmplt = json.loads(job_tmplt_obj.get()['Body'].read().decode('utf-8'))
    # Read the EMR job Arguments from s3.
    job_args_obj = read_s3_object(emr_job_args_path)
    input_job_args = job_args_obj.get()['Body'].read().decode('utf-8')
    LOGGER.info(f"\n Given Input Job Arguments - {input_job_args} \n")
    #input_job_args="/usr/bin/spark-submit --class com.anthem.etl.cii.ETLSFDriver --master yarn --deploy-mode cluster --driver-memory 4G --executor-memory 26G --executor-cores 4 --conf spark.executor.memoryOverhead=2GB --conf spark.dynamicAllocation.enabled=true --conf spark.dynamicAllocation.initialExecutors=10 --conf spark.serializer=org.apache.spark.serializer.KryoSerializer --conf spark.default.parallelism=500 --conf spark.sql.shuffle.partitions=500 --conf spark.memory.offHeap.enabled=true --conf spark.memory.offHeap.size=1G --conf spark.yarn.maxAppAttempts=1 s3://antm-cii-{env}-codez-nogbd-nophi-useast1/etl/cii/jar/target/cii-etl-emr-1.0.jar {conf_file_name} CII-SF-EMR-Loads loadTables={load_table_name} {resource_folder_name}"
    dummy_job_args="/usr/bin/spark-submit s3://antm-cii-{env}-codez-nogbd-nophi-useast1/cii/config/cii_dummy.py --driver-memory 26G --executor-cores 4 --conf spark.dynamicAllocation.enabled=true --conf spark.shuffle.service.enabled=true"
    data={}
    data['status']="SUCCEEDED"
    bucket = emr_template_path.split("//")[1].split("/")[0]
    key = "/".join(emr_template_path.replace("//", "").split("/")[1:-1])


#---------------------------------------------------------------------------------#
#Running the Spark job for each bnch_type and time_period and table               #
#---------------------------------------------------------------------------------#
    for bnch_type in bnch_type_cd:
    	# Checking for the existence of Done file for bnch_type #
    	result1 = os.system(f"aws s3 ls s3://{bucket}/{key}/benchmark/{bnch_type}_{benchmark_type_name}.done")
    	if(result1 != 0):
    		LOGGER.info(f"\n The Done file - s3://{bucket}/{key}/benchmark/{bnch_type}_{benchmark_type_name}.done Not Exits-result1 - {result1} \n")
    		for time_period in timeperiod_list:
    			input_data = spark.sql(f"SELECT cast('{time_period}' as int) as bnchmrk_mnth_nbr,cast(date_format(add_months(FROM_UNIXTIME(UNIX_TIMESTAMP( CAST(concat('{time_period}','01') AS STRING) ,'yyyyMMdd'), 'yyyy-MM-dd'),-11),'yyyyMM') as int) as  bnchmrk_tm_prd,12 as bnchmrk_mnths_cnt,'{bnch_type}' as bnchmrk_type_cd,'{load_log_key}' as load_log_key,current_timestamp() as load_dtm")
    			#input_data.write.mode("overwrite").parquet(intermediate_table_path)
    			input_data.write.format('parquet').mode('overwrite').save(intermediate_table_path)
	        # Checking for the existence of Done file for bnch_type and time_period #
    			result2 = os.system(f"aws s3 ls s3://{bucket}/{key}/benchmark/{time_period}_{bnch_type}_{benchmark_type_name}.done")
    			if(result2 != 0):
    				LOGGER.info(f"\n The Done file - s3://{bucket}/{key}/benchmark/{time_period}_{bnch_type}_{benchmark_type_name}.done Not Exits-result2 - {result2} \n")
    				for table in load_table_list:
    					# Checking for the existence of Done file for bnch_type and time_period and table#
    					result3 = os.system(f"aws s3 ls s3://{bucket}/{key}/benchmark/{table}_{time_period}_{bnch_type}_{benchmark_type_name}.done")
    					if(result3 != 0):
    						LOGGER.info(f"\n The Done file - s3://{bucket}/{key}/benchmark/{table}_{time_period}_{bnch_type}_{benchmark_type_name}.done Not Exits-result3 - {result3} \n")
    						#           Calling Create EMR Cluster Fucntion One Time                                  #
    						if(create_cluster=='YES'):
    						    LOGGER.info(f"\n Calling Create EMR Cluster Fucntion One Time \n")
    						    createEMRCluster(LOGGER, env, json_tmplt, dummy_job_args, 'dummy_job', benchmark_type_name, create_cluster, emr_config_name, 'NO')
    						    create_cluster='NO'
    						    
    						job_args=input_job_args.format(env=env, conf_file_name=conf_file_name, load_table_name=table, resource_folder_name=resource_folder_name)
    						emr_job_param={}
    						emr_job_param['etl_stp_parms']=emrConfigParameters(env, json_tmplt, job_args, table + '_' + time_period + '_' + bnch_type, benchmark_type_name, 'NO', emr_config_name, 'NO')
    						executionArn=callingEMRAsync(LOGGER, env, emr_job_param)
    						#Checking the status of the EMR Async Job
    						LOGGER.info(f"\n Checking the status of the EMR Async Job for Table - {table}, Time Period - {time_period} , Benchmark Type - {bnch_type} \n")
    						status=checkStatusEMRAsync(executionArn)
    						if(status=="SUCCEEDED"):
    							LOGGER.info(f"\n For the Table - {table}, the Time Period - {time_period} for Bench Type Code - {bnch_type} is loaded successfully \n")
    							# Creating done file for table, time_period and bnch_type#
    							done_file_path = "s3://" + bucket + "/" + key + "/benchmark/" + f"{table}_{time_period}_{bnch_type}_{benchmark_type_name}.done"
    							upload_s3_object(done_file_path, json.dumps(data))
    							snsPublication(LOGGER, f'SUCCEEDED-{benchmark_type_name}', f"\n For the Table - {table}, the Time Period - {time_period} for Bench Type Code - {bnch_type} is loaded successfully \n")
    						else:
    							LOGGER.info(f"\n For the Table - {table}, the Time Period - {time_period} for Bench Type Code - {bnch_type} is Failed/TimedOut/Aborted, Please check the logs. \n")
    							#Terminating the Cluster
    							LOGGER.info(f"\n Calling Terminate EMR Cluster and exit(1) \n")
    							snsNotification(LOGGER, f"Failed-{benchmark_type_name}", f"\n For the Table - {table}, the Time Period - {time_period} for Bench Type Code - {bnch_type} is Failed/TimedOut/Aborted, Please check the logs. Terminating the Cluster and exit(1)\n")
    							terminateEMRCluster(LOGGER, env, json_tmplt, dummy_job_args, 'dummy_job', benchmark_type_name, 'NO', emr_config_name, 'YES')
    							exit(1)
    					else:
    						LOGGER.info(f"\n For the Table - {table}, the Time Period - {time_period} for Bench Type Code - {bnch_type} is already loaded \n")
    				# Creating done file for time_period and bnch_type#
    				done_file_path = "s3://" + bucket + "/" + key + "/benchmark/" + f"{time_period}_{bnch_type}_{benchmark_type_name}.done"
    				upload_s3_object(done_file_path, json.dumps(data))
    			else:
    				LOGGER.info(f"\n The Time Period - {time_period} for Bench Type Code - {bnch_type} is already loaded \n")
    		# Creating done file for bnch_type#
    		done_file_path = "s3://" + bucket + "/" + key + "/benchmark/" + f"{bnch_type}_{benchmark_type_name}.done"
    		upload_s3_object(done_file_path, json.dumps(data))
    	else:
    		LOGGER.info(f"Bench Mark Type Code - {bnch_type} is already loaded \n")
    		
#---------------------------------------------------------------------------------#
#                    Removing the Done Files                                      #
#---------------------------------------------------------------------------------#
    for bnch_type in bnch_type_cd:
        for time_period in timeperiod_list:
            for table in load_table_list:
                # Removing done file for table, time_period and bnch_type#
                done_file_path = "s3://" + bucket + "/" + key + "/benchmark/" + f"{table}_{time_period}_{bnch_type}_{benchmark_type_name}.done"
                os.system('aws s3 rm ' + done_file_path)
            # Removing done file for time_period and bnch_type#
            done_file_path = "s3://" + bucket + "/" + key + "/benchmark/" + f"{time_period}_{bnch_type}_{benchmark_type_name}.done"
            os.system('aws s3 rm ' + done_file_path)
        # Removing done file for tbnch_type#
        done_file_path = "s3://" + bucket + "/" + key + "/benchmark/" + f"{bnch_type}_{benchmark_type_name}.done"
        os.system('aws s3 rm ' + done_file_path)
    	

#---------------------------------------------------------------------------------#
#                           Terminating Cluster                                   #
#---------------------------------------------------------------------------------#
    #Terminating Cluster
    if(create_cluster=='NO'):
        LOGGER.info(f"\n Calling Terminate EMR Cluster during normal Execution \n")
        terminateEMRCluster(LOGGER, env, json_tmplt, dummy_job_args, 'dummy_job', benchmark_type_name, 'NO', emr_config_name, 'YES')
    else:
        LOGGER.info(f"\n Cluster Termination is not Required as the Cluster is not Created in this Run \n")
#---------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------#    		  
except Exception as e:
    #Terminating Cluster
    if(create_cluster=='NO'):
        LOGGER.info(f"\n Calling Terminate EMR Cluster during normal Exception \n")
        terminateEMRCluster(LOGGER, env, json_tmplt, dummy_job_args, 'dummy_job', benchmark_type_name, 'NO', emr_config_name, 'YES')
    else:
        LOGGER.info(f"\n Cluster Termination is not Required as the Cluster is not Created in this Run \n")
    raise e