############################################################################################################## 
# Description   : Glue job to load the Data from Snowflake to RDS
# Author        : Legato
# Created       : 02-25-2022 
# Version       : V1.0
# Version Description : Initial Version
# last Updated  : ##-###-####
############################################################################################################## 

"""
DOCSTRING : Glue job to load the Data from Snowflake to RDS
"""
## This script requires parameters such as aplctn_cd, snowflake_env,warehouse_size_suffix and env

import re
import snowflake.connector as sf
# from snowflake.connector import DictCursor
from awsglue.utils import getResolvedOptions
from ReduceReuseRecycle import *
from ReduceReuseRecycle.snowflakefunc import *
from awsglue.utils import getResolvedOptions
from boto_wrapper import sfs,acc_info,secretkey
import logging
import json
import sys
import os
import boto3
import base64
from datetime import date, time
from botocore.exceptions import ClientError
import psycopg2
#Import common Modules
import os
import sys
import json
import boto3
import uuid
import pandas as pd
from datetime import *
from awsglue.utils import getResolvedOptions
from botocore.exceptions import ClientError
from ReduceReuseRecycle import load_log_config, InvalidStatus

#---------------------------------------------------------------------------------#
# Creating boto3 client for glue, stepfuntion, s3, sns                            #
#---------------------------------------------------------------------------------#
glue = boto3.client('glue')
client = boto3.client('s3')
sns = boto3.client('sns')
sfn = boto3.client('stepfunctions')
LOGGER = load_log_config(glue=True)
#---------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------#
LOGGER.info("Reading Glue Job Parameters... \n")

# Parse Arguments for Glue Job

# Define mandatory params
params = ['etl_stp_parms', 'etl_sfn_parms']
 
# Parse Arguments for Glue Job
ARGS = getResolvedOptions(sys.argv, params)
                                    
#set Variables
etl_parms = json.loads(ARGS['etl_stp_parms'])
etl_sfn_parms = json.loads(ARGS['etl_sfn_parms'])
#Input Parameters Passed/Needed
ENV = etl_parms.get('env').strip().lower()
aplctn_cd = etl_parms.get('aplctn_cd').strip().lower()
db_config_path = etl_parms.get('db_config_path').strip()
snowflake_rds_details_path = etl_parms.get('snowflake_rds_details_path').strip()
target_rds_database_table_name = etl_parms.get('target_rds_database_table_name').strip()
delete_target_rds_table = etl_parms.get('delete_target_rds_table').strip().upper()
#delete_target_rds_table_query = etl_parms.get('delete_target_rds_table_query').strip()
swap_target_rds_table = etl_parms.get('swap_target_rds_table').strip().upper()
get_info_snowflake_table = etl_parms.get('get_info_snowflake_table', 'NA').strip().upper()
get_info_snowflake_table_query = etl_parms.get('get_info_snowflake_table_query', 'NA').strip()
check_on_target_rds_table = etl_parms.get('check_on_target_rds_table', 'NA').strip().upper()
check_on_target_rds_table_query = etl_parms.get('check_on_target_rds_table_query', 'NA').strip()
parms = etl_parms.get('parms')
REGION_NAME = 'us-east-1'
load_log_key = uuid.uuid1()
APLCTN_CD = aplctn_cd
WAREHOUSE_SIZE_SUFFIX = ''
LOGGER.info(f'\n**** Argument List ****\n-----------------------')
LOGGER.info(f'\nREGION_NAME : {REGION_NAME} \nENV : {ENV} \nAPLCTN_CD : {APLCTN_CD} \nsnowflake_rds_details_path : {snowflake_rds_details_path} '
            f'\ntarget_rds_database_table_name : {target_rds_database_table_name} \ndelete_target_rds_table : {delete_target_rds_table} '
            f'\nswap_target_rds_table : {swap_target_rds_table} '
            f'\nWAREHOUSE_SIZE_SUFFIX : {WAREHOUSE_SIZE_SUFFIX}'
            f'\nparms : {parms}'
            f'\netl_sfn_parms : {etl_sfn_parms} \nget_info_snowflake_table: {get_info_snowflake_table}'
            f'\nget_info_snowflake_table : {get_info_snowflake_table} \nget_info_snowflake_table_query: {get_info_snowflake_table_query}'
            f'\ncheck_on_target_rds_table_query : {check_on_target_rds_table_query}')

# Fetch the SECRET Instance based on Application Code
SECRET = get_secret(LOGGER, ENV, REGION_NAME, f"/snowflake/{APLCTN_CD}")

SECRET_JSON = json.loads(SECRET)
#-------------------------------------------------------------------------------------------------------------------#
# Function to Load Table from Snowflake to RDS and also Delete data in Target RDS Table if Needed
#-------------------------------------------------------------------------------------------------------------------#
def snowflake_to_rds_load_data(LOGGER, cursor, conn_rds, source_snowflake_query_to_run, target_rds_database_table_name, delete_target_rds_table, delete_target_rds_table_query, swap_target_rds_table, get_info_snowflake_table, check_on_target_rds_table):
    try:
        if(get_info_snowflake_table == 'YES'):
            LOGGER.info(f'*** Executing the Snowflake Query:{get_info_snowflake_table_query} ***')
            cursor.execute(get_info_snowflake_table_query)
            get_info_snowflake_rslt = cursor.fetchone()[0]
            LOGGER.info(f'*** Value Recived from Snowflake:get_info_snowflake_rslt:{get_info_snowflake_rslt} ***')
        LOGGER.info(f'*** Executing the Snowflake Query:{source_snowflake_query_to_run} ***')
        cursor.execute(source_snowflake_query_to_run)
        flag=True
        count=0
        if(delete_target_rds_table == 'YES'):
            LOGGER.info(f'*** Executing the Delete Queryon RDS for Target Data Deletion:' + str(delete_target_rds_table_query.replace("${get_info_snowflake_rslt}", str(get_info_snowflake_rslt))) )
            cursor_rds.execute( delete_target_rds_table_query.replace("${get_info_snowflake_rslt}", str(get_info_snowflake_rslt)) )
            del_result = cursor_rds.statusmessage
            LOGGER.info(f'*** Result of Delete SQL - {del_result} ***')
        if(check_on_target_rds_table == 'YES'):
            LOGGER.info(f'*** check_on_target_rds_table Query#:***' + str(check_on_target_rds_table_query.replace("${get_info_snowflake_rslt}", str(get_info_snowflake_rslt))) )
            cursor_rds.execute(check_on_target_rds_table_query.replace("${get_info_snowflake_rslt}", str(get_info_snowflake_rslt)))
            result_rds_rpt = cursor_rds.fetchone()[0]
            LOGGER.info(f'*** check_on_target_rds_table - result_rds_rpt - {result_rds_rpt} ***')
        while flag:
            final_result = cursor.fetchmany(10000)
            final_result1 = ""
            if len(final_result) > 0:
                fectch_count = len(final_result)
                count = count + 1
                LOGGER.info(f'*** Number of Records in the fetch#:{count} and Count - {fectch_count} ***')
                for data in final_result:
                    final_result1 = final_result1 + "," + str(data)
                    final_result2 = final_result1[1:]
                    #LOGGER.info(f'*** Number of Records in the fetch: {final_result2} ***')
                if( result_rds_rpt == 1 ):
                    cursor_rds.execute("INSERT INTO " + target_rds_database_table_name + " values " + final_result2 )
                    LOGGER.info(f'*** Records Insert Happened: result_rds_rpt - {result_rds_rpt}, check_on_target_rds_table - {check_on_target_rds_table} ***')
                else:
                    LOGGER.info(f'*** Records Insert Not Happened: result_rds_rpt - {result_rds_rpt} ***')
                if(check_on_target_rds_table != 'YES'):
                    cursor_rds.execute("INSERT INTO " + target_rds_database_table_name + " values " + final_result2 )
                    LOGGER.info(f'*** Records Insert Happened:fectch_count - {fectch_count}, check_on_target_rds_table - {check_on_target_rds_table}  ***')
            else:
                flag=False
        LOGGER.info(f'*** Executing the commit on RDS  ***')
        conn_rds.commit()
        if(swap_target_rds_table == 'YES'):
            table_name_with_a = target_rds_database_table_name.split(".")[1]
            table_name = target_rds_database_table_name.split(".")[1][:-2]
            database_name = target_rds_database_table_name.split(".")[0]
            table_name_with_b = table_name + "_b"
            LOGGER.info(f'*** Swapping RDS Table from - {target_rds_database_table_name}, to Original Table and Vice Versa ***')
            cursor_rds.execute("ALTER TABLE " + target_rds_database_table_name + " RENAME TO " + table_name_with_b)
            cursor_rds.execute("ALTER TABLE " + database_name + "." + table_name + " RENAME TO " + table_name_with_a)
            cursor_rds.execute("ALTER TABLE " + database_name + "." + table_name_with_b + " RENAME TO " + table_name)
            conn_rds.commit()
        cursor.close()
    except Exception as err:
        LOGGER.critical('*** ERROR: While executing the query on Snowflake/RDS***')
        LOGGER.critical('*** ERROR: %s ***', err)
        raise err
#---------------------------------------------------------------------------------#
#Class to get the Account Number                                                  #
#---------------------------------------------------------------------------------#
class acc_info:
    sts_function_client=boto3.client('sts')
    def __init__(self):
        acc_details=acc_info.sts_function_client.get_caller_identity()
        self.account=acc_details['Account']
    @property
    def get_account(self):
        return self.account

def get_secret(secret_name):
    """
    Function to fetch details from AWS Secrets Manager
    Usage   : Get Secret JSON String
    Args    : Secret Name
    Returns : Secure string of Secret
    Raises  : Exception While getting the Secret.
    
    """
    secret = ''
    secret_client = boto3.client("secretsmanager")

    try:
        get_secret_value_response = secret_client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as error:
        if error.response['Error']['Code'] == 'DecryptionFailureException':
            raise error
        elif error.response['Error']['Code'] == 'InternalServiceErrorException':
            raise error
        elif error.response['Error']['Code'] == 'InvalidParameterException':
            raise error
        elif error.response['Error']['Code'] == 'InvalidRequestException':
            raise error
        elif error.response['Error']['Code'] == 'ResourceNotFoundException':
            raise error
    else:
        if 'SecretString' in get_secret_value_response:
            secret = get_secret_value_response['SecretString']
            return secret
        else:
            decoded_binary_secret = base64.b64decode(
                get_secret_value_response['SecretBinary'])
            return decoded_binary_secret


def rds_conn(LOGGER, host_name, secret_name, port_no, schema_name):
    """
    Function to use Secrets Manager to create an RDS Connection Object
    :param host_name: Host name of the RDS
    :param secret_name: secret name for fetching user password
    :param port_no: Port Number of RDS
    :param schema_name: Schema Name in RDS
    :return: RDS Connection Object
    """
    try:
        secure_string   = get_secret(secret_name)
        secure_dict     = json.loads(secure_string)
        postgre_username  = secure_dict.get('username')
        postgre_password  = secure_dict.get('password')
        engine = psycopg2.connect(
                database=schema_name,
                user=postgre_username,
                password=postgre_password,
                host=host_name,
                port=port_no
            )
    except Exception as err:
        LOGGER.critical("ERROR: Unexpected error: Could not connect to Aurora instance.")
        LOGGER.critical('*** ERROR: %s ***', err)
        raise err

    return engine

def _read_s3_object(s3_path):
    """
    Function to read object from s3 path
    :param s3_path: S3 object full path
    :return: object
    """
    s3 = boto3.resource('s3')
    bucket = s3_path.split("//")[1].split("/")[0]
    key = "/".join(s3_path.replace("//", "").split("/")[1:])
    
    LOGGER.info("Reading S3 obj {}".format(s3_path))
    obj = s3.Object(bucket, key)
    
    return obj
#---------------------------------------------------------------------------------#
#                      Business Logic                                             #
#---------------------------------------------------------------------------------#	
# Create SQL Cursor from Function 'snowflake_conn'
    
try:
    LOGGER.info('*** Creating Snowflake and RDS Connection & Cursor ***')
    # Reads the configuration File from S3
    json_obj = _read_s3_object(db_config_path)
    config = json.loads(json_obj.get()['Body'].read().decode('utf-8'))
    #Reading Snowflake RDS Details
    json_obj = _read_s3_object(snowflake_rds_details_path)
    snowflake_rds_details = json.loads(json_obj.get()['Body'].read().decode('utf-8'))
    source_snowflake_query_to_run = snowflake_rds_details['source_snowflake_query_to_run']['query']
    delete_target_rds_table_query = snowflake_rds_details['delete_target_rds_table_query']['query']
    LOGGER.info(f'Input Snowflake Query - {source_snowflake_query_to_run} \nInput Delete RDS Query - {delete_target_rds_table_query}')
    
    # Getting RDS connection Details from configuration file
    databaseName = config['database_details']['database']
    schema_name = config['database_details']['schema']
    host = config['database_details']['host']
    port = config['database_details']['port']
    secret_name = config['database_details']['secret_name']
    preval_databaseName = config['database_details']['preval_database']
    # Find all parameters used in sql query that needs to be substituted from etl_sfn_parms.
    sql_vars_1 = set(re.findall(r'\$\{([\w]+?)\}', source_snowflake_query_to_run))
    etl_sfn_parms_json = etl_sfn_parms
    if etl_sfn_parms_json:
        for key in sql_vars_1:
            try:
                LOGGER.info(f'sql_vars_1:Parameter to be replaced in the script: ${{{key}}}')
                LOGGER.info(f'sql_vars_1:Parameter Value to be replaced with in the script: {etl_sfn_parms_json[key]}')
                source_snowflake_query_to_run = source_snowflake_query_to_run.replace(f'${{{key}}}', etl_sfn_parms_json[key])
            except KeyError as ke:
                LOGGER.info(f"sql_vars_1:Replace key not found in sfn params ${{{key}}}")
    sql_vars_2 = set(re.findall(r'\$\{([\w]+?)\}', delete_target_rds_table_query))
    etl_sfn_parms_json = etl_sfn_parms
    if etl_sfn_parms_json:
        for key in sql_vars_2:
            try:
                LOGGER.info(f'sql_vars_2:Parameter to be replaced in the script: ${{{key}}}')
                LOGGER.info(f'sql_vars_2:Parameter Value to be replaced with in the script: {etl_sfn_parms_json[key]}')
                delete_target_rds_table_query = delete_target_rds_table_query.replace(f'${{{key}}}', etl_sfn_parms_json[key])
            except KeyError as ke:
                LOGGER.info(f"sql_vars_2:Replace key not found in sfn params ${{{key}}}")
    # Find all parameters used in sql query that needs to be substituted from parms.
    sql_vars1 = set(re.findall(r'\$\{([\w]+?)\}', source_snowflake_query_to_run))
    # Look up the parms for parameters used in SQL and substitute it with value found in parms.
    LOGGER.info('*** sql_vars1:Substituting parameters passed through parms in SQL Files ***\n')
    if parms:
        for key in sql_vars1:
            if key not in parms.keys():
                LOGGER.error(f'*** sql_vars1:Error: Cannot substitute  variable \'{key}\' in the sql script as it is not found in parms. ')
                raise InvalidStatus(f"sql_vars1:Parameter not found in parms")
            else:
                LOGGER.info(f'sql_vars1:Parameter to be replaced in the script: ${{{key}}}')
                LOGGER.info(f'sql_vars1:Parameter Value to be replaced with in the script: {parms[key]}')
                source_snowflake_query_to_run = source_snowflake_query_to_run.replace(f'${{{key}}}', parms[key])
    # Find all parameters used in sql query that needs to be substituted from parms.
    sql_vars2 = set(re.findall(r'\$\{([\w]+?)\}', delete_target_rds_table_query))
    # Look up the parms for parameters used in SQL and substitute it with value found in parms.
    LOGGER.info('*** sql_vars2:Substituting parameters passed through parms in SQL Files ***\n')
    if parms:
        for key in sql_vars2:
            if ( key not in parms.keys() and (key not in 'get_info_snowflake_rslt') ):
                LOGGER.error(f'*** sql_vars2:Error: Cannot substitute  variable \'{key}\' in the sql script as it is not found in parms. ')
                raise InvalidStatus(f"sql_vars2:Parameter not found in parms")
            else:
                if ( (key not in 'get_info_snowflake_rslt') ):
                    LOGGER.info(f'sql_vars2:Parameter to be replaced in the script: ${{{key}}}')
                    LOGGER.info(f'sql_vars2:Parameter Value to be replaced with in the script: {parms[key]}')
                    delete_target_rds_table_query = delete_target_rds_table_query.replace(f'${{{key}}}', parms[key])
    # Find all parameters used in sql query when check_on_target_rds_table is 'YES'.
    if (check_on_target_rds_table == 'YES'):
        sql_vars_3 = set(re.findall(r'\$\{([\w]+?)\}', check_on_target_rds_table_query))
        etl_sfn_parms_json = etl_sfn_parms
        if etl_sfn_parms_json:
            for key in sql_vars_3:
                try:
                    LOGGER.info(f'sql_vars_3:Parameter to be replaced in the script: ${{{key}}}')
                    LOGGER.info(f'sql_vars_3:Parameter Value to be replaced with in the script: {etl_sfn_parms_json[key]}')
                    check_on_target_rds_table_query = check_on_target_rds_table_query.replace(f'${{{key}}}', etl_sfn_parms_json[key])
                except KeyError as ke:
                    LOGGER.info(f"sql_vars_3:Replace key not found in sfn params ${{{key}}}")
        if parms:
            for key in sql_vars_3:
                if ( key not in parms.keys() and (key not in 'get_info_snowflake_rslt') ):
                    LOGGER.error(f'*** sql_vars_3:Error: Cannot substitute  variable \'{key}\' in the sql script as it is not found in parms. ')
                    raise InvalidStatus(f"sql_vars_3:Parameter not found in parms")
                else:
                    if ( (key not in 'get_info_snowflake_rslt') ):
                        LOGGER.info(f'sql_vars_3:Parameter to be replaced in the script: ${{{key}}}')
                        LOGGER.info(f'sql_vars_3:Parameter Value to be replaced with in the script: {parms[key]}')
                        check_on_target_rds_table_query = check_on_target_rds_table_query.replace(f'${{{key}}}', parms[key])
    # Creates RDS Connection Object and Cursor
    conn_rds = rds_conn(LOGGER, host, secret_name, port, schema_name)
    cursor_rds = conn_rds.cursor()
    LOGGER.info("Connection to RDS has been established, Cursor is created.")
    conn = snowflake_conn(logger=LOGGER, aplctn_cd=APLCTN_CD, secret=SECRET, warehouse_size_suffix=WAREHOUSE_SIZE_SUFFIX)
    cursor = conn.cursor()
    LOGGER.info('*** Created Snowflake Connection & Cursor ***')
    warehouse = SECRET_JSON.get(f'{APLCTN_CD}_warehouse')
    warehouse = warehouse + WAREHOUSE_SIZE_SUFFIX
    LOGGER.info(f'Based on warehouse size value passed as \'{WAREHOUSE_SIZE_SUFFIX}\', '
				f'warehouse \'{warehouse}\' is used for this session')
    LOGGER.info(f"*** Setting up the time format is: alter session set timestamp_output_format = 'YYYY-MM-DD HH24:MI:SS.FF'; ***")
    cursor.execute("alter session set timestamp_output_format = 'YYYY-MM-DD HH24:MI:SS.FF'")
    LOGGER.info(f"*** Calling Snowflake to RDS Load Data Function ***")
    snowflake_to_rds_load_data(LOGGER, cursor, conn_rds, source_snowflake_query_to_run, target_rds_database_table_name, delete_target_rds_table, delete_target_rds_table_query, swap_target_rds_table, get_info_snowflake_table, check_on_target_rds_table)
    LOGGER.info(f"*** Execution of Snowflake to RDS Load Data Function Completed Succesfully***")

except sf.DatabaseError as SnowflakeConnectionFailure:
	LOGGER.critical('*** CRITICAL: Cannot establish connection with Snowflake ***')
	LOGGER.critical(SnowflakeConnectionFailure)
	raise SnowflakeConnectionFailure
#---------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------#    		  
except Exception as e:
    #snsNotification(LOGGER, f'FAILED - Load - Data from Snowflake to RDS \n")
    raise e