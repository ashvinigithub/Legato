############################################################################################################## 
# Description   : Glue job to Process Standard Insights L#2 Reports for each Request/RPT_RUN_ID
# Author        : Legato
# Created       : 06/08/2022 
# Version       : V1.0
# Version Description : Initial Version
# last Updated  : ##-###-####
############################################################################################################## 
"""
DOCSTRING : Glue job to Process Standard Insights L#2 Reports for each Request/RPT_RUN_ID
"""
import re
from boto_wrapper import sfs,acc_info,secretkey
import logging
import json
import sys
import os
import boto3
import base64
from datetime import date, time
from botocore.exceptions import ClientError
import psycopg2
import uuid
import pandas as pd
from datetime import *
from awsglue.utils import getResolvedOptions
from botocore.exceptions import ClientError
from ReduceReuseRecycle import load_log_config, InvalidStatus
import sys
from awsglue.utils import getResolvedOptions
# Parse Arguments for Glue Job
params = ['etl_stp_parms']
# Parse Arguments for Glue Job
ARGS = getResolvedOptions(sys.argv, params)
#set Variables
etl_parms = json.loads(ARGS['etl_stp_parms'])
ENV = etl_parms.get('env').strip()
envn = ENV

from ReduceReuseRecycle import download_site_packages
download_site_packages(envn)

from ReduceReuseRecycle import *
from ReduceReuseRecycle.snowflakefunc import *
from ReduceReuseRecycle.pymysqlfunc import *
from ReduceReuseRecycle.psycopgfunc import *
#---------------------------------------------------------------------------------#
# Creating boto3 client for glue, stepfuntion, s3, sns                            #
#---------------------------------------------------------------------------------#
glue = boto3.client('glue')
client = boto3.client('s3')
sns = boto3.client('sns')
sfn = boto3.client('stepfunctions')
LOGGER = load_log_config(glue=True)
#-------------------------------------------------------------------------------------------------------------------#
# Function to Log Error in RDS Table - etl_evolve_job_hist, for a given RPT_RUN_ID
#-------------------------------------------------------------------------------------------------------------------#
def log_error_to_rds(LOGGER, conn_sf, cursor_sf, conn_rds, cursor_rds, rpt_run_id, rpt_strt_dtm, number_of_tries, rpt_stts, rpt_err_log, rqst_stts_txt):
    try:
        #Taking the current_timestamp for End time
        cursor_sf.execute("select current_timestamp")
        rpt_strt_dtm = str(cursor_sf.fetchone()[0])[:26]
        rpt_err_log = rpt_err_log.replace("'"," ")
        LOGGER.info(f'*** Executing the Query on RDS to log status/error details for rpt_run_id:{rpt_run_id} ***')
        query_to_log_error = f"""insert into aciisst_appl.etl_evolve_job_hist select {rpt_run_id} as rpt_run_id, '{rpt_strt_dtm}' as rpt_strt_dtm, current_timestamp as rpt_end_dtm, {number_of_tries} as number_of_tries, '{rpt_stts}' as rpt_stts, '{rpt_err_log}' as rpt_err_log, 88888 as creatd_by_user_id, 88888 as updtd_by_user_id, current_timestamp as creatd_dtm, current_timestamp as updtd_dtm"""
        LOGGER.info(f'*** Executing the Query on RDS to log status/error details :{query_to_log_error} ***')
        cursor_rds.execute(query_to_log_error)
        conn_rds.commit()
        #Updating status for given rpt_run_id in RDS table - aciisst_rpt_cstm_rqst
        query_to_update = f"update aciisst_appl.aciisst_rpt_cstm_rqst set rqst_stts_txt = '{rqst_stts_txt}', updtd_dtm = current_timestamp, updtd_by_user_id = 88888 where pkg_id = {rpt_run_id}"
        LOGGER.info(f'*** Executing the Query on RDS to log status of rpt_run_id :{rpt_run_id}, {query_to_update} ***')
        cursor_rds.execute(query_to_update)
        conn_rds.commit()
    except Exception as err:
        LOGGER.critical(f'*** ERROR: While trying to log status/error details to RDS - {query_to_log_error}***')
        LOGGER.critical('*** ERROR: %s ***', err)
        raise err
#-------------------------------------------------------------------------------------------------------------------#
# Function to Get the Needed Details from RDS for a given RPT_RUN_ID
#-------------------------------------------------------------------------------------------------------------------#
def l2_re_run_process_get_details_rds(LOGGER, conn_sf, cursor_sf, conn_rds, cursor_rds, rpt_strt_dtm, number_of_tries):
    try:
        query_to_run_rds = f"select rqst_temp.rpt_run_id, max(rqst_temp.number_of_tries) as number_of_tries, max(rqst_temp.re_run) as re_run from (select cast(max(rqst.pkg_id) as varchar) as rpt_run_id, case when max(hist.rpt_run_id) is not null then cast(max(hist.number_of_tries) as varchar) else '0' end as number_of_tries, 'YES' as re_run from aciisst_appl.aciisst_rpt_cstm_rqst rqst left join aciisst_appl.etl_evolve_job_hist hist on rqst.pkg_id = hist.rpt_run_id where upper(trim(rqst_stts_txt)) in ('NEW','RETRY') and rqst.trgr_ind = 'Y' and (hist.number_of_tries is null or hist.number_of_tries >= 0) group by rqst.pkg_id) rqst_temp where cast(number_of_tries as bigint) <= 2 group by rqst_temp.rpt_run_id"
        LOGGER.info(f'*** Executing the Query on RDS Tables -aciisst_rpt_cstm_rqst, etl_evolve_job_hist to Fetch request Details from RDS:{query_to_run_rds} ***')
        cursor_rds.execute(query_to_run_rds)
        l2_re_run_process_details = cursor_rds.fetchall()
        
        return l2_re_run_process_details
    except Exception as err:
        log_error_to_rds(LOGGER, conn_sf, cursor_sf, conn_rds, cursor_rds, -1, rpt_strt_dtm, number_of_tries, f'RETRY', "Glue:Job:StandardInsightsL2ReRun - Failed while trying process RETRY and Unprocessed NEW requests using tables - aciisst_rpt_cstm_rqst, etl_evolve_job_hist", "RETRY")
        LOGGER.critical('*** ERROR: While executing the query on RDS***')
        LOGGER.critical('*** ERROR: %s ***', err)
        raise err
#---------------------------------------------------------------------------------#
#Class to get the Account Number                                                  #
#---------------------------------------------------------------------------------#
class acc_info:
    sts_function_client=boto3.client('sts')
    def __init__(self):
        acc_details=acc_info.sts_function_client.get_caller_identity()
        self.account=acc_details['Account']
    @property
    def get_account(self):
        return self.account

def get_secret_rds(secret_name):
    """
    Function to fetch details from AWS Secrets Manager
    Usage   : Get Secret JSON String
    Args    : Secret Name
    Returns : Secure string of Secret
    Raises  : Exception While getting the Secret.
    
    """
    secret = ''
    secret_client = boto3.client("secretsmanager")

    try:
        get_secret_value_response = secret_client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as error:
        if error.response['Error']['Code'] == 'DecryptionFailureException':
            raise error
        elif error.response['Error']['Code'] == 'InternalServiceErrorException':
            raise error
        elif error.response['Error']['Code'] == 'InvalidParameterException':
            raise error
        elif error.response['Error']['Code'] == 'InvalidRequestException':
            raise error
        elif error.response['Error']['Code'] == 'ResourceNotFoundException':
            raise error
    else:
        if 'SecretString' in get_secret_value_response:
            secret = get_secret_value_response['SecretString']
            return secret
        else:
            decoded_binary_secret = base64.b64decode(
                get_secret_value_response['SecretBinary'])
            return decoded_binary_secret


def rds_conn(LOGGER, host_name, secret_name, port_no, schema_name):
    """
    Function to use Secrets Manager to create an RDS Connection Object
    :param host_name: Host name of the RDS
    :param secret_name: secret name for fetching user password
    :param port_no: Port Number of RDS
    :param schema_name: Schema Name in RDS
    :return: RDS Connection Object
    """
    try:
        secure_string   = get_secret_rds(secret_name)
        secure_dict     = json.loads(secure_string)
        postgre_username  = secure_dict.get('username')
        postgre_password  = secure_dict.get('password')
        engine = psycopg2.connect(
                database=schema_name,
                user=postgre_username,
                password=postgre_password,
                host=host_name,
                port=port_no
            )
    except Exception as err:
        LOGGER.critical("ERROR: Unexpected error: Could not connect to Aurora instance.")
        LOGGER.critical('*** ERROR: %s ***', err)
        raise err

    return engine

def _read_s3_object(s3_path):
    """
    Function to read object from s3 path
    :param s3_path: S3 object full path
    :return: object
    """
    s3 = boto3.resource('s3')
    S3C = boto3.client('s3')
    bucket = s3_path.split("//")[1].split("/")[0]
    key = "/".join(s3_path.replace("//", "").split("/")[1:])
    
    LOGGER.info("Reading S3 obj {}".format(s3_path))
    obj = s3.Object(bucket, key)
    #obj = S3C.get_object(Bucket=bucket, Key=key)
    
    return obj
#---------------------------------------------------------------------------------#
#                      Business Logic                                             #
#---------------------------------------------------------------------------------#
LOGGER.info("Reading Glue Job Parameters... \n")
# Parse Arguments for Glue Job
params = ['etl_stp_parms']
# Parse Arguments for Glue Job
ARGS = getResolvedOptions(sys.argv, params)
                                    
#set Variables
etl_parms = json.loads(ARGS['etl_stp_parms'])
#Input Parameters Passed/Needed
#Mandatory Parameters
aplctn_cd = etl_parms.get('aplctn_cd','CII').strip().lower()
ENV = etl_parms.get('env').strip()
# Reads the configuration File from S3
json_obj_l2 = _read_s3_object("s3://antm-cii-{env}-codez-nogbd-nophi-useast1/cii_config/cii_config_l2_parm.json".format(env=ENV))
config_l2 = json.loads(json_obj_l2.get()['Body'].read().decode('utf-8'))

db_config_path = config_l2['db_config_path'].strip().format(env=ENV)
l2_config_file = config_l2['l2_config_file'].strip().format(env=ENV)
l2_sqls_path = config_l2['l2_sqls_path'].strip().format(env=ENV)
aciisst_adhoc_schema_name = config_l2['aciisst_adhoc_schema_name'].strip()
aciisst_schema_name = config_l2['aciisst_schema_name'].strip()
evolve_schema_name = config_l2['evolve_schema_name'].strip()
data = {}
data["etl_stp_parms"] = {}
data["etl_stp_parms"]["env"] = ENV
data["etl_stp_parms"]["aplctn_cd"] = aplctn_cd
#data["etl_stp_parms"]["db_config_path"] = "s3://antm-cii-{env}-codez-nogbd-nophi-useast1/cii_config/cii_sf_sfltr_dbconfig_{env}.json".format(env=ENV)
data["etl_stp_parms"]["db_config_path"] = db_config_path
#data["etl_stp_parms"]["l2_config_file"] = "s3://antm-cii-{env}-codez-nogbd-nophi-useast1/cii_config/cii_standard_insights_l2_config_file.config".format(env=ENV)
data["etl_stp_parms"]["l2_config_file"] = l2_config_file
#data["etl_stp_parms"]["l2_sqls_path"] = "s3://antm-cii-{env}-codez-nogbd-nophi-useast1/cii/snowflake-etl/static-rpt".format(env=ENV)
data["etl_stp_parms"]["l2_sqls_path"] = l2_sqls_path
data["etl_stp_parms"]["aciisst_adhoc_schema_name"] = aciisst_adhoc_schema_name
data["etl_stp_parms"]["aciisst_schema_name"] = aciisst_schema_name
data["etl_stp_parms"]["evolve_schema_name"] = evolve_schema_name
data["etl_stp_parms"]["manual_run"] = "NO"

#Getting region_name, account and account_name
REGION_NAME = get_region_name()
account = get_account()
account_name = get_account_name()
load_log_key = uuid.uuid1()
APLCTN_CD = aplctn_cd
WAREHOUSE_SIZE_SUFFIX = ''
LOGGER.info(f'\n**** Argument List ****\n-----------------------')
LOGGER.info(f'\nREGION_NAME : {REGION_NAME} \nENV : {ENV} \nAPLCTN_CD : {APLCTN_CD} ')

# Fetch the SECRET Instance based on Application Code
#SECRET = get_secret(LOGGER, ENV, REGION_NAME, f"/snowflake/{APLCTN_CD}")

#SECRET_JSON = json.loads(SECRET)    
try:
    LOGGER.info('*** Creating Snowflake and RDS Connection & Cursor ***')
    # Reads the configuration File from S3
    json_obj = _read_s3_object(data["etl_stp_parms"]["db_config_path"])
    config = json.loads(json_obj.get()['Body'].read().decode('utf-8'))
    
    # Getting RDS connection Details from configuration file
    databaseName = config['database_details']['database']
    schema_name = config['database_details']['schema']
    host = config['database_details']['host']
    port = config['database_details']['port']
    secret_name = config['database_details']['secret_name']
    preval_databaseName = config['database_details']['preval_database']
    # Creates RDS Connection Object and Cursor
    conn_rds = rds_conn(LOGGER, host, secret_name, port, schema_name)
    cursor_rds = conn_rds.cursor()
    LOGGER.info("Connection to RDS has been established, Cursor is created.")
    #conn_sf = snowflake_conn(logger=LOGGER, aplctn_cd=APLCTN_CD, secret=SECRET, warehouse_size_suffix=WAREHOUSE_SIZE_SUFFIX)
    conn_sf = get_snowflake_conn(LOGGER, aplctn_cd, ENV, REGION_NAME, warehouse_size_suffix=WAREHOUSE_SIZE_SUFFIX)
    cursor_sf = conn_sf.cursor()
    LOGGER.info('*** Created Snowflake Connection & Cursor ***')
    #warehouse = SECRET_JSON.get(f'{APLCTN_CD}_warehouse')
    #warehouse = warehouse + WAREHOUSE_SIZE_SUFFIX
    LOGGER.info(f'Based on warehouse size value passed as \'{WAREHOUSE_SIZE_SUFFIX}\', '
				f'warehouse \'{WAREHOUSE_SIZE_SUFFIX}\' is used for this session')
    LOGGER.info(f"*** Setting up the time format is: alter session set timestamp_output_format = 'YYYY-MM-DD HH24:MI:SS.FF'; ***")
    cursor_sf.execute("alter session set timestamp_output_format = 'YYYY-MM-DD HH24:MI:SS.FF'")
    #Taking the current_timestamp for start time
    cursor_sf.execute("select current_timestamp")
    rpt_strt_dtm = str(cursor_sf.fetchone()[0])[:26]
    #Calling l2_re_run_process_get_details function to fetch details from RDS
    l2_re_run_process_details = l2_re_run_process_get_details_rds(LOGGER, conn_sf, cursor_sf, conn_rds, cursor_rds, rpt_strt_dtm, -1)
    
    #running/re-running the rpt_run_id/pkg_id
    if (len(l2_re_run_process_details) > 0):
        for row in l2_re_run_process_details:
            data1 = "|".join(row)
            data2 = data1.split("|")
            data["etl_stp_parms"]["rpt_run_id"] = data2[0]
            rpt_run_id = data2[0]
            data["etl_stp_parms"]["number_of_tries"] = data2[1]
            number_of_tries = data2[1]
            data["etl_stp_parms"]["re_run"] = "'" + str(data2[2]) + "'"
            #Chekcing current ETL_IN_PROGRESS in RDS table - aciisst_rpt_cstm_rqst
            count_inprogress_query = "select count(distinct pkg_id) from aciisst_appl.aciisst_rpt_cstm_rqst where upper(trim(rqst_stts_txt)) = 'ETL_IN_PROGRESS'"
            cursor_rds.execute(count_inprogress_query)
            count_in_progress = cursor_rds.fetchone()[0]
            if (count_in_progress >= 20):
                LOGGER.info('*** Unable to Process New pkg_id/rpt_run_id as Maximum Allowed Quota of ETL_IN_PROGRESS requests reached***')
                sys.exit(1)
            else:
                update_rds_cstm_rqst_sql = f"update aciisst_appl.aciisst_rpt_cstm_rqst set rqst_stts_txt = 'ETL_IN_PROGRESS', err_txt = 'Re-Running - StandardInsightsL2Process' where pkg_id = {rpt_run_id}"
                cursor_rds.execute(update_rds_cstm_rqst_sql)
                conn_rds.commit()
            #Triggering L#2 Processing
            load_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            load_time = load_time.replace('-', '').replace(' ', '-').replace(':', '')
            execution_name = f"{aplctn_cd}-StandardInsights-Re-Run-{number_of_tries}-L2-{rpt_run_id}-RunDt-{load_time}"[:100]
            # Create Step Function Execution with ARN, Custom Name and Config JSON
            sfn_arn = 'arn:aws:states:' + REGION_NAME + ':' + account + ':stateMachine:ANTM-' + aplctn_cd.upper() + '-' + ENV + '-Sfn-SF-Aciisst-StandardInsightsL2Process'
            LOGGER.info('*** Call Step Function : %s ***', sfn_arn)
            sfn_json = json.dumps(data)
            LOGGER.info('*** Call Step Function with input: %s ***', sfn_json)
            response = sfn.start_execution(stateMachineArn=sfn_arn,
                                           name=execution_name,
                                           input=sfn_json)
            LOGGER.info(f'*** Step Function Response ARN: {response.get("executionArn")}')
            LOGGER.info(f"*** Step Function Execution Name: {execution_name}")
    
    
except Exception as e:
	LOGGER.critical('*** ERROR: %s ***', e)
	error_detail = str(e)
	log_error_to_rds(LOGGER, conn_sf, cursor_sf, conn_rds, cursor_rds, -1, rpt_strt_dtm, number_of_tries, f'RETRY', "Glue:Job:StandardInsightsL2ReRun - " + error_detail, "RETRY")
	raise e
#---------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------#
