######################################################################################
#                                                                                    #
#  Description           :  This function will connect to Aurora Postgres & get data #
#                           to put into S3 in Parquet format                         #
#  Environment Variables :  None                                                     #
#  Author                :  Rajdeep Das                                              #                
#  Modified By           :  Rajdeep Das                                              #
#  Creation Date         :  14th Aug-2020                                            #
#                                                                                    #
######################################################################################

################################ Import Modules ######################################

from awsglue.utils import getResolvedOptions
import psycopg2
import boto3
import awswrangler as wr
import pandas as pd
import traceback
import base64
import os
import sys
import json
from botocore.exceptions import ClientError


ARGS = getResolvedOptions(sys.argv, ['db_config_path'])
    
db_config_path = ARGS['db_config_path']
print("Disp2", db_config_path)

############################## Initializing Clients ##################################

secret_client = boto3.client("secretsmanager")

################################## Get Secret Value ##################################

def get_secret(secret_name):

    """
    Usage   : Get Secret JSON String
    Args    : Secret Name
    Returns : Secure string of Secret
    Raises  : Exception While getting the Secret.
    
    """
    secret = ''
    
    try:
        get_secret_value_response = secret_client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as error:
        if error.response['Error']['Code'] == 'DecryptionFailureException':
            raise error
        elif error.response['Error']['Code'] == 'InternalServiceErrorException':
            raise error
        elif error.response['Error']['Code'] == 'InvalidParameterException':
            raise error
        elif error.response['Error']['Code'] == 'InvalidRequestException':
            raise error
        elif error.response['Error']['Code'] == 'ResourceNotFoundException':
            raise error
    else:
        if 'SecretString' in get_secret_value_response:
            secret = get_secret_value_response['SecretString']
            return secret
        else:
            decoded_binary_secret = base64.b64decode(
                get_secret_value_response['SecretBinary'])
            return decoded_binary_secret

################################# Create DB Connection ###############################

def create_conn(db_host,secret_name):

    """
    Usage   : Creates Connection Engine
    Args    : None
    Returns : Connection Engine
    Raises  : Exception While Creating Connection.
    
    """
    
    secure_string   = get_secret(secret_name)
    secure_dict     = json.loads(secure_string)
    postgre_username  = secure_dict.get('username')
    postgre_password  = secure_dict.get('password')

    try:
        eng_postgresql = wr.db.get_engine(
            db_type="postgresql",
            host=db_host,
            port=5432,
            database="cii_appl_snowui",
            user=postgre_username,
            password=postgre_password
        )
    except Exception as e:
        print(e)
        print("Cannot Connect to RDS Postgres")
        raise e
        
        
    return eng_postgresql
    
############################## Create Panda Dataframe #############################
    
def create_dataframe(table_name,connection,database):
    
    """
    Usage   : Creates Dataframe by running select query
    Args    : Connection Engine
    Returns : Dataframe
    Raises  : Exception While Creating Dataframe OR running queries.
    
    """
    try:
        
        query = f"SELECT * FROM {database}.{table_name}"
        df = wr.db.read_sql_query(query, con=connection)
        
    except Exception as e:
        print(e)
        print("Cannot Execute Queries")
        raise e
        
    return df
    
########################## Upload to S3 as Parquet File #########################
    
def upload_to_s3_as_parquet(object_key,dataframe):
    
    """
    Usage   : Uploads to S3 as Parquet file
    Args    : Dataframe
    Returns : Nothing
    Raises  : Exception While Uploading to S3.
    
    """
    try:
    
        wr.s3.to_parquet(dataframe, object_key)
        
    except Exception as e:
        print(e)
        print("Cannot Upload to S3")
        raise e


def _read_s3_object(s3_path):
    """
    Function to read object from s3 path
    :param s3_path: S3 object full path
    :return: object
    """
    s3 = boto3.resource('s3')
    bucket = s3_path.split("//")[1].split("/")[0]
    key = "/".join(s3_path.replace("//", "").split("/")[1:])
    
    obj = s3.Object(bucket, key)
    
    return obj
    
########################### Main Handler Function ############################## 

def main():
    
    try:
        
        json_obj = _read_s3_object(db_config_path)
        config = json.loads(json_obj.get()['Body'].read().decode('utf-8'))
        
        input_list = config['inputlist']

        for eachinput in input_list:
       
            table_list = eachinput['tablelist']
            s3_path = eachinput['s3path']
            database = eachinput['database']
            db_host = eachinput['host']
            secret_name = eachinput['secretname']
            
            connection = create_conn(db_host,secret_name)
            
            for table in table_list:
                dataframe = create_dataframe(table,connection,database)
                print("Fetched " + table + " contents Successfully")
                object_key = f"{s3_path}/{table}/{table}.parquet"
                try:
                    upload_to_s3_as_parquet(object_key,dataframe)
                except Exception as e:
                    if "EmptyDataFrame" in str(e):
                        print("Table : " + table + " has no contents. Please verify.")
                        wr.s3.delete_objects(object_key)
                        print("S3 Object : " + object_key + " has been deleted as " + table + " has no contents.")
                        continue
                
                print("Uploaded " + table + " contents to S3 path :" + object_key)
        
        
        return 'Function Executed Successfully'
        
    except Exception as e:
        
        print('Function failed due to exception.') 
        print(e)
        traceback.print_exc()
        raise e

if __name__ == '__main__':
    main()