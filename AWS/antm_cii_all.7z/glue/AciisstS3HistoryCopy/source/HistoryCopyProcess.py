"""
DOCSTRING : Python Script to do  a copy data from one folder to another*
"""

import os
import sys
import json
import re
import boto3
from awsglue.utils import getResolvedOptions
from botocore.exceptions import ClientError
from ReduceReuseRecycle import load_log_config, InvalidStatus

LOGGER = load_log_config(glue=True)

LOGGER.info("Reading Glue Job Parameters... \n")

# Parse Arguments for Glue Job

# Define mandatory params
params = [
    'env',
    's3_source_bucket',
    's3_source_key',
    's3_target_bucket',
    's3_target_key',
    'table_creation',
    'schema_name'

]

glue = boto3.client('glue')
client = boto3.client('s3')
sns = boto3.client('sns')
 
 
# Parse Arguments for Glue Job
ARGS = getResolvedOptions(sys.argv, params)

class acc_info:
    sts_function_client=boto3.client('sts')
    def __init__(self):
        acc_details=acc_info.sts_function_client.get_caller_identity()
        self.account=acc_details['Account']
    @property
    def get_account(self):
        return self.account


def run_command(command):
    """
    Function to execute a subprocess.run command
    :param command:
    :return: True if successful
    """

    try:
        result = os.system(command)
        # subprocess.run(command_list, stdout=subprocess.PIPE)

        LOGGER.info(result)

        if result >> 8 == 1:
            raise InvalidStatus(f"One or more S3 transfer operations failed: %s" % command)

    except Exception as excp:
        LOGGER.error(format(excp))
        raise InvalidStatus(f"run_command failed: %s" % command)
        return false

    return True

def delete_s3_files(s3_target_bucket, s3_target_key):
    """
    :param s3_target_bucket: S3 Bucket where the delete will be performed
    :param s3_target_key: S3 Key of data to be copied
    :return: True if object was delete successfully
    """

    s3_bucket_path = s3_target_bucket + '/' + s3_target_key + '/'
    
    command = 'aws s3 rm s3://' + s3_bucket_path + ' --recursive'

    try:
        run_command(command)

    except Exception as error:
        LOGGER.error(error)
        raise InvalidStatus(f"Delete s3 failed: %s" % command)
        return False

    return True


def sync_s3_files(s3_source_bucket, s3_source_key, s3_target_bucket, s3_target_key):
    """
    Function to use AWS CLI S3 Sync to move objects between buckets
    :param s3_source_bucket: S3 Bucket Name of Inbound Data
    :param s3_source_key: S3 Key of data to be copied
    :param load_date: YYYYMMDD of the current data load
    :param s3_target_bucket: S3 Bucket destination of copy
    :param s3_target_key: S3 Key destination of copy
    :return: True if object was delete successfully
    """

    print("###Inside sync_s3_files function")
    # Construct source bucket/key/file parameter
    s3_source_bucket = s3_source_bucket + '/' + s3_source_key + '/'
    print("s3_source_bucket=", s3_source_bucket)

    s3_target_bucket = s3_target_bucket + '/' + s3_target_key + '/'
    print("s3_target_bucket=", s3_target_bucket)
    
    command = 'aws s3 sync s3://' + s3_source_bucket + ' s3://' + s3_target_bucket
    print("command=", command)

    try:
        run_command(command)

    except Exception as error:
        LOGGER.error(error)
        raise InvalidStatus(f"Sync s3 failed: %s" % command)
        return false

    return True


def creating_tables(s3_target_bucket, s3_target_key, schema_name, env, account):
    """
    :param s3_target_bucket: S3 Bucket where the delete will be performed
    :param s3_target_key: S3 Key of data to be copied
    :env: environment the job running
    :region_name: region name
    :account: Account number
    """
    bucket_name = s3_target_bucket
    key_name = s3_target_key
    key_path = key_name + '/'
    count_of_slash_in_key_path = key_path.count("/")
    region = os.environ['AWS_DEFAULT_REGION']

    s3_path_to_crawl = ""
    s3_path_to_crawl_copy = ""
    crawled_table_list = []

    kwargs = {'Bucket': bucket_name, 'Prefix': key_name}
    while True:
        result = client.list_objects_v2(**kwargs)
        for key in result[ "Contents" ]:
            keyString = key[ "Key" ]
            s3_path_to_crawl = keyString[:keyString.rfind('/')]
            count_of_slash_in_key = s3_path_to_crawl.count("/")
            if (s3_path_to_crawl == s3_path_to_crawl_copy or key_name not in s3_path_to_crawl or "temp" in s3_path_to_crawl or "$" in s3_path_to_crawl or "flag" in s3_path_to_crawl or count_of_slash_in_key < count_of_slash_in_key_path or count_of_slash_in_key > count_of_slash_in_key_path):
              continue
            else:
              s3_path_to_crawl_copy = s3_path_to_crawl
              if re.search(r'\b' + key_name + r'\b', s3_path_to_crawl_copy):
                 LOGGER.info(f'\nPath which crawler to crawl : {s3_path_to_crawl_copy}\n')
                 table_name = s3_path_to_crawl_copy[s3_path_to_crawl_copy.rfind("/")+1:]
                 LOGGER.info(f'\nTable Name : {table_name}\n')
                 response = glue.start_job_run(
                 JobName = 'ANTM-EDL-' + env + '-Gj-CreateRunCrawler',
                 Arguments = {
                 '--s3_cnsmptn_bkt':   bucket_name,
                 '--s3_cnsmptn_key':  s3_path_to_crawl_copy,
                 '--trgt_tbl_nm':  table_name,
                 '--trgt_schma':  schema_name,
                 '--env':  env,
                 '--region_name':  region,
                 '--account': account,
                 '--unld_partn_key': 'na' } )
                 
                 jobrunid = response['JobRunId']
                 crawled_table_list.append(table_name)
                 LOGGER.info(f'\nJob Run ID for Table: {table_name} Crawler Job: {jobrunid} \n')

        try:
            kwargs['ContinuationToken'] = result['NextContinuationToken']
        except KeyError:
            break
    
    sns_arn = 'arn:aws:sns:' \
              + region + ':' \
              + account + ':{env}-snsCIIPublication'.format(env=env)
    subject = f'Succeeded: CII Backup Athena Database - {schema_name}'
    LOGGER.info('SNS ARN: %s', sns_arn)
    try:
        formatted_msg = f'Backup Taken to S3 Location: {bucket_name}/{key_name} \nTables Created: {crawled_table_list}'
        response = sns.publish(TargetArn=sns_arn,
                              Message=formatted_msg,
                              Subject=subject,
                              MessageStructure='string'
                              )
                               
        LOGGER.info('SNS Response: %s', response)
    except ClientError as sns_error:
        LOGGER.critical('*** SNS Message Publication Failed: %s ***', sns_error)
        raise sns_error

 
# Main Execution
def main():
    """
    This is Job Copies all the folders and files which are under given source bucket and source key to target bucket and target key
    And also creates Athena/Glue Catalog schema if not exists, using the schema_name provided, and creates the tables by crawling on the 
    target bucket and target key
    """

    LOGGER.info('*** Calling sync_s3_files function ***')
    
    ENV = ARGS['env']
    env = ENV
    s3_source_bucket = ARGS['s3_source_bucket']
    s3_source_key = ARGS['s3_source_key']
    s3_target_bucket = ARGS['s3_target_bucket']
    s3_target_key = ARGS['s3_target_key']
    table_creation = ARGS['table_creation']
    schema_name = ARGS['schema_name']
    account = acc_info().get_account
    
    LOGGER.info(f'\n**** Argument List ****\n-----------------------')
    LOGGER.info(f'\nENV : {ENV} \ns3_source_bucket : {s3_source_bucket} \ns3_source_key : {s3_source_key} \ns3_target_bucket : {s3_target_bucket} '
            f'\ns3_target_key : {s3_target_key} \nschema_name : {schema_name} ')
    LOGGER.info(f'\n-----------------------\n')

    #Deleting the files and folder under target key
    LOGGER.info(f'\nCalling the delete_s3_files function \n')
    delete_files = delete_s3_files(s3_target_bucket, s3_target_key)
    LOGGER.info(f'\nResult of delete_s3_files function: {delete_files} \n')

    #Calling function to sync data between source and target buckets
    LOGGER.info(f'\nCalling the sync_s3_files function \n')
    copy_files = sync_s3_files(s3_source_bucket, s3_source_key, s3_target_bucket, s3_target_key)
    LOGGER.info(f'\nCalling the sync_s3_files function: {copy_files} \n')

    #Calling the function to create tables
    if(table_creation.upper()=='YES'):
        LOGGER.info(f'\nCalling the creating_tables function \n')
        creating_tables(s3_target_bucket, s3_target_key, schema_name, env, account)
    else:
        LOGGER.info(f'\nOnly Data Copy Tables Creation Not Required \n')

 
if __name__ == "__main__":
    main()