"""
DOCSTRING : Python Script to Swap Covid 19 Tables from aciisst_c19_vldtn to aciisst_c19
"""
import re
import snowflake.connector as sf
from awsglue.utils import getResolvedOptions
from botocore.exceptions import ClientError
import base64
from ReduceReuseRecycle import *
from ReduceReuseRecycle.snowflakefunc import *


LOGGER = load_log_config(glue=True)

# Define mandatory params
params = [
    'env',
    'table_list',
    'schema_name',
    'clone_level',
    'warehouse_size_suffix'
] 


# Parse Arguments for Glue Job
ARGS = getResolvedOptions(sys.argv, params)

SCHEMA = ARGS.get('schema_name', None)
APLCTN_CD = ARGS.get('aplctn_cd', 'cii').lower()
ENV = ARGS.get('env', None)
TABLE_LIST = ARGS.get('table_list', " ")
WAREHOUSE_SIZE_SUFFIX = ARGS.get('warehouse_size_suffix', '_XL')
CLONE_LEVEL = ARGS.get('clone_level', None).lower()
REGION_NAME = 'us-east-1'

# Intialize Variables
if ARGS.get('warehouse_size_suffix') is None:
    LOGGER.info(f"No WAREHOUSE_SIZE_SUFFIX Parameter Specified - Defaulting to {WAREHOUSE_SIZE_SUFFIX}")

if ENV is None:
    raise ValueError("Expected environment in the Input")

if CLONE_LEVEL is None:
    raise ValueError("Please Specify Appropriate Clone Level. Valid Values are schema or table")

if CLONE_LEVEL not in ('table','schema'):
    raise ValueError("Valid Values for --clone_level are table, schema.")

if SCHEMA is None:
    raise ValueError(f"Please Provide Valid Schema Name for --schema_name")

if 'VLDTN' not in SCHEMA.upper():
    raise ValueError(f"Please Provide Valid Schema Name. Only VLDTN Schema's are allowed")

if CLONE_LEVEL == 'table' and (TABLE_LIST == "" or TABLE_LIST == " "):
    raise ValueError(f"Please Provide Valid Table Names.")

if CLONE_LEVEL == 'schema' and TABLE_LIST != " ":
    raise ValueError(f"Please Provide Clone Level as 'table' when you have valid tables in --table_list argument")

LOGGER.info(f"**** Argument List ****")
LOGGER.info(f"SCHEMA    :   {SCHEMA}")
LOGGER.info(f"APLCTN_CD :   {APLCTN_CD}")
LOGGER.info(f"ENV       :   {ENV}")
LOGGER.info(f"TABLE_LIST    :   {TABLE_LIST}")
LOGGER.info(f"WAREHOUSE_SIZE_SUFFIX :   {WAREHOUSE_SIZE_SUFFIX}")
LOGGER.info(f"CLONE_LEVEL :   {CLONE_LEVEL}")
LOGGER.info(f"REGION_NAME :   {REGION_NAME}")


# Fetch the SECRET Instance based on Application Code
def get_secret(secret_name):
    
	"""
	Usage   : Get Secret JSON String
	Args    : Secret Name
	Returns : Secure string of Secret
	Raises  : Exception While getting the Secret.
	
	"""
	secret = ''
	secret_client = boto3.client("secretsmanager")
	try:
		get_secret_value_response = secret_client.get_secret_value(
			SecretId=secret_name
		)
	except ClientError as error:
		if error.response['Error']['Code'] == 'DecryptionFailureException':
			raise error
		elif error.response['Error']['Code'] == 'InternalServiceErrorException':
			raise error
		elif error.response['Error']['Code'] == 'InvalidParameterException':
			raise error
		elif error.response['Error']['Code'] == 'InvalidRequestException':
			raise error
		elif error.response['Error']['Code'] == 'ResourceNotFoundException':
			raise error
	else:
		if 'SecretString' in get_secret_value_response:
			secret = get_secret_value_response['SecretString']
			return secret
		else:
			decoded_binary_secret = base64.b64decode(
				get_secret_value_response['SecretBinary'])
			return decoded_binary_secret

SECRET = get_secret(f"{ENV}/snowflake/{APLCTN_CD}")
SECRET_JSON = json.loads(SECRET)

DATABASE = SECRET_JSON.get(f"{APLCTN_CD}_database")
LOGGER.info(f"DATABASE :   {DATABASE}")


# Define Functions
def build_swapproc_sql(databasename, schema_name, clone_level, table_name):   
    """
    Function to generate Snowflake Clone SQL based on clone type.
    """
    swapproc_sql = ""
    databasename_upper = databasename.upper()

    if clone_level.lower() == 'schema':
        swapproc_sql = f"CALL {databasename_upper}.ETL_DDLPROC_ACIISST.CLONE_SCHEMA('{databasename}','{schema_name}')"
    elif clone_level.lower() == 'table':
        swapproc_sql = f"CALL {databasename_upper}.ETL_DDLPROC_ACIISST.CLONE_TABLE('{databasename}','{schema_name}','{table_name}')"
    else:
        LOGGER.error('Invalid Clone Level Provided')
        raise Exception('Invalid Clone Level Provided')

    return swapproc_sql


# Main Execution
def main():
    """
    Establishes a Snowflake Connection Object and Executes a Swap schema
    :return: Completes the Snowflake  Swap Schema from ACIISST_C19_VLDTN To ACIISST_C19
    """
    # Create SQL Cursor from Function 'snowflake_conn'
    LOGGER.info('*** Creating Snowflake Connection & Cursor ***')
    try:
        conn = snowflake_conn(logger=LOGGER, aplctn_cd=APLCTN_CD, secret=SECRET,
                                warehouse_size_suffix=WAREHOUSE_SIZE_SUFFIX)
        cursor = conn.cursor()
        LOGGER.info('*** Created Snowflake Connection & Cursor ***')
        warehouse = SECRET_JSON.get(f'{APLCTN_CD}_warehouse')
        warehouse = warehouse + WAREHOUSE_SIZE_SUFFIX
        LOGGER.info(f"Based on warehouse size value passed as {WAREHOUSE_SIZE_SUFFIX},"
                    f"warehouse {warehouse} is used for this session")

    except sf.DatabaseError as SnowflakeConnectionFailure:
        LOGGER.critical('*** CRITICAL: Cannot establish connection with Snowflake ***')
        LOGGER.critical(SnowflakeConnectionFailure)
        raise SnowflakeConnectionFailure
    

    LOGGER.info(f"**** Environment Running CLone: {ENV} ****")
    if CLONE_LEVEL.lower() == 'schema':

        try:
            clone_sql = build_swapproc_sql(DATABASE, SCHEMA, CLONE_LEVEL, "")
            LOGGER.info(f'*** Clone Command at Schema Level : {clone_sql} ***')

            cursor.execute(clone_sql)
            LOGGER.info(f'*** SUCCESS: Clone Successfull for Schema {SCHEMA}***')
        except sf.ProgrammingError as GenericSnowflakeException:
            LOGGER.critical('*** ERROR: Snowflake Swap Failed ***')
            LOGGER.critical(GenericSnowflakeException)
            raise GenericSnowflakeException

    elif CLONE_LEVEL.lower() == 'table':
        
        LOGGER.info(f"Tables passed as input for Clone - '{TABLE_LIST}' ")
        tableslist = TABLE_LIST.strip().split(",")

        for table in tableslist:
            
            try:
                clone_sql = build_swapproc_sql(DATABASE, SCHEMA, CLONE_LEVEL, table)
                LOGGER.info(f"*** Clone Command for Table '{table}' : {clone_sql} ***")

                cursor.execute(clone_sql)
                LOGGER.info(f'*** SUCCESS: Clone Successfull for Table {SCHEMA}.{table}***')
            except sf.ProgrammingError as GenericSnowflakeException:
                LOGGER.critical('*** ERROR: Snowflake Clone Failed ***')
                LOGGER.critical(GenericSnowflakeException)
                raise GenericSnowflakeException

    else:
        LOGGER.error('Invalid Clone Level Provided. Expected table/schema.')
        raise ValueError('Invalid Clone Level Provided. Expected table/schema.')


    # Close Snowflake Connection
    LOGGER.info('*** Closing Snowflake Connection ***')
    conn.close()


if __name__ == "__main__":
    main()
