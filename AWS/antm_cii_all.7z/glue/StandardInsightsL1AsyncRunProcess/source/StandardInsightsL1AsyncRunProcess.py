############################################################################################################## 
# Description   : Glue job to Process Standard Insights L#1 Reports Asyncronously
# Author        : Legato
# Created       : 06/08/2022 
# Version       : V1.0
# Version Description : Initial Version
# last Updated  : ##-###-####
############################################################################################################## 
"""
DOCSTRING : Glue job to Process Standard Insights L#2 Reports for each Request/RPT_RUN_ID
"""
'''
DOCSTRING : Python Script to bulk copy S3 objects to Redshift
'''
import sys
from awsglue.utils import getResolvedOptions

params = ['env']
args = getResolvedOptions(sys.argv, params)
envn = args['env']

from ReduceReuseRecycle import download_site_packages
download_site_packages(envn)

from ReduceReuseRecycle import *
from ReduceReuseRecycle.snowflakefunc import *
from ReduceReuseRecycle.pymysqlfunc import *
from ReduceReuseRecycle.psycopgfunc import *
import re
import time
from datetime import datetime, timedelta


# Define mandatory params
params = [
    'env',
    'metadata_dict'
]

# Define optional params
if '--prcsng_type' in sys.argv:
    params.append('prcsng_type')
if '--warehouse_size_suffix' in sys.argv:
    params.append('warehouse_size_suffix')
if '--etl_stp_parms' in sys.argv:
    params.append('etl_stp_parms')

# Parse Arguments for Glue Job
ARGS = getResolvedOptions(sys.argv, params)

ENV = ARGS['env']
METADATA_DICT = ARGS['metadata_dict']
prcsng_type = ARGS.get('prcsng_type', 'ingest')
REGION_NAME = "us-east-1"
warehouse_size_suffix = ARGS['warehouse_size_suffix']
ETL_STP_PARMS = ARGS.get('etl_stp_parms', {})

def check_sfqid_status(conn, cursor, reslt_qid_dict, reslt_qid_lst, max_elapsed_time):
    """
    Function to check the status of snowflake queries
    """
    time_intervals = [[60,[i for i in range(0,20)]], [90,[i for i in range(20,40)]], [90,[i for i in range(40,60)]], [150,[i for i in range(60,80)]], [180,[i for i in range(80,100)]]]
    tm_slp = 180

    strt_time = datetime.now()
    if "d" in max_elapsed_time.lower():
        run_time = strt_time + timedelta(days=int(re.findall(r'\d+',max_elapsed_time)[0]))
    elif "m" in max_elapsed_time.lower():
        run_time = strt_time + timedelta(minutes=int(re.findall(r'\d+',max_elapsed_time)[0]))
    elif "h" in max_elapsed_time.lower():
        run_time = strt_time + timedelta(hours=int(re.findall(r'\d+',max_elapsed_time)[0]))
    else:
        LOGGER.critical(f"max_elapsed_time Passed {max_elapsed_time} is not valid")
        raise Exception(f"max_elapsed_time Passed {max_elapsed_time} is not valid")
    # Loop till the time all the queries gets Succedded/Failed
    while len(reslt_qid_dict) != len({k:v for k,v in reslt_qid_dict.items() if not 'RUNNING' in v}):
        if datetime.now() < run_time:
            # Get the Sleep time based no:of queries running 
            for k,v in time_intervals:
                if len({k:v for k,v in reslt_qid_dict.items() if 'RUNNING' in v}) in v:
                    tm_slp = k
            for query_id, stts in reslt_qid_dict.items():
                if stts == 'RUNNING' and not conn.is_still_running(conn.get_query_status(query_id)):
                    reslt_qid_dict[query_id] = conn.get_query_status(query_id).name
                # else:
                #     LOGGER.info(f'status1 of {query_id}: {conn.get_query_status(query_id).name}')
            time.sleep(tm_slp)
        else:
            # If reached max_elapsed_time then cancel the current running queries and stop the execution
            for query_id, stts in reslt_qid_dict.items():
                try:
                    if stts == 'RUNNING':
                        query = f"SELECT SYSTEM$CANCEL_QUERY('{query_id}')"
                        LOGGER.info(f'Attempting to cancel query: {query}')
                        cursor.execute(query)
                        LOGGER.info(f'*** Snowflake canceled query w/ id {query_id} ***')
                        reslt_qid_dict[query_id] = 'CANCELLED_BY_USER'
                except sf.ProgrammingError as GenericSnowflakeException:
                    LOGGER.critical(f'*** ERROR: Snowflake failed to cancel query w/ id {query_id} ***')
                    LOGGER.critical(GenericSnowflakeException)
                    cursor.close()
                    conn.close()
                    raise Exception(f"Execution time Reached More than Elapsed time {max_elapsed_time}. Hence Stopping the process")
            LOGGER.info(f'Final run status of query(s): {reslt_qid_dict}')
            LOGGER.critical(f"Execution time Reached More than Elapsed time {max_elapsed_time}. Hence Stopping the process")
            cursor.close()
            conn.close()
            raise Exception(f"Execution time Reached More than Elapsed time {max_elapsed_time}. Hence Stopping the process")
        LOGGER.info(f'Query(s) run status: {reslt_qid_dict}')
    
    LOGGER.info(f'Final run status of query(s): {reslt_qid_dict}')
    failed_qrs = len({k:v for k,v in reslt_qid_dict.items() if not 'SUCCESS' in v.upper()})
    if failed_qrs > 0:
        LOGGER.info(f"{failed_qrs} Queries failed out of Total Queries passed {len(reslt_qid_dict.keys())}")
        raise Exception(f"{failed_qrs} Queries failed out of Total Queries passed {len(reslt_qid_dict.keys())}")

    return reslt_qid_dict

def unpack_metadata(metadata_dict):
    """
    Function to unpack the metadata dictionary that is passed as an argument
    :param metadata_dict: Metadata dictionary
    :return:
    """

    metadata_dict = json.loads(metadata_dict)
    s3_bucket = metadata_dict['etl_stp_s3_code_bkt']
    s3_key = metadata_dict['etl_stp_s3_code_key']
    etl_stp_trgt_schma = metadata_dict['etl_stp_trgt_schma']
    etl_stp_trgt_stg_schma = metadata_dict['etl_stp_trgt_stg_schma']
    etl_stp_src_schma = metadata_dict['etl_stp_src_schma']
    etl_stp_src_stg_schma = metadata_dict['etl_stp_src_stg_schma']
    platform = metadata_dict['etl_stp_trgt_platfrm']
    aplctn_cd = metadata_dict.get('aplctn_cd', 'edl').lower()
    edl_run_id = metadata_dict['edl_run_id']
    edl_load_dtm = metadata_dict['edl_load_dtm']
    etl_stp_parms = metadata_dict['etl_stp_parms']
    etl_stp_trgt_tbl_nm = metadata_dict['etl_stp_trgt_tbl_nm']
    trgt_tbl_nm = metadata_dict['trgt_tbl_nm']
    trgt_schma = metadata_dict['trgt_schma']
    clnt_id = metadata_dict['clnt_id']
    edl_sor_cd = metadata_dict['edl_sor_cd']
    trgt_db_nm = metadata_dict['trgt_db_nm']
    etl_sfn_parms = metadata_dict['etl_sfn_parms']

    return s3_bucket, s3_key, etl_stp_trgt_schma, etl_stp_trgt_stg_schma, \
           etl_stp_src_schma, etl_stp_src_stg_schma, platform, aplctn_cd, \
           edl_run_id, edl_load_dtm, etl_stp_parms, etl_stp_trgt_tbl_nm, \
           trgt_tbl_nm, trgt_schma, clnt_id, edl_sor_cd, trgt_db_nm, etl_sfn_parms


def get_sql_files(s3_sql_bucket, s3_sql_key):
    """
    Function to retrieve list of SQL files from S3
    :param s3_sql_bucket: S3 Bucket for SQL Files
    :param s3_sql_key: S3 Key for SQL Files
    :return:
    """

    s3_sql_bucket = S3R.Bucket(s3_sql_bucket)
    s3_sql_key = s3_sql_key

    sql_file_list = []
    for sql in s3_sql_bucket.objects.filter(Prefix=s3_sql_key):
        if sql.key.endswith('sql'):
            sql_file_list.append(sql.key)
        else:
            LOGGER.info(f'Excluding {sql.key} as it is not a sql file')
    LOGGER.info('*** List of SQL Files to be run: %s ***', sql_file_list)
    
    if len(sql_file_list) == 0:
        raise InvalidStatus(f"No file found in specified folder path: {s3_sql_bucket}/{s3_sql_key}")
    
    return sql_file_list


def open_sql_file(s3_sql_bucket, sql_file_list,
                  etl_stp_trgt_schma, etl_stp_trgt_stg_schma,
                  etl_stp_src_schma, etl_stp_src_stg_schma, edl_run_id, edl_load_dtm, etl_stp_parms,
                  etl_stp_trgt_tbl_nm, trgt_tbl_nm, trgt_schma, aplctn_cd, clnt_id, edl_sor_cd, trgt_db_nm, etl_sfn_parms, column_nm_used_for_async):
    """
    Function to open and store SQL file as a variable in a list and substitute
    in variables for schema names
    :param s3_sql_bucket: S3 Bucket for SQL Files
    :param sql_file_list: List of SQL files
    :param etl_stp_trgt_schma: Name of the Target Schema for the SQL query
    :param etl_stp_trgt_stg_schma: Name of the Stage Schema for the SQL query
    :param etl_stp_src_schma: Name of the Target Schema for the SQL query
    :param etl_stp_src_stg_schma: Name of the Stage Schema for the SQL query
    :param edl_run_id:  edl_run_id of current job execution
    :param edl_load_dtm: edl_load_dtm of current job execution
    :param etl_stp_parms: etl_stp_parms
    :param etl_stp_trgt_tbl_nm: Name of the Target Table from step metadata
    :param trgt_tbl_nm: Name of the Target Table from job metadata
    :param trgt_schma: Name of the Target Schema from job metadata
    :param aplctn_cd: Name of the application
    :return: List of SQL Commands in sqls list variable
    """

    sqls = []
    for file in sql_file_list:
        sql_obj = S3C.get_object(
            Bucket=s3_sql_bucket,
            Key=file
        )
        LOGGER.info('*** Reading File %s Content into Variable ***', file)
        sql = sql_obj['Body'].read()
        sql_query = sql.decode('utf-8')
        LOGGER.info('*** Substituting Following parameters in SQL Files ***\n')
        LOGGER.info('aplctn_cd, etl_stp_trgt_schma, etl_stp_trgt_stg_schma, etl_stp_src_schma, etl_stp_src_stg_schma, '
                    'edl_run_id, edl_load_dtm, etl_stp_trgt_tbl_nm, trgt_tbl_nm, trgt_schma, clnt_id, edl_sor_cd, trgt_db_nm')
        # Replace SQL Query parameters with metadata variables
        
        sql_sub=sql_query
        
        # Find all parameters used in sql query that needs to be substituted from etl_stp_parms.
        sql_vars = set(re.findall(r'\$\{([\w]+?)\}', sql_sub))
        
        etl_sfn_parms_json=json.loads(etl_sfn_parms)
        if etl_sfn_parms_json:
            for key in sql_vars:
                try:
                    LOGGER.info(f'Parameter to be replaced in the script: ${{{key}}}')
                    LOGGER.info(f'Parameter Value to be replaced with in the script: {etl_sfn_parms_json[key]}')
                    sql_sub = sql_sub.replace(f'${{{key}}}', etl_sfn_parms_json[key])
                except KeyError as ke:
                    LOGGER.info(f"Replace key not found in sfn params ${{{key}}}")
        
        sql_sub = sql_sub\
            .replace('${etl_stp_trgt_schma}', etl_stp_trgt_schma)\
            .replace('${etl_stp_trgt_stg_schma}', etl_stp_trgt_stg_schma)\
            .replace('${etl_stp_src_schma}', etl_stp_src_schma)\
            .replace('${etl_stp_src_stg_schma}', etl_stp_src_stg_schma)\
            .replace('${edl_run_id}', edl_run_id)\
            .replace('${edl_load_dtm}', edl_load_dtm)\
            .replace('${etl_stp_trgt_tbl_nm}', etl_stp_trgt_tbl_nm)\
            .replace('${trgt_tbl_nm}', trgt_tbl_nm)\
            .replace('${trgt_schma}', trgt_schma)\
            .replace('${aplctn_cd}', aplctn_cd)\
            .replace('${clnt_id}', clnt_id)\
            .replace('${edl_sor_cd}', edl_sor_cd)\
            .replace('${trgt_db_nm}', trgt_db_nm)

        # Find all parameters used in sql query that needs to be substituted from etl_stp_parms.
        sql_vars = set(re.findall(r'\$\{([\w]+?)\}', sql_sub))

        # Look up the etl_stp_parms for parameters used in SQL and substitute it with value found in etl_stp_parms.
        LOGGER.info('*** Substituting parameters passed through etl_stp_parms in SQL Files ***\n')
        if etl_stp_parms:
            for key in sql_vars:
                if not(key not in etl_stp_parms.keys() or key != column_nm_used_for_async):
                    LOGGER.error(f'*** Error: Cannot substitute  variable \'{key}\' in the sql script as it is '
                                 f'not found in etl_stp_parms. ')
                    raise InvalidStatus(f"Parameter not found in etl_stp_parms")
                else:
                    if (key != column_nm_used_for_async):
                        LOGGER.info(f'Parameter to be replaced in the script: ${{{key}}}')
                        LOGGER.info(f'Parameter Value to be replaced with in the script: {etl_stp_parms[key]}')
                        sql_sub = sql_sub.replace(f'${{{key}}}', etl_stp_parms[key])

        sqls.append(sql_sub)

    return sqls


def snowflake(cursor, sqls, column_nm_used_for_async, prefix_value, start_async_exec_num, end_async_exec_num):
    """
    Function to execute SQL file contents in Snowflake
    :param cursor: Cursor object for Snowflake
    :param sqls: List of SQL commands to run
    :param start_async_exec_num/end_async_exec_num: Number of instances/range of execution of an sql starting from start_async_exec_num to end_async_exec_num
    :return: True if all successful
    """

    number_of_files = len(sqls)
    LOGGER.info('*** Total Number of SQL Files to Execute: %s ***',
                str(number_of_files))
    reslt_qid_dict = {}
    reslt_qid_lst = []
    try:
        for sql in sqls:
            LOGGER.info('*** Executing Snowflake File ***')
            # cursor.execute("BEGIN")
            sql_list = sql.split(";")
            if len(sql_list) <= 100:
                for individual_sql in sql_list:
                    if individual_sql != '' and individual_sql is not None and individual_sql != '\n\n':
                        if 'DELETE' not in individual_sql.upper():
                            #initializing counter 'i'
                            i = 0
                            while i < len(prefix_value):
                                for x in range(int(start_async_exec_num[i]), (int(end_async_exec_num[i]) + 1) ):
                                    value = "'" + prefix_value[i] + str(x) + "'"
                                    individual_sql_after_replace = individual_sql.replace(f'${{{column_nm_used_for_async}}}', value)
                                    LOGGER.info('*** Single Query - After Replace: %s ***', individual_sql_after_replace)
                                    cursor.execute_async(individual_sql_after_replace)
                                    query_id = cursor.sfqid
                                    LOGGER.info(f"Query ID {query_id} for SQL {individual_sql_after_replace}")
                                    reslt_qid_dict[query_id] = 'RUNNING'
                                    reslt_qid_lst.append(query_id)
                                    value = ''
                                i = i + 1
                            #initializing counter 'i' again
                            i = 0
                        else:
                            LOGGER.info('*** Single Query - Delete Query: %s ***', individual_sql)
                            cursor.execute(individual_sql)
                            query_id = cursor.sfqid
                            LOGGER.info(f"Query ID {query_id} for SQL {individual_sql}")
                            reslt_qid_dict[query_id] = 'RUNNING'
                            reslt_qid_lst.append(query_id)
                            
                # cursor.execute("COMMIT")
                LOGGER.info('*** SUCCESS: Whole SQL File is complete! ***')
            else:
                LOGGER.critical("Found SQL's to be executed as more than 500. Hence stopping the process")
                raise Exception("Found SQL's to be executed as more than 500. Hence stopping the process")

    except sf.ProgrammingError as GenericSnowflakeException:
        LOGGER.critical('*** ERROR: Snowflake SQL Execution Failed: %s ***', individual_sql)
        LOGGER.critical(GenericSnowflakeException)
        cursor.close()
        raise GenericSnowflakeException

    return reslt_qid_dict, reslt_qid_lst

LOGGER = load_log_config(glue=True)
S3C = boto3.client('s3')
S3R = boto3.resource('s3')

# Main Execution
def main():
    """Establishes a Redshift Connection Object and Executes SQL Files Stored in
    S3 to create flattened data sets in Redshift.
    :return: Completes the Redshift COPY to Staging Table"""

    LOGGER.info('*** Metadata from Dictionary: %s ***',
                str(METADATA_DICT))
    s3_bucket, s3_key, \
        etl_stp_trgt_schma, etl_stp_trgt_stg_schma, \
        etl_stp_src_schma, etl_stp_src_stg_schma, \
        platform, aplctn_cd, edl_run_id, edl_load_dtm, etl_stp_parms, \
        etl_stp_trgt_tbl_nm, trgt_tbl_nm, trgt_schma, \
        clnt_id, edl_sor_cd, trgt_db_nm, etl_sfn_parms = unpack_metadata(METADATA_DICT)

    etl_stp_parms = json.loads(etl_stp_parms)
    LOGGER.info('*** etl_stp_parms: %s ***', str(etl_stp_parms))
    column_nm_used_for_async = etl_stp_parms.get('column_nm_used_for_async').strip()
    prefix_value = etl_stp_parms.get('prefix_value').strip().split("|")
    start_async_exec_num = etl_stp_parms.get('start_async_exec_num', '1').strip().split("|")
    end_async_exec_num = etl_stp_parms.get('end_async_exec_num', '1').strip().split("|")
    max_elapsed_time = etl_stp_parms.get('max_elapsed_time', '1d')
    if (len(prefix_value) == len(start_async_exec_num)):
        if (len(prefix_value) == len(end_async_exec_num)):
            LOGGER.info('Grain of Prameters Looking Good - prefix_value, start_async_exec_num, end_async_exec_num - ' + str(prefix_value) + ' , ' + str(start_async_exec_num) + ' , ' + str(end_async_exec_num))
        else:
            LOGGER.info('Grain of Prameters Not Looking Good - prefix_value, start_async_exec_num, end_async_exec_num - ' + str(prefix_value) + ' , ' + str(start_async_exec_num) + ' , ' + str(end_async_exec_num))
            sys.exit(1)
    else:
        LOGGER.info('Grain of Prameters Not Looking Good - prefix_value, start_async_exec_num, end_async_exec_num - ' + str(prefix_value) + ' , ' + str(start_async_exec_num) + ' , ' + str(end_async_exec_num))
        sys.exit(1)
    # Create SQL Cursor based on Target Platform
    LOGGER.info('*** Creating Cursor for Platform: %s ***', platform.upper())

    if platform.upper() == 'SNOWFLAKE':

        try:
            conn = get_snowflake_conn(LOGGER, aplctn_cd, ENV, REGION_NAME, warehouse_size_suffix=warehouse_size_suffix)
            cursor = conn.cursor()
            cursor.execute('alter session set TRANSACTION_ABORT_ON_ERROR = True')
        except sf.DatabaseError as SnowflakeConnectionFailure:
            LOGGER.critical('*** CRITICAL: Cannot establish connection with Snowflake ***')
            LOGGER.critical(SnowflakeConnectionFailure)
            raise SnowflakeConnectionFailure
    else:
        LOGGER.critical(
            '*** Platform Type %s is not supported at this time ***',
            platform.upper())
        raise Exception('*** Platform Type %s is not supported at this time ***',
            platform.upper())

    LOGGER.info('*** Created Cursor for Platform: %s ***', platform.upper())

    try:
        LOGGER.info('*** Creating List of SQL Files from S3 to Execute ***')
        sql_file_list = get_sql_files(s3_bucket, s3_key)
        LOGGER.info('*** Storing SQLs to Execute in List ***')
        sqls = open_sql_file(s3_bucket, sql_file_list,
                             etl_stp_trgt_schma, etl_stp_trgt_stg_schma,
                             etl_stp_src_schma, etl_stp_src_stg_schma, edl_run_id, edl_load_dtm, etl_stp_parms,
                             etl_stp_trgt_tbl_nm, trgt_tbl_nm, trgt_schma, aplctn_cd, clnt_id, edl_sor_cd, trgt_db_nm, etl_sfn_parms, column_nm_used_for_async)

        LOGGER.info('*** Executing SQLs in Platform: %s ***', platform.upper())
        if platform.upper() == 'SNOWFLAKE':
            reslt_qid_dict, reslt_qid_lst = snowflake(cursor, sqls, column_nm_used_for_async, prefix_value, start_async_exec_num, end_async_exec_num)
            reslt_qid_dict_final = check_sfqid_status(conn, cursor, reslt_qid_dict, reslt_qid_lst, max_elapsed_time)
            LOGGER.info(f"Final Query ID Dict {reslt_qid_dict_final}")
            cursor.close()
            conn.close()
        else:
            LOGGER.critical(
                '*** Platform Type %s is not supported at this time ***',
                platform.upper())
            raise Exception(
                '*** Platform Type %s is not supported at this time ***',
                platform.upper())

    except ClientError as s3_error:
        LOGGER.critical(s3_error)
        LOGGER.critical('*** ERROR: S3 Object Read Failed ***')
        LOGGER.critical(s3_error)
        raise s3_error
    except sf.ProgrammingError as GenericSnowflakeException:
        LOGGER.critical('*** ERROR: Snowflake SQL Execution Failed ***')
        LOGGER.critical(GenericSnowflakeException)
        raise GenericSnowflakeException


if __name__ == "__main__":
    main()