############################################################################################################## 
# Description   : This is a re-usable script to run the EMR Jobs for Benchmark Tables.
# Author        : Legato
# Created       : 05-Apr-2021 
# Version       : V1.0
# last Updated  : ##-###-####
############################################################################################################## 

#Import Pyspark Modules
from pyspark.sql import SparkSession
from pyspark.context import SparkContext
from pyspark.sql import functions as F
from pyspark.storagelevel import StorageLevel 
from pyspark.sql.types import StructType, StructField, StringType

#Import GLue modules
from awsglue.utils import getResolvedOptions
from awsglue.dynamicframe import DynamicFrame
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.transforms import *

#Import common Modules
import os
import sys
import json
import re
import boto3
from datetime import *
from awsglue.utils import getResolvedOptions
from botocore.exceptions import ClientError
from ReduceReuseRecycle import load_log_config, InvalidStatus

glue = boto3.client('glue')
client = boto3.client('s3')
sns = boto3.client('sns')
sfn = boto3.client('stepfunctions')
logger = load_log_config()

#Defnition to update Dataframe Schema to Nullable
def _read_s3_object(s3_path):
    """
    Function to read s3 config path for job processing
    :param s3_path: path to read the s3 file.
    :return: object 
    """
    s3 = boto3.resource('s3')
    bucket = s3_path.split("//")[1].split("/")[0]
    key = "/".join(s3_path.replace("//", "").split("/")[1:])
    
    logger.info("Reading s3 object {}".format(s3_path))
    obj = s3.Object(bucket, key)
    
    return obj
    
def _upload_s3_object(s3_path, data):
    """
    Function to upload file to s3
    :param bucket_name: Bucket name for s3 upload
    :param object_key: key name for s3 upload
    :param table_nm: Table name for s3 upload
    :return: None
    """
    
    s3 = boto3.resource('s3')
    bucket = s3_path.split("//")[1].split("/")[0]
    key = "/".join(s3_path.replace("//", "").split("/")[1:])
    obj = s3.Object(bucket, key)
    
    logger.info("Uploading s3 object {}".format(s3_path))
    obj.put(Body=data)
    
    return
    
def emrConfigParameters(env, json_frmt, job_args, benchmark_type_name, create_cluster, emr_config_name, terminate_cluster):
    
    json_frmt['clusternm'] = benchmark_type_name
    json_frmt['configfile'] = emr_config_name
    json_frmt['jobargs']['job'] = job_args.split(" ")
    json_frmt['emrenv'] = env
    json_frmt['createcluster'] = create_cluster
    json_frmt['terminateoption'] = terminate_cluster
    json_frmt['logpath'] = json_frmt['logpath'].format(env=env)
                    
    return json_frmt

class acc_info:
    sts_function_client=boto3.client('sts')
    def __init__(self):
        acc_details=acc_info.sts_function_client.get_caller_identity()
        self.account=acc_details['Account']
    @property
    def get_account(self):
        return self.account
        
        
def callingEMRAsync(logger, env, sfn_json):
    """
    Function to start the Step Function state machine with JSON input
    :param logger: basic log object
    :param env: environment (dev, sit, prod)
    :param region_name: region on aws (us-east-1)
    :param account: aws account number
    :param account_name: aws account name (edl)
    :param sfn: Step functions client
    :param sfn_json: JSON Input for state machine
    :return:
    """

    load_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S').replace('-', '').replace(' ', '-').replace(':', '')
    execution_name = f"CII-RunDt-{load_time}"[:100]
    region_name = os.environ['AWS_DEFAULT_REGION']
    account = acc_info().get_account

    #sfn_json = json.dumps(sfn_json)

    # Create Step Function Execution with ARN, Custom Name and Config JSON
    sfn_arn = 'arn:aws:states:' + region_name + ':' + account \
              + ':stateMachine:ANTM-' + 'EDL' + '-' + env + '-Sfn-InvokeEMRAsync'

    try:
        logger.info('*** Call Step Function with the following inputs: %s ***',
                    sfn_json)
        response = sfn.start_execution(stateMachineArn=sfn_arn,
                                       name=execution_name,
                                       input=sfn_json)
        execution_arn = response.get("executionArn")
        logger.info(f'*** Step Function Response ARN: {response.get("executionArn")}')
        logger.info(f"*** Step Function Execution Name: {execution_name}")
        return execution_arn
    except ClientError as sfn_exception:
        logger.critical('*** SFN Exception occured: %s', sfn_exception)
        logger.critical('*** Failed to create SFN ***')
        raise sfn_exception

#print("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$")
# Define mandatory params
params = [
    'env',
    'bnch_type_cd',
    'timeperiod_list',
    'intermediate_table_path',
    'table_list',
    'emr_config_path',
    'etl_sfn_parms'

]
 
# Parse Arguments for Glue Job
ARGS = getResolvedOptions(sys.argv, params)
                                    
#print("$$$$ 1st checkpoint")
#set Variables
etl_parms           = json.loads(args['etl_sfn_parms'])
                                            
# read from parmeters
env = etl_parms.get('env').strip()
benchmark_type_name = etl_parms.get('benchmark_type_name').strip()
emr_template_path = etl_parms.get('emr_template_path').strip()
emr_config_path = etl_parms.get('emr_config_path').strip()
bnch_type_cd = etl_parms.get('bnch_type_cd').strip().split("|")
timeperiod_list = etl_parms.get('timeperiod_list').strip().split("|")
intermediate_table_path = etl_parms.get('intermediate_table_path').strip()
conf_file_name = etl_parms.get('conf_file_name').strip()
load_table_list = etl_parms.get('load_table_list').strip().split("|")
resource_folder_name = etl_parms.get('resource_folder_name').strip()


try:
    #create spark session
    spark = SparkSession \
        .builder \
        .appName(jobName) \
        .config("spark.sql.autoBroadcastJoinThreshold", "-1") \
        .enableHiveSupport() \
        .getOrCreate()
    
    spark.sparkContext._jsc.hadoopConfiguration().set("mapred.output.committer.class", "org.apache.hadoop.mapred.FileOutputCommitter")
    glueContext = GlueContext(spark)
    
    # Read the EMR job template from s3.
    job_tmplt_obj = _read_s3_object(emr_template_path)
    json_tmplt = json.loads(job_tmplt_obj.get()['Body'].read().decode('utf-8'))
    #Preparig the Job Arguments
    input_job_args="/usr/bin/spark-submit --class com.anthem.etl.cii.ETLSFDriver --master yarn --deploy-mode cluster --driver-memory 4G --executor-memory 26G --executor-cores 4 --conf spark.executor.memoryOverhead=2GB --conf spark.dynamicAllocation.enabled=true --conf spark.dynamicAllocation.initialExecutors=10 --conf spark.serializer=org.apache.spark.serializer.KryoSerializer --conf spark.default.parallelism=500 --conf spark.sql.shuffle.partitions=500 --conf spark.memory.offHeap.enabled=true --conf spark.memory.offHeap.size=1G --conf spark.yarn.maxAppAttempts=1 s3://antm-cii-{env}-codez-nogbd-nophi-useast1/etl/cii/jar/target/cii-etl-emr-1.0.jar {conf_file_name} CII-SF-EMR-Loads loadTables={load_table_name} {resource_folder_name}"
    dummy_job_args="/usr/bin/spark-submit s3://${etl_stp_s3_code_bkt}/cii/config/cii_dummy.py --driver-memory 26G --executor-cores 4 --conf spark.dynamicAllocation.enabled=true --conf spark.shuffle.service.enabled=true"

#Creating Cluster
    emr_job_param=emrConfigParameters(env, json_tmplt, dummy_job_args, benchmark_type_name, 'YES', emr_config_name, 'NO')
    callingEMRAsync(logger, env, emr_job_param)

    for bnch_type in bnch_type_cd:
    	result1 = os.system(f"aws s3 ls s3://antm-cii-{env}-codez-nogbd-nophi-useast1/cii/benchmark/{bnch_type}_{benchmark_type_name}.done")
    	if(result1 != 0):
    		for time_period in timeperiod_list:
    			input_data = spark.sql(f"SELECT ${j},
	              date_format(add_months(FROM_UNIXTIME(UNIX_TIMESTAMP( CAST(concat({time_period},'01') AS STRING) ,'yyyyMMdd'), 'yyyy-MM-dd'),-11),'yyyyMM'),
	              12,'${bnch_type}','5dfe51b0-04da-4ddf-8b5b-ae046e4ee0a8',current_timestamp")
	        input_data.write.parquet(intermediate_table_path)
    			result2 = os.system(f"aws s3 ls s3://antm-cii-{env}-codez-nogbd-nophi-useast1/cii/benchmark/{time_period}_{bnch_type}_{benchmark_type_name}.done")
    			if(result2 != 0):
    				for table in load_table_list:
    					job_args=input_job_args.format(env=env, conf_file_name=conf_file_name, load_table_name=table, resource_folder_name=resource_folder_name)
    					emr_job_param=emrConfigParameters(env, json_tmplt, benchmark_type_name, 'NO', emr_config_name, 'NO')
    			else:
    				logger.info(f"The Time Period - {time_period} for Bench Type Code - {bnch_type} is already loaded")
    	else:
    		logger.info(f"Bench Mark Type Code - {bnch_type} is already loaded")
    		
    #Terminating Cluster
    emr_job_param=emrConfigParameters(env, json_tmplt, dummy_job_args, benchmark_type_name, 'NO', emr_config_name, 'YES')
    callingEMRAsync(logger, env, emr_job_param)
    		  
except Exception as e:
    #Terminating Cluster
    emr_job_param=emrConfigParameters(env, json_tmplt, dummy_job_args, benchmark_type_name, 'NO', emr_config_name, 'YES')
    callingEMRAsync(logger, env, emr_job_param)
    raise e