"""
DOCSTRING : Python Script to do  a purge*
"""

import snowflake.connector as sf
# from snowflake.connector import DictCursor
from awsglue.utils import getResolvedOptions
from ReduceReuseRecycle import *
from ReduceReuseRecycle.snowflakefunc import *

 
LOGGER = load_log_config(glue=True)

LOGGER.info("Reading Glue Job Parameters... \n")

# Parse Arguments for Glue Job

# Define mandatory params
params = [
    'env'
]

 
 
# Parse Arguments for Glue Job
ARGS = getResolvedOptions(sys.argv, params)

APLCTN_CD = ARGS.get('aplctn_cd', 'cii').lower()
PRCSNG_TYPE = ARGS.get('prcsng_type', 'ingest').lower()
ENV = ARGS['env']

REGION_NAME = 'us-east-1'

LOGGER.info(f'\n**** Argument List ****\n-----------------------')
LOGGER.info(f'\n-----------------------\n')

 
 
# Define Exception Handling Classes
class RecordCountsDoNotMatch(Exception):
    """
    Simple Class to handle Record Mismatch Exception
    """
    pass

 
class RecordCountZero(Exception):
    """
    Simple Class to handle Record Count 0 Exception
    """
    pass

 

SECRET = get_secret(LOGGER, ENV, REGION_NAME, f"/snowflake/cii")
SECRET_JSON = json.loads(SECRET)

## Done save nd try

 
# Main Execution
def main():
    """
    Establishes a Snowflake Connection Object and Executes a COPY command
    :return: Completes the Snowflake COPY to Staging Table
    """
        # Create SQL Cursor from Function 'snowflake_conn'
    LOGGER.info('*** Creating Snowflake Cursor ***')

    try:
        #conn = snowflake_conn(LOGGER, APLCTN_CD, SECRET)
        conn = snowflake_conn(LOGGER, APLCTN_CD, SECRET)
        cursor = conn.cursor()
        LOGGER.info('*** Created Snowflake Cursor ***')
        spsql ="Delete from ACIISST_APPL.ACIISST_SGMNTN_BRDG WHERE FLTR_SRC_NM = 'User Session' AND ACCT_ID <> SRC_FLTR_ID AND CREATD_DTM < dateadd(minute,-240,current_timestamp());"
        #spsql ='select * from ACIISST_APPL.ACIISST_USER_SGMNTN limit 10;'
      
        cursor.execute(spsql)

        commitsql ='COMMIT;'
      
        cursor.execute(commitsql)
        LOGGER.info(f'Data Deletion completed')

    except sf.DatabaseError as SnowflakeConnectionFailure:
        LOGGER.critical('*** CRITICAL: Cannot establish connection with Snowflake ***')
        LOGGER.critical(SnowflakeConnectionFailure)
        raise SnowflakeConnectionFailure

 
       
        # Close Snowflake Connection
    LOGGER.info('*** Closing Snowflake Connection ***')
    conn.close()

 
if __name__ == "__main__":
    main()