############################################################################################################## 
# Description   : Glue job to Update and Insert data into data availability history table in RDS
# Author        : Legato
# Created       : 04-18-2022 
# Version       : V1.0
# Version Description : Initial Version
# last Updated  : ##-###-####
############################################################################################################## 

"""
DOCSTRING : Glue job to Update and Insert data into data availability history table in RDS
"""
## This script requires parameters such as aplctn_cd, snowflake_env,warehouse_size_suffix and env

import re
import snowflake.connector as sf
# from snowflake.connector import DictCursor
from awsglue.utils import getResolvedOptions
from ReduceReuseRecycle import *
from ReduceReuseRecycle.snowflakefunc import *
from awsglue.utils import getResolvedOptions
from boto_wrapper import sfs,acc_info,secretkey
import logging
import json
import sys
import os
import boto3
import base64
from datetime import date, time
from botocore.exceptions import ClientError
import psycopg2
import uuid
import pandas as pd
from datetime import *
from awsglue.utils import getResolvedOptions
from botocore.exceptions import ClientError
from ReduceReuseRecycle import load_log_config, InvalidStatus

#---------------------------------------------------------------------------------#
# Creating boto3 client for glue, stepfuntion, s3, sns                            #
#---------------------------------------------------------------------------------#
glue = boto3.client('glue')
client = boto3.client('s3')
sns = boto3.client('sns')
sfn = boto3.client('stepfunctions')
LOGGER = load_log_config(glue=True)
#---------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------#
LOGGER.info("Reading Glue Job Parameters... \n")

# Parse Arguments for Glue Job

# Define mandatory params
params = ['etl_stp_parms']
 
# Parse Arguments for Glue Job
ARGS = getResolvedOptions(sys.argv, params)
                                    
#set Variables
etl_parms = json.loads(ARGS['etl_stp_parms'])
#Input Parameters Passed/Needed
ENV = etl_parms.get('env').strip().lower()
env = ENV
aplctn_cd = etl_parms.get('aplctn_cd').strip().lower()
db_config_path = etl_parms.get('db_config_path').strip()
sr_run_prd_schema = etl_parms.get('sr_run_prd_schema').strip().lower()
subj_area_txt_list = etl_parms.get('subj_area_txt_list').strip().split("|")
REGION_NAME = 'us-east-1'
load_log_key = uuid.uuid1()
APLCTN_CD = aplctn_cd
WAREHOUSE_SIZE_SUFFIX = ''
LOGGER.info(f'\n**** Argument List ****\n-----------------------')
LOGGER.info(f'\nREGION_NAME : {REGION_NAME} \nENV : {ENV} \nAPLCTN_CD : {APLCTN_CD}  '
            f'\nsubj_area_txt_list : {subj_area_txt_list} ')

# Fetch the SECRET Instance based on Application Code
SECRET = get_secret(LOGGER, ENV, REGION_NAME, f"/snowflake/{APLCTN_CD}")

SECRET_JSON = json.loads(SECRET)
#---------------------------------------------------------------------------------#
#Class to get the Account Number                                                  #
#---------------------------------------------------------------------------------#
class acc_info:
    sts_function_client=boto3.client('sts')
    def __init__(self):
        acc_details=acc_info.sts_function_client.get_caller_identity()
        self.account=acc_details['Account']
    @property
    def get_account(self):
        return self.account

def get_secret(secret_name):
    """
    Function to fetch details from AWS Secrets Manager
    Usage   : Get Secret JSON String
    Args    : Secret Name
    Returns : Secure string of Secret
    Raises  : Exception While getting the Secret.
    
    """
    secret = ''
    secret_client = boto3.client("secretsmanager")

    try:
        get_secret_value_response = secret_client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as error:
        if error.response['Error']['Code'] == 'DecryptionFailureException':
            raise error
        elif error.response['Error']['Code'] == 'InternalServiceErrorException':
            raise error
        elif error.response['Error']['Code'] == 'InvalidParameterException':
            raise error
        elif error.response['Error']['Code'] == 'InvalidRequestException':
            raise error
        elif error.response['Error']['Code'] == 'ResourceNotFoundException':
            raise error
    else:
        if 'SecretString' in get_secret_value_response:
            secret = get_secret_value_response['SecretString']
            return secret
        else:
            decoded_binary_secret = base64.b64decode(
                get_secret_value_response['SecretBinary'])
            return decoded_binary_secret


def rds_conn(LOGGER, host_name, secret_name, port_no, schema_name):
    """
    Function to use Secrets Manager to create an RDS Connection Object
    :param host_name: Host name of the RDS
    :param secret_name: secret name for fetching user password
    :param port_no: Port Number of RDS
    :param schema_name: Schema Name in RDS
    :return: RDS Connection Object
    """
    try:
        secure_string   = get_secret(secret_name)
        secure_dict     = json.loads(secure_string)
        postgre_username  = secure_dict.get('username')
        postgre_password  = secure_dict.get('password')
        engine = psycopg2.connect(
                database=schema_name,
                user=postgre_username,
                password=postgre_password,
                host=host_name,
                port=port_no
            )
    except Exception as err:
        LOGGER.critical("ERROR: Unexpected error: Could not connect to Aurora instance.")
        LOGGER.critical('*** ERROR: %s ***', err)
        raise err

    return engine

def _read_s3_object(s3_path):
    """
    Function to read object from s3 path
    :param s3_path: S3 object full path
    :return: object
    """
    s3 = boto3.resource('s3')
    bucket = s3_path.split("//")[1].split("/")[0]
    key = "/".join(s3_path.replace("//", "").split("/")[1:])
    
    LOGGER.info("Reading S3 obj {}".format(s3_path))
    obj = s3.Object(bucket, key)
    
    return obj
#---------------------------------------------------------------------------------#
# Function to Send SNS for Success                                                #
#---------------------------------------------------------------------------------#
def snsPublication(LOGGER, subject, message):
    region_name = os.environ['AWS_DEFAULT_REGION']
    account = acc_info().get_account
    sns_arn = 'arn:aws:sns:' \
              + region_name + ':' \
              + account + ':{env}-snsCIIPublication'.format(env=env)
    subject = subject
    LOGGER.info('SNS ARN: %s', sns_arn)
    try:
        formatted_msg = message
        response = sns.publish(TargetArn=sns_arn,
                              Message=formatted_msg,
                              Subject=subject,
                              MessageStructure='string'
                              )
                               
        LOGGER.info('SNS Response: %s', response)
    except ClientError as sns_error:
        LOGGER.critical('*** SNS Message Publication Failed: %s ***', sns_error)
        raise sns_error
    	

#---------------------------------------------------------------------------------#
# Function to Send SNS for Failure                                                #
#---------------------------------------------------------------------------------#
def snsNotification(LOGGER, subject, message):
    region_name = os.environ['AWS_DEFAULT_REGION']
    account = acc_info().get_account
    sns_arn = 'arn:aws:sns:' \
              + region_name + ':' \
              + account + ':{env}-snsCIINotification'.format(env=env)
    subject = subject
    LOGGER.info('SNS ARN: %s', sns_arn)
    try:
        formatted_msg = message
        response = sns.publish(TargetArn=sns_arn,
                              Message=formatted_msg,
                              Subject=subject,
                              MessageStructure='string'
                              )
                               
        LOGGER.info('SNS Response: %s', response)
    except ClientError as sns_error:
        LOGGER.critical('*** SNS Message Notification Failed: %s ***', sns_error)
        raise sns_error
    	
#---------------------------------------------------------------------------------#
# Function to Generate Filter value                                               #
#---------------------------------------------------------------------------------#
def generateFilterValue(LOGGER, subj_area_txt_list):
    filter_value = ''
    LOGGER.info(f'*** Generating the Filter Value for subject area text : {subj_area_txt_list} ***')
    counter=0
    for subj_area_txt in subj_area_txt_list:
        counter = counter + 1
        if(counter == len(subj_area_txt_list)):
            filter_value = filter_value + "'" + subj_area_txt + "'"
        else:
            filter_value = filter_value + "'" + subj_area_txt + "'" + ","
    
    return filter_value
#---------------------------------------------------------------------------------#
# Function to Generate Union Query                                                #
#---------------------------------------------------------------------------------#
def generateUnionQuery(LOGGER, data_thru_dt, subj_area_txt_list, actv_ind):
    union_query = ''
    LOGGER.info(f'*** Subject Area Text Inserting are : {subj_area_txt_list} ***')
    counter=0
    for subj_area_txt in subj_area_txt_list:
        counter = counter + 1
        if(counter == len(subj_area_txt_list)):
            union_query = union_query + f"select cast('{data_thru_dt}' as date) as data_thru_dt, '{subj_area_txt}' as subj_area_txt, '{actv_ind}' as actv_ind, current_timestamp as creatd_dtm, current_timestamp as updtd_dtm, 88888 as creatd_by_user_id, 88888 as updtd_by_user_id "
        else:
            union_query = union_query + f"select cast('{data_thru_dt}' as date) as data_thru_dt, '{subj_area_txt}' as subj_area_txt, '{actv_ind}' as actv_ind, current_timestamp as creatd_dtm, current_timestamp as updtd_dtm, 88888 as creatd_by_user_id, 88888 as updtd_by_user_id union all "
    
    return union_query
#---------------------------------------------------------------------------------#
#                      Business Logic                                             #
#---------------------------------------------------------------------------------#	
# Create SQL Cursor from Function 'snowflake_conn'
    
try:
    LOGGER.info('*** Creating Snowflake and RDS Connection & Cursor ***')
    # Reads the configuration File from S3
    json_obj = _read_s3_object(db_config_path)
    config = json.loads(json_obj.get()['Body'].read().decode('utf-8'))
    
    # Getting RDS connection Details from configuration file
    databaseName = config['database_details']['database']
    schema_name = config['database_details']['schema']
    host = config['database_details']['host']
    port = config['database_details']['port']
    secret_name = config['database_details']['secret_name']
    preval_databaseName = config['database_details']['preval_database']
    
    # Creates RDS Connection Object and Cursor
    conn_rds = rds_conn(LOGGER, host, secret_name, port, schema_name)
    cursor_rds = conn_rds.cursor()
    LOGGER.info("Connection to RDS has been established, Cursor is created.")
    conn = snowflake_conn(logger=LOGGER, aplctn_cd=APLCTN_CD, secret=SECRET, warehouse_size_suffix=WAREHOUSE_SIZE_SUFFIX)
    cursor = conn.cursor()
    LOGGER.info('*** Created Snowflake Connection & Cursor ***')
    warehouse = SECRET_JSON.get(f'{APLCTN_CD}_warehouse')
    warehouse = warehouse + WAREHOUSE_SIZE_SUFFIX
    LOGGER.info(f'Based on warehouse size value passed as \'{WAREHOUSE_SIZE_SUFFIX}\', '
				f'warehouse \'{warehouse}\' is used for this session')
    LOGGER.info(f"*** Setting up the time format is: alter session set timestamp_output_format = 'YYYY-MM-DD HH24:MI:SS.FF'; ***")
    cursor.execute("alter session set timestamp_output_format = 'YYYY-MM-DD HH24:MI:SS.FF'")
    LOGGER.info(f"*** Calling Snowflake to RDS Load Data Function ***")
    #Running SQL on Snowflake to get the run through date - data_thru_dt
    sql_data_thru_dt = f"select last_day(to_date(concat(substr(max(RUN_YEAR_MNTH_NBR),1,4),'-',substr(max(RUN_YEAR_MNTH_NBR),5,2),'-','01'))) AS data_thru_dt from {sr_run_prd_schema}.CII_RUN_PRD"
    cursor.execute(sql_data_thru_dt)
    data_thru_dt = cursor.fetchone()[0]
    LOGGER.info(f"data_thru_dt is fetched from Snowflake is - {data_thru_dt}")
    
    if (ENV.strip().upper() == 'PROD'):
        subj_area_txt_filter = generateFilterValue(LOGGER, subj_area_txt_list)
        
        #Deleting in preval with active indicator as 'Y' for the input Subject Area Text for the latest as of month number
        LOGGER.info(f"Deleting Existing Records with Same AS OF MONTH NUMBER - {subj_area_txt_filter}, from the table - aciisst_data_avlblty_hist, in the RDS Database - {preval_databaseName}")
        delete_statement = f"delete from {preval_databaseName}.aciisst_data_avlblty_hist where actv_ind = 'Y' and data_thru_dt = cast('{data_thru_dt}' as date) and subj_area_txt in ({subj_area_txt_filter})"
        LOGGER.info(f"Running the Delete Statement - {delete_statement}")
        cursor_rds.execute(delete_statement)
        conn_rds.commit()
        LOGGER.info(f"Delete Ran Successfully")
        
        #Updating in preval with active indicator as 'N' for the input subj_area_txt for the previous records with activ_ind as Y
        LOGGER.info(f"Environment - {ENV}, Updating the table - aciisst_data_avlblty_hist, in the RDS Database - {preval_databaseName}")
        update_statement = f"update {preval_databaseName}.aciisst_data_avlblty_hist set actv_ind = 'N' where actv_ind = 'Y' and subj_area_txt in ({subj_area_txt_filter})"
        LOGGER.info(f"Running the Update Statement - {update_statement}")
        cursor_rds.execute(update_statement)
        conn_rds.commit()
        LOGGER.info(f"Update Ran Successfully")
        
        #Inserting into preval with active indicator as 'Y' for the input Subject Area Text
        union_query = generateUnionQuery(LOGGER, data_thru_dt, subj_area_txt_list, 'Y')
        insert_union_query = f"insert into {preval_databaseName}.aciisst_data_avlblty_hist {union_query}"
        LOGGER.info(f"Running the Insert Statement - {insert_union_query}")
        cursor_rds.execute(insert_union_query)
        conn_rds.commit()
        LOGGER.info(f"Insert Ran Successfully")
        
        #Deleting in Prod with active indicator as 'N' for the input subj_area_txt for the latest as of month number
        LOGGER.info(f"Deleting Existing Records with Same AS OF MONTH NUMBER - {subj_area_txt_filter}, from the table - aciisst_data_avlblty_hist, in the RDS Database - {databaseName}")
        delete_statement = f"delete from {databaseName}.aciisst_data_avlblty_hist where actv_ind = 'N' and data_thru_dt = cast('{data_thru_dt}' as date) and subj_area_txt in ({subj_area_txt_filter})"
        LOGGER.info(f"Running the Delete Statement - {delete_statement}")
        cursor_rds.execute(delete_statement)
        conn_rds.commit()
        LOGGER.info(f"Delete Ran Successfully")
        
        #Inserting into Prod with active indicator as 'N' for the input subj_area_txt
        union_query = generateUnionQuery(LOGGER, data_thru_dt, subj_area_txt_list, 'N')
        insert_union_query = f"insert into {databaseName}.aciisst_data_avlblty_hist {union_query}"
        LOGGER.info(f"Running the Insert Statement - {insert_union_query}")
        cursor_rds.execute(insert_union_query)
        conn_rds.commit()
        LOGGER.info(f"Insert Ran Successfully")
        #Sending SNS for Success
        snsPublication(LOGGER, f'SUCCEEDED-aciisst_data_avlblty_hist-RDS_Load', f"\n For the subj_area_txt_list - {subj_area_txt_list}")
        LOGGER.info(f"SUCCEEDED-aciisst_data_avlblty_hist-RDS_Load- SNS Sent for Success")
    else:
        subj_area_txt_filter = generateFilterValue(LOGGER, subj_area_txt_list)
        
        #Deleting with active indicator as 'Y' for the input Subject Area Text
        LOGGER.info(f"Deleting Existing Records with Same AS OF MONTH NUMBER - {subj_area_txt_filter}, from the table - aciisst_data_avlblty_hist, in the RDS Database - {databaseName}")
        delete_statement = f"delete from {databaseName}.aciisst_data_avlblty_hist where actv_ind = 'Y' and data_thru_dt = cast('{data_thru_dt}' as date) and subj_area_txt in ({subj_area_txt_filter})"
        LOGGER.info(f"Running the Delete Statement - {delete_statement}")
        cursor_rds.execute(delete_statement)
        conn_rds.commit()
        LOGGER.info(f"Delete Ran Successfully")
        
        #Updating with active indicator as 'N' for the input subj_area_txt
        LOGGER.info(f"Environment - {ENV}, Updating the table - aciisst_data_avlblty_hist, in the RDS Database - {databaseName}")
        update_statement = f"update {databaseName}.aciisst_data_avlblty_hist set actv_ind = 'N' where actv_ind = 'Y' and subj_area_txt in ({subj_area_txt_filter})"
        LOGGER.info(f"Running the Update Statement - {update_statement}")
        cursor_rds.execute(update_statement)
        conn_rds.commit()
        LOGGER.info(f"Update Ran Successfully")
        
        #Inserting into with active indicator as 'Y' for the input subj_area_txt
        union_query = generateUnionQuery(LOGGER, data_thru_dt, subj_area_txt_list, 'Y')
        insert_union_query = f"insert into {databaseName}.aciisst_data_avlblty_hist {union_query}"
        LOGGER.info(f"Running the Insert Statement - {insert_union_query}")
        cursor_rds.execute(insert_union_query)
        conn_rds.commit()
        LOGGER.info(f"Insert Ran Successfully")
        #Sending SNS for Success
        snsPublication(LOGGER, f'SUCCEEDED-aciisst_data_avlblty_hist-RDS_Load', f"\n For the subj_area_txt_list - {subj_area_txt_list}")
        LOGGER.info(f"SUCCEEDED-aciisst_data_avlblty_hist-RDS_Load- SNS Sent for Success")

except Exception as e:
	snsNotification(LOGGER, f"Failed-aciisst_data_avlblty_hist-RDS_Load", f"\n For the subj_area_txt_list - {subj_area_txt_list} \n Please check the logs \n" + str(e))
	LOGGER.info(f"Failed-aciisst_data_avlblty_hist-RDS_Load- SNS Sent for Failure")
	raise e