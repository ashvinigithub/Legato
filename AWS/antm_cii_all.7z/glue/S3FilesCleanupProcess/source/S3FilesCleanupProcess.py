"""
DOCSTRING : Python Script to do S3 Files cleanup for Archive/Speficed pattern from an S3 bucket*
"""

import os
import sys
import json
import re
import boto3
import uuid
from datetime import datetime
from dateutil.relativedelta import relativedelta
from dateutil import parser
import time
from awsglue.utils import getResolvedOptions
from botocore.exceptions import ClientError
from ReduceReuseRecycle import load_log_config, InvalidStatus

LOGGER = load_log_config(glue=True)

LOGGER.info("Reading Glue Job Parameters... \n")

# Parse Arguments for Glue Job

params = ['etl_stp_parms']
#---------------------------------------------------------------------------------#
#Parse Arguments for Glue Job                                                     #
#---------------------------------------------------------------------------------#
ARGS = getResolvedOptions(sys.argv, params)
                                    
etl_parms           = json.loads(ARGS['etl_stp_parms'])
#---------------------------------------------------------------------------------#
#Boto3 Clients for Glue, s3 and SNS                                               #
#---------------------------------------------------------------------------------#
glue = boto3.client('glue')
client = boto3.client('s3')
sns = boto3.client('sns')

#---------------------------------------------------------------------------------#
#Fucntion to Get the account information                                          #
#---------------------------------------------------------------------------------#
class acc_info:
    sts_function_client=boto3.client('sts')
    def __init__(self):
        acc_details=acc_info.sts_function_client.get_caller_identity()
        self.account=acc_details['Account']
    @property
    def get_account(self):
        return self.account

#---------------------------------------------------------------------------------#
# Function to Send SNS for Success                                                #
#---------------------------------------------------------------------------------#
def snsPublication(LOGGER, subject, message,env):
    region_name = os.environ['AWS_DEFAULT_REGION']
    account = acc_info().get_account
    sns_arn = 'arn:aws:sns:' \
              + region_name + ':' \
              + account + ':{env}-snsCIIPublication'.format(env=env)
    subject = subject
    LOGGER.info('SNS ARN: %s', sns_arn)
    try:
        formatted_msg = message
        response = sns.publish(TargetArn=sns_arn,
                              Message=formatted_msg,
                              Subject=subject,
                              MessageStructure='string'
                              )
                               
        LOGGER.info('SNS Response: %s', response)
    except ClientError as sns_error:
        LOGGER.critical('*** SNS Message Publication Failed: %s ***', sns_error)
        raise sns_error
    	

#---------------------------------------------------------------------------------#
# Function to Send SNS for Failure                                                #
#---------------------------------------------------------------------------------#
def snsNotification(LOGGER, subject, message,env):
    region_name = os.environ['AWS_DEFAULT_REGION']
    account = acc_info().get_account
    sns_arn = 'arn:aws:sns:' \
              + region_name + ':' \
              + account + ':{env}-snsCIINotification'.format(env=env)
    subject = subject
    LOGGER.info('SNS ARN: %s', sns_arn)
    try:
        formatted_msg = message
        response = sns.publish(TargetArn=sns_arn,
                              Message=formatted_msg,
                              Subject=subject,
                              MessageStructure='string'
                              )
                               
        LOGGER.info('SNS Response: %s', response)
    except ClientError as sns_error:
        LOGGER.critical('*** SNS Message Notification Failed: %s ***', sns_error)
        raise sns_error

#---------------------------------------------------------------------------------#
#Fucntion to run the OS system command                                            #
#---------------------------------------------------------------------------------#
def run_command(command):
    """
    Function to execute a subprocess.run command
    :param command:
    :return: True if successful
    """

    try:
        result = os.system(command)
        # subprocess.run(command_list, stdout=subprocess.PIPE)

        LOGGER.info(result)

        if result >> 8 == 1:
            raise InvalidStatus(f"One or more S3 transfer operations failed: %s" % command)

    except Exception as excp:
        LOGGER.error(format(excp))
        raise InvalidStatus(f"run_command failed: %s" % command)
        return false

    return True

#---------------------------------------------------------------------------------#
#Fucntion to delete and s3 file                                                   #
#---------------------------------------------------------------------------------#
def delete_s3_files(s3_target_bucket, s3_target_key):
    """
    :param s3_target_bucket: S3 Bucket where the delete will be performed
    :param s3_target_key: S3 Key of data to be copied
    :return: True if object was delete successfully
    """

    s3_bucket_path = s3_target_bucket + '/' + s3_target_key
    
    command1 = 'aws s3 rm s3://' + s3_bucket_path + ' --recursive'
    command2 = 'aws s3 rm s3://' + s3_bucket_path

    try:
        run_command(command1)
        run_command(command2)

    except Exception as error:
        LOGGER.error(error)
        raise InvalidStatus(f"Delete s3 failed: %s" % command)
        return False

    return True

#---------------------------------------------------------------------------------#
#Fucntion to Upload an object to S3                                               #
#---------------------------------------------------------------------------------#
def upload_s3_object(s3_path, data):
    """
    Function to upload file to s3
    :param bucket_name: Bucket name for s3 upload
    :param object_key: key name for s3 upload
    :param table_nm: Table name for s3 upload
    :return: None
    """
    
    s3 = boto3.resource('s3')
    bucket = s3_path.split("//")[1].split("/")[0]
    key = "/".join(s3_path.replace("//", "").split("/")[1:])
    obj = s3.Object(bucket, key)
    
    #LOGGER.info("\n Uploading s3 object {} \n".format(s3_path))
    obj.put(Body=data)
    
    return

#---------------------------------------------------------------------------------#
#Fucntion to delete files for archive S3 bucket                                   #
#---------------------------------------------------------------------------------#
def delete_s3_files_for_archive_bucket(env,s3_cleanup_bucket_name, s3_cleanup_folder_name,delete_files,s3_cleanup_output_path,number_of_months_to_keep,account):
    """
    :param s3_cleanup_bucket_name: S3 Bucket where the delete will be performed
    :param s3_cleanup_folder_name: S3 Key of for files to be identified
    :delete_files: if yes other than last three months(including current month) remaining will be deleted
                   otherwise only files identified will be written s3, no deletion happens
    """
    bucket_name = s3_cleanup_bucket_name
    key_name = s3_cleanup_folder_name
    number_of_months_to_keep=int(number_of_months_to_keep)
    region = os.environ['AWS_DEFAULT_REGION']
    date_time_format1 = "%Y-%m"
    date_time_format2 = "%Y%m"
    current_year=datetime.today().year
    current_month=datetime.today().month
    current_day=datetime.today().day
    hour=datetime.today().hour
    minute=datetime.today().minute
    second=datetime.today().second
    s3_path_to_delete = ""
    s3_path_to_delete_copy = ""
    delete_log_key = uuid.uuid1()
    delete_dtm = time.strftime('%Y-%m-%d %H:%M:%S')
    deleted_files_path_list_s3 = []
    deleted_files_path_list = []
    files_path_list_count=0
    size_in_bytes=0
    total_size_in_bytes=0
    file_count=0
    i=0
    output_bucket="antm-cii-{env}-cnfz-nogbd-phi-useast1".format(env=env)
    output_file_path = s3_cleanup_output_path + "/" + "s3cleanupprocess" + "/" + "archive_files" + "/"

    kwargs = {'Bucket': bucket_name, 'Prefix': key_name}
    while True:
      result = client.list_objects_v2(**kwargs)
      if(result['KeyCount']==0):
      	LOGGER.info('No Files Matching found for the given path', bucket_name + "/" + key_name)
      	break
      else:
        for key in result[ "Contents" ]:
            keyString = key[ "Key" ]
            size_in_bytes = key["Size"]
            s3_path_to_delete = keyString[:keyString.rfind('/')]
            while (i < number_of_months_to_keep):
                if (re.findall(str((parser.parse(str(current_year) +"-"+ str(current_month) + "-" + "01").date() - relativedelta(months=i)).strftime(date_time_format1)),keyString) or re.findall(str((parser.parse(str(current_year) +"-"+ str(current_month) + "-" + "01").date() - relativedelta(months=i)).strftime(date_time_format2)),keyString)):
                    file_flag=True
                    break
                else:
                    file_flag=False
                    i = i + 1
            i=0
            if not(file_flag):
            		total_size_in_bytes = float(total_size_in_bytes) + float(size_in_bytes)
            		if (s3_path_to_delete == s3_path_to_delete_copy):
            			continue
            		else:
            			deleted_files_path_list_s3.append({"s3_path_deleted":s3_path_to_delete, "delete_log_key":str(delete_log_key), "delete_dtm":delete_dtm})
            			deleted_files_path_list.append(s3_path_to_delete)
            			s3_path_to_delete_copy = s3_path_to_delete
            			files_path_list_count = files_path_list_count + 1
            			if(files_path_list_count == 10000):
            				file_count = file_count + 1 
            				upload_s3_object(output_file_path + str(current_year) + str(current_month) + str(current_day) + str(hour)+ str(minute) + str(second) + "/" + str(file_count) + "_cii_archive_delete_files_list.json", json.dumps(deleted_files_path_list_s3))
            				deleted_files_path_list_s3 = []
            				files_path_list_count = 0

        try:
            kwargs['ContinuationToken'] = result['NextContinuationToken']
        except KeyError:
            break
    #Writing the files to S3 after coming our from While Loop, to not to miss anything which was not written
    file_count = file_count + 1
    upload_s3_object(output_file_path + str(current_year) + str(current_month) + str(current_day) + str(hour)+ str(minute) + str(second) + "/" + str(file_count) + "_cii_archive_delete_files_list.json", json.dumps(deleted_files_path_list_s3))
    
    #Deleting the files which were collected to deleted_files_path_list
    if(delete_files=='YES'):
    	for path in deleted_files_path_list:
    	    LOGGER.info('Folder being deleted - ' + path)
    	    delete_s3_files(bucket_name, path)
    else:
    	LOGGER.info('Delete not perfomed for the identified folders')
    
    total_folders=len(deleted_files_path_list)
    data_size_cleanedup_in_tb = float((((float(total_size_in_bytes)/1024)/1024)/1024)/1024)
    
    subject = f'Succeeded: CII S3 Cleanup for Archive Bucket:{bucket_name}'
    message_template = """
       Cleanedup Bucket: {bucket_name}
       Cleanedup S3 Path: {key_name}
       Total Folders Cleanedup: {total_folders}
       Total Size Freed in TB: {data_size_cleanedup_in_tb}
       Delete Option Choosen: {delete_files}
       Note: If Delete Option choosen is YES then only files gets deleted otherwise Deletion not happens
        """.format(
        bucket_name=bucket_name,
        key_name=key_name,
        total_folders=total_folders,
        data_size_cleanedup_in_tb=data_size_cleanedup_in_tb,
        delete_files=delete_files
        )
    snsPublication(LOGGER, subject, message_template,env)
    
    return message_template
#---------------------------------------------------------------------------------#
#Fucntion to Caluculate the Size of a S3 Folder under a Bucket                    #
#---------------------------------------------------------------------------------#
def calc_size(env,s3_cleanup_bucket_name, pattern_cleanup_regex_list,account):
    """
    :param s3_cleanup_bucket_name: S3 Bucket where the delete will be performed
    :pattern_cleanup_regex_list: list which helps to identify the files to keep
    """
    bucket_name = s3_cleanup_bucket_name
    region = os.environ['AWS_DEFAULT_REGION']
    size_of_folders = []
    total_size_of_folders_in_pattern = 0
    
    for path in pattern_cleanup_regex_list:
        size_in_bytes=0
        total_size_in_bytes=0
        file_count=0
        kwargs = {'Bucket': bucket_name, 'Prefix': path}
        while True:
            result = client.list_objects_v2(**kwargs)
            if(result['KeyCount']==0):
                break
            else:
                for key in result[ "Contents" ]:
                    keyString = key[ "Key" ]
                    size_in_bytes = key["Size"]
                    total_size_in_bytes = float(total_size_in_bytes) + float(size_in_bytes)
                    total_size_of_folders_in_pattern = float(total_size_of_folders_in_pattern) + float(size_in_bytes)
                try:
                    kwargs['ContinuationToken'] = result['NextContinuationToken']
                except KeyError:
                    break
        size_of_folders.append({"s3_folder_path":path, "size_in_TB":str(float((((float(total_size_in_bytes)/1024)/1024)/1024)/1024))})
    
    return size_of_folders, float((((float(total_size_of_folders_in_pattern)/1024)/1024)/1024)/1024)

#---------------------------------------------------------------------------------#
#Fucntion to delete files for specified pattern for an S3 bucket                  #
#---------------------------------------------------------------------------------#
def delete_s3_files_for_pattern(env,s3_cleanup_bucket_name, s3_cleanup_folder_name,pattern_cleanup_regex_string,pattern_cleanup_regex_list,delete_files,s3_cleanup_output_path,account):
    """
    :param s3_cleanup_bucket_name: S3 Bucket where the delete will be performed
    :param s3_cleanup_folder_name: S3 Key of for files to be identified
    :pattern_cleanup_regex_list: list which helps to identify the files to keep
    """
    bucket_name = s3_cleanup_bucket_name
    key_name = s3_cleanup_folder_name
    region = os.environ['AWS_DEFAULT_REGION']
    current_year=datetime.today().year
    current_month=datetime.today().month
    current_day=datetime.today().day
    hour=datetime.today().hour
    minute=datetime.today().minute
    second=datetime.today().second
    s3_path_to_delete = ""
    s3_path_to_delete_copy = ""
    delete_log_key = uuid.uuid1()
    delete_dtm = time.strftime('%Y-%m-%d %H:%M:%S')
    deleted_files_path_list_s3 = []
    deleted_files_path_list = []
    base_path_value = []
    files_path_list_count=0
    size_in_bytes=0
    total_size_in_bytes=0
    file_count=0
    output_bucket="antm-cii-{env}-cnfz-nogbd-phi-useast1".format(env=env)
    output_file_path = s3_cleanup_output_path + "/" + "s3cleanupprocess" + "/" + "pattern_cleanup_files" + "/"
    
    #Collecting the base path value from input regex pattern values
    for value in pattern_cleanup_regex_list:
        base_path_value.append(value.split('/')[0])
    LOGGER.info('Base Path Values List' + str(base_path_value))
    kwargs = {'Bucket': bucket_name, 'Prefix': key_name}
    while True:
      result = client.list_objects_v2(**kwargs)
      if(result['KeyCount']==0):
      	LOGGER.info('No Files Matching found for the given path,' + bucket_name + "/" + key_name)
      	break
      else:
        for key in result[ "Contents" ]:
            keyString = key[ "Key" ]
            if(keyString.strip() in pattern_cleanup_regex_list):
                LOGGER.info('#1Skipping the Folder - ' + keyString)
            else:
                size_in_bytes = key["Size"]
                s3_path_to_delete = keyString[:keyString.rfind('/')]
                for regex_string in pattern_cleanup_regex_list:
                    if ((re.findall(regex_string.strip(),keyString)) or (re.findall(keyString, regex_string.strip())) or regex_string.strip()==s3_path_to_delete+'/'):
                        file_flag=True
                        break
                    else:
                        file_flag=False
                if not(file_flag):
                        total_size_in_bytes = float(total_size_in_bytes) + float(size_in_bytes)
                        if (re.findall(s3_path_to_delete, pattern_cleanup_regex_string.strip())):
                           deleted_files_path_list_s3.append({"s3_path_deleted":keyString, "delete_log_key":str(delete_log_key), "delete_dtm":delete_dtm})
                           deleted_files_path_list.append(keyString)
                           files_path_list_count = files_path_list_count + 1
                        else:
                            if(s3_path_to_delete.strip().lower() in base_path_value or s3_path_to_delete.strip() in pattern_cleanup_regex_list):
                                LOGGER.info('#2Skipping the Folder - ' + s3_path_to_delete)
                            else:
                                if(s3_path_to_delete_copy == s3_path_to_delete):
                                    continue
                                else:
                                    deleted_files_path_list_s3.append({"s3_path_deleted":s3_path_to_delete, "delete_log_key":str(delete_log_key), "delete_dtm":delete_dtm})
                                    deleted_files_path_list.append(s3_path_to_delete)
                                    s3_path_to_delete_copy = s3_path_to_delete
                                    files_path_list_count = files_path_list_count + 1
                                    if(files_path_list_count >= 10000):
                                        file_count = file_count + 1
                                        upload_s3_object(output_file_path + str(current_year) + str(current_month) + str(current_day) + str(hour)+ str(minute) + str(second) + "/" + str(file_count) + "_cii_pattern_delete_files_list.json", json.dumps(deleted_files_path_list_s3))
                                        deleted_files_path_list_s3 = []
                                        files_path_list_count = 0

        try:
            kwargs['ContinuationToken'] = result['NextContinuationToken']
        except KeyError:
            break
    #Writing the files to S3 after coming our from While Loop, to not to miss anything which was not written
    file_count = file_count + 1
    upload_s3_object(output_file_path + str(current_year) + str(current_month) + str(current_day) + str(hour)+ str(minute) + str(second) + "/" + str(file_count) + "_cii_pattern_delete_files_list.json", json.dumps(deleted_files_path_list_s3))
    
    #Deleting the files which were collected to deleted_files_path_list
    if(delete_files=='YES'):
        for path in deleted_files_path_list:
            LOGGER.info('Folder being deleted - ' + path)
            delete_s3_files(bucket_name, path)
    else:
        LOGGER.info('Delete not perfomed for the identified folder')
    
    total_folders=len(deleted_files_path_list)
    data_size_cleanedup_in_tb = float((((float(total_size_in_bytes)/1024)/1024)/1024)/1024)
    size_of_each_folder_in_pattern, total_size_of_folders_in_pattern = calc_size(env,s3_cleanup_bucket_name, pattern_cleanup_regex_list,account)
    
    subject = f'Succeeded: CII S3 Cleanup for specific pattern Bucket:{bucket_name}'
    message_template = """
        Cleanedup Bucket: {bucket_name}
        Cleanedup S3 Path: {key_name}
        Total Files/Folders Cleanedup: {total_folders}
        Total Size Freed in TB: {data_size_cleanedup_in_tb}
        Delete Option Choosen: {delete_files}
        Pattern Used: {pattern_cleanup_regex_string}
        
        size_of_each_folder_in_pattern: {size_of_each_folder_in_pattern}
        total_size_of_folders_in_pattern_in_TB: {total_size_of_folders_in_pattern}
        Note: If Delete Option choosen is YES then only files gets deleted otherwise Deletion not happens
        """.format(
        bucket_name=bucket_name,
        key_name=key_name,
        total_folders=total_folders,
        data_size_cleanedup_in_tb=data_size_cleanedup_in_tb,
        delete_files=delete_files,
        pattern_cleanup_regex_string=pattern_cleanup_regex_list,
        size_of_each_folder_in_pattern=size_of_each_folder_in_pattern,
        total_size_of_folders_in_pattern=total_size_of_folders_in_pattern
        )
    snsPublication(LOGGER, subject, message_template,env)
    
    return message_template
 
#---------------------------------------------------------------------------------#
#Main Function - Bussines Logic Starts here                                       #
#---------------------------------------------------------------------------------#
def main():
    """
    This is Job if the paramters - delete_files, s3_cleanup_for_archive_bucket set to 'YES',
    deletes data from the given archive bucket by keeping last three months(including current month) data, It uses matching pattern example - 202112 or 2021-12 to identify files for a month
    which are having these dates in the file paths. Other than the last three months(including current month) remaining files are deleted from the archive bucket.
    Note: Data in Archive buckets in CII are stored as date in 20211201* or 2021-12-01* format as one of folder names in the S3 path
    """
    #Parameters Needed
    env = etl_parms.get('env').strip().lower()
    s3_cleanup_bucket_name = etl_parms.get('s3_cleanup_bucket_name').strip()
    s3_cleanup_folder_name = etl_parms.get('s3_cleanup_folder_name').strip()
    s3_cleanup_output_path = etl_parms.get('s3_cleanup_output_path').strip()
    number_of_months_to_keep = etl_parms.get('number_of_months_to_keep').strip()
    delete_files = etl_parms.get('delete_files').strip().upper()
    s3_cleanup_for_archive_bucket = etl_parms.get('s3_cleanup_for_archive_bucket').strip().upper()
    only_pattern_input_size_scan = etl_parms.get('only_pattern_input_size_scan').strip().upper()
    pattern_cleanup = etl_parms.get('pattern_cleanup').strip().upper()
    pattern_cleanup_bucket_name = etl_parms.get('pattern_cleanup_bucket_name').strip()
    pattern_cleanup_folder_name = etl_parms.get('pattern_cleanup_folder_name').strip()
    pattern_cleanup_regex_string = etl_parms.get('pattern_cleanup_regex_string').strip()
    pattern_cleanup_regex_list = etl_parms.get('pattern_cleanup_regex_string').strip().split('|')
    load_log_key = uuid.uuid1()
    region = os.environ['AWS_DEFAULT_REGION']
    account = acc_info().get_account
    
    LOGGER.info(f'\n**** Argument List ****\n-----------------------')
    LOGGER.info(f'\nENV : {env} \ns3_cleanup_bucket_name : {s3_cleanup_bucket_name} \ns3_cleanup_folder_name : {s3_cleanup_folder_name} \ns3_cleanup_output_path : {s3_cleanup_output_path} \nnumber_of_months_to_keep : {number_of_months_to_keep} \ndelete_files : {delete_files}  '
            f'\nonly_pattern_input_size_scan : {only_pattern_input_size_scan} \ns3_cleanup_for_archive_bucket : {s3_cleanup_for_archive_bucket} \npattern_cleanup : {pattern_cleanup} \npattern_cleanup_bucket_name : {pattern_cleanup_bucket_name} \npattern_cleanup_folder_name : {pattern_cleanup_folder_name} \npattern_cleanup_regex_string : {pattern_cleanup_regex_list} ')
    LOGGER.info(f'\n-----------------------\n')

    #Deleting the files and folder under s3_cleanup_bucket_name as per the archive policy
    try:
    	if(s3_cleanup_for_archive_bucket=='YES' or pattern_cleanup=='YES' or only_pattern_input_size_scan == 'YES'):
    	    if(s3_cleanup_for_archive_bucket=='YES'):
    	        LOGGER.info(f'\nCalling the delete_s3_files_for_archive_bucket function \n')
    	        delete_files = delete_s3_files_for_archive_bucket(env,s3_cleanup_bucket_name, s3_cleanup_folder_name,delete_files,s3_cleanup_output_path,number_of_months_to_keep,account)
    	        LOGGER.info(f'\nResult of delete_s3_files_for_archive_bucket function: {delete_files} \n')
    	    if((pattern_cleanup=='YES') and pattern_cleanup_regex_list[0].upper() != 'NA'):
    	        LOGGER.info(f'\nCalling the delete_s3_files_for_pattern function \n')
    	        delete_files = delete_s3_files_for_pattern(env,pattern_cleanup_bucket_name, pattern_cleanup_folder_name,pattern_cleanup_regex_string,pattern_cleanup_regex_list,delete_files,s3_cleanup_output_path,account)
    	        LOGGER.info(f'\nResult of delete_s3_files_for_pattern function: {delete_files} \n')
    	    if(only_pattern_input_size_scan == 'YES'):
    	        LOGGER.info(f'\nCalling the only S3 Size for Pattern Folders \n')
    	        size_of_each_folder_in_pattern, total_size_of_folders_in_pattern = calc_size(env,pattern_cleanup_bucket_name, pattern_cleanup_regex_list,account)
    	        subject = f'Succeeded: CII S3 Cleanup Only Size Scan for pattern - Bucket:{pattern_cleanup_bucket_name}'
    	        message_template = """
    	        Cleanedup Bucket: {bucket_name}
    	        only pattern input folders size scan: {only_pattern_input_size_scan}
    	        Pattern Used: {pattern_cleanup_regex_string}
    	        
    	        size_of_each_folder_in_pattern: {size_of_each_folder_in_pattern}
    	        total_size_of_folders_in_pattern_in_TB: {total_size_of_folders_in_pattern}
    	        """.format(
    	        bucket_name=pattern_cleanup_bucket_name,
    	        only_pattern_input_size_scan=only_pattern_input_size_scan,
    	        pattern_cleanup_regex_string=pattern_cleanup_regex_list,
    	        size_of_each_folder_in_pattern=size_of_each_folder_in_pattern,
    	        total_size_of_folders_in_pattern=total_size_of_folders_in_pattern
    	        )
    	        snsPublication(LOGGER, subject, message_template,env)
    	else:
    	  LOGGER.info(f'\nInvalid Inputs for s3_cleanup_for_archive_bucket or pattern_cleanup \n')
    	  LOGGER.info(f'\nPass YES only for s3_cleanup_for_archive_bucket or pattern_cleanup \n')
    	  LOGGER.info(f'\nIf you Pass YES for pattern_cleanup pass proper value for pattern_cleanup_regex_string as well\n')
    	  exit(1)
    except Exception as e:
        LOGGER.info(f'\nError Details' + str(e))
        snsNotification(LOGGER, f'Failed: CII S3 Cleanup', f'Failed for s3_cleanup_for_archive_bucket:{s3_cleanup_for_archive_bucket}, s3_cleanup_bucket_name:{s3_cleanup_bucket_name} or pattern_cleanup:{pattern_cleanup}, pattern_cleanup_bucket_name:{pattern_cleanup_bucket_name}',env)
        exit(1)
 
if __name__ == "__main__":
    main()