from awsglue.utils import getResolvedOptions
from boto_wrapper import sfs,acc_info,secretkey
from query_variables import *
import logging
import json
import sys
import os
import boto3
import base64
from datetime import date, time
from botocore.exceptions import ClientError
import psycopg2
import time

# Define mandatory params
params = ['etl_stp_parms']
 
# Parse Arguments for Glue Job
ARGS = getResolvedOptions(sys.argv, params)
                                    
#print("$$$$ 1st checkpoint")
#set Variables
etl_parms           = json.loads(ARGS['etl_stp_parms'])
                                            
# read from parmeters
environment = etl_parms.get('env').strip().lower()
db_config_path = etl_parms.get('db_config').strip()

# Define Functions
def load_log_config():
    """
    # Basic config. Replace with your own logging config if required
    :return: object for basic logging
    """
    global logger

    MSG_FORMAT = '%(asctime)s %(levelname)s %(name)s: %(message)s'
    DATETIME_FORMAT = '%Y-%m-%d %H:%M:%S'
    logging.basicConfig(format=MSG_FORMAT, datefmt=DATETIME_FORMAT)
    logger = logging.getLogger("ACIISST_ADHOC_FLD_DTLS")

    logger.setLevel(logging.INFO)


def get_secret(secret_name):
    """
    Function to fetch details from AWS Secrets Manager
    Usage   : Get Secret JSON String
    Args    : Secret Name
    Returns : Secure string of Secret
    Raises  : Exception While getting the Secret.

    """
    secret = ''
    secret_client = boto3.client("secretsmanager")

    try:
        get_secret_value_response = secret_client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as error:
        if error.response['Error']['Code'] == 'DecryptionFailureException':
            raise error
        elif error.response['Error']['Code'] == 'InternalServiceErrorException':
            raise error
        elif error.response['Error']['Code'] == 'InvalidParameterException':
            raise error
        elif error.response['Error']['Code'] == 'InvalidRequestException':
            raise error
        elif error.response['Error']['Code'] == 'ResourceNotFoundException':
            raise error
    else:
        if 'SecretString' in get_secret_value_response:
            secret = get_secret_value_response['SecretString']
            return secret
        else:
            decoded_binary_secret = base64.b64decode(
                get_secret_value_response['SecretBinary'])
            return decoded_binary_secret


def rds_conn(host_name, secret_name, port_no, schema_name):
    """
    Function to use Secrets Manager to create an RDS Connection Object
    :param host_name: Host name of the RDS
    :param secret_name: secret name for fetching user password
    :param port_no: Port Number of RDS
    :param schema_name: Schema Name in RDS
    :return: RDS Connection Object
    """
    try:
        secure_string   = get_secret(secret_name)
        secure_dict     = json.loads(secure_string)
        postgre_username  = secure_dict.get('username')
        postgre_password  = secure_dict.get('password')
        engine = psycopg2.connect(
            database=schema_name,
            user=postgre_username,
            password=postgre_password,
            host=host_name,
            port=port_no
        )
    except Exception as err:
        logger.critical("ERROR: Unexpected error: Could not connect to Aurora instance.")
        logger.critical('*** ERROR: %s ***', err)
        raise err

    return engine

def _read_s3_object(s3_path):
    """
    Function to read object from s3 path
    :param s3_path: S3 object full path
    :return: object
    """
    s3 = boto3.resource('s3')
    bucket = s3_path.split("//")[1].split("/")[0]
    key = "/".join(s3_path.replace("//", "").split("/")[1:])

    logger.info("Reading S3 obj {}".format(s3_path))
    obj = s3.Object(bucket, key)

    return obj
#---------------------------------------------------------------------------------#
#Fucntion to Upload an object to S3                                               #
#---------------------------------------------------------------------------------#
def upload_s3_object(s3_path, data):
    """
    Function to upload file to s3
    :param bucket_name: Bucket name for s3 upload
    :param object_key: key name for s3 upload
    :param table_nm: Table name for s3 upload
    :return: None
    """
    
    s3 = boto3.resource('s3')
    bucket = s3_path.split("//")[1].split("/")[0]
    key = "/".join(s3_path.replace("//", "").split("/")[1:])
    obj = s3.Object(bucket, key)
    
    logger.info("\n Uploading s3 object {} \n".format(s3_path))
    obj.put(Body=data)
    
    return


def  lov(conn,cursor):
    """
    Function to execute the sql

    """

    # 1. SELECT
    cursor.execute("""select 'SELECT DISTINCT ''' || kkey || ''',' || regexp_replace(value, E'[\\n\\r\\t]+', ' ', 'g' ) from (
select distinct
       tbl_nm || '.' || fld_als_txt as kkey ,
       max(case when scndry_tbl_nm is null then
       fld_sql_txt || ' FROM ' || tbl_nm 
       else
       fld_sql_txt || ' FROM ' || prmry_tbls.prmry_tbl_nm || ' ' || sql_txt end) as value 
       from {db_name}.aciisst_adhoc_fld_dtls aafd
join (
       select
              distinct UPPER(fld_cntxt_txt) as fld_cntxt_txt , UPPER(tbl_nm) as prmry_tbl_nm
       from
              {db_name}.aciisst_adhoc_fld_dtls aafd1
       where
              prmry_ind = 'Y' ) prmry_tbls on
       aafd.fld_cntxt_txt = prmry_tbls.fld_cntxt_txt
       
left join {db_name}.aciisst_tbl_join atj on
       aafd.tbl_nm = atj.scndry_tbl_nm and atj.prmry_tbl_nm = prmry_tbls.prmry_tbl_nm

where upper(actv_ind) = 'Y'
       and upper(dsply_ind) = 'Y'
       and upper(fltr_ind) = 'L'
       group by 1
       )aa
where value not like '%TM_PRD_NM%' 
       order by 1
                  """.format(db_name=DBname))
    result = cursor.fetchall()
    logger.info("Completed SELECT")
    
    output_data = ""

    for row_tuple in result:
	    output_data = output_data + ",".join(row_tuple) + "\n"


    return output_data

def main():
    """
    Main Processing Function
    :param mnthly_ind: Argument.
    :param db_config_path: Configuration file s3 path for database RDS variables
    """
    # Logger Information for the Script

    load_log_config()

    # Defining global Variables
    global databaseName, preval_databaseName , DBname


    # Reads the configuration File from S3
    json_obj = _read_s3_object(db_config_path)
    config = json.loads(json_obj.get()['Body'].read().decode('utf-8'))
    logger.info(f"Config Details - {config}")
    # Getting RDS connection Details from configuration file
    databaseName = config['database_details']['database']
    schema_name = config['database_details']['schema']
    host = config['database_details']['host']
    port = config['database_details']['port']
    secret_name = config['database_details']['secret_name']
    preval_databaseName = config['database_details']['preval_database']
    # user = config['database_details']['user']
    # passwd = config['database_details']['passwd']

    # Creates RDS Connection Object and Cursor
    conn = rds_conn(host, secret_name, port, schema_name)
    cursor = conn.cursor()
    logger.info("Connection to RDS has been established, Cursor is created.")
    
    
    DBname = ''
    
    if environment == 'prod':
        DBname = preval_databaseName
    elif environment == 'preval':
        DBname = preval_databaseName
    elif environment in ('dev','sit','uat','preprod'):
        DBname = databaseName
    else:
        raise ValueError("Invalid parameters has been passed for environment key , Possible parameters are  'prod','preval','preprod','dev','sit','uat' ")
        
    logger.info(f"Environment is {environment}   and  Database  {DBname} is selected ")

    DBnm = ''
    
    if environment == 'prod':
        DBnm = 'p01_cii_adhoc_cons'
    elif environment == 'dev':
        DBnm = 'd01_cii_adhoc_cons'
    elif environment == 'sit':
        DBnm = 't01_cii_adhoc_cons'
    elif environment == 'uat':
        DBnm = 'u01_cii_adhoc_cons'
    elif environment == 'preprod':
        DBnm = 'r01_cii_adhoc_cons'
    else:
        raise ValueError("Invalid parameters has been passed for environment key , Possible parameters are  'prod','dev','sit','uat' ")

    # Calling function
    xyz = lov(conn,cursor)
    logger.info("Completed lov function")
    #Reading from RDS and writing to S3
    s3_path = f"s3://antm-cii-{environment}-cnfz-nogbd-phi-useast1/cii/es/abc.txt"
    upload_s3_object(s3_path,xyz)
    logger.info("RDS data written successfully into S3")

    logger.info("Committing all the changes made and closing the RDS Connection")
    conn.commit()
    conn.close()
    #Commands to delete the files in s3 folder estgt
    bucket_path = f"antm-cii-{environment}-cnfz-nogbd-phi-useast1"
    s3_fldr_rm = boto3.resource('s3')
    bucket = s3_fldr_rm.Bucket(bucket_path)
    for obj in bucket.objects.filter(Prefix='cii/estgt/'):
     s3_fldr_rm.Object(bucket.name,obj.key).delete()
    logger.info("Files in s3 folder estgt removed successfully")
	
    error_path = f"s3://antm-cii-{environment}-cnfz-nogbd-phi-useast1/cii/eserror/error.txt"
    tgt_path = f"s3://antm-cii-{environment}-cnfz-nogbd-phi-useast1/cii/estgt"
	#Athena connectivity and execute queries line by line
    s3_obj = _read_s3_object(s3_path)
    file_cntnt = s3_obj.get()['Body'].read().decode('utf-8')
    client = boto3.client('athena')
    sql_cnt = 0
    query_id_list = []
    error_sql = ""
    for line in file_cntnt.split("\n"):
       if len(line) > 6:
          try:
              query = client.start_query_execution(
              QueryString=line,
			  QueryExecutionContext={
				'Database': DBnm
			  },
			  ResultConfiguration={
				'OutputLocation': tgt_path
			  },
			  WorkGroup='primary'
			  )
          except:
              print('Entered except block: {}'.format(query))
              error_sql = error_sql + line + "\n"
              print('Query failed is: {}'.format(line))

          query_id = query['QueryExecutionId']
          query_id_list.append(query_id)

       time.sleep(30)

    for qid in query_id_list:
        response = client.get_query_execution(
	    QueryExecutionId=qid
        )
        query_status = response['QueryExecution']['Status']['State']
        query_sql = response['QueryExecution']['Query']
        while (query_status == "QUEUED" or query_status == "RUNNING"):
           time.sleep(10)
           response = client.get_query_execution(
	       QueryExecutionId=qid
           )
           query_status = response['QueryExecution']['Status']['State']
           
        if query_status == "FAILED":
           error_sql = error_sql + query_sql + "\n"

        #time.sleep(10)

     
    upload_s3_object(error_path,error_sql)
    
    logger.info("Connected to Athena and query execution completed successfully")

    return


if __name__ == '__main__':
    main()
