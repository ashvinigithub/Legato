############################################################################################################## 
# Description   : Glue job to Process Standard Insights L#2 Reports for each Request/RPT_RUN_ID
# Author        : Legato
# Created       : 06/08/2022 
# Version       : V1.0
# Version Description : Initial Version
# last Updated  : ##-###-####
############################################################################################################## 
"""
DOCSTRING : Glue job to Process Standard Insights L#2 Reports for each Request/RPT_RUN_ID
"""
import re
from boto_wrapper import sfs,acc_info,secretkey
import logging
import json
import sys
import os
import boto3
import base64
from datetime import date, time
from botocore.exceptions import ClientError
import psycopg2
import uuid
import pandas as pd
from datetime import *
import time
from awsglue.utils import getResolvedOptions
from botocore.exceptions import ClientError
from ReduceReuseRecycle import load_log_config, InvalidStatus
import sys
from awsglue.utils import getResolvedOptions
# Parse Arguments for Glue Job
params = ['etl_stp_parms']
# Parse Arguments for Glue Job
ARGS = getResolvedOptions(sys.argv, params)
#set Variables
etl_parms = json.loads(ARGS['etl_stp_parms'])
ENV = etl_parms.get('env').strip()
envn = ENV

from ReduceReuseRecycle import download_site_packages
download_site_packages(envn)

from ReduceReuseRecycle import *
from ReduceReuseRecycle.snowflakefunc import *
from ReduceReuseRecycle.pymysqlfunc import *
from ReduceReuseRecycle.psycopgfunc import *
#---------------------------------------------------------------------------------#
# Creating boto3 client for glue, stepfuntion, s3, sns                            #
#---------------------------------------------------------------------------------#
glue = boto3.client('glue')
client = boto3.client('s3')
sns = boto3.client('sns')
sfn = boto3.client('stepfunctions')
LOGGER = load_log_config(glue=True)
#-------------------------------------------------------------------------------------------------------------------#
# Function to Log Error in RDS Table - etl_evolve_job_hist, for a given RPT_RUN_ID
#-------------------------------------------------------------------------------------------------------------------#
def log_error_to_rds(LOGGER, conn_sf, cursor_sf, conn_rds, cursor_rds, rpt_run_id, rpt_strt_dtm, number_of_tries, rpt_stts, rpt_err_log, rqst_stts_txt):
    try:
        #Taking the current_timestamp for End time
        cursor_sf.execute("select current_timestamp")
        rpt_end_dtm = str(cursor_sf.fetchone()[0])[:26]
        rpt_err_log = rpt_err_log.replace("'"," ")
        LOGGER.info(f'*** Executing the Query on RDS to log status/error details for rpt_run_id:{rpt_run_id} ***')
        query_to_log_error = f"""insert into aciisst_appl.etl_evolve_job_hist select {rpt_run_id} as rpt_run_id, '{rpt_strt_dtm}' as rpt_strt_dtm, '{rpt_end_dtm}' as rpt_end_dtm, {number_of_tries} as number_of_tries, '{rpt_stts}' as rpt_stts, '{rpt_err_log}' as rpt_err_log, 88888 as creatd_by_user_id, 88888 as updtd_by_user_id, current_timestamp as creatd_dtm, current_timestamp as updtd_dtm"""
        LOGGER.info(f'*** Executing the Query on RDS to log status/error details :{query_to_log_error} ***')
        cursor_rds.execute(query_to_log_error)
        conn_rds.commit()
        #Error Details for table - 
        rpt_err_log_rqst = rpt_err_log[:2450]
        #Updating status for given rpt_run_id in RDS table - aciisst_rpt_cstm_rqst
        query_to_update = f"update aciisst_appl.aciisst_rpt_cstm_rqst set rqst_stts_txt = '{rqst_stts_txt}', err_txt = '{rpt_err_log_rqst}',updtd_dtm = '{rpt_end_dtm}', updtd_by_user_id = 88888 where pkg_id = {rpt_run_id}"
        LOGGER.info(f'*** Executing the Query on RDS to log status of rpt_run_id :{rpt_run_id}, {query_to_update} ***')
        cursor_rds.execute(query_to_update)
        conn_rds.commit()
    except Exception as err:
        LOGGER.critical(f'*** ERROR: While trying to log status/error details to RDS - {query_to_log_error}***')
        LOGGER.critical('*** ERROR: %s ***', err)
        raise err
#-------------------------------------------------------------------------------------------------------------------#
# Function to Get the Needed Details from RDS for a given RPT_RUN_ID
#-------------------------------------------------------------------------------------------------------------------#
def l2_process_get_details_rds(LOGGER, conn_sf, cursor_sf, conn_rds, cursor_rds, rpt_run_id, step_name, rpt_strt_dtm, number_of_tries):
    try:
        LOGGER.info(f'*** Executing the Query on RDS L#2 Tables to Fetch request Details for rpt_run_id:{rpt_run_id} ***')
        query_to_run_rds = f"select rqst.as_of_year_mnth_nbr as as_of_mnth_nbr ,cast(rqst.pkg_id as varchar) as l2_rpt_run_id, case when (lower(trim(as_of_year_mnth_nbr)) <> lower(trim(ui_as_of_year_mnth_nbr)) or lower(trim(rqst.tm_prd_type_cd)) = 'custom') then cast(rqst.pkg_id as varchar) else cast(parm.rpt_run_id as varchar) end as l2_rpt_run_id_bnchmrk, rqst.acct_id ,rqst.src_fltr_id , rqst.l2_rpt_shrt_nm as l2_rpt_shrt_nm ,case when (lower(trim(as_of_year_mnth_nbr)) <> lower(trim(ui_as_of_year_mnth_nbr)) or lower(trim(rqst.tm_prd_type_cd)) = 'custom') then cast(rqst.pkg_id as varchar) else rqst.tm_prd_type_cd end as tm_prd_type_cd,rqst.incrd_paid_cd ,cast(rqst.hcc_thrshld_amt as varchar) as hcc_thrshld_amt ,cast(rqst.year_id as varchar) as year_id,coalesce(rqst.cp_stndrd_strt_mnth_nbr,'') as cp_stndrd_strt_mnth_nbr ,coalesce(rqst.cp_stndrd_end_mnth_nbr,'') as cp_stndrd_end_mnth_nbr ,coalesce(rqst.cp_srvc_strt_mnth_nbr,'') as cp_srvc_strt_mnth_nbr ,coalesce(rqst.cp_srvc_end_mnth_nbr,'') as cp_srvc_end_mnth_nbr ,coalesce(rqst.cp_paid_strt_mnth_nbr,'') as cp_paid_strt_mnth_nbr ,coalesce(rqst.cp_paid_end_mnth_nbr,'') as cp_paid_end_mnth_nbr ,coalesce(rqst.pp_1_stndrd_strt_mnth_nbr,'') as pp_1_stndrd_strt_mnth_nbr ,coalesce(rqst.pp_1_stndrd_end_mnth_nbr,'') as pp_1_stndrd_end_mnth_nbr ,coalesce(rqst.pp_1_srvc_strt_mnth_nbr,'') as pp_1_srvc_strt_mnth_nbr ,coalesce(rqst.pp_1_srvc_end_mnth_nbr,'') as pp_1_srvc_end_mnth_nbr ,coalesce(rqst.pp_1_paid_strt_mnth_nbr,'') as pp_1_paid_strt_mnth_nbr ,coalesce(rqst.pp_1_paid_end_mnth_nbr,'') as pp_1_paid_end_mnth_nbr ,coalesce(rqst.pp_2_stndrd_strt_mnth_nbr,'') as pp_2_stndrd_strt_mnth_nbr ,coalesce(rqst.pp_2_stndrd_end_mnth_nbr,'') as pp_2_stndrd_end_mnth_nbr ,coalesce(rqst.pp_2_srvc_strt_mnth_nbr,'') as pp_2_srvc_strt_mnth_nbr ,coalesce(rqst.pp_2_srvc_end_mnth_nbr,'') as pp_2_srvc_end_mnth_nbr ,coalesce(rqst.pp_2_paid_strt_mnth_nbr,'') as pp_2_paid_strt_mnth_nbr ,coalesce(rqst.pp_2_paid_end_mnth_nbr,'') as pp_2_paid_end_mnth_nbr, lower(trim(rqst.ui_as_of_year_mnth_nbr)) as ui_as_of_year_mnth_nbr, lower(trim(rqst.ui_tm_prd_type_cd)) as ui_tm_prd_type_cd from (select as_of_year_mnth_nbr, pkg_id, acct_id, src_fltr_id, string_agg(l2_rpt_shrt_nm,',') as l2_rpt_shrt_nm, tm_prd_type_cd, hcc_thrshld_amt, incrd_paid_cd, year_id, cp_paid_strt_mnth_nbr, cp_paid_end_mnth_nbr, cp_srvc_strt_mnth_nbr, cp_srvc_end_mnth_nbr, cp_stndrd_strt_mnth_nbr, cp_stndrd_end_mnth_nbr, pp_1_paid_strt_mnth_nbr, pp_1_paid_end_mnth_nbr, pp_1_srvc_strt_mnth_nbr, pp_1_srvc_end_mnth_nbr, pp_1_stndrd_strt_mnth_nbr, pp_1_stndrd_end_mnth_nbr, pp_2_paid_strt_mnth_nbr, pp_2_paid_end_mnth_nbr, pp_2_srvc_strt_mnth_nbr, pp_2_srvc_end_mnth_nbr, pp_2_stndrd_strt_mnth_nbr, pp_2_stndrd_end_mnth_nbr, ui_as_of_year_mnth_nbr, ui_tm_prd_type_cd from aciisst_appl.aciisst_rpt_cstm_rqst WHERE trgr_ind <> 'Y' and l2_rpt_shrt_nm <> '' and pkg_id = {rpt_run_id} group by  as_of_year_mnth_nbr, pkg_id, acct_id, src_fltr_id, tm_prd_type_cd, hcc_thrshld_amt, incrd_paid_cd, year_id, cp_paid_strt_mnth_nbr, cp_paid_end_mnth_nbr, cp_srvc_strt_mnth_nbr, cp_srvc_end_mnth_nbr, cp_stndrd_strt_mnth_nbr, cp_stndrd_end_mnth_nbr, pp_1_paid_strt_mnth_nbr, pp_1_paid_end_mnth_nbr, pp_1_srvc_strt_mnth_nbr, pp_1_srvc_end_mnth_nbr, pp_1_stndrd_strt_mnth_nbr, pp_1_stndrd_end_mnth_nbr, pp_2_paid_strt_mnth_nbr, pp_2_paid_end_mnth_nbr, pp_2_srvc_strt_mnth_nbr, pp_2_srvc_end_mnth_nbr, pp_2_stndrd_strt_mnth_nbr, pp_2_stndrd_end_mnth_nbr, ui_as_of_year_mnth_nbr, ui_tm_prd_type_cd union all select as_of_year_mnth_nbr, pkg_id, acct_id, src_fltr_id, 'BNCHMRK' as l2_rpt_shrt_nm, rqst1.tm_prd_type_cd as tm_prd_type_cd, rqst1.hcc_thrshld_amt, rqst1.incrd_paid_cd, year_id, cp_paid_strt_mnth_nbr, cp_paid_end_mnth_nbr, cp_srvc_strt_mnth_nbr, cp_srvc_end_mnth_nbr, cp_stndrd_strt_mnth_nbr, cp_stndrd_end_mnth_nbr, pp_1_paid_strt_mnth_nbr, pp_1_paid_end_mnth_nbr, pp_1_srvc_strt_mnth_nbr, pp_1_srvc_end_mnth_nbr, pp_1_stndrd_strt_mnth_nbr, pp_1_stndrd_end_mnth_nbr, pp_2_paid_strt_mnth_nbr, pp_2_paid_end_mnth_nbr, pp_2_srvc_strt_mnth_nbr, pp_2_srvc_end_mnth_nbr, pp_2_stndrd_strt_mnth_nbr, pp_2_stndrd_end_mnth_nbr, ui_as_of_year_mnth_nbr, ui_tm_prd_type_cd from aciisst_appl.aciisst_rpt_cstm_rqst rqst1 WHERE trgr_ind = 'Y' and l2_rpt_shrt_nm <> '' and lower(trim(rqst1.tm_prd_type_cd)) = 'custom' and pkg_id = {rpt_run_id} group by  as_of_year_mnth_nbr, pkg_id, acct_id, src_fltr_id, rqst1.tm_prd_type_cd, rqst1.hcc_thrshld_amt, rqst1.incrd_paid_cd, year_id, cp_paid_strt_mnth_nbr, cp_paid_end_mnth_nbr, cp_srvc_strt_mnth_nbr, cp_srvc_end_mnth_nbr, cp_stndrd_strt_mnth_nbr, cp_stndrd_end_mnth_nbr, pp_1_paid_strt_mnth_nbr, pp_1_paid_end_mnth_nbr, pp_1_srvc_strt_mnth_nbr, pp_1_srvc_end_mnth_nbr, pp_1_stndrd_strt_mnth_nbr, pp_1_stndrd_end_mnth_nbr, pp_2_paid_strt_mnth_nbr, pp_2_paid_end_mnth_nbr, pp_2_srvc_strt_mnth_nbr, pp_2_srvc_end_mnth_nbr, pp_2_stndrd_strt_mnth_nbr, pp_2_stndrd_end_mnth_nbr, ui_as_of_year_mnth_nbr, ui_tm_prd_type_cd union all select as_of_year_mnth_nbr, pkg_id, acct_id, src_fltr_id, 'BNCHMRK' as l2_rpt_shrt_nm, rqst1.tm_prd_type_cd as tm_prd_type_cd, rqst1.hcc_thrshld_amt, rqst1.incrd_paid_cd, year_id, cp_paid_strt_mnth_nbr, cp_paid_end_mnth_nbr, cp_srvc_strt_mnth_nbr, cp_srvc_end_mnth_nbr, cp_stndrd_strt_mnth_nbr, cp_stndrd_end_mnth_nbr, pp_1_paid_strt_mnth_nbr, pp_1_paid_end_mnth_nbr, pp_1_srvc_strt_mnth_nbr, pp_1_srvc_end_mnth_nbr, pp_1_stndrd_strt_mnth_nbr, pp_1_stndrd_end_mnth_nbr, pp_2_paid_strt_mnth_nbr, pp_2_paid_end_mnth_nbr, pp_2_srvc_strt_mnth_nbr, pp_2_srvc_end_mnth_nbr, pp_2_stndrd_strt_mnth_nbr, pp_2_stndrd_end_mnth_nbr, ui_as_of_year_mnth_nbr, ui_tm_prd_type_cd from aciisst_appl.aciisst_rpt_cstm_rqst rqst1 WHERE trgr_ind = 'N' and incrd_paid_cd = 'INC3' and l2_rpt_shrt_nm <> '' and lower(trim(rqst1.tm_prd_type_cd)) = 'custom' and pkg_id = {rpt_run_id} group by  as_of_year_mnth_nbr, pkg_id, acct_id, src_fltr_id, rqst1.tm_prd_type_cd, rqst1.hcc_thrshld_amt, rqst1.incrd_paid_cd, year_id, cp_paid_strt_mnth_nbr, cp_paid_end_mnth_nbr, cp_srvc_strt_mnth_nbr, cp_srvc_end_mnth_nbr, cp_stndrd_strt_mnth_nbr, cp_stndrd_end_mnth_nbr, pp_1_paid_strt_mnth_nbr, pp_1_paid_end_mnth_nbr, pp_1_srvc_strt_mnth_nbr, pp_1_srvc_end_mnth_nbr, pp_1_stndrd_strt_mnth_nbr, pp_1_stndrd_end_mnth_nbr, pp_2_paid_strt_mnth_nbr, pp_2_paid_end_mnth_nbr, pp_2_srvc_strt_mnth_nbr, pp_2_srvc_end_mnth_nbr, pp_2_stndrd_strt_mnth_nbr, pp_2_stndrd_end_mnth_nbr, ui_as_of_year_mnth_nbr, ui_tm_prd_type_cd) rqst left join aciisst_appl.cii_bnchmrk_parm parm on lower(trim(rqst.tm_prd_type_cd)) = lower(trim(parm.tm_prd_type_cd)) and lower(trim(rqst.incrd_paid_cd)) = lower(trim(parm.incrd_paid_cd)) where rqst.pkg_id = {rpt_run_id}"
        LOGGER.info(f'*** Executing the Query on RDS L#2 Tables to Fetch request Details from RDS:{query_to_run_rds} ***')
        cursor_rds.execute(query_to_run_rds)
        result = cursor_rds.fetchall()
        if (len(result) > 0):
            data = result
            LOGGER.info(f'*** Result of the Query:{data} ***')
        else:
            raise Exception(f"No Records found for the given - RPT_RUN_ID - {rpt_run_id}")
        return data
    except Exception as err:
        log_error_to_rds(LOGGER, conn_sf, cursor_sf, conn_rds, cursor_rds, rpt_run_id, rpt_strt_dtm, number_of_tries, f'RETRY', "Failed while trying to fetch Needed Details from RDS Table - aciisst_rpt_cstm_rqst :" + str(err), "RETRY")
        LOGGER.critical('*** ERROR: While executing the query on RDS***')
        LOGGER.critical('*** ERROR: %s ***', err)
        raise err
#-------------------------------------------------------------------------------------------------------------------#
# Function to Get the src_pkg_id details and update the final status for a given RPT_RUN_ID
#-------------------------------------------------------------------------------------------------------------------#
def final_status_dtls_rqst_update(LOGGER, conn_sf, cursor_sf, conn_rds, cursor_rds, rpt_run_id, rpt_strt_dtm, number_of_tries):
    try:
        LOGGER.info(f'*** Executing the Query on RDS L#2 Tables to update src_pkg_ids for rpt_run_id:{rpt_run_id} ***')
        query_to_run_update = f"update aciisst_appl.aciisst_rpt_cstm_rqst_dtls dtl set src_pkg_id = rqst.pkg_id, updtd_by_user_id = 88888, updtd_dtm = current_timestamp from (select rqst_4.pkg_id, rqst_4.l2_rpt_shrt_nm as rpt_shrt_nm from aciisst_appl.aciisst_rpt_cstm_rqst rqst_4 inner join (select distinct rqst_1.pkg_id from aciisst_appl.aciisst_rpt_cstm_rqst rqst_1 inner join (select distinct as_of_year_mnth_nbr, acct_id, src_fltr_id, tm_prd_type_cd, hcc_thrshld_amt, incrd_paid_cd, year_id, cp_paid_strt_mnth_nbr, cp_paid_end_mnth_nbr,cp_srvc_strt_mnth_nbr, cp_srvc_end_mnth_nbr, cp_stndrd_strt_mnth_nbr, cp_stndrd_end_mnth_nbr, pp_1_paid_strt_mnth_nbr, pp_1_paid_end_mnth_nbr, pp_1_srvc_strt_mnth_nbr, pp_1_srvc_end_mnth_nbr, pp_1_stndrd_strt_mnth_nbr, pp_1_stndrd_end_mnth_nbr, pp_2_paid_strt_mnth_nbr, pp_2_paid_end_mnth_nbr, pp_2_srvc_strt_mnth_nbr, pp_2_srvc_end_mnth_nbr, pp_2_stndrd_strt_mnth_nbr, pp_2_stndrd_end_mnth_nbr, ui_as_of_year_mnth_nbr, ui_tm_prd_type_cd from aciisst_appl.aciisst_rpt_cstm_rqst where pkg_id = {rpt_run_id} ) rqst_2 on rqst_1.as_of_year_mnth_nbr = rqst_2.as_of_year_mnth_nbr and rqst_1.acct_id = rqst_2.acct_id and rqst_1.src_fltr_id = rqst_2.src_fltr_id and rqst_1.tm_prd_type_cd = rqst_2.tm_prd_type_cd and rqst_1.hcc_thrshld_amt = rqst_2.hcc_thrshld_amt and rqst_1.incrd_paid_cd = rqst_2.incrd_paid_cd and rqst_1.year_id = rqst_2.year_id and rqst_1.cp_paid_strt_mnth_nbr = rqst_2.cp_paid_strt_mnth_nbr and rqst_1.cp_paid_end_mnth_nbr = rqst_2.cp_paid_end_mnth_nbr and rqst_1.cp_srvc_strt_mnth_nbr = rqst_2.cp_srvc_strt_mnth_nbr and rqst_1.cp_srvc_end_mnth_nbr = rqst_2.cp_srvc_end_mnth_nbr and rqst_1.cp_stndrd_strt_mnth_nbr = rqst_2.cp_stndrd_strt_mnth_nbr and rqst_1.cp_stndrd_end_mnth_nbr = rqst_2.cp_stndrd_end_mnth_nbr and rqst_1.pp_1_paid_strt_mnth_nbr = rqst_2.pp_1_paid_strt_mnth_nbr and rqst_1.pp_1_paid_end_mnth_nbr = rqst_2.pp_1_paid_end_mnth_nbr and rqst_1.pp_1_srvc_strt_mnth_nbr = rqst_2.pp_1_srvc_strt_mnth_nbr and rqst_1.pp_1_srvc_end_mnth_nbr = rqst_2.pp_1_srvc_end_mnth_nbr and rqst_1.pp_1_stndrd_strt_mnth_nbr = rqst_2.pp_1_stndrd_strt_mnth_nbr and rqst_1.pp_1_stndrd_end_mnth_nbr = rqst_2.pp_1_stndrd_end_mnth_nbr and rqst_1.pp_2_paid_strt_mnth_nbr = rqst_2.pp_2_paid_strt_mnth_nbr and rqst_1.pp_2_paid_end_mnth_nbr = rqst_2.pp_2_paid_end_mnth_nbr and rqst_1.pp_2_srvc_strt_mnth_nbr = rqst_2.pp_2_srvc_strt_mnth_nbr and rqst_1.pp_2_srvc_end_mnth_nbr = rqst_2.pp_2_srvc_end_mnth_nbr and rqst_1.pp_2_stndrd_strt_mnth_nbr = rqst_2.pp_2_stndrd_strt_mnth_nbr and rqst_1.pp_2_stndrd_end_mnth_nbr = rqst_2.pp_2_stndrd_end_mnth_nbr and rqst_1.ui_as_of_year_mnth_nbr = rqst_2.ui_as_of_year_mnth_nbr and rqst_1.ui_tm_prd_type_cd = rqst_2.ui_tm_prd_type_cd where rqst_1.l2_rpt_shrt_nm <> '' ) rqst_3 on rqst_4.pkg_id = rqst_3.pkg_id) rqst where trim(dtl.rpt_shrt_nm) = trim(rqst.rpt_shrt_nm) and dtl.pkg_id = {rpt_run_id} and upper(trim(dtl.rpt_type_nm)) = 'L2'"
        LOGGER.info(f'*** Executing the Query to update src_pkg_ids in the table - aciisst_rpt_cstm_rqst_dtls:{query_to_run_update} ***')
        cursor_rds.execute(query_to_run_update)
        conn_rds.commit()
        query_src_pkg_id = f"select distinct cast(src_pkg_id as varchar) as src_pkg_id from aciisst_appl.aciisst_rpt_cstm_rqst_dtls where pkg_id = {rpt_run_id} and src_pkg_id is not null"
        LOGGER.info(f'*** Executing the Query to to get src_pkg_ids in the table - aciisst_rpt_cstm_rqst_dtls:{query_src_pkg_id} ***')
        cursor_rds.execute(query_src_pkg_id)
        src_pkg_id_result = cursor_rds.fetchall()
        LOGGER.info(f'*** Executing the Query to to get src_pkg_ids in the table - aciisst_rpt_cstm_rqst_dtls:{src_pkg_id_result} ***')
        #Initializing src_pkg_id status in table - aciisst_rpt_cstm_rqst failed/completed count to zero
        counter = 0
        src_pkg_ids_rpt = ''
        src_pkg_id_failed_cnt = 0
        src_pkg_id_completed_cnt = 0
        src_pkg_id_processed = []
        src_pkg_ids1 = []
        src_pkg_ids2 = []
        src_pkg_ids3 = []
        if (len(src_pkg_id_result) > 0):
            for data in src_pkg_id_result:
                data1 = "|".join(data)
                LOGGER.info(f'*** Result of the Query - before append:{data1.split("|")[0]} ***')
                src_pkg_ids1.append(str(data1.split("|")[0]))
                src_pkg_ids2.append(str(data1.split("|")[0]))
                src_pkg_ids3.append(str(data1.split("|")[0]))
                LOGGER.info(f'*** Result of the Query - after append - src_pkg_ids1, src_pkg_ids2, src_pkg_ids3:{src_pkg_ids1}, {src_pkg_ids2}, {src_pkg_ids3} ***')
            src_pkg_ids2_cnt = len(src_pkg_ids2)
            while len(src_pkg_id_processed) < src_pkg_ids2_cnt:
                for src_pkg_id in src_pkg_ids3:
                    status_query = f"select distinct rqst_stts_txt from aciisst_appl.aciisst_rpt_cstm_rqst where pkg_id = {src_pkg_id} and pkg_id <> {rpt_run_id}"
                    LOGGER.info(f'*** Executing the Query to to get src_pkg_ids in the table - aciisst_rpt_cstm_rqst, src_pkg_ids_rpt:{status_query}, {src_pkg_ids_rpt} ***')
                    cursor_rds.execute(status_query)
                    result_status_cnt = cursor_rds.rowcount
                    LOGGER.info(f'*** result_status_cnt:{result_status_cnt} ***')
                    if (result_status_cnt > 0):
                        result_status = cursor_rds.fetchone()[0]
                    else:
                        result_status = ''
                    LOGGER.info(f'*** result_status, src_pkg_id, rpt_run_id:{result_status_cnt}, {src_pkg_id}, {rpt_run_id} ***')
                    if ( (result_status.strip().upper() in ('COMPLETED','NOTIFIED_WITH_SUCCESS', 'NOTIFIED')) or (int(src_pkg_id) == int(rpt_run_id)) ):
                        src_pkg_id_completed_cnt = src_pkg_id_completed_cnt + 1
                        src_pkg_id_processed.append(src_pkg_id)
                        src_pkg_ids3.remove(src_pkg_id)
                        update_rds_rqst_dtl_sql = f"update aciisst_appl.aciisst_rpt_cstm_rqst_dtls dtls set rpt_instnc_mtdta_id = rpt.rpt_instnc_mtdta_id, updtd_by_user_id = 88888 ,updtd_dtm = current_timestamp from aciisst_appl.aciisst_rpt_instnc_mtdta rpt where dtls.pkg_id = {rpt_run_id} and dtls.src_pkg_id = rpt.pkg_id and dtls.rpt_shrt_nm = rpt.indx_nm"
                        LOGGER.info(f'*** update_rds_rqst_dtl_sql, src_pkg_id_completed_cnt, src_pkg_ids2_cnt:{update_rds_rqst_dtl_sql}, {src_pkg_id_completed_cnt}, {src_pkg_ids2_cnt} ***')
                        cursor_rds.execute(update_rds_rqst_dtl_sql)
                        conn_rds.commit()
                    else:
                        if ( result_status.strip().upper() in ('FAILED','NOTIFIED_WITH_FAILURE') ):
                            src_pkg_id_failed_cnt = src_pkg_id_failed_cnt + 1
                            src_pkg_id_processed.append(src_pkg_id)
                            LOGGER.info(f'*** src_pkg_id_failed_cnt:{src_pkg_id_failed_cnt} ***')
                        else:
                            import time
                            LOGGER.info(f'*** src_pkg_id_failed_cnt, src_pkg_id_completed_cnt:{src_pkg_id_failed_cnt}, {src_pkg_id_completed_cnt} ***')
                            LOGGER.info(f'\n Waiting for 30 Seconds \n')
                            time.sleep(30)
            LOGGER.info(f'*** src_pkg_id_failed_cnt, src_pkg_id_completed_cnt, src_pkg_ids2_cnt:{src_pkg_id_failed_cnt}, {src_pkg_id_completed_cnt}, {src_pkg_ids2_cnt} ***')
            LOGGER.info(f'*** Checking for rpt_instnc_mtdta_id count in table - aciisst_rpt_instnc_mtdta for a given rpt_run_id/pkg_id, src_pkg_ids2 - {str(src_pkg_ids2)}: ***')
            for src_pkg_id in src_pkg_ids2:
                counter = counter + 1
                if (counter == len(src_pkg_ids2)):
                    src_pkg_ids_rpt = src_pkg_ids_rpt + src_pkg_id
                else:
                    src_pkg_ids_rpt = src_pkg_ids_rpt + src_pkg_id + ","
            query_rpt_instnc_mtdta_id = f"select count(distinct rpt_instnc_mtdta_id) from aciisst_appl.aciisst_rpt_instnc_mtdta where pkg_id in ({src_pkg_ids_rpt})"
            LOGGER.info(f'Executing the Query - {query_rpt_instnc_mtdta_id}, with src_pkg_ids_rpt - {src_pkg_ids_rpt} as input')
            cursor_rds.execute(query_rpt_instnc_mtdta_id)
            rpt_instnc_mtdta_id_cnt = cursor_rds.fetchone()[0]
            if ( (src_pkg_id_failed_cnt == 0) and (src_pkg_id_completed_cnt == src_pkg_ids2_cnt) and (rpt_instnc_mtdta_id_cnt > 0) ):
                #Logging Details to RDS log Table for Successful Completion
                error_detail = 'ALL Steps Successfully Finished'
                log_error_to_rds(LOGGER, conn_sf, cursor_sf, conn_rds, cursor_rds, rpt_run_id, rpt_strt_dtm, number_of_tries, 'COMPLETED', error_detail, "COMPLETED")
            else:
                #Logging Details to RDS log Table for FAILED Completion
                error_detail = f"One of the src_pkg_id failed from - {src_pkg_ids1}, failing this pkg_id - {rpt_run_id}, rpt_instnc_mtdta_id_cnt - {rpt_instnc_mtdta_id_cnt}"
                log_error_to_rds(LOGGER, conn_sf, cursor_sf, conn_rds, cursor_rds, rpt_run_id, rpt_strt_dtm, number_of_tries, 'FAILED', error_detail, "FAILED")
                sys.exit(1)
        else:
            raise Exception(f"No Records found for the given - RPT_RUN_ID - {rpt_run_id}")
    except Exception as err:
        log_error_to_rds(LOGGER, conn_sf, cursor_sf, conn_rds, cursor_rds, rpt_run_id, rpt_strt_dtm, number_of_tries, f'RETRY', "F:final_status_dtls_rqst_update - Failed while trying to fetch Needed Details from RDS Table - aciisst_rpt_cstm_rqst :" + str(err), "RETRY")
        LOGGER.critical('*** ERROR: While executing the query on RDS***')
        LOGGER.critical('*** ERROR: %s ***', err)
        raise err
#-------------------------------------------------------------------------------------------------------------------#
# Function to Generate temp time period sql for the given RPT_RUN_ID using the details received from RDS
#-------------------------------------------------------------------------------------------------------------------#
def generate_rqst_tm_prd_dtl(conn_sf, cursor_sf, conn_rds, cursor_rds, step_name, l2_process_get_details_data):
    try:
        l2_rpt_run_id_bnchmrk_lst = []
        l2_rpt_shrt_nm_lst = []
        rqst_tm_prd_dtl = ''
        for data in l2_process_get_details_data:
            data1 = "|".join(data)
            LOGGER.info(f'*** Result of the Query:{data1} ***')
            data2 = data1.split("|")
            as_of_mnth_nbr ,l2_rpt_run_id, l2_rpt_run_id_bnchmrk, acct_id ,src_fltr_id ,l2_rpt_shrt_nm ,tm_prd_type_cd ,incrd_paid_cd ,hcc_thrshld_amt ,year_id,cp_stndrd_strt_mnth_nbr ,cp_stndrd_end_mnth_nbr ,cp_srvc_strt_mnth_nbr ,cp_srvc_end_mnth_nbr ,cp_paid_strt_mnth_nbr ,cp_paid_end_mnth_nbr ,pp_1_stndrd_strt_mnth_nbr ,pp_1_stndrd_end_mnth_nbr ,pp_1_srvc_strt_mnth_nbr ,pp_1_srvc_end_mnth_nbr ,pp_1_paid_strt_mnth_nbr ,pp_1_paid_end_mnth_nbr ,pp_2_stndrd_strt_mnth_nbr ,pp_2_stndrd_end_mnth_nbr ,pp_2_srvc_strt_mnth_nbr ,pp_2_srvc_end_mnth_nbr ,pp_2_paid_strt_mnth_nbr ,pp_2_paid_end_mnth_nbr, ui_as_of_year_mnth_nbr, ui_tm_prd_type_cd = data2[0],data2[1],data2[2],data2[3],data2[4],data2[5].split(","),data2[6],data2[7],data2[8],int(data2[9]),data2[10],data2[11],data2[12],data2[13],data2[14],data2[15],data2[16],data2[17],data2[18],data2[19],data2[20],data2[21],data2[22],data2[23],data2[24],data2[25],data2[26],data2[27],data2[28],data2[29]
            l2_rpt_run_id_bnchmrk_lst.append(l2_rpt_run_id_bnchmrk)
            LOGGER.info(f'*** Generating Temp Time Period SQL, for rpt_run_id, l2_rpt_run_id_bnchmrk_lst, l2_rpt_shrt_nm_lst:{rpt_run_id}, {str(l2_rpt_run_id_bnchmrk_lst)} ***')
            current_tm_prd = cp_stndrd_strt_mnth_nbr + "|" + cp_stndrd_end_mnth_nbr + "|" + cp_srvc_strt_mnth_nbr + "|" + cp_srvc_end_mnth_nbr + "|" + cp_paid_strt_mnth_nbr + "|" + cp_paid_end_mnth_nbr
            PP_1_tm_prd = pp_1_stndrd_strt_mnth_nbr + "|" + pp_1_stndrd_end_mnth_nbr + "|" + pp_1_srvc_strt_mnth_nbr + "|" + pp_1_srvc_end_mnth_nbr + "|" + pp_1_paid_strt_mnth_nbr + "|" + pp_1_paid_end_mnth_nbr
            PP_2_tm_prd = pp_2_stndrd_strt_mnth_nbr + "|" + pp_2_stndrd_end_mnth_nbr + "|" + pp_2_srvc_strt_mnth_nbr + "|" + pp_2_srvc_end_mnth_nbr + "|" + pp_2_paid_strt_mnth_nbr + "|" + pp_2_paid_end_mnth_nbr
            #Total Time Period received
            total_tm_prd_rcvd = current_tm_prd + ":" + PP_1_tm_prd + ":" + PP_2_tm_prd
            count = 1
            for rpt_shrt_nm in l2_rpt_shrt_nm:
                l2_rpt_shrt_nm_lst.append(rpt_shrt_nm)
                while count <= year_id:
                    if (count == year_id):
                        total_tm_prd_rcvd_list = total_tm_prd_rcvd.split(":")
                        tm_prd = total_tm_prd_rcvd_list[count -1].split("|")
                        strt_mnth_nbr = tm_prd[0]
                        end_mnth_nbr = tm_prd[1]
                        srvc_strt_mnth_nbr = tm_prd[2]
                        srvc_end_mnth_nbr = tm_prd[3]
                        paid_strt_mnth_nbr = tm_prd[4]
                        paid_end_mnth_nbr = tm_prd[5]
                        rqst_tm_prd_dtl = rqst_tm_prd_dtl + "select " + f"{as_of_mnth_nbr} as as_of_mnth_nbr,'{rpt_run_id}' as rpt_run_id,'{acct_id}' as acct_id,'{src_fltr_id}' as src_fltr_id,'{rpt_shrt_nm}' as rpt_shrt_nm,'{tm_prd_type_cd}' as tm_prd_type_cd,'{incrd_paid_cd}' as incrd_paid_cd,{hcc_thrshld_amt} as hcc_thrshld_amt,{count} as year_id,{strt_mnth_nbr} as strt_mnth_nbr,{end_mnth_nbr} as end_mnth_nbr,{srvc_strt_mnth_nbr} as srvc_strt_mnth_nbr,{srvc_end_mnth_nbr} as srvc_end_mnth_nbr,{paid_strt_mnth_nbr} as paid_strt_mnth_nbr,{paid_end_mnth_nbr} as paid_end_mnth_nbr,{ui_as_of_year_mnth_nbr} as ui_as_of_year_mnth_nbr,'{ui_tm_prd_type_cd}' as ui_tm_prd_type_cd" + " UNION ALL "
                    else:
                        total_tm_prd_rcvd_list = total_tm_prd_rcvd.split(":")
                        tm_prd = total_tm_prd_rcvd_list[count -1].split("|")
                        strt_mnth_nbr = tm_prd[0]
                        end_mnth_nbr = tm_prd[1]
                        srvc_strt_mnth_nbr = tm_prd[2]
                        srvc_end_mnth_nbr = tm_prd[3]
                        paid_strt_mnth_nbr = tm_prd[4]
                        paid_end_mnth_nbr = tm_prd[5]
                        rqst_tm_prd_dtl = rqst_tm_prd_dtl + "select " + f"{as_of_mnth_nbr} as as_of_mnth_nbr,'{rpt_run_id}' as rpt_run_id,'{acct_id}' as acct_id,'{src_fltr_id}' as src_fltr_id,'{rpt_shrt_nm}' as rpt_shrt_nm,'{tm_prd_type_cd}' as tm_prd_type_cd,'{incrd_paid_cd}' as incrd_paid_cd,{hcc_thrshld_amt} as hcc_thrshld_amt,{count} as year_id,{strt_mnth_nbr} as strt_mnth_nbr,{end_mnth_nbr} as end_mnth_nbr,{srvc_strt_mnth_nbr} as srvc_strt_mnth_nbr,{srvc_end_mnth_nbr} as srvc_end_mnth_nbr,{paid_strt_mnth_nbr} as paid_strt_mnth_nbr,{paid_end_mnth_nbr} as paid_end_mnth_nbr,{ui_as_of_year_mnth_nbr} as ui_as_of_year_mnth_nbr,'{ui_tm_prd_type_cd}' as ui_tm_prd_type_cd" + " UNION ALL "
                    count = count + 1
                #Initializing Count again
                count = 1
        l2_rpt_run_id_bnchmrk_value = ''
        #Generated rpt_shrt_nm which can be passed as parameter to sqls
        counter = 0
        for rpt_run_id_bnchmrk in l2_rpt_run_id_bnchmrk_lst:
            counter = counter + 1
            if (counter == len(l2_rpt_run_id_bnchmrk_lst)):
                l2_rpt_run_id_bnchmrk_value = l2_rpt_run_id_bnchmrk_value + str(rpt_run_id_bnchmrk)
            else:
                l2_rpt_run_id_bnchmrk_value = l2_rpt_run_id_bnchmrk_value + str(rpt_run_id_bnchmrk) + ","
        return rqst_tm_prd_dtl[:-11], l2_rpt_run_id_bnchmrk_value, l2_rpt_shrt_nm_lst, src_fltr_id
    except Exception as err:
        log_error_to_rds(LOGGER, conn_sf, cursor_sf, conn_rds, cursor_rds, rpt_run_id, rpt_strt_dtm, number_of_tries, f'RETRY', "Failed while framing the Time period Details for the given RPT_RUN_ID :" + str(err), "RETRY")
        LOGGER.critical('*** ERROR: %s ***', err)
        raise err
#-------------------------------------------------------------------------------------------------------------------#
# Function to fetch SQLs from S3 and replace parameters with values
#-------------------------------------------------------------------------------------------------------------------#
def open_sql_file(conn_sf, cursor_sf, conn_rds, cursor_rds, s3_sql_bucket, sql_file_list, work_tables_list, l2_rpt_shrt_nm, parms, rpt_run_id, step_name, rpt_strt_dtm, number_of_tries):
    """
    Function to open and store SQL file as a variable in a list and substitute
    in variables for schema names
    :param cursor_rds: cursor to run sqls on RDS
    :param s3_sql_bucket: S3 Bucket for SQL Files
    :param sql_file_list: Contains sql files with paths
    :param parms: Contains parameter along with values which needs to be replaced in sqls
    :return: List of SQL Commands in sqls list variable
    """
    LOGGER.info(f"*** Fetching the sql files and applying paramters using the fucntion - open_sql_file***")
    try:
        sqls = []
        S3C = boto3.client('s3')
        for file in sql_file_list:
            sql_obj = S3C.get_object(Bucket=s3_sql_bucket, Key=file)
            LOGGER.info('*** Reading File %s Content into Variable ***', file)
            sql = sql_obj['Body'].read()
            sql_query = sql.decode('utf-8')
            LOGGER.info('*** Substituting Following parameters in SQL Files ***\n')
            sql_sub=sql_query
            # Find all parameters used in sql query that needs to be substituted from parms.
            sql_vars = set(re.findall(r'\$\{([\w]+?)\}', sql_sub))
            # Look up the parms for parameters used in SQL and substitute it with value found in parms.
            LOGGER.info('*** Substituting parameters passed through parms in SQL Files ***\n')
            if parms:
                for key in sql_vars:
                    if key not in parms.keys():
                        LOGGER.error(f'*** Error: Cannot substitute  variable \'{key}\' in the sql script as it is not found in parms. ')
                        raise InvalidStatus(f"Parameter not found in parms")
                    else:
                        LOGGER.info(f'SQL file - ' + file.split("/")[-1])
                        if ( (key == 'rpt_run_id_bnchmrk') and (file.split("/")[-1] not in work_tables_list) and ('BNCHMRK' not in l2_rpt_shrt_nm) ):
                            LOGGER.info(f'Inside - SQL file - ' + file.split("/")[-1])
                            rpt_run_id_bnchmrk = str(parms['rpt_run_id']) + ',' + str(parms['rpt_run_id_bnchmrk'])
                            LOGGER.info(f'SMRY-Parameter to be replaced in the script: ${{{key}}}')
                            LOGGER.info(f'SMRY-Parameter Value to be replaced with in the script: {rpt_run_id_bnchmrk}')
                            sql_sub = sql_sub.replace(f'${{{key}}}', rpt_run_id_bnchmrk)
                        else:
                            if ( (key == 'rpt_run_id_bnchmrk') and (file.split("/")[-1] in work_tables_list) and ('BNCHMRK' not in l2_rpt_shrt_nm) ):
                                rpt_run_id_bnchmrk = str(parms['rpt_run_id'])
                                LOGGER.info(f'WORK-Parameter to be replaced in the script: ${{{key}}}')
                                LOGGER.info(f'WORK-Parameter Value to be replaced with in the script: {rpt_run_id_bnchmrk}')
                                sql_sub = sql_sub.replace(f'${{{key}}}', rpt_run_id_bnchmrk)
                            else:
                                LOGGER.info(f'OTHR-Parameter to be replaced in the script: ${{{key}}}')
                                LOGGER.info(f'OTHR-Parameter Value to be replaced with in the script: {parms[key]}')
                                if ( (key == 'rpt_shrt_nm') and ("CII_SR_CMPLTD_RPT" in sql_sub.upper()) ):
                                    rpt_shrt_nm = str(parms['rpt_shrt_nm']).replace("'BNCHMRK'", "''")
                                    LOGGER.info(f'IN-Parameter to be replaced in the script: ${{{key}}}')
                                    LOGGER.info(f'IN-Parameter Value to be replaced with in the script: {rpt_shrt_nm}')
                                    sql_sub = sql_sub.replace(f'${{{key}}}', rpt_shrt_nm)
                                else:
                                    if ( (key == 'rpt_shrt_nm') and ( "l2_rpt_cii_sr_acct_sgmntn_tm_prd_parm_bnchmrk" in file.split("/")[-1]) ):
                                        rpt_shrt_nm = "'BNCHMRK'"
                                        LOGGER.info(f'BNCHMRK-Parameter to be replaced in the script: ${{{key}}}')
                                        LOGGER.info(f'BNCHMRK-Parameter Value to be replaced with in the script: {rpt_shrt_nm}')
                                        sql_sub = sql_sub.replace(f'${{{key}}}', rpt_shrt_nm)
                                    LOGGER.info(f'OUT-Parameter to be replaced in the script: ${{{key}}}')
                                    LOGGER.info(f'OUT-Parameter Value to be replaced with in the script: {parms[key]}')
                                    sql_sub = sql_sub.replace(f'${{{key}}}', parms[key])
            sqls.append(sql_sub)
            
        return sqls
    except Exception as err:
        log_error_to_rds(LOGGER, conn_sf, cursor_sf, conn_rds, cursor_rds, rpt_run_id, rpt_strt_dtm, number_of_tries, 'RETRY', "Failed while trying to fetch SQLs and apply parameters for the given RPT_RUN_ID :" + str(file) + str(err), "RETRY")
        LOGGER.critical('*** ERROR: %s ***', err)
        raise err
#-------------------------------------------------------------------------------------------------------------------#
# Function to Submit SQLs to snowflake Asynchronously
#-------------------------------------------------------------------------------------------------------------------#
def submit_sql_to_snowflake(conn_sf, cursor_sf, conn_rds, cursor_rds, sqls, rpt_run_id, step_name, rpt_strt_dtm, number_of_tries):
    """
    Function to execute SQL file contents in Snowflake
    :param cursor_sf: Cursor object for Snowflake
    :param cursor_rds: Cursor object for RDS
    :param sqls: List of SQL commands to run
    :return: True if all successful
    """
    LOGGER.info(f"*** Submitting SQLs to Snowflake using - submit_sql_to_snowflake***")

    number_of_files = len(sqls)
    LOGGER.info('*** Total Number of SQL Files to Execute: %s ***',
                str(number_of_files))
    reslt_qid_dict = {}
    reslt_qid_lst = []
    try:
        for sql in sqls:
            #Initializing
            sql_delete = ''
            sql_normal = ''
            sql_list_all = sql.split(";")
            for sql in sql_list_all:
                if ('DELETE' in sql.upper()):
                    sql_delete = sql_delete + sql + ';'
                else:
                    sql_normal = sql_normal + sql + ';'
            LOGGER.info('*** Executing Delete Sql on Snowflake from the file***')
            # cursor.execute("BEGIN")
            sql_list_delete = sql_delete.split(";")
            if len(sql_list_delete) <= 1000:
                for individual_sql in sql_list_delete:
                    if individual_sql != '' and individual_sql is not None and individual_sql != '\n\n':
                        LOGGER.info('*** Single Query: %s ***', individual_sql)
                        cursor_sf.execute(individual_sql)
            LOGGER.info('*** Executing Remaining Sqls on Snowflake from the file***')
            # cursor.execute("BEGIN")
            sql_list_normal = sql_normal.split(";")
            if len(sql_list_normal) <= 1000:
                for individual_sql in sql_list_normal:
                    if individual_sql != '' and individual_sql is not None and individual_sql != '\n\n':
                        LOGGER.info('*** Single Query: %s ***', individual_sql)
                        cursor_sf.execute_async(individual_sql)
                        query_id = cursor_sf.sfqid
                        LOGGER.info(f"Query ID {query_id} for SQL {individual_sql}")
                        reslt_qid_dict[query_id] = 'RUNNING'
                        reslt_qid_lst.append(query_id)
                # cursor.execute("COMMIT")
                LOGGER.info('*** SUCCESS: Whole SQL File is complete! ***')
            else:
                LOGGER.critical("Found SQL's to be executed as more than 100. Hence stopping the process")
                raise Exception("Found SQL's to be executed as more than 100. Hence stopping the process")

    except sf.ProgrammingError as GenericSnowflakeException:
        log_error_to_rds(LOGGER, conn_sf, cursor_sf, conn_rds, cursor_rds, rpt_run_id, rpt_strt_dtm, number_of_tries, 'RETRY', "Failed while trying submit sqls to snowflake for the given RPT_RUN_ID" + str(GenericSnowflakeException), "RETRY")
        LOGGER.critical('*** ERROR: Snowflake SQL Execution Failed: %s ***', individual_sql)
        LOGGER.critical(GenericSnowflakeException)
        #cursor_sf.close()
        raise GenericSnowflakeException

    return reslt_qid_dict, reslt_qid_lst
#-------------------------------------------------------------------------------------------------------------------#
# Function to check status of SQLs submitted Asynchronously
#-------------------------------------------------------------------------------------------------------------------#
def check_sfqid_status(conn_sf, cursor_sf, conn_rds, cursor_rds, rpt_run_id, step_name, rpt_strt_dtm, number_of_tries, reslt_qid_dict, reslt_qid_lst, max_elapsed_time):
    """
    Function to check the status of snowflake queries
    """
    time_intervals = [[20,[i for i in range(0,20)]], [20,[i for i in range(20,40)]], [20,[i for i in range(40,60)]], [20,[i for i in range(60,80)]], [20,[i for i in range(80,100)]]]
    tm_slp = 20

    strt_time = datetime.now()
    if "d" in max_elapsed_time.lower():
        run_time = strt_time + timedelta(days=int(re.findall(r'\d+',max_elapsed_time)[0]))
    elif "m" in max_elapsed_time.lower():
        run_time = strt_time + timedelta(minutes=int(re.findall(r'\d+',max_elapsed_time)[0]))
    elif "h" in max_elapsed_time.lower():
        run_time = strt_time + timedelta(hours=int(re.findall(r'\d+',max_elapsed_time)[0]))
    else:
        LOGGER.critical(f"max_elapsed_time Passed {max_elapsed_time} is not valid")
        raise Exception(f"max_elapsed_time Passed {max_elapsed_time} is not valid")
    # Loop till the time all the queries gets Succedded/Failed
    while len(reslt_qid_dict) != len({k:v for k,v in reslt_qid_dict.items() if not 'RUNNING' in v}):
        if datetime.now() < run_time:
            # Get the Sleep time based no:of queries running 
            for k,v in time_intervals:
                if len({k:v for k,v in reslt_qid_dict.items() if 'RUNNING' in v}) in v:
                    tm_slp = k
            for query_id, stts in reslt_qid_dict.items():
                if stts == 'RUNNING' and not conn_sf.is_still_running(conn_sf.get_query_status(query_id)):
                    reslt_qid_dict[query_id] = conn_sf.get_query_status(query_id).name
                # else:
                #     LOGGER.info(f'status1 of {query_id}: {conn_sf.get_query_status(query_id).name}')
            time.sleep(tm_slp)
        else:
            # If reached max_elapsed_time then cancel the current running queries and stop the execution
            for query_id, stts in reslt_qid_dict.items():
                try:
                    if stts == 'RUNNING':
                        query = f"SELECT SYSTEM$CANCEL_QUERY('{query_id}')"
                        LOGGER.info(f'Attempting to cancel query: {query}')
                        cursor_sf.execute(query)
                        LOGGER.info(f'*** Snowflake canceled query w/ id {query_id} ***')
                        reslt_qid_dict[query_id] = 'CANCELLED_BY_USER'
                except sf.ProgrammingError as GenericSnowflakeException:
                    LOGGER.critical(f'*** ERROR: Snowflake failed to cancel query w/ id {query_id} ***')
                    LOGGER.critical(GenericSnowflakeException)
                    #cursor_sf.close()
                    #conn_sf.close()
                    raise Exception(f"Execution time Reached More than Elapsed time {max_elapsed_time}. Hence Stopping the process")
            LOGGER.info(f'Final run status of query(s): {reslt_qid_dict}')
            LOGGER.critical(f"Execution time Reached More than Elapsed time {max_elapsed_time}. Hence Stopping the process")
            #cursor_sf.close()
            #conn_sf.close()
            raise Exception(f"Execution time Reached More than Elapsed time {max_elapsed_time}. Hence Stopping the process")
        LOGGER.info(f'Query(s) run status: {reslt_qid_dict}')
    
    LOGGER.info(f'Final run status of query(s): {reslt_qid_dict}')
    failed_qrs = len({k:v for k,v in reslt_qid_dict.items() if not 'SUCCESS' in v.upper()})
    if failed_qrs > 0:
        LOGGER.info(f"{failed_qrs} Queries failed out of Total Queries passed {len(reslt_qid_dict.keys())}")
        reslt_qid_json = json.dumps(reslt_qid_dict)
        log_error_to_rds(LOGGER, conn_sf, cursor_sf, conn_rds, cursor_rds, rpt_run_id, rpt_strt_dtm, number_of_tries, f'RETRY', f"{failed_qrs} Queries failed out of Total Queries passed {len(reslt_qid_dict.keys())} :" + str(reslt_qid_json), "RETRY")
        raise Exception(f"{failed_qrs} Queries failed out of Total Queries passed {len(reslt_qid_dict.keys())}")

    return reslt_qid_dict
#-------------------------------------------------------------------------------------------------------------------#
# Function to Load Table from Snowflake to RDS and also Delete data in Target RDS Table if Needed
#-------------------------------------------------------------------------------------------------------------------#
def snowflake_to_rds_load_data(LOGGER, conn_sf, cursor_sf, cursor_rds, conn_rds, source_snowflake_query_to_run, target_rds_database_table_name, delete_target_rds_table, delete_target_rds_table_query, swap_target_rds_table, parms, rpt_run_id, step_name, rpt_strt_dtm, number_of_tries):
    try:
        get_info_snowflake_table_query = f"SELECT MAX(RUN_YEAR_MNTH_NBR) FROM {aciisst_adhoc_schema_name}.CII_RUN_PRD"
        # Find all parameters used in sql query that needs to be substituted from parms.
        sql_vars1 = set(re.findall(r'\$\{([\w]+?)\}', source_snowflake_query_to_run))
        # Look up the parms for parameters used in SQL and substitute it with value found in parms.
        LOGGER.info('*** sql_vars1:Substituting parameters passed through parms in SQL Files ***\n')
        if parms:
            for key in sql_vars1:
                if key not in parms.keys():
                    LOGGER.error(f'*** Error: Cannot substitute  variable \'{key}\' in the sql script as it is not found in parms. ')
                    raise InvalidStatus(f"Parameter not found in parms")
                else:
                    LOGGER.info(f'Parameter to be replaced in the script: ${{{key}}}')
                    LOGGER.info(f'Parameter Value to be replaced with in the script: {parms[key]}')
                    source_snowflake_query_to_run = source_snowflake_query_to_run.replace(f'${{{key}}}', parms[key])
                    LOGGER.info(f'Before:get_info_snowflake_table_query: {get_info_snowflake_table_query}')
                    get_info_snowflake_table_query = get_info_snowflake_table_query.replace(f'${{{key}}}', parms[key])
                    LOGGER.info(f'After:get_info_snowflake_table_query: {get_info_snowflake_table_query}')
        # Find all parameters used in sql query that needs to be substituted from parms.
        sql_vars2 = set(re.findall(r'\$\{([\w]+?)\}', delete_target_rds_table_query))
        # Look up the parms for parameters used in SQL and substitute it with value found in parms.
        LOGGER.info('*** sql_vars2:Substituting parameters passed through parms in SQL Files ***\n')
        if parms:
            for key in sql_vars2:
                if ( key not in parms.keys() and (key not in 'get_info_snowflake_rslt') ):
                    LOGGER.error(f'*** Error: Cannot substitute  variable \'{key}\' in the sql script as it is not found in parms. ')
                    raise InvalidStatus(f"Parameter not found in parms")
                else:
                    if ( (key not in 'get_info_snowflake_rslt') ):
                        LOGGER.info(f'Parameter to be replaced in the script: ${{{key}}}')
                        LOGGER.info(f'Parameter Value to be replaced with in the script: {parms[key]}')
                        delete_target_rds_table_query = delete_target_rds_table_query.replace(f'${{{key}}}', parms[key])
        #Executing query on cii_run_prd table
        LOGGER.info(f'*** Executing the Snowflake Query:{get_info_snowflake_table_query} ***')
        cursor_sf.execute(get_info_snowflake_table_query)
        get_info_snowflake_rslt = cursor_sf.fetchone()[0]
        LOGGER.info(f'*** Value Recived from Snowflake:get_info_snowflake_rslt:{get_info_snowflake_rslt} ***')
        LOGGER.info(f'*** Executing the Snowflake Query:{source_snowflake_query_to_run} ***')
        cursor_sf.execute(source_snowflake_query_to_run)
        flag=True
        count=0
        commit_count = 0
        if(delete_target_rds_table == 'YES'):
            LOGGER.info(f'*** Executing the Delete Queryon RDS for Target Data Deletion:' + str(delete_target_rds_table_query.replace("${get_info_snowflake_rslt}", str(get_info_snowflake_rslt))) )
            cursor_rds.execute( delete_target_rds_table_query.replace("${get_info_snowflake_rslt}", str(get_info_snowflake_rslt)) )
            conn_rds.commit()
        while flag:
            final_result = cursor_sf.fetchmany(10000)
            final_result1= ""
            if len(final_result) > 0:
                fectch_count =len(final_result)
                count = count + 1
                LOGGER.info(f'*** Number of Records in the fetch#:{count} and Count - {fectch_count} ***')
                for data in final_result:
                    final_result1 = final_result1 + "," + str(data)
                    final_result2 = final_result1[1:]
                    #LOGGER.info(f'*** Number of Records in the fetch: {final_result2} ***')
                check_on_target_rds_table_query = f"SELECT COUNT(*) FROM ACIISST_APPL.ACIISST_RPT_INSTNC_MTDTA WHERE 1 = (SELECT CASE WHEN RPT.AS_OF_MNTH_NBR is not null and 'NO' = {re_run} then 0 WHEN RPT.AS_OF_MNTH_NBR is not null and 'YES' = {re_run} THEN 0 WHEN RPT.AS_OF_MNTH_NBR is null and 'NO' = {re_run} THEN 1 WHEN RPT.AS_OF_MNTH_NBR is null and 'YES' = {re_run} THEN 1 ELSE 1 END AS RESULT FROM (SELECT {get_info_snowflake_rslt} AS AS_OF_MNTH_NBR) PRD LEFT JOIN ( SELECT max(cast(AS_OF_MNTH_NBR as integer)) AS AS_OF_MNTH_NBR FROM ACIISST_APPL.ACIISST_RPT_INSTNC_MTDTA  WHERE PKG_ID in ({rpt_run_id}) AND (UPPER(TRIM(INDX_NM)) in ({rpt_shrt_nm}) OR 'ALL' in ({rpt_shrt_nm})) AND cast(AS_OF_MNTH_NBR as integer) = (SELECT {get_info_snowflake_rslt} AS AS_OF_MNTH_NBR) ) RPT ON PRD.AS_OF_MNTH_NBR = RPT.AS_OF_MNTH_NBR)"
                sql_vars_3 = set(re.findall(r'\$\{([\w]+?)\}', check_on_target_rds_table_query))
                if parms:
                    for key in sql_vars_3:
                        if ( key not in parms.keys() and (key not in 'get_info_snowflake_rslt') ):
                            LOGGER.error(f'*** sql_vars_3:Error: Cannot substitute  variable \'{key}\' in the sql script as it is not found in parms. ')
                            raise InvalidStatus(f"sql_vars_3:Parameter not found in parms")
                        else:
                            if ( (key not in 'get_info_snowflake_rslt') ):
                                LOGGER.info(f'sql_vars_3:Parameter to be replaced in the script: ${{{key}}}')
                                LOGGER.info(f'sql_vars_3:Parameter Value to be replaced with in the script: {parms[key]}')
                                check_on_target_rds_table_query = check_on_target_rds_table_query.replace(f'${{{key}}}', parms[key])
                LOGGER.info(f'*** check_on_target_rds_table Query#:***' + str(check_on_target_rds_table_query.replace("${get_info_snowflake_rslt}", str(get_info_snowflake_rslt))) )
                cursor_rds.execute(check_on_target_rds_table_query.replace("${get_info_snowflake_rslt}", str(get_info_snowflake_rslt)))
                result_rds_rpt = cursor_rds.fetchone()[0]
                if( result_rds_rpt != 0 ):
                    cursor_rds.execute("INSERT INTO " + target_rds_database_table_name + " values " + final_result2 )
                    LOGGER.info(f'*** Records Insert Happened: result_rds_rpt - {result_rds_rpt}***')
                    commit_count = commit_count + fectch_count
                    if(commit_count == 500000):
                        conn_rds.commit()
                        commit_count = 0
                else:
                    LOGGER.info(f'*** Records Insert Not Happened: result_rds_rpt - {result_rds_rpt} ***')
            else:
                flag=False
        conn_rds.commit()
        if(swap_target_rds_table == 'YES'):
            table_name_with_a = target_rds_database_table_name.split(".")[1]
            table_name = target_rds_database_table_name.split(".")[1][:-2]
            database_name = target_rds_database_table_name.split(".")[0]
            table_name_with_b = table_name + "_b"
            LOGGER.info(f'*** Swapping RDS Table from - {target_rds_database_table_name}, to Original Table and Vice Versa ***')
            cursor_rds.execute("ALTER TABLE " + target_rds_database_table_name + " RENAME TO " + table_name_with_b)
            cursor_rds.execute("ALTER TABLE " + database_name + "." + table_name + " RENAME TO " + table_name_with_a)
            cursor_rds.execute("ALTER TABLE " + database_name + "." + table_name_with_b + " RENAME TO " + table_name)
            conn_rds.commit()
        #cursor_sf.close()
    except Exception as err:
        LOGGER.critical('*** ERROR: %s ***', err)
        error_detail = str(err)
        log_error_to_rds(LOGGER, conn_sf, cursor_sf, conn_rds, cursor_rds, rpt_run_id, rpt_strt_dtm, number_of_tries, f'RETRY', error_detail, "RETRY")
        raise err
#---------------------------------------------------------------------------------#
#Class to get the Account Number                                                  #
#---------------------------------------------------------------------------------#
class acc_info:
    sts_function_client=boto3.client('sts')
    def __init__(self):
        acc_details=acc_info.sts_function_client.get_caller_identity()
        self.account=acc_details['Account']
    @property
    def get_account(self):
        return self.account

def get_secret_rds(secret_name):
    """
    Function to fetch details from AWS Secrets Manager
    Usage   : Get Secret JSON String
    Args    : Secret Name
    Returns : Secure string of Secret
    Raises  : Exception While getting the Secret.
    
    """
    secret = ''
    secret_client = boto3.client("secretsmanager")

    try:
        get_secret_value_response = secret_client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as error:
        if error.response['Error']['Code'] == 'DecryptionFailureException':
            raise error
        elif error.response['Error']['Code'] == 'InternalServiceErrorException':
            raise error
        elif error.response['Error']['Code'] == 'InvalidParameterException':
            raise error
        elif error.response['Error']['Code'] == 'InvalidRequestException':
            raise error
        elif error.response['Error']['Code'] == 'ResourceNotFoundException':
            raise error
    else:
        if 'SecretString' in get_secret_value_response:
            secret = get_secret_value_response['SecretString']
            return secret
        else:
            decoded_binary_secret = base64.b64decode(
                get_secret_value_response['SecretBinary'])
            return decoded_binary_secret


def rds_conn(LOGGER, host_name, secret_name, port_no, schema_name):
    """
    Function to use Secrets Manager to create an RDS Connection Object
    :param host_name: Host name of the RDS
    :param secret_name: secret name for fetching user password
    :param port_no: Port Number of RDS
    :param schema_name: Schema Name in RDS
    :return: RDS Connection Object
    """
    try:
        secure_string   = get_secret_rds(secret_name)
        secure_dict     = json.loads(secure_string)
        postgre_username  = secure_dict.get('username')
        postgre_password  = secure_dict.get('password')
        engine = psycopg2.connect(
                database=schema_name,
                user=postgre_username,
                password=postgre_password,
                host=host_name,
                port=port_no
            )
    except Exception as err:
        LOGGER.critical("ERROR: Unexpected error: Could not connect to Aurora instance.")
        LOGGER.critical('*** ERROR: %s ***', err)
        raise err

    return engine

def _read_s3_object(s3_path):
    """
    Function to read object from s3 path
    :param s3_path: S3 object full path
    :return: object
    """
    s3 = boto3.resource('s3')
    S3C = boto3.client('s3')
    bucket = s3_path.split("//")[1].split("/")[0]
    key = "/".join(s3_path.replace("//", "").split("/")[1:])
    
    LOGGER.info("Reading S3 obj {}".format(s3_path))
    obj = s3.Object(bucket, key)
    #obj = S3C.get_object(Bucket=bucket, Key=key)
    
    return obj
#---------------------------------------------------------------------------------#
#                      Business Logic                                             #
#---------------------------------------------------------------------------------#
LOGGER.info("Reading Glue Job Parameters... \n")
# Parse Arguments for Glue Job
params = ['etl_stp_parms']
# Parse Arguments for Glue Job
ARGS = getResolvedOptions(sys.argv, params)
                                    
try:
    #set Variables
    etl_parms = json.loads(ARGS['etl_stp_parms'])
    #Input Parameters Passed/Needed
    #Mandatory Parameters
    rpt_run_id = etl_parms.get('rpt_run_id').strip().lower()
    rpt_run_id = int(rpt_run_id)
    aplctn_cd = etl_parms.get('aplctn_cd','CII').strip().lower()
    ENV = etl_parms.get('env').strip()
    db_config_path = etl_parms.get('db_config_path').strip()
    l2_config_file = etl_parms.get('l2_config_file').strip()
    l2_sqls_path = etl_parms.get('l2_sqls_path').strip()
    aciisst_adhoc_schema_name = etl_parms.get('aciisst_adhoc_schema_name', 'ACIISST_ADHOC_ALLPHI').strip().upper()
    aciisst_schema_name = etl_parms.get('aciisst_schema_name', 'ACIISST_ALLPHI').strip().upper()
    evolve_schema_name = etl_parms.get('evolve_schema_name', 'CII_EVOLVE_ALLPHI').strip().upper()
    #Optional Parameters
    manual_run = etl_parms.get('manual_run','NO').strip().upper()
    re_run = etl_parms.get('re_run',"'YES'").strip().upper()
    number_of_tries = etl_parms.get('number_of_tries','0').strip().upper()
    as_of_year_mnth_nbr = etl_parms.get('as_of_year_mnth_nbr','').strip()
    acct_id = etl_parms.get('acct_id','').strip()
    src_fltr_id = etl_parms.get('src_fltr_id','').strip()
    l2_rpt_shrt_nm = etl_parms.get('l2_rpt_shrt_nm','').strip()
    tm_prd_type_cd = etl_parms.get('tm_prd_type_cd','').strip()
    incrd_paid_cd = etl_parms.get('incrd_paid_cd','').strip()
    ui_as_of_year_mnth_nbr = etl_parms.get('ui_as_of_year_mnth_nbr','').strip()
    ui_tm_prd_type_cd = etl_parms.get('ui_tm_prd_type_cd','').strip()
    hcc_thrshld_amt = etl_parms.get('hcc_thrshld_amt','').strip()
    year_id = etl_parms.get('year_id','').strip()
    cp_stndrd_strt_mnth_nbr = etl_parms.get('cp_stndrd_strt_mnth_nbr','').strip()
    cp_stndrd_end_mnth_nbr = etl_parms.get('cp_stndrd_end_mnth_nbr','').strip()
    cp_srvc_strt_mnth_nbr = etl_parms.get('cp_srvc_strt_mnth_nbr','').strip()
    cp_srvc_end_mnth_nbr = etl_parms.get('cp_srvc_end_mnth_nbr','').strip()
    cp_paid_strt_mnth_nbr = etl_parms.get('cp_paid_strt_mnth_nbr','').strip()
    cp_paid_end_mnth_nbr = etl_parms.get('cp_paid_end_mnth_nbr','').strip()
    pp_1_stndrd_strt_mnth_nbr = etl_parms.get('pp_1_stndrd_strt_mnth_nbr','').strip()
    pp_1_stndrd_end_mnth_nbr = etl_parms.get('pp_1_stndrd_end_mnth_nbr','').strip()
    pp_1_srvc_strt_mnth_nbr = etl_parms.get('pp_1_srvc_strt_mnth_nbr','').strip()
    pp_1_srvc_end_mnth_nbr = etl_parms.get('pp_1_srvc_end_mnth_nbr','').strip()
    pp_1_paid_strt_mnth_nbr = etl_parms.get('pp_1_paid_strt_mnth_nbr','').strip()
    pp_1_paid_end_mnth_nbr = etl_parms.get('pp_1_paid_end_mnth_nbr','').strip()
    pp_2_stndrd_strt_mnth_nbr = etl_parms.get('pp_2_stndrd_strt_mnth_nbr','').strip()
    pp_2_stndrd_end_mnth_nbr = etl_parms.get('pp_2_stndrd_end_mnth_nbr','').strip()
    pp_2_srvc_strt_mnth_nbr = etl_parms.get('pp_2_srvc_strt_mnth_nbr','').strip()
    pp_2_srvc_end_mnth_nbr = etl_parms.get('pp_2_srvc_end_mnth_nbr','').strip()
    pp_2_paid_strt_mnth_nbr = etl_parms.get('pp_2_paid_strt_mnth_nbr','').strip()
    pp_2_paid_end_mnth_nbr = etl_parms.get('pp_2_paid_end_mnth_nbr','').strip()
    REGION_NAME = 'us-east-1'
    load_log_key = uuid.uuid1()
    APLCTN_CD = aplctn_cd
    if (ENV.strip().lower() == 'prod'):
        WAREHOUSE_SIZE_SUFFIX = '_2XL'
    else:
        WAREHOUSE_SIZE_SUFFIX = '_XL'
    LOGGER.info(f'\n**** Argument List ****\n-----------------------')
    LOGGER.info(f'\nREGION_NAME : {REGION_NAME} \nENV : {ENV} \nAPLCTN_CD : {APLCTN_CD} ')
    # Fetch the SECRET Instance based on Application Code
    #SECRET = get_secret(LOGGER, ENV, REGION_NAME, f"/snowflake/{APLCTN_CD}")
    #SECRET_JSON = json.loads(SECRET) 
    LOGGER.info('*** Creating Snowflake and RDS Connection & Cursor ***')
    # Reads the configuration File from S3
    json_obj = _read_s3_object(db_config_path)
    config = json.loads(json_obj.get()['Body'].read().decode('utf-8'))
    
    # Getting RDS connection Details from configuration file
    databaseName = config['database_details']['database']
    schema_name = config['database_details']['schema']
    host = config['database_details']['host']
    port = config['database_details']['port']
    secret_name = config['database_details']['secret_name']
    preval_databaseName = config['database_details']['preval_database']
    # Creates RDS Connection Object and Cursor
    conn_rds = rds_conn(LOGGER, host, secret_name, port, schema_name)
    cursor_rds = conn_rds.cursor()
    LOGGER.info("Connection to RDS has been established, Cursor is created.")
    #conn_sf = snowflake_conn(logger=LOGGER, aplctn_cd=APLCTN_CD, secret=SECRET, warehouse_size_suffix=WAREHOUSE_SIZE_SUFFIX)
    conn_sf = get_snowflake_conn(LOGGER, aplctn_cd, ENV, REGION_NAME, warehouse_size_suffix=WAREHOUSE_SIZE_SUFFIX)
    cursor_sf = conn_sf.cursor()
    LOGGER.info('*** Created Snowflake Connection & Cursor ***')
    #warehouse = SECRET_JSON.get(f'{APLCTN_CD}_warehouse')
    #warehouse = warehouse + WAREHOUSE_SIZE_SUFFIX
    LOGGER.info(f'Based on warehouse size value passed as \'{WAREHOUSE_SIZE_SUFFIX}\', '
				f'warehouse \'{WAREHOUSE_SIZE_SUFFIX}\' is used for this session')
    LOGGER.info(f"*** Setting up the time format is: alter session set timestamp_output_format = 'YYYY-MM-DD HH24:MI:SS.FF'; ***")
    cursor_sf.execute("alter session set timestamp_output_format = 'YYYY-MM-DD HH24:MI:SS.FF'")
    #Taking the current_timestamp for start time
    cursor_sf.execute("select current_timestamp")
    rpt_strt_dtm = str(cursor_sf.fetchone()[0])[:26]
    number_of_tries = int(number_of_tries) + 1
    if (number_of_tries > 2):
        number_of_tries = int(number_of_tries) - 1
        LOGGER.info('*** Number of Tries are more than allowed Not Processing again for rpt_run_id - {rpt_run_id}, number_of_tries - {number_of_tries}  ***')
        log_error_to_rds(LOGGER, conn_sf, cursor_sf, conn_rds, cursor_rds, rpt_run_id, rpt_strt_dtm, number_of_tries, f'FAILED', f"For the rpt_run_id - {rpt_run_id}, Maximum allowed Number of retries - {number_of_tries}, were reached.", "FAILED")
        sys.exit(1)
    #Checking the rpt_run_id is greater than benchmark rpt_run_id reserved numbers
    if (rpt_run_id <= 100000):
        LOGGER.info('*** rpt_run_id - {rpt_run_id} is not greater than Benchmark RPT_RUN_ID allowed range  ***')
        log_error_to_rds(LOGGER, conn_sf, cursor_sf, conn_rds, cursor_rds, rpt_run_id, rpt_strt_dtm, number_of_tries, f'INVALID_REQUEST', f"rpt_run_id - {rpt_run_id} is not greater than Benchmark RPT_RUN_ID allowed range, please check.", "INVALID_REQUEST")
        sys.exit(1)
    #-------------------------------------------------------------------------------------------------------------------#
    # Updating the status to ETL_IN_PROGRESS in RDS for a given RPT_RUN_ID
    #-------------------------------------------------------------------------------------------------------------------#
    update_rds_cstm_rqst_sql = f"update aciisst_appl.aciisst_rpt_cstm_rqst set rqst_stts_txt = 'ETL_IN_PROGRESS', err_txt = 'Running - StandardInsightsL2Process' where pkg_id = {rpt_run_id}"
    LOGGER.info(f'*** Executing the Query on RDS L#2 Tables Status for gvien rpt_run_id:{update_rds_cstm_rqst_sql} ***')
    cursor_rds.execute(update_rds_cstm_rqst_sql)
    conn_rds.commit()
    #-------------------------------------------------------------------------------------------------------------------#
    # Checking count of records in RDS for a given RPT_RUN_ID
    #-------------------------------------------------------------------------------------------------------------------#
    count_query = f"select count(*) from aciisst_appl.aciisst_rpt_cstm_rqst where pkg_id = {rpt_run_id}"
    LOGGER.info(f'*** Executing the Query on RDS L#2 Tables to Fetch count:{count_query} ***')
    cursor_rds.execute(count_query)
    result_count = cursor_rds.fetchone()[0]
    if (result_count == 1):
        LOGGER.info(f'*** Calling update function to update the status to completed as it is a duplicate request - rpt_run_id:{rpt_run_id} ***')
        final_status_dtls_rqst_update(LOGGER, conn_sf, cursor_sf, conn_rds, cursor_rds, rpt_run_id, rpt_strt_dtm, number_of_tries)
        sys.exit(0)
    
    LOGGER.info(f"*** Calling l2 Process Details Get Function - l2_process_get_details_rds***")
    if ( manual_run == 'YES'):
        l2_process_details_manual_query = f"select as_of_mnth_nbr ,l2_rpt_run_id, case when (lower(trim(as_of_mnth_nbr)) <> lower(trim(ui_as_of_year_mnth_nbr)) or lower(trim(rqst.tm_prd_type_cd)) = 'custom') then cast(l2_rpt_run_id as varchar) else cast(parm.rpt_run_id as varchar) end as l2_rpt_run_id_bnchmrk, acct_id,src_fltr_id,l2_rpt_shrt_nm ,rqst.tm_prd_type_cd,rqst.incrd_paid_cd,rqst.hcc_thrshld_amt ,year_id,cp_stndrd_strt_mnth_nbr ,cp_stndrd_end_mnth_nbr ,cp_srvc_strt_mnth_nbr ,cp_srvc_end_mnth_nbr ,cp_paid_strt_mnth_nbr ,cp_paid_end_mnth_nbr ,pp_1_stndrd_strt_mnth_nbr ,pp_1_stndrd_end_mnth_nbr ,pp_1_srvc_strt_mnth_nbr ,pp_1_srvc_end_mnth_nbr ,pp_1_paid_strt_mnth_nbr ,pp_1_paid_end_mnth_nbr ,pp_2_stndrd_strt_mnth_nbr ,pp_2_stndrd_end_mnth_nbr ,pp_2_srvc_strt_mnth_nbr ,pp_2_srvc_end_mnth_nbr ,pp_2_paid_strt_mnth_nbr ,pp_2_paid_end_mnth_nbr, ui_as_of_year_mnth_nbr, ui_tm_prd_type_cd from (select '{as_of_year_mnth_nbr}' as as_of_mnth_nbr ,cast('{rpt_run_id}' as varchar) as l2_rpt_run_id, '{acct_id}' as acct_id,'{src_fltr_id}' as src_fltr_id,case when (lower(trim('{as_of_year_mnth_nbr}')) <> lower(trim('{ui_as_of_year_mnth_nbr}')) or lower(trim('{tm_prd_type_cd}')) = 'custom') then concat('{l2_rpt_shrt_nm}', ',BNCHMRK') else '{l2_rpt_shrt_nm}' end as l2_rpt_shrt_nm ,case when (lower(trim('{as_of_year_mnth_nbr}')) <> lower(trim('{ui_as_of_year_mnth_nbr}')) or lower(trim('{tm_prd_type_cd}')) = 'custom') then cast('{rpt_run_id}' as varchar) else '{tm_prd_type_cd}' end as tm_prd_type_cd,'{incrd_paid_cd}' as incrd_paid_cd,cast('{hcc_thrshld_amt}' as varchar) as hcc_thrshld_amt ,cast('{year_id}' as varchar) as year_id,coalesce('{cp_stndrd_strt_mnth_nbr}','') as cp_stndrd_strt_mnth_nbr ,coalesce('{cp_stndrd_end_mnth_nbr}','') as cp_stndrd_end_mnth_nbr ,coalesce('{cp_srvc_strt_mnth_nbr}','') as cp_srvc_strt_mnth_nbr ,coalesce('{cp_srvc_end_mnth_nbr}','') as cp_srvc_end_mnth_nbr ,coalesce('{cp_paid_strt_mnth_nbr}','') as cp_paid_strt_mnth_nbr ,coalesce('{cp_paid_end_mnth_nbr}','') as cp_paid_end_mnth_nbr ,coalesce('{pp_1_stndrd_strt_mnth_nbr}','') as pp_1_stndrd_strt_mnth_nbr ,coalesce('{pp_1_stndrd_end_mnth_nbr}','') as pp_1_stndrd_end_mnth_nbr ,coalesce('{pp_1_srvc_strt_mnth_nbr}','') as pp_1_srvc_strt_mnth_nbr ,coalesce('{pp_1_srvc_end_mnth_nbr}','') as pp_1_srvc_end_mnth_nbr ,coalesce('{pp_1_paid_strt_mnth_nbr}','') as pp_1_paid_strt_mnth_nbr ,coalesce('{pp_1_paid_end_mnth_nbr}','') as pp_1_paid_end_mnth_nbr ,coalesce('{pp_2_stndrd_strt_mnth_nbr}','') as pp_2_stndrd_strt_mnth_nbr ,coalesce('{pp_2_stndrd_end_mnth_nbr}','') as pp_2_stndrd_end_mnth_nbr ,coalesce('{pp_2_srvc_strt_mnth_nbr}','') as pp_2_srvc_strt_mnth_nbr ,coalesce('{pp_2_srvc_end_mnth_nbr}','') as pp_2_srvc_end_mnth_nbr ,coalesce('{pp_2_paid_strt_mnth_nbr}','') as pp_2_paid_strt_mnth_nbr ,coalesce('{pp_2_paid_end_mnth_nbr}','') as pp_2_paid_end_mnth_nbr, lower(trim('{ui_as_of_year_mnth_nbr}')) as ui_as_of_year_mnth_nbr, lower(trim('{ui_tm_prd_type_cd}')) as ui_tm_prd_type_cd) rqst left join aciisst_appl.cii_bnchmrk_parm parm on lower(trim(rqst.tm_prd_type_cd)) = lower(trim(parm.tm_prd_type_cd)) and lower(trim(rqst.incrd_paid_cd)) = lower(trim(parm.incrd_paid_cd)) where rqst.l2_rpt_run_id = '{rpt_run_id}'"
        LOGGER.info(f'*** Executing the Query on RDS to get manual run L#2 details:{l2_process_details_manual_query} ***')
        cursor_rds.execute(l2_process_details_manual_query)
        result = cursor_rds.fetchall()
        if (len(result) > 0):
            l2_process_get_details_data = result
            LOGGER.info(f'*** Result of the manual run L#2 Query:{l2_process_get_details_data} ***')
        else:
            raise Exception(f"No Records found for the given - RPT_RUN_ID - {rpt_run_id}")
    else:
        l2_process_get_details_data = l2_process_get_details_rds(LOGGER, conn_sf, cursor_sf, conn_rds, cursor_rds, rpt_run_id, "l2_process_get_details_rds", rpt_strt_dtm, number_of_tries)
    
    LOGGER.info(f"*** Calling Function to generate time period temp sql using the input received from RDS for a given RPT_RUN_ID ***")
    rqst_tm_prd_dtl, l2_rpt_run_id_bnchmrk, l2_rpt_shrt_nm, src_fltr_id = generate_rqst_tm_prd_dtl(conn_sf, cursor_sf, conn_rds, cursor_rds, "generate_rqst_tm_prd_dtl", l2_process_get_details_data)
    LOGGER.info(f"*** Generated Time Period Details SQL for a given RPT_RUN_ID : {rqst_tm_prd_dtl}***")
    
    #Generated rpt_shrt_nm which can be passed as parameter to sqls
    counter = 0
    rpt_shrt_nm = ''
    #-----------------------------------------------------------------------------------------------------------------------------
    #As we have two variable names in our Summary SQLs we are trying to populate rpt_run_id that is common to both the variables
    #rpt_run_id variable represent without benchmark
    #rpt_run_id_bnchmrk variabel represent with benchmark
    #-----------------------------------------------------------------------------------------------------------------------------
    rpt_run_id = str(rpt_run_id)
    rpt_run_id_bnchmrk = l2_rpt_run_id_bnchmrk
    for shrt_nm in l2_rpt_shrt_nm:
        counter = counter + 1
        if (counter == len(l2_rpt_shrt_nm)):
            rpt_shrt_nm = rpt_shrt_nm + "'" + shrt_nm + "'"
        else:
            rpt_shrt_nm = rpt_shrt_nm + "'" + shrt_nm + "'" + ","
    LOGGER.info(f"*** Report Short Names - rpt_shrt_nm : {rpt_shrt_nm}***")
    LOGGER.info(f"*** Report Run Id - rpt_run_id : {rpt_run_id}***")
    LOGGER.info(f"*** Report Run Id - rpt_run_id_bnchmrk : {rpt_run_id_bnchmrk}***")
    #parameters that needs to be replaced in sqls
    max_elapsed_time = '1d'

    parms = {}
    parms["rqst_tm_prd_dtl"] = rqst_tm_prd_dtl
    parms["re_run"] = re_run
    parms["rpt_shrt_nm"] = rpt_shrt_nm
    parms["src_fltr_id"] = f"'{src_fltr_id}'"
    parms["rpt_shrt_nm_list"] = rpt_shrt_nm
    #parms["snowflake_rds_details_path"] = "s3://antm-cii-${env}-codez-nogbd-nophi-useast1/cii/snowflake-etl/static-rpt/cii_snowlflake_rds_cii_sr_cmpltd_rpt.json".format(env=ENV)
    #parms["target_rds_database_table_name"] = "aciisst_appl.aciisst_rpt_instnc_mtdta"
    parms["delete_target_rds_table"] = "'YES'"
    parms["swap_target_rds_table"] = "NO"
    parms["sr_run_prd_schema"] = aciisst_adhoc_schema_name
    parms["clnt_prty_grp_cd"] = "'ALL'"
    parms["rpt_run_id"] = rpt_run_id
    parms["rpt_run_id_bnchmrk"] = rpt_run_id_bnchmrk
    parms["rpt_run_id_bnchmrk_min"] = rpt_run_id
    parms["rpt_run_id_bnchmrk_max"] = rpt_run_id
    parms["clnt_prty_grp_cd_bnchmrk"] = "ALL%"
    parms["aciisst_adhoc_schema_name"] = aciisst_adhoc_schema_name
    parms["aciisst_schema_name"] = aciisst_schema_name
    parms["evolve_schema_name"] = evolve_schema_name
    #-----------------------------------------------------------------------------------------------------------------------------
    #Logic to Read SQL from S3 and Submit SQLs to Snowflake and Check Status
    #Write SQLs State to RDS table - ETL_EVOLVE_JOB_HIST for each request/rpt_run_id on each step level
    #This process is having 7 Steps
    #Step#1 - Time Period Table Load for for Input RPT_RUN_ID & RPT_SHRT_NMs
    #Step#2 - Independent Summary and Work Tables Load for Input RPT_RUN_ID & RPT_SHRT_NMs
    #Step#3 - Work Tables and Summary Tables Load which depend on Step#2 for Input RPT_RUN_ID & RPT_SHRT_NMs
    #Step#4 - Summary Tables Load which depend on Step#2 & Step#3 for Input RPT_RUN_ID & RPT_SHRT_NMs
    #Step#5 - CII_SR_CMPLTD_RPT load to Snowflake for Input RPT_RUN_ID & RPT_SHRT_NMs
    #Step#6 - aciisst_rpt_instnc_mtdta load to RDS from CII_SR_CMPLTD_RPT table Snowflake for Input RPT_RUN_ID & RPT_SHRT_NMs
    #Step#7 - Update Status(Success/Failure) for Input RPT_RUN_ID in RDS L#2_STATUS table & updating rqst_dtl table for UI/Middleware usage
    #-----------------------------------------------------------------------------------------------------------------------------
    sql_file_list = []
    s3_sql_bucket = l2_sqls_path.split("//")[1].split("/")[0]
    s3_sql_key = "/".join(l2_sqls_path.replace("//", "").split("/")[1:])
    json_obj = _read_s3_object(l2_config_file)
    l2_config = json_obj.get()['Body'].read().decode('utf-8').replace("\n","").split(";")
    for l2_conf in l2_config:
        l2_conf_list = l2_conf.split(":")
        step_name = l2_conf_list[0]
        #Collecting worktable sql files into a list variable
        if (step_name.strip().lower() == 'step#0'):
            LOGGER.info(f"*** Started Process for Step : {step_name}***")
            work_tables_list = l2_conf_list[1].split("|")
            LOGGER.info(f"*** Process Completed Till Step : {step_name}***")
        l2_config_sql_file_names = l2_conf_list[1].split("|")
        #Calling open_sql_file function to fetch sqls and add parameters to it
        if ((int(step_name.split("#")[1]) > 0) and (int(step_name.split("#")[1]) <= 5)):
            for path in l2_config_sql_file_names:
                sql_file_list.append(s3_sql_key + "/" + path)
            LOGGER.info(f"*** Started Process for Step : {step_name}, {sql_file_list}***")
            sqls = open_sql_file(conn_sf, cursor_sf, conn_rds, cursor_rds, s3_sql_bucket, sql_file_list, work_tables_list, l2_rpt_shrt_nm, parms, rpt_run_id, step_name, rpt_strt_dtm, number_of_tries)
            reslt_qid_dict, reslt_qid_lst = submit_sql_to_snowflake(conn_sf, cursor_sf, conn_rds, cursor_rds, sqls, rpt_run_id, step_name, rpt_strt_dtm, number_of_tries)
            reslt_qid_dict_final = check_sfqid_status(conn_sf, cursor_sf, conn_rds, cursor_rds, rpt_run_id, step_name, rpt_strt_dtm, number_of_tries, reslt_qid_dict, reslt_qid_lst, max_elapsed_time)
            LOGGER.info(f"*** Process Completed Till Step : {step_name}***")
            #Initializing sql_file_list
            sql_file_list = []
        if ( step_name.strip().lower() == 'step#6' and manual_run != 'YES' ):
            LOGGER.info(f"*** Started Process for Step : {step_name}***")
            cmpltd_rpt_json_file = l2_conf_list[1].split("|")
            #Reading Snowflake RDS Details
            json_obj = _read_s3_object(l2_sqls_path + "/" + cmpltd_rpt_json_file[0])
            snowflake_rds_details = json.loads(json_obj.get()['Body'].read().decode('utf-8'))
            source_snowflake_query_to_run = snowflake_rds_details['source_snowflake_query_to_run']['query'].replace("${aciisst_adhoc_schema_name}",aciisst_adhoc_schema_name)
            delete_target_rds_table_query = snowflake_rds_details['delete_target_rds_table_query']['query']
            LOGGER.info(f'Input Snowflake Query - {source_snowflake_query_to_run} \nInput Delete RDS Query - {delete_target_rds_table_query}')
            snowflake_to_rds_load_data(LOGGER, conn_sf, cursor_sf, cursor_rds, conn_rds, source_snowflake_query_to_run, "aciisst_appl.aciisst_rpt_instnc_mtdta", "YES", delete_target_rds_table_query, "NO", parms, rpt_run_id, step_name, rpt_strt_dtm, number_of_tries)
            LOGGER.info(f"*** Process Completed Till Step : {step_name}***")
            #Initializing sql_file_list again
            sql_file_list = []
        if ( step_name.strip().lower() == 'step#7' and manual_run != 'YES' ):
            LOGGER.info(f"*** Started Process for Step : {step_name}***")
            final_status_dtls_rqst_update(LOGGER, conn_sf, cursor_sf, conn_rds, cursor_rds, rpt_run_id, rpt_strt_dtm, number_of_tries)
            LOGGER.info(f"*** Process Completed Till Step : {step_name}***")
            #Initializing sql_file_list again
            sql_file_list = []
    
except Exception as e:
	LOGGER.critical('*** ERROR: %s ***', e)
	error_detail = str(e)
	log_error_to_rds(LOGGER, conn_sf, cursor_sf, conn_rds, cursor_rds, rpt_run_id, rpt_strt_dtm, number_of_tries, f'RETRY', error_detail, "RETRY")
	raise e
#---------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------#