"""
DOCSTRING : Python Script to Purge and append records in ACIISST_SGMNTN_BRDG in ACIISST_APPL in Snowflake
"""
## This script requires parameters such as aplctn_cd, snowflake_env,warehouse_size_suffix and env

import re
import snowflake.connector as sf
# from snowflake.connector import DictCursor
from awsglue.utils import getResolvedOptions
from ReduceReuseRecycle import *
from ReduceReuseRecycle.snowflakefunc import *


#Import common Modules
import os
import sys
import json
import re
import boto3
from datetime import *
from awsglue.utils import getResolvedOptions
from botocore.exceptions import ClientError
from ReduceReuseRecycle import load_log_config, InvalidStatus

#---------------------------------------------------------------------------------#
# Creating boto3 client for glue, stepfuntion, s3, sns                            #
#---------------------------------------------------------------------------------#
glue = boto3.client('glue')
client = boto3.client('s3')
sns = boto3.client('sns')
sfn = boto3.client('stepfunctions')

LOGGER = load_log_config(glue=True)

LOGGER.info("Reading Glue Job Parameters... \n")

# Parse Arguments for Glue Job

# Define mandatory params
params = [
    'env'
]

# Parse Arguments for Glue Job
ARGS = getResolvedOptions(sys.argv, params)

PRCSNG_TYPE = ARGS.get('prcsng_type', 'DML ON ACIISST_SGMNTN_BRDG').lower()


SRC_TBL_NM_1 = 'ACIISST_SGMNTN_BRDG_SCD'
SRC_TBL_SCHEMA_1 = 'ACIISST'
SRC_TBL_NM_2 = 'ACIISST_SGMNTN_BRDG_SAVE_FLTR'
SRC_TBL_SCHEMA_2 = 'ACIISST_APPL'
TGT_TBL_NM = 'ACIISST_SGMNTN_BRDG'
TGT_TBL_SCHEMA = 'ACIISST_APPL'
ENV = ARGS['env']
REGION_NAME = 'us-east-1'


APLCTN_CD = ARGS.get('aplctn_cd', 'cii').lower()

WAREHOUSE_SIZE_SUFFIX = ARGS.get('warehouse_size_suffix', '')
if ARGS.get('warehouse_size_suffix') is None:
    LOGGER.info('No WAREHOUSE_SIZE_SUFFIX Parameter Specified - Defaulting to blank  \'\' . \n')

# Fetch the SECRET Instance based on Application Code
SECRET = get_secret(LOGGER, ENV, REGION_NAME, f"/snowflake/{APLCTN_CD}")

SECRET_JSON = json.loads(SECRET)
	


LOGGER.info(f'\n**** Argument List ****\n-----------------------')
LOGGER.info(f'\nREGION_NAME : {REGION_NAME} \nENV : {ENV} \nAPLCTN_CD : {APLCTN_CD} \nPRCSNG_TYPE : {PRCSNG_TYPE} '
            f'\nSRC_TBL_NM_1 : {SRC_TBL_NM_1} \nSRC_TBL_SCHEMA_1 : {SRC_TBL_SCHEMA_1} '
            f'\nSRC_TBL_NM_2 : {SRC_TBL_NM_2} \nSRC_TBL_SCHEMA_2: {SRC_TBL_SCHEMA_2} '
            f'\nTGT_TBL_NM: {TGT_TBL_NM} \nTGT_TBL_SCHEMA : {TGT_TBL_SCHEMA} '
            f'\nWAREHOUSE_SIZE_SUFFIX : {WAREHOUSE_SIZE_SUFFIX}')
LOGGER.info(f'\n-----------------------\n')

# Defing the functions

#---------------------------------------------------------------------------------#
#Class to get the Account Number                                                  #
#---------------------------------------------------------------------------------#
class acc_info:
    sts_function_client=boto3.client('sts')
    def __init__(self):
        acc_details=acc_info.sts_function_client.get_caller_identity()
        self.account=acc_details['Account']
    @property
    def get_account(self):
        return self.account

def count_check_sql(schema, table):
	"""
	Function to generate Snowflake count SQL
	:param schema: Name of the Snowflake Schema
	:param table: Name of the Snowflake Table
	:return: SQL Command to check count
	"""
	count_sql = f'SELECT COUNT(*) FROM {schema}.{table} where FLTR_SRC_NM  not in (\'User Session\')'

	return count_sql

def purge_sql_scd(schema, table):
    """
    Function to generate Snowflake purge table SQL
    :param schema: Name of the Snowflake Schema
    :param table: Name of the Snowflake Table
    :return: SQL Command to Truncate Table
    """
    purge_sql_scd = f'DELETE FROM {schema}.{table} WHERE FLTR_SRC_NM in (\'ERSU\',\'Account\',\'Saved List\')'

    return purge_sql_scd

def purge_sql_svfltr(src_schema, src_table, tgt_schema, tgt_table):
	"""
	Function to generate Snowflake purge table SQL
	:param src_schema: Name of the Snowflake Source Schema
	:param src_table: Name of the Snowflake Source Table
	:param tgt_schema: Name of the Snowflake Target Schema
	:param tgt_table: Name of the Snowflake Target Table
	:return: SQL Command to Truncate Table
	"""
	purge_sql_svfltr = f'DELETE FROM {tgt_schema}.{tgt_table} USING {src_schema}.{src_table} WHERE {tgt_schema}.{tgt_table}.SRC_FLTR_ID={src_schema}.{src_table}.SRC_FLTR_ID'

	return purge_sql_svfltr

def append_to_target(src_schema, src_table, tgt_schema, tgt_table):
	"""
	Function to generate Snowflake append table SQL
	:param src_schema: Name of the Snowflake Source Schema
	:param src_table: Name of the Snowflake Source Table
	:param tgt_schema: Name of the Snowflake Target Schema
	:param tgt_table: Name of the Snowflake Target Table
	:return: SQL Command to Append To Target Table
	"""
	append_sql = f'INSERT INTO {tgt_schema}.{tgt_table}(ACCT_ID,SGMNTN_DIM_KEY,ACIISST_USER_ID,SGMNTN_NM,FLTR_SRC_NM,SRC_FLTR_ID,PBLC_CD,PRVCY_CD,CREATD_DTM,CREATD_BY_USER_ID) SELECT ACCT_ID,SGMNTN_DIM_KEY,ACIISST_USER_ID,SGMNTN_NM,FLTR_SRC_NM,SRC_FLTR_ID,PBLC_CD,PRVCY_CD,CREATD_DTM,CREATD_BY_USER_ID FROM {src_schema}.{src_table}'

	return append_sql
	
def null_check(schema, table):
	"""
	Function to generate Snowflake Null Check SQL for brdige table
	:return: SQL Command to null check
	"""
	null_check_sql = f'select count(*) from ( select * from ACIISST_APPL.ACIISST_SGMNTN_BRDG where acct_id  is null or sgmntn_dim_key  is null or aciisst_user_id  is null or sgmntn_nm  is null or fltr_src_nm  is null or src_fltr_id  is null or  pblc_cd  is null or prvcy_cd  is null or creatd_dtm is null or creatd_by_user_id  is null )null_check'

	return null_check_sql

def dup_check(schema, table):
	"""
	Function to generate Snowflake duplicate Check SQL for brdige table
	:return: SQL Command to duplicate check
	"""
	dup_check_sql = f'select count(*) from( select acct_id, sgmntn_dim_key, sgmntn_nm,src_fltr_id from ACIISST_APPL.ACIISST_SGMNTN_BRDG group by acct_id, sgmntn_dim_key, sgmntn_nm,src_fltr_id having count(*) > 1 )dups'

	return dup_check_sql

	
	
def ersu_count_check_brdg(schema, table):
	"""
	Function to generate Snowflake counts for brdige table for ERSU records
	:return: SQL Command to count to check ERSU records in Brdige table
	"""
	ersu_count_check_brdg_sql = f'select  count(*) from ACIISST_APPL.ACIISST_SGMNTN_BRDG where fltr_src_nm = \'ERSU\''

	return ersu_count_check_brdg_sql

def ersu_count_check_scd(schema, table):
	"""
	Function to generate Snowflake counts for brdige SCD table for ERSU records
	:return: SQL Command to count to check ERSU records in Brdige SCD work table
	"""
	ersu_count_check_scd_sql = f'select  count(*) from ACIISST.ACIISST_SGMNTN_BRDG_SCD where fltr_src_nm = \'ERSU\''

	return ersu_count_check_scd_sql
	
	

def acct_count_check_brdg(schema, table):
	"""
	Function to generate Snowflake counts for brdige table for Total Account records
	:return: SQL Command to count to check Total Account records in Brdige table
	"""
	acct_count_check_brdg_sql = f'select  count(*) from ACIISST_APPL.ACIISST_SGMNTN_BRDG where fltr_src_nm = \'Account\''

	return acct_count_check_brdg_sql

def acct_count_check_scd(schema, table):
	"""
	Function to generate Snowflake counts for brdige SCD table for Total Account records
	:return: SQL Command to count to check Total Account records in Brdige SCD work table
	"""
	acct_count_check_scd_sql = f'select  count(*) from ACIISST.ACIISST_SGMNTN_BRDG_SCD where fltr_src_nm = \'Account\''

	return acct_count_check_scd_sql	
	

def fltr_count_check_brdg(schema, table):
	"""
	Function to generate Snowflake counts for brdige table for Save Filter records
	:return: SQL Command to count to check Save Filter records in Brdige table
	"""
	fltr_count_check_brdg_sql = f'select  count(*) from ACIISST_APPL.ACIISST_SGMNTN_BRDG where fltr_src_nm = \'Saved List\''

	return fltr_count_check_brdg_sql

def fltr_count_check_scd(schema, table):
	"""
	Function to generate Snowflake counts for brdige SCD table for Save Filter  records
	:return: SQL Command to count to check  Save Filter records in Brdige SCD work table
	"""
	fltr_count_check_scd_sql = f'select  count(*) from ACIISST_APPL.ACIISST_SGMNTN_BRDG_SAVE_FLTR where fltr_src_nm = \'Saved List\''

	return fltr_count_check_scd_sql	
	

#---------------------------------------------------------------------------------#
# Function to Send SNS for Success                                                #
#---------------------------------------------------------------------------------#
def snsPublication(LOGGER, subject, message):
    region_name = os.environ['AWS_DEFAULT_REGION']
    account = acc_info().get_account
    sns_arn = 'arn:aws:sns:' \
              + region_name + ':' \
              + account + ':{ENV}-snsCIIPublication'.format(ENV=ENV)
    subject = subject
    LOGGER.info('SNS ARN: %s', sns_arn)
    try:
        formatted_msg = message
        response = sns.publish(TargetArn=sns_arn,
                              Message=formatted_msg,
                              Subject=subject,
                              MessageStructure='string'
                              )
                               
        LOGGER.info('SNS Response: %s', response)
    except ClientError as sns_error:
        LOGGER.critical('*** SNS Message Publication Failed: %s ***', sns_error)
        raise sns_error
    	

#---------------------------------------------------------------------------------#
# Function to Send SNS for Failure                                                #
#---------------------------------------------------------------------------------#
def snsNotification(LOGGER, subject, message):
    region_name = os.environ['AWS_DEFAULT_REGION']
    account = acc_info().get_account
    sns_arn = 'arn:aws:sns:' \
              + region_name + ':' \
              + account + ':{ENV}-snsCIINotification'.format(ENV=ENV)
    subject = subject
    LOGGER.info('SNS ARN: %s', sns_arn)
    try:
        formatted_msg = message
        response = sns.publish(TargetArn=sns_arn,
                              Message=formatted_msg,
                              Subject=subject,
                              MessageStructure='string'
                              )
                               
        LOGGER.info('SNS Response: %s', response)
    except ClientError as sns_error:
        LOGGER.critical('*** SNS Message Notification Failed: %s ***', sns_error)
        raise sns_error
    	

	
def main():
	"""
	Establishes a Snowflake Connection Object and Executes a Purge and append command
	:return: Completes the Snowflake purge and append to ACIISST_SGMNTN_BRDG
	"""
	# Create SQL Cursor from Function 'snowflake_conn'
	LOGGER.info('*** Creating Snowflake Connection & Cursor ***')

	try:
		conn = snowflake_conn(logger=LOGGER, aplctn_cd=APLCTN_CD, secret=SECRET, warehouse_size_suffix=WAREHOUSE_SIZE_SUFFIX)
		cursor = conn.cursor()
		LOGGER.info('*** Created Snowflake Connection & Cursor ***')
		warehouse = SECRET_JSON.get(f'{APLCTN_CD}_warehouse')
		warehouse = warehouse + WAREHOUSE_SIZE_SUFFIX
		LOGGER.info(f'Based on warehouse size value passed as \'{WAREHOUSE_SIZE_SUFFIX}\', '
					f'warehouse \'{warehouse}\' is used for this session')

	except sf.DatabaseError as SnowflakeConnectionFailure:
		LOGGER.critical('*** CRITICAL: Cannot establish connection with Snowflake ***')
		LOGGER.critical(SnowflakeConnectionFailure)
		raise SnowflakeConnectionFailure
	
	# CHECKING COUNT OF RECORDS IN ACIISST_SGMNTN_BRDG  BEFORE DELETE
	try:
		LOGGER.info(f'*** CHECKING COUNT OF RECORDS IN {TGT_TBL_SCHEMA}.{TGT_TBL_NM}***')
		count_check = count_check_sql(TGT_TBL_SCHEMA, TGT_TBL_NM)
		LOGGER.info(f'*** Count Before Operation Command is: {count_check} ***')
		cursor.execute(count_check)
		count = cursor.fetchone()[0]
		LOGGER.info(f'*** COUNT: Before Operation {TGT_TBL_SCHEMA}.{TGT_TBL_NM} is {count} ***')


	except sf.ProgrammingError as GenericSnowflakeException:
		LOGGER.critical('*** ERROR: Snowflake Count before Operation {TGT_TBL_SCHEMA}.{TGT_TBL_NM}***')
		LOGGER.critical(GenericSnowflakeException)
		raise GenericSnowflakeException


	# Deleting records from ACIISST_SGMNTN_BRDG for ERSU and Account Records and also save list

	try:
		LOGGER.info(f'*** Deleting records from  Table {TGT_TBL_SCHEMA}.{TGT_TBL_NM}***')
		purge_table_scd = purge_sql_scd(TGT_TBL_SCHEMA, TGT_TBL_NM)
		LOGGER.info(f'*** Purge Table Command is: {purge_table_scd} ***')
		cursor.execute(purge_table_scd)
		LOGGER.info(f'*** SUCCESS: Purged {TGT_TBL_SCHEMA}.{TGT_TBL_NM} For SCD***')


	except sf.ProgrammingError as GenericSnowflakeException:
		LOGGER.critical('*** ERROR: Snowflake Purge Failed for {TGT_TBL_SCHEMA}.{TGT_TBL_NM} For SCD***')
		LOGGER.critical(GenericSnowflakeException)
		raise GenericSnowflakeException

		
		
	#Deleting records from ACIISST_SGMNTN_BRDG for ERSU  for save filter  changed the delete logic to delete all save list records from segmentation table
#	try:
#		LOGGER.info(f'*** Deleting records from  Table {TGT_TBL_SCHEMA}.{TGT_TBL_NM}***')
#		purge_table_save = purge_sql_svfltr(SRC_TBL_SCHEMA_2,SRC_TBL_NM_2,TGT_TBL_SCHEMA, TGT_TBL_NM)
#		LOGGER.info(f'*** Purge Table Command is: {purge_table_save} ***')
#		cursor.execute(purge_table_save)
#		LOGGER.info(f'*** SUCCESS: Purged {TGT_TBL_SCHEMA}.{TGT_TBL_NM} For Save Filter***')
#
#
#	except sf.ProgrammingError as GenericSnowflakeException:
#		LOGGER.critical('*** ERROR: Snowflake Purge Failed for {TGT_TBL_SCHEMA}.{TGT_TBL_NM} For Save Filter***')
#		LOGGER.critical(GenericSnowflakeException)
#		raise GenericSnowflakeException

	
	
	
	
	# Appending records to ACIISST_SGMNTN_BRDG for ERSU and Account 

	try:
		LOGGER.info(f'*** Appending records from  Table {SRC_TBL_SCHEMA_1}.{SRC_TBL_NM_1} to {TGT_TBL_SCHEMA}.{TGT_TBL_NM} ***')
		append_table_scd = append_to_target(SRC_TBL_SCHEMA_1,SRC_TBL_NM_1,TGT_TBL_SCHEMA, TGT_TBL_NM)
		LOGGER.info(f'*** Append To Table Command from SCD work table is: {append_table_scd} ***')
		cursor.execute(append_table_scd)
		LOGGER.info(f'*** SUCCESS: Append to {TGT_TBL_SCHEMA}.{TGT_TBL_NM} For SCD and Total Account***')
		
	except sf.ProgrammingError as GenericSnowflakeException:
		LOGGER.critical('*** ERROR: Snowflake Append Failed for {TGT_TBL_SCHEMA}.{TGT_TBL_NM} For SCD and Total Account***')
		LOGGER.critical(GenericSnowflakeException)
		raise GenericSnowflakeException

	# Appending records to ACIISST_SGMNTN_BRDG for Save Filter  uncomment this for Jan release
	try:
		LOGGER.info(f'*** Appending records from  Table {SRC_TBL_SCHEMA_2}.{SRC_TBL_NM_2} to {TGT_TBL_SCHEMA}.{TGT_TBL_NM} ***')
		append_table_save = append_to_target(SRC_TBL_SCHEMA_2,SRC_TBL_NM_2,TGT_TBL_SCHEMA, TGT_TBL_NM)
		LOGGER.info(f'*** Append To Table Command for save filter is: {append_table_save} ***')
		cursor.execute(append_table_save)
		LOGGER.info(f'*** SUCCESS: Append to {TGT_TBL_SCHEMA}.{TGT_TBL_NM} For save Filter***')
		
	except sf.ProgrammingError as GenericSnowflakeException:
		LOGGER.critical('*** ERROR: Snowflake Append Failed for {TGT_TBL_SCHEMA}.{TGT_TBL_NM} For Save filter***')
		LOGGER.critical(GenericSnowflakeException)

		raise GenericSnowflakeException

		
	# CHECKING COUNT OF RECORDS IN ACIISST_SGMNTN_BRDG  AFTER APPEND
	try:
		LOGGER.info(f'*** CHECKING COUNT OF RECORDS IN {TGT_TBL_SCHEMA}.{TGT_TBL_NM} After Append and Delete***')
		count_check = count_check_sql(TGT_TBL_SCHEMA, TGT_TBL_NM)
		LOGGER.info(f'*** Count Command is: {count_check} ***')
		cursor.execute(count_check)
		count = cursor.fetchone()[0]
		LOGGER.info(f'*** COUNT: Post Append in {TGT_TBL_SCHEMA}.{TGT_TBL_NM} is {count} ***')

		#Null Check
		null_check_sql = null_check(TGT_TBL_SCHEMA, TGT_TBL_NM)
		cursor.execute(null_check_sql)
		null_count = cursor.fetchone()[0]

		#Duplicate Check
		dup_check_sql = dup_check(TGT_TBL_SCHEMA, TGT_TBL_NM)
		cursor.execute(dup_check_sql)
		dup_count = cursor.fetchone()[0]

		#ERSU Count check
		ersu_count_check_brdg_sql = ersu_count_check_brdg(TGT_TBL_SCHEMA, TGT_TBL_NM)
		cursor.execute(ersu_count_check_brdg_sql)
		ersu_brdg_count = cursor.fetchone()[0]

		ersu_count_check_scd_sql = ersu_count_check_scd(TGT_TBL_SCHEMA, TGT_TBL_NM)
		cursor.execute(ersu_count_check_scd_sql)
		ersu_scd_count = cursor.fetchone()[0]

		#Total Account Count check
		acct_count_check_brdg_sql = acct_count_check_brdg(TGT_TBL_SCHEMA, TGT_TBL_NM)
		cursor.execute(acct_count_check_brdg_sql)
		acct_brdg_count = cursor.fetchone()[0]

		acct_count_check_scd_sql = acct_count_check_scd(TGT_TBL_SCHEMA, TGT_TBL_NM)
		cursor.execute(acct_count_check_scd_sql)
		acct_scd_count = cursor.fetchone()[0]

		# Save Filter Count check
		fltr_count_check_brdg_sql = fltr_count_check_brdg(TGT_TBL_SCHEMA, TGT_TBL_NM)
		cursor.execute(fltr_count_check_brdg_sql)
		fltr_brdg_count = cursor.fetchone()[0]

		fltr_count_check_scd_sql = fltr_count_check_scd(TGT_TBL_SCHEMA, TGT_TBL_NM)
		cursor.execute(fltr_count_check_scd_sql)
		fltr_scd_count = cursor.fetchone()[0]

		LOGGER.info(f'*** Total Count in Brdige Table is {count}, Duplicate Count in Brdige Table is {dup_count}, Null Count in Brdige Table is {null_count} ,	ERSU Count in Brdige table is {ersu_brdg_count}, ERSU count in SCD work table is {ersu_scd_count} , Total Account Count in Brdige table is {acct_brdg_count}, Total Account count in SCD work table is {acct_scd_count} , Save Filter Count in Brdige table is {fltr_brdg_count}, Save Filter count in SAVE FLTR work table is {fltr_scd_count} 		***')
		
		if (	dup_count != 0  or null_count != 0 or (ersu_brdg_count != ersu_scd_count) or (acct_brdg_count != acct_scd_count) or (fltr_brdg_count != fltr_scd_count)	):
			LOGGER.info(f'Duplicates or null or counts issue found in the ACIISST_SGMNTN_BRDG,  Tuncating the records inserted, Please recheck and reload the table')
			LOGGER.info(f'*** Deleting ERSU, Account and Saved List records from  Table {TGT_TBL_SCHEMA}.{TGT_TBL_NM}***')
			purge_table_scd = purge_sql_scd(TGT_TBL_SCHEMA, TGT_TBL_NM)
			cursor.execute(purge_table_scd)
			snsNotification(LOGGER, f"Glue Job Failed - {TGT_TBL_NM}", f"\n For the Table - {TGT_TBL_SCHEMA}.{TGT_TBL_NM}. Failed/TimedOut/Aborted/Data issue, Table is truncated for ERSU,Total Account and Saved List data. Please check the logs for Glue job Gj-AciisstSgmntnBrdgDMLMonthly and re run it\n")
			LOGGER.info(f'*** SUCCESS: Deletion {TGT_TBL_SCHEMA}.{TGT_TBL_NM} For SCD. Notification Sent***')
			exit(1)
			
		else:
			snsPublication(LOGGER, f' GLUE JOB SUCCEEDED- {TGT_TBL_NM}', f"\n For the Table - {TGT_TBL_SCHEMA}.{TGT_TBL_NM} \n Total Count in {TGT_TBL_NM} except User Session records is {count} \n Duplicate Count in {TGT_TBL_NM} Table is {dup_count} \n Null Count in {TGT_TBL_NM} Table is {null_count} \n	ERSU Count in {TGT_TBL_NM} table is {ersu_brdg_count} \n ERSU count in ACIISST_SGMNTN_BRDG_SCD work table is {ersu_scd_count} \n Total Account Count in {TGT_TBL_NM} table is {acct_brdg_count} \n Total Account count in ACIISST_SGMNTN_BRDG_SCD work table is {acct_scd_count} \n Save Filter Count in {TGT_TBL_NM} table is {fltr_brdg_count}\n Save Filter count in ACIISST_SGMNTN_BRDG_SAVE FLTR work table is {fltr_scd_count} \n")
			LOGGER.info(f' ACIISST_SGMNTN_BRDG Loaded Sucessfully. Notification Sent')
			
			
	except sf.ProgrammingError as GenericSnowflakeException:
		LOGGER.critical('*** ERROR: Snowflake After append Failed for {TGT_TBL_SCHEMA}.{TGT_TBL_NM} ***')
		LOGGER.critical(GenericSnowflakeException)
		raise GenericSnowflakeException	
		

	# Close Snowflake Connection
	LOGGER.info('*** Closing Snowflake Connection ***')
	conn.close()


if __name__ == "__main__":
    main()
