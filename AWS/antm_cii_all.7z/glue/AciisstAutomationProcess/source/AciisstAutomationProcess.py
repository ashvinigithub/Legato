# -*- coding: utf-8 -*-
"""
#====================================================================================================================================================
# Title            : Test Automation Framework
# ProjectName      : CII
# Filename         : validation_script.py
# Description      : Test Automation Framework is utilizing software which is solely configuration
#                    driven coded in Pyspark and completely scalable. It ensures the data 
#                    collected is accurate, qualitative and healthy for provided business conditions.
#Benefits          : Open for use by any Application to Automate Test cases or Regression suites
# Logic            : Connected to Impala to get the query output and send to CDL Consumers about Daily Table Load Status
# Date                         Ver#     Modified By(Name)                 Change and Reason for Change
# ----------    -----        -----------------------------               --------------------------------------
# 2020/09/01                      1     Dinan Biswas                          New Script Built
#  **************************************************************************************************************************************************
"""

from __future__ import division
import re
import os
import sys
import ast
import time
import socket
import copy
from sys import argv
from datetime import datetime
from pyspark.sql.types import IntegerType,StringType,NullType,StructType,StructField,LongType
from pyspark.sql import SparkSession
from awsglue.utils import getResolvedOptions
from pyspark.sql.functions import col, concat_ws, lit, when,lower,array,udf,count
try:
    from ConfigParser import RawConfigParser
except:
    from configparser import RawConfigParser
from functools import reduce  # For Python 3.x
from pyspark.sql import DataFrame
from email.mime.text import MIMEText
from subprocess import Popen, PIPE
import json
try:
    import boto3
    from urllib.parse import urlparse
except:
    pass


start_time = time.time()

hiveedata_lt = []
df_list = []
##default value
today = datetime.today()
# yrmnth = int(today.strftime("%Y%m"))
yrmnth = ""
#yrmnth = 202102
loaddtm = today.strftime("%m/%d/%Y %X.%f")
tablenm = ""
section_id = ""
validation_file = ""
glb_param = {}
jobstatus = True
donepath = ""
audit_tbnm = ""
email_ids = None
glb_col_def_lt = None
final_colnm = None

stringcol = ["tbl_nm","grp_col_nm","join_val","test_cs_nm",
             "vldtn_typ","src_tbl_val","tgt_tbl_val","var_pct_agd" ,"var_pct_act",
             "status"]
integercol = ["test_cs_id","mnth_load"]
ordered_process = ["global_variable","validation_rule"]

def get_order_process(filenm):
    """
    func: to order the process of execution st: null to end:business
    """
    indx = 99999
    for process in ordered_process:
        if process in filenm:
            indx = ordered_process.index(process)
            break
    return indx

def update_hivedata(grp_col_nm="",join_val="", tstcasenm="",tstcaseid=None,vldtn_type="",
                    expect=None,actual=None,VarianceAgreed="NA",Variance="NA",Status="",
                    MnthLoad=yrmnth,LoadDTM=loaddtm):
    """
    Func to make list containing audit row that need to be inserted into Audit
    Table
    Args:
        All fixed Columns
    Returns:
        list is append to main hivedata_lt list
    """
    global tablenm
    global glb_col_def_lt
    tbnm = tablenm.upper()
    expect = str(expect)
    actual = str(actual)
    VarianceAgreed = str(VarianceAgreed)
    Variance = str(Variance)
    col_lt = ["" for col in glb_col_def_lt ]
    data = [tbnm] + col_lt + [grp_col_nm,join_val,tstcasenm,tstcaseid,vldtn_type,expect,
                              actual,VarianceAgreed,Variance, Status,LoadDTM,MnthLoad]
    hiveedata_lt.append(data)

def create_done_file():
    """
    This Func will create a done file after each validation.
    """
    global validation_file
    global section_id
    global donepath
    validation_file = os.path.basename(validation_file)
    done_file = validation_file.split(".")[0] + "+" + section_id + ".done"
    with open(os.path.join(donepath,done_file),"w") as fw:
        pass
def create_fail_file():
    """
    This Func is to update the overall job status. Used later by sendemail()
    """
    global jobstatus
    jobstatus = False


def setupconfig(config, pair_sec):
    pair_sec1 = dict(pair_sec)
    final_dict = {}
    for key, val in pair_sec1.items():
        subfinal = {}
        for subkey in val:
            value = clean_query(config.get(key,subkey))
            subfinal[subkey] = value
        final_dict[key.upper()] = subfinal
    ##Spark object
    for key, val in final_dict.items():
        if "spark" in val["dbname"].lower():
            app_name = val["app_name"]
            spark_builder = (SparkSession
                             .builder
                             .appName(app_name))
            try:
                sprk_config = val["config"]
            except:
                sprk_config = {}
            spark_config = None
            if isinstance(sprk_config,str):
                spark_config = ast.literal_eval(sprk_config)
            elif isinstance(sprk_config, dict):
                spark_config = sprk_config

            for key, val in spark_config.items():
                spark_builder.config(key, val)

            spark = spark_builder.enableHiveSupport().getOrCreate()
            spark.conf.set("spark.sql.crossJoin.enabled", True)
            spark.conf.set("spark.debug.maxToStringFields",100)
            return (spark, final_dict)

def main(tablenmparm,config_file,global_file,validation_path):
    """
    Main Func is to read the properties file and trigger the validation
    """
    global tablenm
    global validation_file
    global section_id
    tablenm = tablenmparm
    donelist = []

    config, pair_sec = parse_config(config_file)
    spark, dbconfigdict = setupconfig(config,pair_sec)

    config, pair_sec = parse_config(global_file, skipsec="DataFrame")
    if len(pair_sec) != 0:
        try:
            define_global_df(spark,config,pair_sec,dbconfigdict)
        except:
            raise
            #send_mail(msg="No Data in the Table")
            raise ValueError("No Data in the Table")
    print(glb_param)
    global yrmnth
    try:
        yrmnth = int(glb_param["$mnth_load$"])
    except:
        yrmnth = int(today.strftime("%Y%m"))
    print("month_load:",yrmnth)
    print("entered into validation")
    config, pair_sec = parse_config(validation_path, skipsec="DataFrame")
    if len(pair_sec) != 0:
        define_global_df(spark,config,pair_sec,dbconfigdict)
    validation_file = validation_path
    business_logic(spark,validation_path,donelist,dbconfigdict)

    insert_data_into_hive(spark,dbconfigdict)


def insert_data_into_hive(spark,dbconfigdict):
    """
    Func to insert data to hive table
    """
    global hiveedata_lt
    global audit_tbnm
    if len(hiveedata_lt) != 0:
        df_fromlist = spark.createDataFrame(hiveedata_lt,final_colnm)
        df_list.append(df_fromlist)
    result_df = unionAll(df_list)
    for colnm in stringcol:
        result_df = result_df.withColumn(colnm, result_df[colnm].cast(StringType()))
    for colnm in integercol:
        result_df = result_df.withColumn(colnm, result_df[colnm].cast(IntegerType()))
    result_df = result_df.na.fill("",["var_pct_act"])

    for col_pair in glb_col_def_lt:
        result_df = result_df.withColumnRenamed(col_pair[0], col_pair[1])

    #    print(result_df.show(truncate=False))
    print("final --- %s seconds ---" % (time.time() - start_time))
    flag = False
    print(audit_tbnm)
    if ";" in audit_tbnm:
        tb_dtl, tb_ref = audit_tbnm.split(";")
        tb_ref_up = tb_ref.strip().upper()
        if  tb_ref_up in dbconfigdict.keys():
            db_prop = dbconfigdict[tb_ref_up]
            if "SPARK" in db_prop['dbname'].upper():
                audit_tbnm = tb_dtl
                flag=True
            elif "TERADATA" in db_prop['dbname'].upper():
                jdbcURL,conn_prop = getjdbcAndConfigProp(spark,db_prop)
                result_df.write.jdbc(url=jdbcURL,dbtable=tb_dtl.strip(),properties=conn_prop) ##Teradata Write
        elif tb_ref_up == "EXCEL":
            excl_path = tb_dtl
            nullchk = []
            for colnc in glb_col_def_lt:
                nullchk.append(colnc[1])
            pandasdf = result_df.toPandas()
            nan_value = float("NaN")
            pandasdf.replace("", nan_value, inplace=True)
            pandasdf.dropna(how='all', axis=1, inplace=True)
            if os.path.isdir(excl_path):
                now = datetime.now()
                timestamp = now.strftime("%m%d%Y%H%M%S")
                filename = "audit_table_" + timestamp + ".xlsx"
                excl_path = os.path.join(excl_path,filename)
            pandasdf.to_excel(excl_path, index=False)
        elif tb_ref_up.upper() == "CSV":
            excl_path = tb_dtl
            nullchk=[]
            for colnc in glb_col_def_lt:
                nullchk.append(colnc[1])
            result_df = result_df.replace("",None)
            print(result_df.show())
            df1 = result_df.agg(*[count(c).alias(c) for c in result_df.columns])
            nonNull_cols = [c for c in df1.columns if df1[[c]].first()[c] > 0]
            result_df = result_df.select(*nonNull_cols)
            #            result_df = result_df.na.drop(subset=nullchk)
            print(result_df.show())
            #            result_df = result_df.na.fill(0, nullchk)
            if os.path.isdir(excl_path):
                now = datetime.now()
                timestamp = now.strftime("%m%d%Y%H%M%S")
                filename = "audit_table_" + timestamp + ".csv"
                excl_path = os.path.join(excl_path,filename)
            result_df.coalesce(1).write.format('csv').option('header',True).mode('overwrite').option('sep','|').save(excl_path)

    elif (";" not in audit_tbnm) or flag:
        if ("s3" in audit_tbnm.split("/")[0]) or (os.path.exists(audit_tbnm)):
            hdfspath = audit_tbnm
        else:
            if not spark.catalog._jcatalog.tableExists(audit_tbnm):
                print("please create table first")
                raise ValueError("please create table first")
            else:
                hdfspath = (spark.sql("desc formatted {0}".format(audit_tbnm)) \
                            .filter("col_name=='Location'") \
                            .collect()[0].data_type)
        tb_hdfspath = os.path.join(str(hdfspath),"mnth_load={0}".format(yrmnth))
        result_df.coalesce(10).write.format("parquet").mode("append").save(tb_hdfspath)

    print("final write --- %s seconds ---" % (time.time() - start_time))

def define_global_df(spark,confg,sect,dbconfigdict):
    """
    Func to define global variable
    Args:
        Spark, configparser object and all section in global properties
    Returns:
        1) create dataframe temp view for global dataframe use
        2) update global parameter variable
    """
    subsectnm = sect[0][0]
    subsec = sect[0][1]
    only_regdf = []
    q_variable = []
    query_var = {}  # To Hold parameter variable
    ##defining the global parameter
    global glb_col_def_lt
    global final_colnm
    global glb_param
    for sec in subsec:
        grpv = re.search(r"\$([A-Za-z0-9_#0-9]+)\$", sec)
        if grpv:
            q_variable.append(sec)
        else:
            only_regdf.append(sec)
    for qv in q_variable:
        if ("query_to_variable" in qv):
            key = qv
            query_var[qv] = []
        elif ("audit_table_variable" in qv):
            try:
                glb_column_def = confg.get(subsectnm,qv)
                glb_col_def_lt = [(col.split(":")[0].strip(),col.split(":")[1].strip())  for col in glb_column_def.strip().split(",")]
                tb_col = [colnm[0] for colnm in glb_col_def_lt]
            except:
                tb_col = []
                glb_col_def_lt = []
            final_colnm = ["tbl_nm"] + tb_col + ["grp_col_nm","join_val","test_cs_nm","test_cs_id",
                                                 "vldtn_typ","src_tbl_val","tgt_tbl_val","var_pct_agd" ,"var_pct_act",
                                                 "status","load_dtm","mnth_load"]
        elif ("variable_kv" in qv):
            var_kv = confg.get(subsectnm,qv)
            if (var_kv != ""):
                var_kv = var_kv.replace("'","").replace('"','')
                var_kv = var_kv.split(",")
                for val in var_kv:
                    k, v = val.split(":")
                    glb_param[k.strip()] = clean_query(v)

        else:
            query_var[key].append(qv)
    ## Defining global register table    
    for ssect in only_regdf:
        stmnt = clean_query(confg.get(subsectnm,ssect))
        if '#' in ssect:
            dbinfo = ssect.split("#")[0]
            dbdf = "#".join(ssect.split("#")[1:])
            dbnm = "-".join(dbinfo.split("-")[1:]).upper()
            dbprop = dbconfigdict[dbnm]
            if (len(dbprop) == 0) or ("spark" == dbprop["dbname"].lower()):
                stmtdf = spark.sql(stmnt)
            elif ("snowflake" == dbprop["dbname"].lower()):
                sfparam,sfOptions = getSecretMangerProp(spark,dbprop)
                sfformat = sfparam["format"]
                stmtdf = spark.read.format(sfformat).options(**sfOptions).option("query",stmnt).load()
            elif ("rds" == dbprop["dbname"].lower()):
                rdsparam,rdsOptions = getSecretMangerProp(spark,dbprop)
                rdsjdbc = rdsparam["jdbc_url"]
                stmtdf = spark.read.jdbc(url=rdsjdbc,table='('+ stmnt + ') T',properties=rdsOptions)
            elif ("elasticsearch" == dbprop["dbname"].lower()):
                esparam,esOptions = getFullProp(spark,dbprop)
                esformat = esparam["format"]
                stmtdf = spark.read.format(esformat).options(**esOptions).load(stmnt)
            else:
                jdbcURL,conn_prop = getjdbcAndConfigProp(spark,dbprop)
                stmtdf = spark.read.jdbc(url=jdbcURL,table='('+ stmnt + ') T',properties=conn_prop)
            stmtdf.createOrReplaceTempView(dbdf)
            spark.catalog.cacheTable(dbdf)

        else:
            #            stmnt = clean_query(confg.get(subsectnm,ssect))
            stmtdf = spark.sql(stmnt)
            stmtdf.createOrReplaceTempView(ssect)
            spark.catalog.cacheTable(ssect)

    for key, value in query_var.items():
        stmnt = clean_query(confg.get(subsectnm,key))
        if ('#' in key) and (key.count('#') > 1):
            dbinfo = key.split("#")[0]
            dbdf = "#".join(key.split("#")[0][1:])
            dbnm = "-".join(dbinfo.split("-")[1:]).upper()
            dbprop = dbconfigdict[dbnm]
            if (len(dbprop) == 0) or ("spark" == dbprop["dbname"].lower()):
                globalparmdf = spark.sql(stmnt)
            elif ("snowflake" == dbprop["dbname"].lower()):
                sfparam,sfOptions = getSecretMangerProp(spark,dbprop)
                sfformat = sfparam["format"]
                globalparmdf = spark.read.format(sfformat).options(**sfOptions).option("query",stmnt).load()
            elif ("rds" == dbprop["dbname"].lower()):
                rdsparam,rdsOptions = getSecretMangerProp(spark,dbprop)
                rdsjdbc = rdsparam["jdbc_url"]
                globalparmdf = spark.read.jdbc(url=rdsjdbc,table='('+ stmnt + ') T',properties=rdsOptions)
            else:
                jdbcURL,conn_prop = getjdbcAndConfigProp(spark,dbprop)
                globalparmdf = spark.read.jdbc(url=jdbcURL,table='('+ stmnt + ') T',properties=conn_prop)
            src_dataschema = globalparmdf.schema.names
            collect_out = globalparmdf.collect()[0]
            for val in value:
                indx_var = confg.get(subsectnm,val)
                indx_var = int(indx_var.split("-")[0])
                glb_param[val] = collect_out[src_dataschema[indx_var]]
        else:
            globalparmdf = spark.sql(stmnt)
            src_dataschema = globalparmdf.schema.names
            collect_out = globalparmdf.collect()[0]
            for val in value:
                indx_var = confg.get(subsectnm,val)
                indx_var = int(indx_var.split("-")[0])
                glb_param[val] = collect_out[src_dataschema[indx_var]]

def count_validation(spark, src_query,dst_query,test_case_name,test_case_id,
                     vldtn_type,grp_col,src_dbprop,dst_dbprop,
                     variance=None,jobname="count_validation"):
    """
    Func to do matching between number to number and with variance
    Args:
        spark, source query, destination query, test case name , test case id,
        validation type, variance[Optional], job name[Optional]
    Returns:
        Call update hive list to append data to list. This list will be used later 
        to create dataframe to insert into hive
    """
    print("{} Beginning".format(jobname))
    if (len(src_dbprop) == 0) or ("spark" == src_dbprop["dbname"].lower()):
        src_df = spark.sql(src_query)
    else:
        jdbcURL,conn_prop = getjdbcAndConfigProp(spark,src_dbprop)
        src_df = spark.read.jdbc(url=jdbcURL,table='('+ src_query + ') T',properties=conn_prop)

    if (len(dst_dbprop) == 0) or ("spark" == dst_dbprop["dbname"].lower()):
        dst_df = spark.sql(dst_query)
    else:
        jdbcURL,conn_prop = getjdbcAndConfigProp(spark,dst_dbprop)
        dst_df = spark.read.jdbc(url=jdbcURL,table='('+ dst_query + ') T',properties=conn_prop)
    src_dataschema, dst_dataschema = src_df.schema.names, dst_df.schema.names
    src_cnt = src_df.collect()[0][src_dataschema[0]]
    dst_cnt = dst_df.collect()[0][dst_dataschema[0]]

    grp_colv = ""
    if grp_col:
        for grp in grp_col:
            if grp[0] == "append":
                grp_colv = grp[1]
            else:
                grp_colv = ""
    else:
        grp_colv = ""

    if variance ==  None:
        if src_cnt == dst_cnt:
            update_hivedata(grp_col_nm=grp_colv,tstcasenm=test_case_name,tstcaseid=test_case_id,
                            actual=dst_cnt,expect=src_cnt,vldtn_type=vldtn_type,Status="PASS")
            #            create_done_file()
            print("Passed: Count validation successfull")
        else:
            update_hivedata(grp_col_nm=grp_colv,tstcasenm=test_case_name,tstcaseid=test_case_id,
                            actual=dst_cnt,expect=src_cnt,vldtn_type=vldtn_type,Status="FAIL")
            create_fail_file()
            print("Failed: Count source: {} and destination: {}".format(src_cnt, dst_cnt))
    elif variance != None:
        var = None
        if ((dst_cnt == 0) and (src_cnt == 0)):
            var = 0
        elif ((dst_cnt == 0) or (src_cnt == 0)):
            var = 100
        else:
            var = ((dst_cnt - src_cnt)/src_cnt)*100
        n_abs_var = abs(var)
        var = abs(var)
        value = re.findall('\d+', variance )
        result = False
        if len(value) == 1:
            var_check = int(value[0])
        elif len(value) == 2:
            var_check = float(value[0] + "." + value[1])
        if ("less" in variance) and ("equal" in variance):
            result = (var <= var_check)
        elif ("greater" in variance) and ("equal" in variance):
            result = (var >= var_check)
        elif ("less" in variance):
            result = (var < var_check)
        elif ("greater" in variance):
            result = (var > var_check)
        if result:
            update_hivedata(grp_col_nm=grp_colv,tstcasenm=test_case_name,tstcaseid=test_case_id,
                            actual=dst_cnt,expect=src_cnt,VarianceAgreed=var_check,
                            Variance=n_abs_var,vldtn_type=vldtn_type,Status="PASS")
            #            create_done_file()
            print("Passed: {} successful".format(jobname))
        else:
            update_hivedata(grp_col_nm=grp_colv,tstcasenm=test_case_name,tstcaseid=test_case_id,
                            actual=dst_cnt,expect=src_cnt,VarianceAgreed=var_check,
                            Variance=n_abs_var,vldtn_type=vldtn_type,Status="FAIL")
            create_fail_file()
            print("Failed: {0} variance {1}".format(jobname,var))

def parseS3Path(fpath):
    parse = urlparse(fpath, allow_fragments=False)
    if parse.path[0] == "/":
        objpath = parse.path[1:]
    else:
        objpath = parse.path
    return (parse.netloc,objpath)

def parse_config(file, skipsec = None):
    """
    Func to read the properties file and parser it
    Args:
        file path, skipsec - any section to skip like global variable
    Returns:
        config object , properties file section paired up
        
    """
    config = RawConfigParser()
    if "s3" in file.split("/")[0]:
        conn = boto3.client('s3')
        bucketname, objpath = parseS3Path(file)
        print(bucketname, objpath)
        obj = conn.get_object(Bucket=bucketname, Key=objpath)
        data = obj['Body'].read()
        config.read_string(data.decode("utf-8"))
    else:
        config.read(file)
    all_sec = config.sections()
    sec_key = []
    for sec in all_sec:
        key = list(config.options(sec))
        sec_key.append((sec,key))
    sec_key_cp  = copy.deepcopy(sec_key)
    pair_sec = []
    if (skipsec in all_sec) and (skipsec is not None):
        pair_sec.append([sec for sec in sec_key if sec[0] == skipsec][0])
    elif (skipsec is not None):
        pass
    else:
        for indx, sec in enumerate(all_sec):
            if "SOURCE" not in sec:     ##Check if the section should start with source
                for sect in sec_key:
                    if sect[0] == sec:
                        sec_key.remove(sect)
            else:
                break

        for i in range(0,len(sec_key),2):
            try:
                val = (sec_key[i], sec_key[i+1])
            except:
                val = (sec_key[i],)
            pair_sec.append(val)

    if len(pair_sec) == 0:
        pair_sec = sec_key_cp
    return (config,pair_sec)

def getGroupNmLogic(grp_nm):
    chk = grp_nm.split(",")
    grpnmlt = []
    applt = []
    for enumindx, chk_col in enumerate(chk):
        indx_chk = chk_col.split("-")[0].strip()
        if indx_chk.isdigit():
            grpnmlt.append((indx_chk,"-".join(chk_col.split("-")[1:])))
        else:
            grpnmlt.append(("append",chk_col.strip()))
            applt.append(enumindx)
    return grpnmlt


def getcolrule(config,type_key,rule_type):
    """
    Func to get the column index for variable audit table columns
    Args:
        config object, main section string, column rule (defined in properties)
    Return:
        rule defination ([(column1, 0),(column2,1),(column3, "")])
    """
    rule_def = []
    tb_col = [colnm[0] for colnm in glb_col_def_lt]
    for col_def in tb_col:
        if col_def in rule_type:
            get_data = clean_query(config.get(type_key,col_def))
            #            print("first step" + str(get_data))
            if "-" in get_data:
                sub_lt = []
                for col_d in get_data.split(","):
                    if "-" in col_d:
                        sub_lt.append(int(col_d.split("-")[0]))
                    else:
                        sub_lt.append("static" + str(col_d))
                rule_def.append((col_def,sub_lt))
            else:
                rule_def.append((col_def,get_data))
        else:
            rule_def.append((col_def,get_data))
    #    print(rule_def)
    return rule_def

def unionAll(dfs):
    """
    Func to union all the spark dataframe in provided as list
    """
    return reduce(DataFrame.unionAll, dfs)

def business_logic(spark,file,donelt,dbconfigdict):
    """
    Func to do all Technical Validation like query to query match , query to value match
    Args:
        spark object, technical validation properties file path, done file list 
    """
    config,pair_sec = parse_config(file)
    global section_id
    filenm = os.path.basename(file)
    print(pair_sec)
    for each_sec in pair_sec:
        src_sec,type1 = each_sec[0][0],each_sec[0][1][0]
        section_id = str(src_sec.split("#")[1])
        donefile = filenm.split(".")[0] + "+" + section_id + ".done"
        if donefile not in donelt:
            if len(each_sec[1][1]) == 0:
                dest_type_lt = each_sec[1][1]
                src_q,type_lt1 = each_sec[0][0],each_sec[0][1]
                if len(dest_type_lt) == 0:
                    src_query = clean_query(config.get(src_q,type_lt1[0]))
                    test_case_name = config.get(src_q, "test_case_name").upper()
                    test_case_id = int(config.get(src_q, "test_case_id"))
                    vldtn_type = config.get(src_q, "validation_type").upper()
                    try:
                        dbtype = config.get(src_q, "destination_db")
                        dbprop = dbconfigdict[dbtype.upper()]
                    except:
                        dbprop = {}
                    null_dup_validation(spark,src_query,test_case_name,test_case_id,vldtn_type,dbprop)

            else:
                des_sec,type2 = each_sec[1][0],each_sec[1][1][0]
                dest_type_lt = each_sec[1][1]
                test_case_name = config.get(des_sec, "test_case_name").upper()
                test_case_id = int(config.get(des_sec, "test_case_id"))
                vldtn_type = config.get(des_sec, "validation_type").upper()
                print(type1,type2)

                if (type1 == "query") and (type2 == "query"):
                    src_query = clean_query(config.get(src_sec,type1))
                    des_query = clean_query(config.get(des_sec,type2))
                    if ("join_key" not in dest_type_lt) and ("variance" in dest_type_lt):
                        variance_logic = clean_query(config.get(des_sec,"variance"))
                        try:
                            groupName = clean_query(config.get(des_sec,"group_column"))
                            groupValue = getGroupNmLogic(groupName) if groupName != "" else None
                        except:
                            groupValue = None
                        try:
                            src_dbtype = config.get(des_sec, "source_db")
                            src_dbprop = dbconfigdict[src_dbtype.upper()]
                        except:
                            src_dbprop = {}
                        try:
                            dst_dbtype = config.get(des_sec, "destination_db")
                            dst_dbprop = dbconfigdict[dst_dbtype.upper()]
                        except:
                            dst_dbprop = {}
                        count_validation(spark,src_query,des_query,test_case_name,
                                         test_case_id,vldtn_type,groupValue,src_dbprop,dst_dbprop,variance=variance_logic,
                                         jobname = "count_validation")
                    else:
                        business_query(spark,src_query,des_query,test_case_name,test_case_id,vldtn_type,src_dbprop,dst_dbprop)

                elif (type1 == "query") and (type2 == "value"):
                    src_query = clean_query(config.get(src_sec,type1))
                    des_lt = ast.literal_eval(config.get(des_sec,type2))
                    try:
                        src_dbtype = config.get(des_sec, "source_db")
                        src_dbprop = dbconfigdict[src_dbtype.upper()]
                    except:
                        src_dbprop = {}
                    business_value(spark,src_query,des_lt,test_case_name,test_case_id,vldtn_type,src_dbprop)

                elif (type1 == "period") and (type2 == "period"):
                    src_query = clean_query(config.get(src_sec,type1))
                    des_query = clean_query(config.get(des_sec,type2))

                    variance_logic = clean_query(config.get(des_sec,"variance"))
                    vldtn_type = clean_query(config.get(des_sec,"validation_type")).upper()
                    join_key = clean_query(config.get(des_sec,"join_key"))
                    variance_col = clean_query(config.get(des_sec,"variance_column"))
                    try:
                        table_nm = clean_query(config.get(des_sec,"table_name"))
                    except:
                        table_nm = ""
                    try:
                        groupName = clean_query(config.get(des_sec,"group_column"))
                        groupValue = getGroupNmLogic(groupName) if groupName != "" else None
                    except:
                        groupValue = None

                    try:
                        src_dbtype = config.get(des_sec, "source_db")
                        src_dbprop = dbconfigdict[src_dbtype.upper()]
                    except:
                        src_dbprop = {}
                    try:
                        dst_dbtype = config.get(des_sec, "destination_db")
                        dst_dbprop = dbconfigdict[dst_dbtype.upper()]
                    except:
                        dst_dbprop = {}


                    join_keys = [key.split("-") for key in join_key.split(",")]
                    variance_col = [key.split("-") for key in variance_col.split(",")]
                    try:
                        rules_def = getcolrule(config,des_sec,dest_type_lt)
                    except:
                        rules_def = []
                    period_df = business_multi(spark,src_query,des_query,join_keys,variance_col,
                                               variance_logic,rules_def,groupValue,test_case_name,
                                               test_case_id,vldtn_type,src_dbprop,dst_dbprop,table_nm)
                    df_list.append(period_df)

                elif (type1 == "period") and (type2 == "value"):
                    src_query = clean_query(config.get(src_sec,type1))
                    des_query = clean_query(config.get(des_sec,type2))
                    vldtn_type = clean_query(config.get(des_sec,"validation_type")).upper()
                    logic = clean_query(config.get(des_sec,"logic"))
                    match_col = clean_query(config.get(des_sec,"match_column"))
                    try:
                        table_nm = clean_query(config.get(des_sec,"table_name"))
                    except:
                        table_nm = ""
                    try:
                        groupName = clean_query(config.get(des_sec,"group_column"))
                        groupValue = getGroupNmLogic(groupName) if groupName != "" else None
                    except:
                        groupValue = None
                    try:
                        src_dbtype = config.get(des_sec, "source_db")
                        src_dbprop = dbconfigdict[src_dbtype.upper()]
                    except:
                        src_dbprop = {}

                    match_col = match_col.split("-")
                    try:
                        rules_def = getcolrule(config,des_sec,dest_type_lt)
                    except:
                        rules_def = []
                    period_df = business_multi_val(spark,src_query,des_query,match_col,logic,
                                                   rules_def,groupValue,test_case_name,test_case_id,vldtn_type,src_dbprop,table_nm)
                    df_list.append(period_df)
                    print("multi query value validation final --- %s seconds ---" % (time.time() - start_time))

                elif ("current" in type1) and ("current" in type2):
                    print("Entered into the Period")
                    all_period = []
                    for period in each_sec[0][1]:
                        src_pdquery = clean_query(config.get(src_sec, period))
                        dst_pdquery = clean_query(config.get(des_sec, period))
                        variance_logic = clean_query(config.get(des_sec,"variance"))
                        vldtn_type = clean_query(config.get(des_sec,"validation_type"))
                        join_key = clean_query(config.get(des_sec,"join_key"))
                        variance_col = clean_query(config.get(des_sec,"variance_column"))
                        try:
                            groupName = clean_query(config.get(des_sec,"group_column"))
                            groupValue = getGroupNmLogic(groupName) if groupName != "" else None
                        except:
                            groupValue = None
                        try:
                            src_dbtype = config.get(des_sec, "source_db")
                            src_dbprop = dbconfigdict[src_dbtype.upper()]
                        except:
                            src_dbprop = {}
                        try:
                            dst_dbtype = config.get(des_sec, "destination_db")
                            dst_dbprop = dbconfigdict[dst_dbtype.upper()]
                        except:
                            dst_dbprop = {}

                        join_keys = [key.split("-") for key in join_key.split(",")]
                        variance_col = variance_col.split("-")
                        rules_def = getcolrule(config,des_sec,dest_type_lt)
                        period_df = business_multi(spark,src_pdquery,dst_pdquery,join_keys,variance_col,
                                                   variance_logic,rules_def,groupValue,test_case_name,
                                                   test_case_id,vldtn_type,src_dbprop,dst_dbprop)
                        all_period.append(period_df)
                    period_data = unionAll(all_period)
                    df_list.append(period_data)
                    print("multi validation final --- %s seconds ---" % (time.time() - start_time))


def clean_query(query):
    """
    Func to make query to spark.sql and updating global variable
    """
    query = query.replace("\n"," ").replace(";","").replace("\t"," ")
    global glb_param
    for key, val in glb_param.items():
        query = query.replace(key,str(val))
    return query

def business_query(spark, src_q, des_q,test_case_name,test_case_id,vldtn_typ,
                   src_dbprop,dst_dbprop):
    """
    Func to compare two query output(dataframe) - value to value match
    """
    print("Business Validation Query to Query")
    if (len(src_dbprop) == 0) or ("spark" == src_dbprop["dbname"].lower()):
        src_df = spark.sql(src_q)
    else:
        jdbcURL,conn_prop = getjdbcAndConfigProp(spark,src_dbprop)
        src_df = spark.read.jdbc(url=jdbcURL,table='('+ src_q + ') T',properties=conn_prop)

    if (len(dst_dbprop) == 0) or ("spark" == dst_dbprop["dbname"].lower()):
        des_df = spark.sql(des_q)
    else:
        jdbcURL,conn_prop = getjdbcAndConfigProp(spark,dst_dbprop)
        des_df = spark.read.jdbc(url=jdbcURL,table='('+ des_q + ') T',properties=conn_prop)
    src_shape = (src_df.count(), len(src_df.columns))
    des_shape = (des_df.count(), len(des_df.columns))
    if len(src_df.columns) == 1:
        src_dataschema, dst_dataschema = src_df.schema.names, des_df.schema.names
        expect = src_df.collect()[0][src_dataschema[0]]
        actual = des_df.collect()[0][dst_dataschema[0]]
    else:
        expect = src_df.rdd.map(lambda row : tuple([item for item in row])).collect()
        actual = des_df.rdd.map(lambda row : tuple([item for item in row])).collect()

    if src_shape == des_shape:
        print("source and destination have same shape - row and columns")
        final_df = des_df.subtract(src_df)
        if (final_df.count() == 0):
            update_hivedata(tstcasenm=test_case_name,tstcaseid=test_case_id,
                            actual=actual,expect=expect,vldtn_type=vldtn_typ,Status="PASS")
            #            create_done_file()
            print("q to q validation --- %s seconds ---" % (time.time() - start_time))
            print("Passed: Validation passed")
        else:
            update_hivedata(tstcasenm=test_case_name,tstcaseid=test_case_id,
                            actual=actual,expect=expect,vldtn_type=vldtn_typ,Status="FAIL")
            create_fail_file()
            print("Failed: Validation is failed - data missmatched" )
    else:
        update_hivedata(tstcasenm=test_case_name,tstcaseid=test_case_id,
                        actual=actual,expect=expect,vldtn_type=vldtn_typ,Status="FAIL")
        create_fail_file()
        print("""Failed:Business validation failed - shape doesn't match \nSource query - row:column {0} 
        \nTarget query - row:column {1}""".format(src_shape,des_shape))

def business_value(spark,src_q,des_tup,test_case_name,test_case_id,vldtn_typ,src_dbprop):
    """
    Func to match fixed query output with fixed value (passed hardcoded value)
    """
    print("Business Validation Query to Value")
    if (len(src_dbprop) == 0) or ("spark" == src_dbprop["dbname"].lower()):
        src_df = spark.sql(src_q)
    else:
        jdbcURL,conn_prop = getjdbcAndConfigProp(spark,src_dbprop)
        src_df = spark.read.jdbc(url=jdbcURL,table='('+ src_q + ') T',properties=conn_prop)
    target_df = spark.createDataFrame(des_tup[0],des_tup[1])
    src_shape = (src_df.count(), len(src_df.columns))
    des_shape = (target_df.count(), len(target_df.columns))
    expect = src_df.rdd.map(lambda row : tuple([item for item in row])).collect()
    actual = target_df.rdd.map(lambda row : tuple([item for item in row])).collect()
    if src_shape == des_shape:
        print("source and destination have same shape - row and columns")
        final_df = target_df.subtract(src_df)

        if (final_df.count() == 0):
            update_hivedata(tstcasenm=test_case_name,tstcaseid=test_case_id,
                            actual=actual,expect=expect,vldtn_type=vldtn_typ,Status="PASS")
            #            create_done_file()
            print("q to v validation --- %s seconds ---" % (time.time() - start_time))
            print("Passed:Validation passed")
        else:
            update_hivedata(tstcasenm=test_case_name,tstcaseid=test_case_id,
                            actual=actual,expect=expect,vldtn_type=vldtn_typ,Status="FAIL")
            create_fail_file()
            print("Failed:Validation is failed - data missmatched" )
    else:
        update_hivedata(tstcasenm=test_case_name,tstcaseid=test_case_id,
                        actual=actual,expect=expect,vldtn_type=vldtn_typ,Status="FAIL")
        create_fail_file()
        print("""Failed: Business validation failed - shape doesn't match \nSource query - row:column {0} 
        \nTarget query - row:column {1}""".format(src_shape,des_shape))

def multi_variance_chk(src_cnt1, dst_cnt1,var_threshold,th_logic):
    """
    Func to provide max variance value
    param: src_cnt -> comma separated value 
           dst_cnt -> comma separated value
    RETURN: Max variance value
    """
    src_cnt1 = src_cnt1 if src_cnt1 !="" else "0"
    dst_cnt1 = dst_cnt1 if dst_cnt1 !="" else "0"
    src_indv_val = []
    dst_indv_val = []
    try:
        for srcv in src_cnt1.split(","):
            try:
                src_indv_val.append(float(srcv.strip()))
            except:
                src_indv_val.append(float(0))
        for dstv in dst_cnt1.split(","):
            try:
                dst_indv_val.append(float(dstv.strip()))
            except:
                dst_indv_val.append(float(0))

    except:
        raise ValueError(src_cnt1, type(src_cnt1))

    if len(src_indv_val) != len(dst_indv_val):
        diff = abs(len(src_indv_val) - len(dst_indv_val))
        if len(src_indv_val) > len(dst_indv_val):
            dst_indv_val.extend([float(0)]*diff)
        else:
            src_indv_val.extend([float(0)]*diff)

    zip_indv_val = zip(src_indv_val, dst_indv_val)
    calc_max_lt = []
    for indv_val in zip_indv_val:
        src_v = indv_val[0]
        dst_v = indv_val[1]
        if (src_v == 0.0) and (dst_v == 0.0):
            calc_max_lt.append(float(0))
        elif (src_v == 0.0) or (dst_v == 0.0):
            calc_max_lt.append(float(100))
        else:
            calc = round(((dst_v - src_v)/src_v) * 100,2)
            calc_max_lt.append(abs(calc))
    sts = []
    var_threshold = ast.literal_eval(var_threshold)
    for indx, var_pct in enumerate(calc_max_lt):
        if ("less" in th_logic) and ("equal" in th_logic):
            sts.append("PASS" if (var_pct <= var_threshold[indx]) else "FAIL")
        elif ("greater" in th_logic) and ("equal" in th_logic):
            sts.append("PASS" if (var_pct >= var_threshold[indx]) else "FAIL")
        elif ("less" in th_logic):
            sts.append("PASS" if (var_pct < var_threshold[indx]) else "FAIL")
        elif ("greater" in th_logic):
            sts.append("PASS" if (var_pct > var_threshold[indx]) else "FAIL")

    calc_max_lt_abs = [str(abs(val)) for val in calc_max_lt]
    #    status = "FAIL" if "FAIL" in sts else "PASS"
    status = ",".join(sts)
    return (",".join(calc_max_lt_abs),status)

rec_schema = StructType([
    StructField("var_pct_act", StringType(), True),
    StructField("status", StringType(), True)
])

def isint(x):
    try:
        a = float(x)
        b = int(a)
    except (TypeError, ValueError):
        return False
    else:
        return a == b

def business_multi(spark,src_q, dst_q,joinkeys,var_col,var,rules_def,grp_val,
                   tst_cse_nm,tst_cse_id,vldtn_typ,src_dbprop,dst_dbprop,tbl_nm):
    """
    Func to calculate variance between number from between query
    """
    start_time1 = time.time()
    print("test case id:" + str(tst_cse_id))
    print(src_q)
    print(dst_q)
    if (len(src_dbprop) == 0) or ("spark" == src_dbprop["dbname"].lower()) or ("elasticsearch" == src_dbprop["dbname"].lower()):
        src_df = spark.sql(src_q)
    elif ("snowflake" == src_dbprop["dbname"].lower()):
        sfparam,sfOptions = getSecretMangerProp(spark,src_dbprop)
        sfformat = sfparam["format"]
        src_df = spark.read.format(sfformat).options(**sfOptions).option("query",src_q).load()
    elif ("rds" == src_dbprop["dbname"].lower()):
        rdsparam,rdsOptions = getSecretMangerProp(spark,src_dbprop)
        rdsjdbc = rdsparam["jdbc_url"]
        #        print("first")
        #        print(rdsparam,rdsOptions)
        src_df = spark.read.jdbc(url=rdsjdbc,table='('+ src_q + ') T',properties=rdsOptions)
    else:
        jdbcURL,conn_prop = getjdbcAndConfigProp(spark,src_dbprop)
        src_df = spark.read.jdbc(url=jdbcURL,table='('+ src_q + ') T',properties=conn_prop)

    if (len(dst_dbprop) == 0) or ("spark" == dst_dbprop["dbname"].lower()) or ("elasticsearch" == src_dbprop["dbname"].lower()):
        dst_df = spark.sql(dst_q)
    elif ("snowflake" == dst_dbprop["dbname"].lower()):
        sfparam,sfOptions = getSecretMangerProp(spark,dst_dbprop)
        sfformat = sfparam["format"]
        dst_df = spark.read.format(sfformat).options(**sfOptions).option("query",dst_q).load()
    elif ("rds" == dst_dbprop["dbname"].lower()):
        rdsparam,rdsOptions = getSecretMangerProp(spark,dst_dbprop)
        rdsjdbc = rdsparam["jdbc_url"]
        #        print("second")
        dst_df = spark.read.jdbc(url=rdsjdbc,table='('+ dst_q + ') T',properties=rdsOptions)
    else:
        jdbcURL,conn_prop = getjdbcAndConfigProp(spark,dst_dbprop)
        dst_df = spark.read.jdbc(url=jdbcURL,table='('+ dst_q + ') T',properties=conn_prop)

    src_df = src_df.select([col(c).alias("src_"+c) for c in src_df.columns])
    dst_df = dst_df.select([col(c).alias("dst_"+c) for c in dst_df.columns])
    src_schema, dst_schema = src_df.schema.names,dst_df.schema.names

    src_cnt_col = [src_schema[int(cnt_col[0])] for cnt_col in var_col]
    dst_cnt_col = [dst_schema[int(cnt_col[0])] for cnt_col in var_col]

    src_dtype = [i.dataType for i in src_df.schema]
    src_join_indx = [src_schema[int(key[0])] for key in joinkeys]
    dst_join_indx = [dst_schema[int(key[0])] for key in joinkeys]

    all_var_lt = []
    ##Get variance parameter from query else variable
    if var.find("(") != -1:
        flag_var = var[0:var.find("(")]
        var_query = var[var.find("(")+1:var.find(")")]
        var_df = spark.sql(var_query)
        var_schema = var_df.schema.names
        var_val = var_df.collect()[0][var_schema[0]]
        for val in var_val.split(","):
            if isint(val):
                all_var_lt.append(int(float(val)))
            else:
                all_var_lt.append(float(val))
    else:
        sub_var = var.split(",")
        flag_var = sub_var[0]

        for svar in sub_var:
            value = re.findall('\d+', svar)
            var_check = 0
            if len(value) == 1:
                var_check = int(value[0])
            elif len(value) == 2:
                var_check = float(value[0] + "." + value[1])
            all_var_lt.append(var_check)
    ##if variabel passed is less than variance column
    if len(all_var_lt) < len(var_col):
        diff_len = abs(len(var_col) - len(all_var_lt))
        all_var_lt.extend([all_var_lt[0]]*diff_len)

    final_df = src_df.join(dst_df, [col(x) == col(y) for (x,y) in zip(src_join_indx,dst_join_indx)],"outer")

    #    final_df.show(truncate=False)
    final_df = final_df.na.fill(0, src_cnt_col)
    final_df = final_df.na.fill(0, dst_cnt_col)

    final_df = final_df.withColumn("src_tbl_val", concat_ws(",", *src_cnt_col))
    final_df = final_df.withColumn("tgt_tbl_val", concat_ws(",", *dst_cnt_col))
    gen_udf = udf(lambda tbl_val: multi_variance_chk(tbl_val[0],tbl_val[1],tbl_val[2],tbl_val[3]), rec_schema)
    final_df = final_df.withColumn("var_struct", gen_udf(array("src_tbl_val",
                                                               "tgt_tbl_val",lit(str(all_var_lt)),lit(flag_var))))

    final_schema = final_df.schema.names
    final_df = final_df.select("var_struct.var_pct_act","var_struct.status",*final_schema)
    final_df = final_df.withColumn("join_val", when(concat_ws(",",*src_join_indx) == "", concat_ws(",",*dst_join_indx)) \
                                   .otherwise(concat_ws(",",*src_join_indx)))
    for rules in rules_def:
        if isinstance(rules[1],list):
            col_nm = rules[0]
            col_indx = rules[1]
            src_audit_indx = []
            dst_audit_indx = []
            for key in col_indx:
                if "static" in str(key):
                    src_audit_indx.append(lit(key.replace("static","")))
                    dst_audit_indx.append(lit(key.replace("static","")))
                else:
                    src_audit_indx.append(col(src_schema[int(key)]))
                    dst_audit_indx.append(col(dst_schema[int(key)]))


            final_df = final_df.withColumn(col_nm, when(concat_ws(",",array(*src_audit_indx)) == "",
                                                        concat_ws(",",array(*dst_audit_indx))) \
                                           .otherwise(concat_ws(",",array(*src_audit_indx))))
        else:
            col_nm = rules[0]
            col_val = rules[1]
            final_df = final_df.withColumn(col_nm, lit(col_val))

    if grp_val:
        src_grpval_lt = []
        dst_grpval_lt = []
        for grp in grp_val:
            if grp[0] != "append":
                if isinstance(src_dtype[int(grp[0])],NullType):
                    src_grpval_lt.append(col(dst_schema[int(grp[0])]))
                    dst_grpval_lt.append(col(dst_schema[int(grp[0])]))
                else:
                    src_grpval_lt.append(col(src_schema[int(grp[0])]))
                    dst_grpval_lt.append(col(dst_schema[int(grp[0])]))
            else:
                src_grpval_lt.append(lit(grp[1]))
                dst_grpval_lt.append(lit(grp[1]))
        final_df = final_df.withColumn("grp_col_nm", when(concat_ws(",",array(*src_grpval_lt)) == "",
                                                          concat_ws(",",array(*dst_grpval_lt))).otherwise(concat_ws(",",array(*src_grpval_lt))))
    else:
        final_df = final_df.withColumn("grp_col_nm", lit(""))

    final_df = final_df.withColumn("src_tbl_val",col("src_tbl_val").cast(StringType())) \
        .withColumn("tgt_tbl_val",col("tgt_tbl_val").cast(StringType()))
    ##taking table from property
    global tablenm
    if tbl_nm != "":
        table_name = tbl_nm
    else:
        table_name = tablenm
    final_df = final_df.withColumn("tbl_nm",lit(table_name.upper())) \
        .withColumn("test_cs_nm",lit(tst_cse_nm)) \
        .withColumn("test_cs_id",lit(tst_cse_id)) \
        .withColumn("vldtn_typ",lit(vldtn_typ)) \
        .withColumn("var_pct_agd",lit(",".join([str(i) for i in all_var_lt]))) \
        .withColumn("mnth_load",lit(yrmnth)) \
        .withColumn("load_dtm",lit(loaddtm))
    final_df = final_df.select(final_colnm)
    fail_df = final_df.filter(col("status") == "FAIL")
    #    if len(fail_df.head(1)) > 0:
    if fail_df.count() > 0:
        create_fail_file()
        print("Failed:Technical validation failed" )
    else:
        print("multi validation --- %s seconds ---" % (time.time() - start_time))
        #        create_done_file()
        print("Passed:Technical validation passed" )
    print("---Time Took to Run %s seconds ---" % (time.time() - start_time1))
    return final_df

def business_multi_val(spark,src_q, dst_q,match_col,logic,rules_def,grp_col,
                       tst_cse_nm,tst_cse_id,vldtn_typ,src_dbprop,tbl_nm):
    """
    func to compare/varince calc numeric column from source dataframe with single number
    """
    print(src_q)
    if (len(src_dbprop) == 0) or ("spark" == src_dbprop["dbname"].lower()) or ("elasticsearch" == src_dbprop["dbname"].lower()):
        final_df = spark.sql(src_q)
    elif ("snowflake" == src_dbprop["dbname"].lower()):
        sfparam,sfOptions = getSecretMangerProp(spark,src_dbprop)
        sfformat = sfparam["format"]
        final_df = spark.read.format(sfformat).options(**sfOptions).option("query",src_q).load()
    elif ("rds" == src_dbprop["dbname"].lower()):
        rdsparam,rdsOptions = getSecretMangerProp(spark,src_dbprop)
        rdsjdbc = rdsparam["jdbc_url"]
        final_df = spark.read.jdbc(url=rdsjdbc,table='('+ src_q + ') T',properties=rdsOptions)
    else:
        jdbcURL,conn_prop = getjdbcAndConfigProp(spark,src_dbprop)
        final_df = spark.read.jdbc(url=jdbcURL,table='('+ src_q + ') T',properties=conn_prop)

    flagInt = True
    var = logic.lower()
    src_schema = final_df.schema.names
    var_check = dst_q.strip()
    src_cnt_col = src_schema[int(match_col[0])]
    grp_val = list(set(src_schema) - set([src_cnt_col]))

    try:
        var_check = int(var_check)
        #        final_df = final_df.withColumn("tgt_tbl_val", final_df[src_cnt_col].cast(IntegerType()))
        final_df = final_df.withColumn("tgt_tbl_val", final_df[src_cnt_col].cast(LongType()))
    except:
        var_check = var_check.lower()
        flagInt = False
        final_df = final_df.withColumn("tgt_tbl_val", lower(col(src_cnt_col)))

    if(flagInt):
        if ("less" in var) and ("equal" in var):
            final_df = final_df.withColumn("status",when((col("tgt_tbl_val") <= var_check),"PASS").otherwise("FAIL"))

        elif ("greater" in var) and ("equal" in var):
            final_df = final_df.withColumn("status",when((col("tgt_tbl_val") >= var_check),"PASS").otherwise("FAIL"))

        elif ("less" in var):
            final_df = final_df.withColumn("status",when((col("tgt_tbl_val") < var_check),"PASS").otherwise("FAIL"))

        elif ("greater" in var):
            final_df = final_df.withColumn("status",when((col("tgt_tbl_val") > var_check),"PASS").otherwise("FAIL"))
        elif ("equal" in var):
            #print("entered equal")
            final_df = final_df.withColumn("status",when((col("tgt_tbl_val") == var_check),"PASS").otherwise("FAIL"))
    else:
        final_df = final_df.withColumn("status",when((col("tgt_tbl_val") == var_check),"PASS").otherwise("FAIL"))

    final_df = final_df.withColumn("join_val", concat_ws(",",*grp_val))
    final_df = final_df.withColumn("tgt_tbl_val",col("tgt_tbl_val").cast(StringType()))

    #    var_check = var.upper() + " " + str(var_check)
    var_check = str(var_check)
    if grp_col:
        grpval_lt  = []
        for grp in grp_col:
            if grp[0] != "append":
                grpval_lt.append(col(src_schema[int(grp[0])]))
            else:
                grpval_lt.append(lit(grp[1]))
        final_df = final_df.withColumn("grp_col_nm", concat_ws(",",array(*grpval_lt)))
    else:
        final_df = final_df.withColumn("grp_col_nm", lit(""))

    for rules in rules_def:
        if isinstance(rules[1],list):
            col_nm = rules[0]
            col_indx = rules[1]
            src_audit_indx = []

            for key in col_indx:
                if "static" in str(key):
                    src_audit_indx.append(lit(key.replace("static","")))
                else:
                    src_audit_indx.append(col(src_schema[int(key)]))

            final_df = final_df.withColumn(col_nm, concat_ws(",",array(*src_audit_indx)))
        else:
            col_nm = rules[0]
            col_val = rules[1]
            final_df = final_df.withColumn(col_nm, lit(col_val))

    global tablenm
    if tbl_nm != "":
        table_name = tbl_nm
    else:
        table_name = tablenm
    final_df = final_df.withColumn("src_tbl_val",lit(str(var_check))) \
        .withColumn("tbl_nm",lit(table_name.upper())) \
        .withColumn("test_cs_nm",lit(tst_cse_nm)) \
        .withColumn("test_cs_id",lit(tst_cse_id)) \
        .withColumn("vldtn_typ",lit(vldtn_typ)) \
        .withColumn("var_pct_act",lit("NA")) \
        .withColumn("var_pct_agd",lit("NA")) \
        .withColumn("mnth_load",lit(yrmnth)) \
        .withColumn("load_dtm",lit(loaddtm))
    final_df = final_df.select(final_colnm)
    fail_df = final_df.filter(col("status") == "FAIL")
    #    if len(fail_df.head(1)) > 0:
    if fail_df.count() > 0:
        create_fail_file()
        print("Failed:Technical validation failed" )
    else:
        print("multi validation --- %s seconds ---" % (time.time() - start_time))
        #        create_done_file()
        print("Passed:Technical validation passed" )

    return final_df


def null_dup_validation(spark, query,test_case_name,test_case_id,vldtn_typ,dbprop):
    """
    func to check the record count (if null than pass - Null/Duplicate Validation)
    """
    print("Null and Duplicate Validation")
    print(query)
    if (len(dbprop) == 0) or ("spark" == dbprop["dbname"].lower()):
        data = spark.sql(query)
    else:
        jdbcURL,conn_prop = getjdbcAndConfigProp(spark,dbprop)
        data = spark.read.jdbc(url=jdbcURL,table='('+ query + ') T',properties=conn_prop)

    src_dataschema= data.schema.names
    count = data.count()
    src_cnt = None
    if count == 1:
        src_cnt = data.collect()[0][src_dataschema[0]]
    print(count)
    if (count == 0) or (src_cnt == 0):
        if src_cnt == 0:
            update_hivedata(tstcasenm=test_case_name,tstcaseid=test_case_id,
                            actual=src_cnt,expect=0,vldtn_type=vldtn_typ,Status="PASS")
        else:
            update_hivedata(tstcasenm=test_case_name,tstcaseid=test_case_id,
                            actual=count,expect=0,vldtn_type=vldtn_typ,Status="PASS")

        #        create_done_file()
        print("null & Dup validation --- %s seconds ---" % (time.time() - start_time))
        print("Passed:Null OR Dup Value")
    else:
        update_hivedata(tstcasenm=test_case_name,tstcaseid=test_case_id,
                        actual=count,expect=0,vldtn_type=vldtn_typ,Status="FAIL")
        create_fail_file()
        print("Failed:Null OR Dup Valued")

def send_mail(msg = ""):
    """
    func to send the mail with the status
    """
    global tablenm
    global jobstatus
    global audit_tbnm
    global email_ids
    global glb_param
    tablename = tablenm.upper()
    #    recipients = ['dinan.biswas@anthem.com', "nitish.mahajan@anthem.com"]
    try:
        email_ids = glb_param["$EMAIL_IDS$"].split(",")
    except:
        email_ids = email_ids
    recipients = email_ids
    host = socket.gethostname()
    status = "FAIL"
    subjectline = ""
    if msg == "":
        status = "PASS"  if jobstatus else "FAIL"
        subjectline = "Server Name:{0} - Data validation Status for {1} Table - {2}".format(host,tablename,status)
        if status == "PASS":
            msg = MIMEText("""
                   Hi Team,</br></br>
                   This email is regards to providing the Data validation status for <b>{0}</b>
                   Table which has been <b>PASSED</b>. You can review the results in Audit table <b>{1}</b> for more information.
                   </br></br>
                   Thanks,</br>
                   CII Team
                   """.format(tablename,audit_tbnm.upper()),"html")
        else:
            msg = MIMEText("""
                   Hi Team,</br></br>
                   This email is regards to providing the Data validation status for <b>{0}</b> 
                   Table which has been <b>FAILED</b>. Please take a look into Audit table <b>{1}</b> 
                   for more information in order to take appropriate actions if required.
                   </br></br>
                   Thanks,</br>
                   CII Team
                   """.format(tablename,audit_tbnm.upper()),"html")
    else:
        print(host,tablename,status)
        subjectline = "Server Name:{0} - Unavailability of Data for {1} Table - {2}".format(host,tablename,status)
        msg = MIMEText("""
               Hi Team,</br></br>
               This email is regards to providing the Data validation status for <b>{0}</b> 
               Table which has been <b>FAILED</b> Due to Unavailability of Data.
               </br></br>
               Thanks,</br>
               CII Team
               """.format(tablename,audit_tbnm.upper()),"html")


    msg['Subject'] = subjectline
    msg['From'] = "CII_TestAutomation"
    msg["To"] = ",".join(recipients)

    p = Popen(["/usr/sbin/sendmail", "-t", "-oi"], stdin=PIPE)
    p.communicate(msg.as_string().encode())
    print(msg.as_string())


def getjdbcAndConfigProp(spark,param):
    dbname = param['dbname']
    connectionProp = {}
    if "teradata" in dbname.lower():
        connectionProp['user'] = param['username']
        if "password" in param.keys():
            passwd = param['password']
        elif "password_alias" in param.keys():
            jdbcPassword = param['password_alias']
            jceksValue = param['jceks']
            x = spark.sparkContext._jsc.hadoopConfiguration()
            x.set("hadoop.security.credential.provider.path", jceksValue)
            act_jdbcPassword = x.getPassword(jdbcPassword)
            passwd = ""
            for i in range(act_jdbcPassword.__len__()):
                passwd = passwd + str(act_jdbcPassword.__getitem__(i))
        else:
            print("please provide the password")
            exit(0)

        connectionProp["password"] = passwd
        connectionProp["driver"] = param['driver']
        jdbcUrl = param['jdbc_url']

        return (jdbcUrl,connectionProp)
def get_secret_value(secretkey):
    import boto3
    session= boto3.session.Session()
    client=session.client(service_name='secretsmanager',region_name='us-east-1')
    secretResponse=client.get_secret_value(SecretId=secretkey)
    #    print(secretResponse['SecretString'])
    secret=ast.literal_eval(secretResponse['SecretString'])
    return secret

def getSecretMangerProp(spark,param):
    secret_manager = param["secret_manager"]
    secret = get_secret_value(secret_manager)
    getOptions = param["options"]
    #    sf_format = param["format"]
    #    param.pop("secret_manager")
    #    param.pop("options")

    manip_options = getOptions.replace("{","").replace("}","")

    for kv in manip_options.split(","):
        k,v = kv.split(":")
        tmp = None
        if "secret" in v:
            v = v.strip()
            lcls = locals()
            exec("%s=%s" %("tmp",v), globals(), lcls)
            tmp = lcls['tmp']
            if isinstance(tmp,int) or isinstance(tmp,float):
                getOptions = getOptions.replace(v,str(tmp))
            else:
                getOptions = getOptions.replace(v,str("'"+tmp+"'"))
    sfOptions = ast.literal_eval(getOptions)
    return(param,sfOptions)

def getFullProp(spark,param):
    try:
        jceksValue = param['jceks']
        x = spark.sparkContext._jsc.hadoopConfiguration()
        x.set("hadoop.security.credential.provider.path", jceksValue)
    except:
        pass

    if "username" in param.keys():
        usernm = param['username']
    elif "username_alias" in param.keys():
        jdbcUsername = param['username_alias']
        act_jdbcUsername = x.getPassword(jdbcUsername)
        usernm = ""
        for i in range(act_jdbcUsername.__len__()):
            usernm = usernm + str(act_jdbcUsername.__getitem__(i))
        else:
            print("Couldn't able to read username")
            exit(0)

    if "password" in param.keys():
        passwd = param['password']
    elif "password_alias" in param.keys():
        jdbcPassword = param['password_alias']
        act_jdbcPassword = x.getPassword(jdbcPassword)
        passwd = ""
        for i in range(act_jdbcPassword.__len__()):
            passwd = passwd + str(act_jdbcPassword.__getitem__(i))
        else:
            print("Couldn't able to read password")
            exit(0)

    esOptions = ast.literal_eval(param["options"])
    esOptions["es.net.http.auth.user"] = usernm
    esOptions["es.net.http.auth.pass"] = passwd
    return(param,esOptions)
#---------------------------------------------------------------------------------#
#Fucntion to Read an object to S3                                               #
#---------------------------------------------------------------------------------#
def _read_s3_object(s3_path):
    """
    Function to read object from s3 path
    :param s3_path: S3 object full path
    :return: object
    """
    s3 = boto3.resource('s3')
    bucket = s3_path.split("//")[1].split("/")[0]
    key = "/".join(s3_path.replace("//", "").split("/")[1:])
    
    print("Reading S3 obj {}".format(s3_path))
    obj = s3.Object(bucket, key)
    
    return obj
#---------------------------------------------------------------------------------#
#Fucntion to Upload an object to S3                                               #
#---------------------------------------------------------------------------------#
def upload_s3_object(s3_path, data):
    """
    Function to upload file to s3
    :param bucket_name: Bucket name for s3 upload
    :param object_key: key name for s3 upload
    :param table_nm: Table name for s3 upload
    :return: None
    """
    
    s3 = boto3.resource('s3')
    bucket = s3_path.split("//")[1].split("/")[0]
    key = "/".join(s3_path.replace("//", "").split("/")[1:])
    obj = s3.Object(bucket, key)
    
    #LOGGER.info("\n Uploading s3 object {} \n".format(s3_path))
    obj.put(Body=data)
    
    return

if __name__ == '__main__':
    #params = ['env', 'table_name', 'audit_tbnm', 'config_file', 'global_file', 'validation_path']
    params = ['etl_stp_parms']
    ARGS = getResolvedOptions(sys.argv, params)
    etl_parms = json.loads(ARGS['etl_stp_parms'])
    glb_param["${env}"] = etl_parms.get('env').strip().lower()
    envv = etl_parms.get('env').strip().lower()
    print("environment variable :" + envv)
    envv = envv.lower()
    if envv == "sit":
        glb_param["${env_nm}"] = "t01"
    elif envv == "dev":
        glb_param["${env_nm}"] = "d01"
    elif envv == "prod":
        glb_param["${env_nm}"] = "p01"
    elif envv == "uat":
        glb_param["${env_nm}"] = "u01"
    elif envv == "preprod":
        glb_param["${env_nm}"] = "r01"            

    tablenmparm = etl_parms.get('table_name').strip()
    print("etl_parms :" + str(etl_parms.keys()))
    glb_param["${table_name}"] = tablenmparm
    audit_tbnm = etl_parms.get('audit_tbnm').strip()
    config_file = etl_parms.get('config_file').strip()
    global_file = etl_parms.get('global_file').strip()
    input_validation_path = etl_parms.get('validation_path').strip()
    validation_sqls = _read_s3_object(input_validation_path).get()['Body'].read().decode('utf-8')
    # Find all parameters used in sql query that needs to be substituted from parms.
    sql_vars1 = set(re.findall(r'\$\{([\w]+?)\}', validation_sqls))
    # Look up the parms for parameters used in SQL and substitute it with value found in parms.
    print(f'*** sql_vars1:{sql_vars1}, Substituting parameters passed through parms in SQL Files ***\n')
    if etl_parms:
        for key in sql_vars1:
            if key not in etl_parms.keys():
                print(f'*** Error: Cannot substitute  variable \'{key}\' in the sql script as it is not found in parms. ')
                raise InvalidStatus(f"Parameter not found in parms")
            else:
                print(f'Parameter to be replaced in the script: ${{{key}}}')
                print(f'Parameter Value to be replaced with in the script: {etl_parms[key]}')
                validation_sqls = validation_sqls.replace(f'${{{key}}}', etl_parms[key])
    if (len(sql_vars1) > 0):
        i = 0
        for key in sql_vars1:
            upload_s3_object(input_validation_path + "_" + str(etl_parms[key]).lower().replace("'","").replace(" ",""), validation_sqls)
            if (i < 1):
                validation_path = input_validation_path + "_" + str(etl_parms[key]).lower().replace("'","").replace(" ","")
                i = i + 1
    else:
        validation_path = input_validation_path
    email_ids = []
    print("environment variable :" + envv + "table_name: " + tablenmparm + "audit_tbnm: " + audit_tbnm + "config_file: " + config_file + "global_file: " + global_file + "validation_path: " + validation_path)

    main(tablenmparm,config_file,global_file,validation_path)
    print("--- %s seconds ---" % (time.time() - start_time))
    print("completed")
    #send_mail()