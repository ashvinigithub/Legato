"""
DOCSTRING : Python Script to Swap Covid 19 Tables from aciisst_c19_vldtn to aciisst_c19
"""

import re
import snowflake.connector as sf
# from snowflake.connector import DictCursor
from awsglue.utils import getResolvedOptions
from ReduceReuseRecycle import *
from ReduceReuseRecycle.snowflakefunc import *


LOGGER = load_log_config(glue=True)

#LOGGER.info("Reading Glue Job Parameters... \n")

# Define mandatory params
params = ['env',
          'table_list'] 


# Parse Arguments for Glue Job
ARGS = getResolvedOptions(sys.argv, params)
PREVAL_SCHEMA = 'aciisst_c19_vldtn'
SCHEMA = 'aciisst_c19'
APLCTN_CD = ARGS.get('aplctn_cd', 'cii').lower()
#STAGE_TABLE_NAME = ARGS['stg_tbl_nm']
#STAGE_SCHEMA = ARGS['stg_schma']
ENV = ARGS['env']
TABLE_LIST = ARGS['table_list']
WAREHOUSE_SIZE_SUFFIX = ARGS.get('warehouse_size_suffix', '')
if ARGS.get('warehouse_size_suffix') is None:
    LOGGER.info('No WAREHOUSE_SIZE_SUFFIX Parameter Specified - Defaulting to blank  \'\' . \n')


    if(ENV == 'dev'):
        DATABASE='D01_ACIISST'    		 
    elif(ENV == 'sit'):
        DATABASE='T01_ACIISST'
    elif(ENV == 'preprod'):
        DATABASE='R01_ACIISST'
    elif(ENV == 'prod'):
        DATABASE='P01_ACIISST'
    else:
        DATABASE='U01_ACIISST'

REGION_NAME = 'us-east-1'

LOGGER.info(f'\n**** Argument List ****\n-----------------------')
LOGGER.info(f'Environment Running Swap - \'{ENV}\' ')
LOGGER.info(f'Tables passed as input for Swap - \'{TABLE_LIST}\' ')
LOGGER.info(f'\n-----------------------\n')

# Define Functions

def build_swapproc_sql(databasename, prevalschema, schema, table):   
    """
    Function to generate Snowflake truncate table SQL
    :param schema: Name of the Snowflake Schema
    :param table: Name of the Snowflake Table
    :return: SQL Command to Swap Table
    """

    #swapproc_sql = f'CALL ETL_DDLPROC_ACIISST.SWAP_TABLE('D01_ACIISST','ACIISST', 'ACIISST_VLDTN','aim_msk_ctgry_dshbrd')'
   # swapproc_sql = f'CALL ETL_DDLPROC_ACIISST.SWAP_TABLE(\'{databasename}\',\'{prevalschema}\', \'{schema}\',\'{table}\')'
    swapproc_sql = f'CALL ETL_DDLPROC_ACIISST.SWAP_TABLE(\'{databasename}\',\'{prevalschema}\', \'{schema}\',\'{table}\')'
    #swapproc_sql = f'CALL D01_ACIISST.ETL_DDLPROC_ACIISST.SWAP_SCHEMA('D01_ACIISST','ACIISST', 'ACIISST_VLDTN')'
#
    
    return swapproc_sql




# Fetch the SECRET Instance based on Application Code
SECRET = get_secret(LOGGER, ENV, REGION_NAME, f"/snowflake/{APLCTN_CD}")

SECRET_JSON = json.loads(SECRET)




# Main Execution
def main():
    """
    Establishes a Snowflake Connection Object and Executes a Swap schema
    :return: Completes the Snowflake  Swap Schema from ACIISST_C19_VLDTN To ACIISST_C19
    """

    #c19tablelist  = ["cii_dim_acct_mcid_prfl", "cii_fact_mbrshp_smry", "cii_fact_mbr_admt_dtl", "cii_fact_mbr_symp", "cii_fact_symp_mbr_clm_dtl", "cii_fact_symp_mbr_clm_smry", "cii_fact_tlhlth_dtl", "cii_hlth_risk_rng_xwalk","cii_kpi_smry"]
    c19tablelist = TABLE_LIST.strip().split("|")
    
    for  table  in c19tablelist:
        # Create SQL Cursor from Function 'snowflake_conn'
        LOGGER.info('*** Creating Snowflake Connection & Cursor ***')
        TABLE_NAME = table
        try:
            conn = snowflake_conn(logger=LOGGER, aplctn_cd=APLCTN_CD, secret=SECRET,
                                  warehouse_size_suffix=WAREHOUSE_SIZE_SUFFIX)
            cursor = conn.cursor()
            LOGGER.info('*** Created Snowflake Connection & Cursor ***')
            warehouse = SECRET_JSON.get(f'{APLCTN_CD}_warehouse')
            warehouse = warehouse + WAREHOUSE_SIZE_SUFFIX
            LOGGER.info(f'Based on warehouse size value passed as \'{WAREHOUSE_SIZE_SUFFIX}\', '
                        f'warehouse \'{warehouse}\' is used for this session')

        except sf.DatabaseError as SnowflakeConnectionFailure:
            LOGGER.critical('*** CRITICAL: Cannot establish connection with Snowflake ***')
            LOGGER.critical(SnowflakeConnectionFailure)
            raise SnowflakeConnectionFailure

        # Swap the data from aciisst_c19_vldtn to aciisst_c19. 

        try:
            LOGGER.info(f'*** swap CALL ETL_DDLPROC_ACIISST.SWAP_TABLE(PREVAL_SCHEMA,PREVAL_SCHEMA,SCHEMA,TARGET_NAME)  ***')
            swap_table = build_swapproc_sql(DATABASE, PREVAL_SCHEMA, SCHEMA, TABLE_NAME)
            LOGGER.info(f'*** Swap  Table Command is: {swap_table} ***')
            cursor.execute(swap_table)
            LOGGER.info(f'*** SUCCESS: Swap from {PREVAL_SCHEMA} to {SCHEMA} for table {TABLE_NAME} ***')

            
        except sf.ProgrammingError as GenericSnowflakeException:
            LOGGER.critical('*** ERROR: Snowflake Swap Failed ***')
            LOGGER.critical(GenericSnowflakeException)
            raise GenericSnowflakeException


        # Close Snowflake Connection
        LOGGER.info('*** Closing Snowflake Connection ***')
        conn.close()


if __name__ == "__main__":
    main()
