############################################################################################################## 
# Description   : This is a script to convert Json file to Parquet file
# Author        : Legato
# Created       : 25-May-2021 
# Version       : V1.0
# last Updated  : ##-###-####
############################################################################################################## 

#Import Pyspark Modules
from pyspark.sql import SparkSession
from pyspark.context import SparkContext
from pyspark.sql import functions as F
from pyspark.storagelevel import StorageLevel 
from pyspark.sql.types import StructType, StructField, StringType

#Import GLue modules
from awsglue.utils import getResolvedOptions
from awsglue.dynamicframe import DynamicFrame
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.transforms import *

#Import common Modules
import os
import sys
import json
import re
import boto3
from datetime import *
from awsglue.utils import getResolvedOptions
from botocore.exceptions import ClientError
from ReduceReuseRecycle import load_log_config, InvalidStatus

#---------------------------------------------------------------------------------#
# Creating boto3 client for glue, stepfuntion, s3, sns                            #
#---------------------------------------------------------------------------------#
glue = boto3.client('glue')
client = boto3.client('s3')
sns = boto3.client('sns')
sfn = boto3.client('stepfunctions')
LOGGER = load_log_config(glue=True)
#---------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------#
# Define mandatory params
params = ['env', 'target_s3_path']
 
# Parse Arguments for Glue Job
ARGS = getResolvedOptions(sys.argv, params)

#set Variables
env = ARGS['env']
target_s3_path = ARGS['target_s3_path']
                                            
#---------------------------------------------------------------------------------#
#          Deciding the Schema Prefix                                             #
#---------------------------------------------------------------------------------#
if(env=='dev'):
    schema_prefix='d01'
elif(env=='sit'):
    schema_prefix='t01'
elif(env=='preprod'):
    schema_prefix='r01'
elif(env=='prod'):
    schema_prefix='p01'
elif(env=='uat'):
    schema_prefix='u01'
else:
    LOGGER.info(f"\n Invalid Environment Passed - {env}, exit(1) \n")
    exit(1)
#---------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------#
LOGGER.info(f"\n Environment - {env} \n")
LOGGER.info(f"\n target_s3_path - {target_s3_path} \n")

#---------------------------------------------------------------------------------#
#                      Business Logic                                             #
#---------------------------------------------------------------------------------#	
try:
    #create spark session
    spark = SparkSession.builder.appName("ETL").config("spark.sql.catalogImplementation", "hive").config("hive.metastore.connect.retries", 15).config("hive.metastore.client.factory.class", "com.amazonaws.glue.catalog.metastore.AWSGlueDataCatalogHiveClientFactory").enableHiveSupport().getOrCreate()
    
    #spark.sparkContext._jsc.hadoopConfiguration().set("mapred.output.committer.class", "org.apache.hadoop.mapred.FileOutputCommitter")
    #glueContext = GlueContext(spark)
    
    # Read the EMR job template from s3.
    cii_sgmntn_list_json = spark.read.json(target_s3_path + "_temp")
    cii_sgmntn_list_json.createOrReplaceTempView("cii_sgmntn_list_json")
    spark.sql("select cast(sgmntn_dim_key as bigint) as sgmntn_dim_key, load_log_key, cast(load_dtm as timestamp) as load_dtm from cii_sgmntn_list_json").write.format('parquet').mode('overwrite').save(target_s3_path)
    
#---------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------#    		  
except Exception as e:
    raise e