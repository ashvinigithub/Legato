from awsglue.utils import getResolvedOptions
from boto_wrapper import sfs,acc_info,secretkey
from query_variables import *
import logging
import json
import sys
import os
import boto3
import base64
from datetime import date, time
from botocore.exceptions import ClientError
import psycopg2


# Parse Arguments for Glue Job
ARGS = getResolvedOptions(sys.argv, ['db_config','env'])
global db_config_path,environment
environment = ARGS['env']

db_config_path = ARGS['db_config']

print("Disp2", db_config_path)

# Define Functions
def load_log_config():
    """
    # Basic config. Replace with your own logging config if required
    :return: object for basic logging
    """
    global logger

    MSG_FORMAT = '%(asctime)s %(levelname)s %(name)s: %(message)s'
    DATETIME_FORMAT = '%Y-%m-%d %H:%M:%S'
    logging.basicConfig(format=MSG_FORMAT, datefmt=DATETIME_FORMAT)
    logger = logging.getLogger("ACIISST_SAVE_FLTR")

    logger.setLevel(logging.INFO)


def get_secret(secret_name):
    """
    Function to fetch details from AWS Secrets Manager
    Usage   : Get Secret JSON String
    Args    : Secret Name
    Returns : Secure string of Secret
    Raises  : Exception While getting the Secret.

    """
    secret = ''
    secret_client = boto3.client("secretsmanager")

    try:
        get_secret_value_response = secret_client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as error:
        if error.response['Error']['Code'] == 'DecryptionFailureException':
            raise error
        elif error.response['Error']['Code'] == 'InternalServiceErrorException':
            raise error
        elif error.response['Error']['Code'] == 'InvalidParameterException':
            raise error
        elif error.response['Error']['Code'] == 'InvalidRequestException':
            raise error
        elif error.response['Error']['Code'] == 'ResourceNotFoundException':
            raise error
    else:
        if 'SecretString' in get_secret_value_response:
            secret = get_secret_value_response['SecretString']
            return secret
        else:
            decoded_binary_secret = base64.b64decode(
                get_secret_value_response['SecretBinary'])
            return decoded_binary_secret


def rds_conn(host_name, secret_name, port_no, schema_name):
    """
    Function to use Secrets Manager to create an RDS Connection Object
    :param host_name: Host name of the RDS
    :param secret_name: secret name for fetching user password
    :param port_no: Port Number of RDS
    :param schema_name: Schema Name in RDS
    :return: RDS Connection Object
    """
    try:
        secure_string   = get_secret(secret_name)
        secure_dict     = json.loads(secure_string)
        postgre_username  = secure_dict.get('username')
        postgre_password  = secure_dict.get('password')
        engine = psycopg2.connect(
            database=schema_name,
            user=postgre_username,
            password=postgre_password,
            host=host_name,
            port=port_no
        )
    except Exception as err:
        logger.critical("ERROR: Unexpected error: Could not connect to Aurora instance.")
        logger.critical('*** ERROR: %s ***', err)
        raise err

    return engine





def _read_s3_object(s3_path):
    """
    Function to read object from s3 path
    :param s3_path: S3 object full path
    :return: object
    """
    s3 = boto3.resource('s3')
    bucket = s3_path.split("//")[1].split("/")[0]
    key = "/".join(s3_path.replace("//", "").split("/")[1:])

    logger.info("Reading S3 obj {}".format(s3_path))
    obj = s3.Object(bucket, key)

    return obj



def  unmasking_ddl(conn,cursor):
    """
    Function to execute the sql

    """

    # 1. DELETE
    cursor.execute("DELETE FROM {db_name}.ACIISST_GRP_PRFL WHERE GRP_ID LIKE 'XXXXXXXX%'".format(db_name=DBname)) 
    logger.info("Completed DELETE query")
    conn.commit()


    # 2. INSERT
    cursor.execute("""INSERT INTO {db_name}.ACIISST_GRP_PRFL
                (
                GRP_NM,
                CREATD_DTM,
                GRP_EFCTV_DT,
                PRSE_RULE_ID,
                UPDTD_DTM,
                SRC_GRP_NBR,
                GRP_SOR_CD,
                GRP_ID,
                GRP_TRMNTN_DT,
                CREATD_BY_USER_ID,
                UPDTD_BY_USER_ID,
                SCRTY_LVL_CD,
                RPTG_PRMRY_WAC_ID,
                OFSHR_ACSBL_IND,
                RPTG_OFSHR_ACSBL_IND,
                DSCVR_RPTG_CD,
                SCD_ORG_LND_CNT,
                LND_RPT_ELGBLTY_CD,
                RPTG_LND_RPT_ELGBLTY_CD
                )
                SELECT
                GRP_NM,
                CREATD_DTM,
                GRP_EFCTV_DT,
                PRSE_RULE_ID,
                UPDTD_DTM,
                SRC_GRP_NBR,
                GRP_SOR_CD,
                'XXXXXXXX'||ROW_NUMBER()OVER( ORDER BY GRP_ID,GRP_SOR_CD ) AS GRP_ID,
                GRP_TRMNTN_DT,
                CREATD_BY_USER_ID,
                UPDTD_BY_USER_ID,
                SCRTY_LVL_CD,
                RPTG_PRMRY_WAC_ID,
                OFSHR_ACSBL_IND,
                RPTG_OFSHR_ACSBL_IND,
                DSCVR_RPTG_CD,
                SCD_ORG_LND_CNT,
                LND_RPT_ELGBLTY_CD,
                RPTG_LND_RPT_ELGBLTY_CD

                FROM {db_name}.ACIISST_GRP_PRFL WHERE GRP_ID IN
                (
                SELECT  GRP_ID FROM {db_name}.ACIISST_DDIM_SGMNTN  SG
                INNER JOIN {db_name}.ACIISST_GRP_PRFL  PR
                ON SG.SGMNTN_GRP_ID = PR.GRP_ID
                AND SG.SGMNTN_SOR_CD=PR.GRP_SOR_CD
                WHERE ACCT_ID = 'W0004156'
                GROUP BY 1
                )""".format(db_name=DBname))
    logger.info("Completed INSERT")
    conn.commit()


    # 3.UPDATE
    cursor.execute("""UPDATE {db_name}.ACIISST_DDIM_SGMNTN
                    SET SGMNTN_GRP_ID =SRC.MASKED_GRP_ID,SGMNTN_SUBGRP_ID =SRC.MASKED_GRP_ID
                    FROM
                    (SELECT
                         ACIISST_SGMNTN_DIM_KEY
                        ,ACCT_ID
                        ,SGMNTN_GRP_ID
                        ,SGMNTN_SUBGRP_ID
                        ,SGMNTN_SOR_CD
                     ,MASKED_GRP_ID
                        FROM {db_name}.ACIISST_DDIM_SGMNTN
                     INNER JOIN
                     (
                     SELECT
                      GRP_ID AS GRP_ID,
                      GRP_SOR_CD AS GRP_SOR_CD,
                      'XXXXXXXX'|| ROW_NUMBER() OVER( ORDER BY GRP_ID,GRP_SOR_CD) AS MASKED_GRP_ID
                        FROM {db_name}.ACIISST_DDIM_SGMNTN  SG
                        INNER JOIN {db_name}.ACIISST_GRP_PRFL  PR
                        ON SG.SGMNTN_GRP_ID = PR.GRP_ID
                        WHERE ACCT_ID = 'W0004156'
                        GROUP BY 1,2
                        ) MASK
                        ON MASK.GRP_ID=ACIISST_DDIM_SGMNTN.SGMNTN_GRP_ID
                        AND MASK.GRP_SOR_CD=ACIISST_DDIM_SGMNTN.SGMNTN_SOR_CD
                        WHERE ACCT_ID = 'W0004156'
                        GROUP BY 1,2,3,4,5,6
                        ) SRC
                    WHERE
                    ACIISST_DDIM_SGMNTN.ACIISST_SGMNTN_DIM_KEY = SRC.ACIISST_SGMNTN_DIM_KEY
                    AND ACIISST_DDIM_SGMNTN.ACCT_ID = SRC.ACCT_ID
                    AND ACIISST_DDIM_SGMNTN.SGMNTN_GRP_ID = SRC.SGMNTN_GRP_ID
                    AND ACIISST_DDIM_SGMNTN.SGMNTN_SUBGRP_ID = SRC.SGMNTN_SUBGRP_ID
                    AND ACIISST_DDIM_SGMNTN.SGMNTN_SOR_CD=SRC.SGMNTN_SOR_CD""".format(db_name=DBname))
    logger.info("Completed UPDATE query")
    conn.commit()


    return



def main():
    """
    Main Processing Function
    :param mnthly_ind: Argument.
    :param db_config_path: Configuration file s3 path for database RDS variables
    """
    # Logger Information for the Script

    load_log_config()

    # Defining global Variables
    global databaseName, preval_databaseName , DBname


    # Reads the configuration File from S3
    json_obj = _read_s3_object(db_config_path)
    config = json.loads(json_obj.get()['Body'].read().decode('utf-8'))
    logger.info(f"Config Details - {config}")
    # Getting RDS connection Details from configuration file
    databaseName = config['database_details']['database']
    schema_name = config['database_details']['schema']
    host = config['database_details']['host']
    port = config['database_details']['port']
    secret_name = config['database_details']['secret_name']
    preval_databaseName = config['database_details']['preval_database']
    # user = config['database_details']['user']
    # passwd = config['database_details']['passwd']

    # Creates RDS Connection Object and Cursor
    conn = rds_conn(host, secret_name, port, schema_name)
    cursor = conn.cursor()
    logger.info("Connection to RDS has been established, Cursor is created.")
    
    
    DBname = ''
    
    if environment == 'prod':
        DBname = databaseName
    elif environment == 'preval':
        DBname = preval_databaseName
    elif environment in ('dev','sit','uat'):
        DBname = databaseName
    else:
        raise ValueError("Invalid parameters has been passed for environment key , Possible parameters are  'prod','preval','dev','sit','uat' ")
        
    
    logger.info(f"Environment is {environment}   and  Database  {DBname} is selected ")
    # Calling function
    unmasking_ddl(conn,cursor)
    logger.info("Completed ddl function")


    logger.info("Committing all the changes made and closing the RDS Connection")
    conn.commit()
    conn.close()


    return


if __name__ == '__main__':
    main()
