"""
DOCSTRING : Glue job to load the table - cii_sgmntn_list, by collecting sgmntn_dim_key's from dashboard and adhoc
"""
## This script requires parameters such as aplctn_cd, snowflake_env,warehouse_size_suffix and env

import re
import snowflake.connector as sf
# from snowflake.connector import DictCursor
from awsglue.utils import getResolvedOptions
from ReduceReuseRecycle import *
from ReduceReuseRecycle.snowflakefunc import *

LOGGER = load_log_config(glue=True)

#Import common Modules
import os
import sys
import json
import boto3
import uuid
import pandas as pd
from datetime import *
from awsglue.utils import getResolvedOptions
from botocore.exceptions import ClientError
from ReduceReuseRecycle import load_log_config, InvalidStatus

#---------------------------------------------------------------------------------#
# Creating boto3 client for glue, stepfuntion, s3, sns                            #
#---------------------------------------------------------------------------------#
glue = boto3.client('glue')
client = boto3.client('s3')
sns = boto3.client('sns')
sfn = boto3.client('stepfunctions')
LOGGER = load_log_config(glue=True)
#---------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------#
LOGGER.info("Reading Glue Job Parameters... \n")

# Parse Arguments for Glue Job

# Define mandatory params
params = ['etl_stp_parms']
 
# Parse Arguments for Glue Job
ARGS = getResolvedOptions(sys.argv, params)
                                    
#print("$$$$ 1st checkpoint")
#set Variables
etl_parms           = json.loads(ARGS['etl_stp_parms'])

ENV = etl_parms.get('env').strip().lower()
dashboard_schema = etl_parms.get('dashboard_schema').strip().upper()
adhoc_schema = etl_parms.get('adhoc_schema').strip().upper()
output_file_path = etl_parms.get('output_file_path')
REGION_NAME = 'us-east-1'
load_log_key = uuid.uuid1()

#---------------------------------------------------------------------------------#
#          Deciding the Schema Prefix                                             #
#---------------------------------------------------------------------------------#
if(ENV=='dev'):
    schema_prefix='d01'
elif(ENV=='sit'):
    schema_prefix='t01'
elif(ENV=='preprod'):
    schema_prefix='r01'
elif(ENV=='prod'):
    schema_prefix='p01'
elif(ENV=='uat'):
    schema_prefix='u01'
else:
    LOGGER.info(f"\n Invalid Environment Passed - {ENV}, exit(1) \n")
    exit(1)

APLCTN_CD = ARGS.get('aplctn_cd', 'cii').lower()

#---------------------------------------------------------------------------------#
WAREHOUSE_SIZE_SUFFIX = ARGS.get('warehouse_size_suffix', '')
if ARGS.get('warehouse_size_suffix') is None:
    LOGGER.info('No WAREHOUSE_SIZE_SUFFIX Parameter Specified - Defaulting to blank  \'\' . \n')

# Fetch the SECRET Instance based on Application Code
SECRET = get_secret(LOGGER, ENV, REGION_NAME, f"/snowflake/{APLCTN_CD}")

SECRET_JSON = json.loads(SECRET)

LOGGER.info(f'\n**** Argument List ****\n-----------------------')
LOGGER.info(f'\nREGION_NAME : {REGION_NAME} \nENV : {ENV} \nAPLCTN_CD : {APLCTN_CD} \dashboard_schema : {dashboard_schema} '
            f'\adhoc_schema : {adhoc_schema} '
            f'\nWAREHOUSE_SIZE_SUFFIX : {WAREHOUSE_SIZE_SUFFIX}')
LOGGER.info(f'\n-----------------------\n')
#---------------------------------------------------------------------------------#
# Function to run query on Snowflake                                              #
#---------------------------------------------------------------------------------#
def runQueryonSnowflake(LOGGER, cursor, target_schema):
    try:
        LOGGER.info(f'*** Running the Query for Schema - {target_schema}***')
        query_to_execute = f"""select distinct t.table_name
                               from information_schema.tables t
                               inner join information_schema.columns c on 
                               c.table_schema = t.table_schema and c.table_name = t.table_name
                               where c.column_name = 'SGMNTN_DIM_KEY'
                               and c.table_schema = '{target_schema}'
                               and t.table_name not like '%$B%' and t.table_name not like '%$%' and t.table_name not like '%_STG'
                               and t.table_name not like '%DIM_SGMNTN%' and t.table_name not like '%ACIISST_SGMNTN_BRDG_SCD%' and t.table_name not like '%_BKP%'
                               order by t.table_name"""
        LOGGER.info(f'*** Query to be executed is: {query_to_execute} ***')
        cursor.execute(query_to_execute)
        result = cursor.fetchall()
        LOGGER.info(f'*** Result is : {result} ***')
        return result
    
    except sf.ProgrammingError as GenericSnowflakeException:
        LOGGER.critical('*** ERROR: While executing the query for Schema - {target_schema}***')
        LOGGER.critical(GenericSnowflakeException)
        raise GenericSnowflakeException

#---------------------------------------------------------------------------------#
# Function to Generate Union Query                                                #
#---------------------------------------------------------------------------------#
def generateUnionQuery(LOGGER, snowflake_result, schema):
    try:
        union_query = ''
        tables = []
        for table in snowflake_result:
            tables.append("|".join(table))
        LOGGER.info(f'*** Tables for processing are : {tables} ***')
        counter=0
        for table in tables:
            counter = counter + 1
            if(counter == len(tables)):
                union_query = union_query + f"select SGMNTN_DIM_KEY from {schema}.{table}"
            else:
                union_query = union_query + f"select SGMNTN_DIM_KEY from {schema}.{table} union all "
      
        return union_query
    
    except sf.ProgrammingError as GenericSnowflakeException:
        LOGGER.critical('*** ERROR: While executing the query for Schema - {schema}***')
        LOGGER.critical(GenericSnowflakeException)
        raise GenericSnowflakeException
#---------------------------------------------------------------------------------#
#Class to get the Account Number                                                  #
#---------------------------------------------------------------------------------#
class acc_info:
    sts_function_client=boto3.client('sts')
    def __init__(self):
        acc_details=acc_info.sts_function_client.get_caller_identity()
        self.account=acc_details['Account']
    @property
    def get_account(self):
        return self.account
#---------------------------------------------------------------------------------#
# Function to read an object in S3                                                #
#---------------------------------------------------------------------------------#
def delete_s3_object(s3_path):
    """
    Function to read s3 config path for job processing
    :param s3_path: path to read the s3 file.
    """
    try:
        s3 = boto3.resource('s3')
        bucket = s3_path.split("//")[1].split("/")[0]
        key = "/".join(s3_path.replace("//", "").split("/")[1:])
        kwargs = {'Bucket': bucket, 'Prefix': key}
        while True:
            result = client.list_objects_v2(**kwargs)
            for key in result[ "Contents" ]:
                keyString = key[ "Key" ]
                LOGGER.info("\n Deleting s3 object {} \n".format(keyString))
                obj = s3.Object(bucket, keyString).delete()
            try:
                kwargs['ContinuationToken'] = result['NextContinuationToken']
            except KeyError:
                break
    except Exception as e:
        LOGGER.info("\n Deleting s3 object {} failed or no objects to delete\n".format(key))

#---------------------------------------------------------------------------------#
#Fucntion to Upload an object to S3                                               #
#---------------------------------------------------------------------------------#
def upload_s3_object(s3_path, data):
    """
    Function to upload file to s3
    :param bucket_name: Bucket name for s3 upload
    :param object_key: key name for s3 upload
    :param table_nm: Table name for s3 upload
    :return: None
    """
    
    s3 = boto3.resource('s3')
    bucket = s3_path.split("//")[1].split("/")[0]
    key = "/".join(s3_path.replace("//", "").split("/")[1:])
    obj = s3.Object(bucket, key)
    
    #LOGGER.info("\n Uploading s3 object {} \n".format(s3_path))
    obj.put(Body=data)
    
    return
#---------------------------------------------------------------------------------#
# Function to Send SNS for Success                                                #
#---------------------------------------------------------------------------------#
def snsPublication(LOGGER, subject, message):
    region_name = os.environ['AWS_DEFAULT_REGION']
    account = acc_info().get_account
    sns_arn = 'arn:aws:sns:' \
              + region_name + ':' \
              + account + ':{env}-snsCIIPublication'.format(env=ENV)
    subject = subject
    LOGGER.info('SNS ARN: %s', sns_arn)
    try:
        formatted_msg = message
        response = sns.publish(TargetArn=sns_arn,
                              Message=formatted_msg,
                              Subject=subject,
                              MessageStructure='string'
                              )
                               
        LOGGER.info('SNS Response: %s', response)
    except ClientError as sns_error:
        LOGGER.critical('*** SNS Message Publication Failed: %s ***', sns_error)
        raise sns_error
    	

#---------------------------------------------------------------------------------#
# Function to Send SNS for Failure                                                #
#---------------------------------------------------------------------------------#
def snsNotification(LOGGER, subject, message):
    region_name = os.environ['AWS_DEFAULT_REGION']
    account = acc_info().get_account
    sns_arn = 'arn:aws:sns:' \
              + region_name + ':' \
              + account + ':{env}-snsCIINotification'.format(env=ENV)
    subject = subject
    LOGGER.info('SNS ARN: %s', sns_arn)
    try:
        formatted_msg = message
        response = sns.publish(TargetArn=sns_arn,
                              Message=formatted_msg,
                              Subject=subject,
                              MessageStructure='string'
                              )
                               
        LOGGER.info('SNS Response: %s', response)
    except ClientError as sns_error:
        LOGGER.critical('*** SNS Message Notification Failed: %s ***', sns_error)
        raise sns_error
#---------------------------------------------------------------------------------#
#Function to check the Status of the job in EMR Async                             #
#---------------------------------------------------------------------------------#
def checkStatusGlueJob(jobname, jobrunid):
	  #Function to check the status of the Glue Job Execution using jobrunid
	  response = glue.get_job_run(JobName=jobname, RunId=jobrunid)
	  status = response['JobRun']['JobRunState']
	  
	  if(status=='RUNNING'):
	  	LOGGER.info(f'\n Status of the Glue Job - {status} \n')
	  	import time
	  	LOGGER.info(f'\n Waiting for 60 Seconds \n')
	  	time.sleep(60)
	  	status=checkStatusGlueJob(jobname, jobrunid)
	  elif(status=="SUCCEEDED"):
	    LOGGER.info(f'\n Status of the Glue Job - {status} \n')
	  elif(status=="FAILED"):
	    LOGGER.info(f'\n Status of the Glue Job - {status} \n')
	  else:
	    LOGGER.info(f'\n Status of the Glue Job - {status} \n')
	  
	  
	  return status
#---------------------------------------------------------------------------------#
#Function to check the Status of the job in EMR Async                             #
#---------------------------------------------------------------------------------#
def runGlueJob(jobname):
    response = glue.start_job_run(
    JobName = 'ANTM-CII-' + ENV + '-Gj-AciisstSgmntnListLoad',
    Arguments = {
    '--env':   ENV,
    '--target_s3_path':  output_file_path } )
    jobrunid = response['JobRunId']
    LOGGER.info(f'\nJob Run ID : {jobrunid} \n')
    status=checkStatusGlueJob(jobname, jobrunid)
    return status
#---------------------------------------------------------------------------------#
#                      Business Logic                                             #
#---------------------------------------------------------------------------------#	
# Create SQL Cursor from Function 'snowflake_conn'
LOGGER.info('*** Creating Snowflake Connection & Cursor ***')

try:
	conn = snowflake_conn(logger=LOGGER, aplctn_cd=APLCTN_CD, secret=SECRET, warehouse_size_suffix=WAREHOUSE_SIZE_SUFFIX)
	cursor = conn.cursor()
	LOGGER.info('*** Created Snowflake Connection & Cursor ***')
	warehouse = SECRET_JSON.get(f'{APLCTN_CD}_warehouse')
	warehouse = warehouse + WAREHOUSE_SIZE_SUFFIX
	LOGGER.info(f'Based on warehouse size value passed as \'{WAREHOUSE_SIZE_SUFFIX}\', '
				f'warehouse \'{warehouse}\' is used for this session')
	LOGGER.info(f"*** Setting up the time format is: alter session set timestamp_output_format = 'YYYY-MM-DD HH24:MI:SS.FF'; ***")
	cursor.execute("alter session set timestamp_output_format = 'YYYY-MM-DD HH24:MI:SS.FF'")

except sf.DatabaseError as SnowflakeConnectionFailure:
	LOGGER.critical('*** CRITICAL: Cannot establish connection with Snowflake ***')
	LOGGER.critical(SnowflakeConnectionFailure)
	raise SnowflakeConnectionFailure

try:
    union_query_for_dashboard = ''
    union_query_for_adhoc = ''
    
    #Calling function - runQueryonSnowflake, for Dashboard tables
    result_for_dashboard = runQueryonSnowflake(LOGGER, cursor, dashboard_schema)
    union_query_for_dashboard = generateUnionQuery(LOGGER, result_for_dashboard, dashboard_schema)
    LOGGER.info(f'\n*** Union Query Built for Dashboard Tables is : {union_query_for_dashboard} ***')
    
    #Calling function - runQueryonSnowflake, for Adhoc tables
    result_for_adhoc = runQueryonSnowflake(LOGGER, cursor, adhoc_schema)
    union_query_for_adhoc = generateUnionQuery(LOGGER, result_for_adhoc, adhoc_schema)
    LOGGER.info(f'\n*** Union Query Built for Adhoc Tables is : {union_query_for_adhoc} ***')
    #Concatenating Dashboard and Adhoc Queries to generate final query
    final_query = f"select distinct cast(SGMNTN_DIM_KEY as string) as SGMNTN_DIM_KEY,'{load_log_key}' as load_log_key, cast(current_timestamp(3) as string) as load_dtm from (" + union_query_for_dashboard + " union all " + union_query_for_adhoc + ")"
    
    LOGGER.info(f'*** Query to be executed is: {final_query} ***')
    cursor.execute(final_query)
    #Deleting the output location before going to write output
    LOGGER.info(f'*** Deleting output path : {output_file_path}_temp/ ***')
    #Calling the delete s3 files function
    delete_s3_object(output_file_path + '_temp')
    flag=True
    count=0
    while flag:
        final_result = cursor.fetchmany(500000)
        output_list = []
        final_output_list = []
        if len(final_result) > 0:
            fectch_count =len(final_result) 
            LOGGER.info(f'*** Number of Records in the fetch: {fectch_count} ***')
            for output in final_result:
                output_list.append("|".join(output))
            written_count =len(output_list)
            LOGGER.info(f'*** Number of Records wirtten as output json: {written_count} ***')
            for data in output_list:
                data_split = data.split("|")
                final_output_list.append({"sgmntn_dim_key":data_split[0], "load_log_key":data_split[1], "load_dtm":data_split[2]})
            count=count + 1
            upload_s3_object(output_file_path + "_temp" + "/" + str(count) + "_cii_sgmntn_list.json", json.dumps(final_output_list))
        else:
            flag=False
    jobname = 'ANTM-CII-' + ENV + '-Gj-AciisstSgmntnListLoad'
    run_counter=0
    while run_counter <=3:
        status = runGlueJob(jobname)
        if(status=="SUCCEEDED"):
            LOGGER.info(f'\nData Loaded to Target Successfully : {output_file_path} \n')
            break
        LOGGER.info(f'\n Waiting for 120 Seconds \n')
        import time
        time.sleep(120)
        run_counter = run_counter + 1
    
    if(status=="SUCCEEDED"):
        snsPublication(LOGGER, f'SUCCEEDED - Load - cii_sgmntn_list', f"\n For the Table - cii_sgmntn data is loaded successfully to the S3 Location - {output_file_path} \n")
    else:
        LOGGER.info(f'\nData Load Failed : {output_file_path} \n')
        snsNotification(LOGGER, f'FAILED - Load - cii_sgmntn_list', f"\n For the Table - cii_sgmntn data is failed to load from Json to Parquet, please check the logs \n")
    cursor.close()
#---------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------#
#---------------------------------------------------------------------------------#    		  
except Exception as e:
    snsNotification(LOGGER, f'FAILED - Load - cii_sgmntn_list', f"\n For the Table - cii_sgmntn data load is failed, please check the logs \n")
    raise e
