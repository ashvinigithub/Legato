from awsglue.utils import getResolvedOptions
from boto_wrapper import sfs,acc_info,secretkey
from query_variables import *
import logging
import json
import sys
import os
import boto3
import base64
from datetime import date, time
from botocore.exceptions import ClientError
import psycopg2

# Parse Arguments for Glue Job
ARGS = getResolvedOptions(sys.argv, [
    'mnthly_ind',
    'db_config'])

global mnthly_ind, db_config_path

mnthly_ind = ARGS['mnthly_ind']
db_config_path = ARGS['db_config']
print("Disp1", mnthly_ind)
print("Disp2", db_config_path)

# Define Functions
def load_log_config():
    """
    # Basic config. Replace with your own logging config if required
    :return: object for basic logging
    """
    global logger

    MSG_FORMAT = '%(asctime)s %(levelname)s %(name)s: %(message)s'
    DATETIME_FORMAT = '%Y-%m-%d %H:%M:%S'
    logging.basicConfig(format=MSG_FORMAT, datefmt=DATETIME_FORMAT)
    logger = logging.getLogger("ACIISST_SAVE_FLTR")

    logger.setLevel(logging.INFO)
    

def get_secret(secret_name):
    """
    Function to fetch details from AWS Secrets Manager
    Usage   : Get Secret JSON String
    Args    : Secret Name
    Returns : Secure string of Secret
    Raises  : Exception While getting the Secret.
    
    """
    secret = ''
    secret_client = boto3.client("secretsmanager")

    try:
        get_secret_value_response = secret_client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as error:
        if error.response['Error']['Code'] == 'DecryptionFailureException':
            raise error
        elif error.response['Error']['Code'] == 'InternalServiceErrorException':
            raise error
        elif error.response['Error']['Code'] == 'InvalidParameterException':
            raise error
        elif error.response['Error']['Code'] == 'InvalidRequestException':
            raise error
        elif error.response['Error']['Code'] == 'ResourceNotFoundException':
            raise error
    else:
        if 'SecretString' in get_secret_value_response:
            secret = get_secret_value_response['SecretString']
            return secret
        else:
            decoded_binary_secret = base64.b64decode(
                get_secret_value_response['SecretBinary'])
            return decoded_binary_secret


def rds_conn(host_name, secret_name, port_no, schema_name):
    """
    Function to use Secrets Manager to create an RDS Connection Object
    :param host_name: Host name of the RDS
    :param secret_name: secret name for fetching user password
    :param port_no: Port Number of RDS
    :param schema_name: Schema Name in RDS
    :return: RDS Connection Object
    """
    try:
        secure_string   = get_secret(secret_name)
        secure_dict     = json.loads(secure_string)
        postgre_username  = secure_dict.get('username')
        postgre_password  = secure_dict.get('password')
        engine = psycopg2.connect(
                database=schema_name,
                user=postgre_username,
                password=postgre_password,
                host=host_name,
                port=port_no
            )
    except Exception as err:
        logger.critical("ERROR: Unexpected error: Could not connect to Aurora instance.")
        logger.critical('*** ERROR: %s ***', err)
        raise err

    return engine

def insert_save_fltr_sgmnt(low, high, total_count, cursor, conn):
    """
    Function to process SAVE_FLTR_ID in multiple batches
    Inserting into the table SAVE_FLTR_SGMNTN
    """
    try:
        if(total_count >= high):
            cursor.execute(insert_save_fltr_sgmntn_mnthly.format(db_name=databaseName,actv_db_name=preval_databaseName,low_range=low,high_range=high))
            conn.commit()
            logger.info(f"1-Processed SAVE_FLTR_ID Range from {low} to {high}")
        else:
            cursor.execute(insert_save_fltr_sgmntn_mnthly.format(db_name=databaseName,actv_db_name=preval_databaseName,low_range=low,high_range=high))
            conn.commit()
            logger.info(f"2-Processed SAVE_FLTR_ID Range from {low} to {high}")
            low=high
            high=high-1000
            insert_save_fltr_sgmnt(low, high, total_count, cursor, conn)
    except Exception as err:
        logger.critical(f"ERROR: Unexpected error: Inert into Table - SAVE_FLTR_SGMNTN Failed for Range low_range={low} to high_range={high} in total={total_count}")
        logger.critical('*** ERROR: %s ***', err)
        raise err

def updt_ctrl_tbl_timestamp(conn, cursor):
    """
    Function to update timestamps in SAVE_FLTR_TBL_CNTRL Table
    :param conn: Connection Object for Aurora RDS
    :param cursor: Cursor to Execute Queries
    :return: None
    """
    
    vldt_qry = "SELECT COUNT(*) FROM {db_name}.SAVE_FLTR_TBL_CNTRL WHERE TBL_NM = '{tbl_name}'"
    updt_query = "UPDATE {db_name}.SAVE_FLTR_TBL_CNTRL SET REFRESH_DTM = CURRENT_TIMESTAMP WHERE TBL_NM = '{tbl_name}'"
    insrt_query = "INSERT INTO {db_name}.SAVE_FLTR_TBL_CNTRL (TBL_NM, REFRESH_DTM) VALUES ('{tbl_name}', CURRENT_TIMESTAMP)"
    
    for table in ["SAVE_FLTR_SGMNTN_BRDG", "SAVE_FLTR_SGMNTN"]:
        cursor.execute(vldt_qry.format(db_name=databaseName, tbl_name=table))
        conn.commit()
        result = cursor.fetchone()[0]
        
        if(result > 0):
            cursor.execute(updt_query.format(db_name=databaseName, tbl_name=table))
        else:
            cursor.execute(insrt_query.format(db_name=databaseName, tbl_name=table))
    
    conn.commit()

    return


def save_fltr_mnthly_process(conn, cursor):
    """
    Function to process monthly loads of saved filter
    :param conn: Connection Object for Aurora RDS
    :param cursor: Cursor to Execute Queries
    :return: None
    """
    
    '''Monthly is full refresh so delete from tables & set LOW_DTM value'''
    logger.info("Deleting the current data from SAVE_FLTR_SGMNTN_BRDG and SAVE_FLTR_SGMNTN")
    cursor.execute("DELETE FROM {db_name}.SAVE_FLTR_SGMNTN_BRDG".format(db_name=databaseName))
    conn.commit()
    cursor.execute("DELETE FROM {db_name}.SAVE_FLTR_SGMNTN".format(db_name=databaseName))
    conn.commit()
    
    
    '''First, we define a volatile table to hold flattened records from the save filter detail table of name-value pairs.  The column names and field lengths shown
       correspond to various parameters passed to the ACIISST_APPL.UPDATE_USER_SGMNTN stored procedure.'''
    logger.info("Creating vfltr_rllup Table")
    cursor.execute(create_vfltr_rllup.format(db_name=databaseName))
    conn.commit()
    
    
    '''PREPARE the latest set of filters and also added logic to re-process any unchanged filters that are mapped to changed primary filters; otherwise, the segmentation details 
       for unchanged filters will be incorrect'''
    logger.info("Inserting Latest set of filter into vfltr_rllup")
    cursor.execute(insert_vfltr_rllup.format(db_name=databaseName))
    conn.commit()
    
    
    '''Delete records from vt where all the strings are @; this means none of the filters from account structure are selected'''
    logger.info("Deleting the data which are not related to account structure")
    cursor.execute(del_vfltr_rllup_no_acct_struct.format(db_name=databaseName))
    conn.commit()
    
    
    '''Append to Bridge table any rows corresponding to new primaries'''
    logger.info("Inserting the new primaries to Segmentation bridge")
    cursor.execute(insert_save_fltr_sgmnt_brdg_mnthly.format(db_name=databaseName,actv_db_name=preval_databaseName))
    conn.commit()
    
    
    '''Update EFCTV_DTM value for primary rows to the max EFCTV_DTM of children'''
    logger.info("Updating Effective Date Time value for primary rows to the max EFCTV_DTM of children")
    cursor.execute(updt_save_fltr_sgmnt_brdg.format(db_name=databaseName))
    conn.commit()
    
    
    '''Delete any existing entries in the table before inserting; this is to make sure that the segmentation keys get updated for any updates to
       existing saved filter definitions'''
    logger.info("Delete any existing entries in the table before inserting into save filter segmentation")
    cursor.execute(del_saved_fltr_sgmnt_delta.format(db_name=databaseName))
    conn.commit()
    
    
    '''Process Account Segmentation Mapping'''
    logger.info("Processing Account Segmentation Mapping")
    cursor.execute(insert_save_fltr_sgmntn.format(db_name=databaseName,actv_db_name=preval_databaseName))
    conn.commit()
    logger.info("Processing Account Segmentation from ACIISST_MSTR_SGMNTN TABLE")
    count_sql = "SELECT MIN(acct_filtr_key) FROM {actv_db_name}.ACIISST_MSTR_SGMNTN WHERE acct_filtr_key <> -1".format(actv_db_name=preval_databaseName)
    cursor.execute(count_sql)
    total_count = cursor.fetchone()[0]    
    insert_save_fltr_sgmnt(-1, total_count, total_count, cursor, conn)

    
    '''Do one final cleanup of orphan segmentation records'''
    logger.info("Doing a final cleanup of orphan segmentation records")
    cursor.execute(sgmnt_brdg_cleanup.format(db_name=databaseName))
    conn.commit()

    logger.info("Updating control table timestamps for save filter control tables")
    updt_ctrl_tbl_timestamp(conn, cursor)

    return


def save_fltr_daily_catchup_process(conn, cursor):
    """
    Function to process Daily/Catchup loads of saved filter
    :param conn: Connection Object for Aurora RDS
    :param cursor: Cursor to Execute Queries
    :return: None
    """
    logger.info("Save filter Daily or Catchup Process Started")
    
    cursor.execute(create_vfltr_rllup.format(db_name=databaseName))
    conn.commit()
    
    '''If daily or catchup then prepare a primary filter set.'''
    cursor.execute(create_vfltr_rllup_primary.format(db_name=databaseName))
    conn.commit()
    
    logger.info("Creating Temporary Tables rllup, rllup_primary")
    '''Insert Primary Set filters'''
    cursor.execute(insert_vfltr_rllup_primary.format(db_name=databaseName))
    conn.commit()
    
    '''PREPARE the latest set of filters and also added logic to re-process any unchanged filters that are mapped to changed primary filters; otherwise, the segmentation details 
       for unchanged filters will be incorrect'''
    logger.info("Inserting the latest set of filters and re-processing any unchanged filters")
    cursor.execute(insert_vfltr_rllup.format(db_name=databaseName))
    conn.commit()   
    
    '''Delete records from vt where all the strings are @; this means none of the filters from account structure are selected'''
    logger.info("Deleting records which are not related to account structure")
    cursor.execute(del_vfltr_rllup_no_acct_struct.format(db_name=databaseName))
    conn.commit()    
    
    ''' delete any existing data in segmentation bridge table '''
    cursor.execute(del_existng_sgmnt_brdg.format(db_name=databaseName))
    conn.commit()
    
    ''' Insert into Segmentation Bridge, only map filters where the filter ids do not match '''
    logger.info("Inserting into Segmentation Bridge, only map filters where the filter ids do not match")
    cursor.execute(insrt_sgmnt_brdg.format(db_name=databaseName))
    conn.commit()
        
    '''Only delete the entries where incoming saved filter is not a primary filter'''
    cursor.execute(del_non_prim_filters.format(db_name=databaseName))
    conn.commit()
    
    '''Append to Bridge table any rows corresponding to new primaries'''
    cursor.execute(insert_save_fltr_sgmnt_brdg.format(db_name=databaseName))
    
    '''Update EFCTV_DTM value for primary rows to the max EFCTV_DTM of children'''
    logger.info("Updating effective date time in segmentation brdg data is done")
    cursor.execute(updt_save_fltr_sgmnt_brdg.format(db_name=databaseName))
    conn.commit()
        
    '''Delete any existing entries in the table before inserting; this is to make sure that the segmentation keys get updated for any updates to
       existing saved filter definitions'''
    logger.info("Deleting the delta filters")
    cursor.execute(del_saved_fltr_sgmnt_delta.format(db_name=databaseName))
    conn.commit()
        
    '''Process Account Segmentation Mapping'''
    cursor.execute(insert_save_fltr_sgmntn.format(db_name=databaseName,actv_db_name=databaseName))
    conn.commit()

    '''Do one final cleanup of orphan segmentation records'''
    logger.info("Doing Final Cleanup for Orphan segmentation records")
    cursor.execute(sgmnt_brdg_cleanup.format(db_name=databaseName))
    conn.commit()
    
    logger.info("All changes Commited")
    
    logger.info("Updating the timestamp for save filter control tables")
    updt_ctrl_tbl_timestamp(conn, cursor)
        
    return
    
    
def update_save_fltr_ctrl(conn, cursor, mnthly_ind):
    """
    Function to update saved filter control table based on monthly indicator
    :param conn: Connection Object for Aurora RDS
    :param cursor: Cursor to Execute Queries
    :param mnthly_ind: Montly Indicator
    :return: None
    """
    
    ''' Mark the scope of processing.  Since Monthly and Catchup loads operate in the Passive DB whereas Daily loads operate in the Active DB, we need to be a bit careful about how we set 
    the LOW_DTM value.  The goal of processing is that Monthly covers all saved filters whereas Catchup covers any filters changed since the last monthly run and Daily covers any 
    filters changed since the last run that occurred in the Active DB.'''
    
    validate_sql = "SELECT COUNT(*) FROM {db_name}.SAVE_FLTR_CNTRL WHERE LKUP_ID = 5".format(db_name=databaseName)
    cursor.execute(validate_sql)
    fetch_vsql_res = cursor.fetchone()[0]
    
    if(fetch_vsql_res != 0):
        updt_sql = "UPDATE {db_name}.SAVE_FLTR_CNTRL SET ACTV_LOAD_IND = 'Y', LOAD_TYPE_CD = '"+ str(mnthly_ind) + "', SAVE_FLTR_LOW_DTM = \
            ( CASE WHEN '"+ str(mnthly_ind) + "' ='M' THEN TIMESTAMP '2010-01-01 00:00:00' \
                   WHEN '"+ str(mnthly_ind) + "' ='C' THEN MNTHLY_RFRSH_DTM ELSE SAVE_FLTR_LOW_DTM END ) \
            , SAVE_FLTR_HIGH_DTM = CURRENT_TIMESTAMP \
            , UPDTD_DTM = CURRENT_TIMESTAMP \
            WHERE LKUP_ID = 5"
        
        print(databaseName)
        updt_sql1 = updt_sql.format(db_name=databaseName)
        print("updated update sql: ",updt_sql1 )
        logger.info("Executing Query {}".format(updt_sql))
        logger.info("Updating record in Save filter Control Table")
        cursor.execute(updt_sql1)
        conn.commit()

        print(updt_sql)
        print("query ran successful")
    else:
        insrt_sql = "INSERT INTO {db_name}.SAVE_FLTR_CNTRL (LKUP_ID, SAVE_FLTR_LOW_DTM, SAVE_FLTR_HIGH_DTM, ACTV_LOAD_IND, \
                LOAD_TYPE_CD, UPDTD_DTM, RFRSH_DTM, MNTHLY_RFRSH_DTM) VALUES \
                (4, TIMESTAMP '2010-01-01 00:00:00', CURRENT_TIMESTAMP, 'Y', \
                '"+ str(mnthly_ind) + "', CURRENT_TIMESTAMP, TIMESTAMP '2010-01-01 00:00:00', TIMESTAMP '2010-01-01 00:00:00')".format(db_name=databaseName)
        
        logger.info("Executing Query {}".format(insrt_sql))
        logger.info("Inserting record in Save filter Control Table")        
        cursor.execute(insrt_sql)
        conn.commit()
        
    return


def _read_s3_object(s3_path):
    """
    Function to read object from s3 path
    :param s3_path: S3 object full path
    :return: object
    """
    s3 = boto3.resource('s3')
    bucket = s3_path.split("//")[1].split("/")[0]
    key = "/".join(s3_path.replace("//", "").split("/")[1:])
    
    logger.info("Reading S3 obj {}".format(s3_path))
    obj = s3.Object(bucket, key)
    
    return obj

        
def main():
    """
    Main Processing Function
    :param mnthly_ind: Argument.
    :param db_config_path: Configuration file s3 path for database RDS variables
    """
    # Logger Information for the Script
    load_log_config()

    # Defining global Variables
    global databaseName, preval_databaseName

    # Validation check for Monthly indicator
    if(mnthly_ind.lower() not in ('d','m','c')):
        logger.exception("FAILED: Invalid Monthly Run Indicator. Valid values are 'M', 'D', or 'C'")
        raise Exception("FAILED: Invalid Monthly Run Indicator. Valid values are 'M', 'D', or 'C'")
    
    # Reads the configuration File from S3
    json_obj = _read_s3_object(db_config_path)
    config = json.loads(json_obj.get()['Body'].read().decode('utf-8'))

    # Getting RDS connection Details from configuration file
    databaseName = config['database_details']['database']
    schema_name = config['database_details']['schema']
    host = config['database_details']['host']
    port = config['database_details']['port']
    secret_name = config['database_details']['secret_name']
    preval_databaseName = config['database_details']['preval_database']
    # user = config['database_details']['user']
    # passwd = config['database_details']['passwd']

    # Creates RDS Connection Object and Cursor
    conn = rds_conn(host, secret_name, port, schema_name)
    cursor = conn.cursor()
    logger.info("Connection to RDS has been established, Cursor is created.")

    # Delete the Temporary Tables created if exists
    cursor.execute("DROP TABLE IF EXISTS {db_name}.vfltr_rllup".format(db_name=databaseName))
    conn.commit()
    cursor.execute("DROP TABLE IF EXISTS {db_name}.vfltr_rllup_primary".format(db_name=databaseName))
    conn.commit()

    # Save Filters Process Start
    update_save_fltr_ctrl(conn, cursor, mnthly_ind)
    logger.info("Save filter Control Table Update Process Completed")
    
    if(mnthly_ind.lower() == 'm'):
        save_fltr_mnthly_process(conn, cursor)
    else:
        save_fltr_daily_catchup_process(conn, cursor)
    
    # Delete the Temporary Tables created
    cursor.execute("DROP TABLE IF EXISTS {db_name}.vfltr_rllup".format(db_name=databaseName))
    conn.commit()
    cursor.execute("DROP TABLE IF EXISTS {db_name}.vfltr_rllup_primary".format(db_name=databaseName))
    logger.info("Deleted Temporary Tables Created as part of the Run.")

    logger.info("Committing all the changes made and closing the RDS Connection")
    conn.commit()
    conn.close()
    
    return 


if __name__ == '__main__':
    main()
