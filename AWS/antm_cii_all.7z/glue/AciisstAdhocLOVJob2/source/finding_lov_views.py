#Import Glue and Common Modules
from awsglue.utils import getResolvedOptions
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.transforms import *
import logging
import json
import sys
import os
import boto3
import base64
from datetime import date, time
from botocore.exceptions import ClientError
import time

#Import Pyspark Modules
from pyspark.sql import SparkSession
from pyspark.context import SparkContext
from pyspark.sql import functions as F
from pyspark.storagelevel import StorageLevel 
from pyspark.sql.types import StructType, StructField, StringType

# Define mandatory params
params = ['etl_stp_parms']
 
# Parse Arguments for Glue Job
ARGS = getResolvedOptions(sys.argv, params)
                                    
etl_parms = json.loads(ARGS['etl_stp_parms'])
                                            
# read from parmeters
environment = etl_parms.get('env').strip().lower()

# Define Functions
def load_log_config():
    """
    # Basic config. Replace with your own logging config if required
    :return: object for basic logging
    """
    global logger

    MSG_FORMAT = '%(asctime)s %(levelname)s %(name)s: %(message)s'
    DATETIME_FORMAT = '%Y-%m-%d %H:%M:%S'
    logging.basicConfig(format=MSG_FORMAT, datefmt=DATETIME_FORMAT)
    logger = logging.getLogger("ACIISST_ADHOC_FLD_DTLS1")

    logger.setLevel(logging.INFO)

def _read_s3_object(s3_path):
    """
    Function to read object from s3 path
    :param s3_path: S3 object full path
    :return: object
    """
    s3 = boto3.resource('s3')
    bucket = s3_path.split("//")[1].split("/")[0]
    key = "/".join(s3_path.replace("//", "").split("/")[1:])

    logger.info("Reading S3 obj {}".format(s3_path))
    obj = s3.Object(bucket, key)

    return obj
#---------------------------------------------------------------------------------#
#Fucntion to Upload an object to S3                                               #
#---------------------------------------------------------------------------------#
def upload_s3_object(s3_path, data):
    """
    Function to upload file to s3
    :param bucket_name: Bucket name for s3 upload
    :param object_key: key name for s3 upload
    :param table_nm: Table name for s3 upload
    :return: None
    """
    
    s3 = boto3.resource('s3')
    bucket = s3_path.split("//")[1].split("/")[0]
    key = "/".join(s3_path.replace("//", "").split("/")[1:])
    obj = s3.Object(bucket, key)
    
    logger.info("\n Uploading s3 object {} \n".format(s3_path))
    obj.put(Body=data)
    
    return

def main():
    """
    Main Processing Function
    :param mnthly_ind: Argument.
    :param db_config_path: Configuration file s3 path for database RDS variables
    """
    # Logger Information for the Script

    load_log_config()

    # Defining global Variables

    DBnm = ''
    
    if environment == 'prod':
        DBnm = 'p01_cii_adhoc_cons'
    elif environment == 'dev':
        DBnm = 'd01_cii_adhoc_cons'
    elif environment == 'sit':
        DBnm = 't01_cii_adhoc_cons'
    elif environment == 'uat':
        DBnm = 'u01_cii_adhoc_cons'
    elif environment == 'preprod':
        DBnm = 'r01_cii_adhoc_cons'
    else:
        raise ValueError("Invalid parameters has been passed for environment key , Possible parameters are  'prod','dev','sit','uat' and 'preprod'")

    #Commands to delete the files in s3 folder estgtfinal
    bucket_path = f"antm-cii-{environment}-cnfz-nogbd-phi-useast1"
    s3_fldr_rm = boto3.resource('s3')
    bucket = s3_fldr_rm.Bucket(bucket_path)
    for obj in bucket.objects.filter(Prefix='cii/estgtfinal/'):
     s3_fldr_rm.Object(bucket.name,obj.key).delete()
    logger.info("Files in s3 folder estgtfinal removed successfully")
	
    error_path_final = f"s3://antm-cii-{environment}-cnfz-nogbd-phi-useast1/cii/eserrorfinal/error.txt"
    error_path = f"s3://antm-cii-{environment}-cnfz-nogbd-phi-useast1/cii/eserror/error.txt"
    tgt_path = f"s3://antm-cii-{environment}-cnfz-nogbd-phi-useast1/cii/estgtfinal"
	#Spark connectivity and execute queries line by line
    s3_obj = _read_s3_object(error_path)
    file_cntnt = s3_obj.get()['Body'].read().decode('utf-8')
    error_sql = ""
    spark = SparkSession.builder.appName("ETL").config("spark.sql.catalogImplementation", "hive").config("hive.metastore.connect.retries", 15).config("hive.metastore.client.factory.class", "com.amazonaws.glue.catalog.metastore.AWSGlueDataCatalogHiveClientFactory").enableHiveSupport().getOrCreate()
    spark.sparkContext._jsc.hadoopConfiguration().set("mapred.output.committer.class", "org.apache.hadoop.mapred.FileOutputCommitter")
    glueContext = GlueContext(spark)
    for line in file_cntnt.split("\n"):
       if len(line) > 6:
          try:
              spark.sql(f"use {DBnm}")
              df = spark.sql(line)
              df.write.format("csv").mode("append").save(tgt_path)
          except:
              error_sql = error_sql + line + "\n"
              print('Query failed is: {}'.format(line))

    upload_s3_object(error_path_final,error_sql)
    
    logger.info("LOV Queries execution completed successfully")

    return


if __name__ == '__main__':
    main()
