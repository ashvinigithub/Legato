from awsglue.utils import getResolvedOptions
from boto_wrapper import sfs,acc_info,secretkey
from query_variables import *
import logging
import json
import sys
import os
import boto3
import base64
from datetime import date, time
from botocore.exceptions import ClientError
import psycopg2


# Parse Arguments for Glue Job
ARGS = getResolvedOptions(sys.argv, ['db_config','env'])
global db_config_path,environment
environment = ARGS['env']

db_config_path = ARGS['db_config']

print("Disp2", db_config_path)

# Define Functions
def load_log_config():
    """
    # Basic config. Replace with your own logging config if required
    :return: object for basic logging
    """
    global logger

    MSG_FORMAT = '%(asctime)s %(levelname)s %(name)s: %(message)s'
    DATETIME_FORMAT = '%Y-%m-%d %H:%M:%S'
    logging.basicConfig(format=MSG_FORMAT, datefmt=DATETIME_FORMAT)
    logger = logging.getLogger("CopytoACIISST")

    logger.setLevel(logging.INFO)


def get_secret(secret_name):
    """
    Function to fetch details from AWS Secrets Manager
    Usage   : Get Secret JSON String
    Args    : Secret Name
    Returns : Secure string of Secret
    Raises  : Exception While getting the Secret.

    """
    secret = ''
    secret_client = boto3.client("secretsmanager")

    try:
        get_secret_value_response = secret_client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as error:
        if error.response['Error']['Code'] == 'DecryptionFailureException':
            raise error
        elif error.response['Error']['Code'] == 'InternalServiceErrorException':
            raise error
        elif error.response['Error']['Code'] == 'InvalidParameterException':
            raise error
        elif error.response['Error']['Code'] == 'InvalidRequestException':
            raise error
        elif error.response['Error']['Code'] == 'ResourceNotFoundException':
            raise error
    else:
        if 'SecretString' in get_secret_value_response:
            secret = get_secret_value_response['SecretString']
            return secret
        else:
            decoded_binary_secret = base64.b64decode(
                get_secret_value_response['SecretBinary'])
            return decoded_binary_secret


def rds_conn(host_name, secret_name, port_no, schema_name):
    """
    Function to use Secrets Manager to create an RDS Connection Object
    :param host_name: Host name of the RDS
    :param secret_name: secret name for fetching user password
    :param port_no: Port Number of RDS
    :param schema_name: Schema Name in RDS
    :return: RDS Connection Object
    """
    try:
        secure_string   = get_secret(secret_name)
        secure_dict     = json.loads(secure_string)
        postgre_username  = secure_dict.get('username')
        postgre_password  = secure_dict.get('password')
        engine = psycopg2.connect(
            database=schema_name,
            user=postgre_username,
            password=postgre_password,
            host=host_name,
            port=port_no
        )
    except Exception as err:
        logger.critical("ERROR: Unexpected error: Could not connect to Aurora instance.")
        logger.critical('*** ERROR: %s ***', err)
        raise err

    return engine


def  copy(conn,cursor):
    """
    Function to execute the sql

    """
	
	
    # DELETE
    cursor.execute(""" Delete FROM {database}.ACIISST_ACCT_RPTG_PKG """.format(database=databaseName,preval_database=preval_databaseName))
	
	# DELETE
    cursor.execute(""" Delete FROM {database}.cii_lnd_cbsa_fltr """.format(database=databaseName,preval_database=preval_databaseName))
	
	# DELETE
    cursor.execute(""" Delete FROM {database}.aciisst_acct_cvrg """.format(database=databaseName,preval_database=preval_databaseName))	

	# DELETE
    cursor.execute(""" Delete FROM {database}.aciisst_acct_exmpt """.format(database=databaseName,preval_database=preval_databaseName))	

	# DELETE
    cursor.execute(""" Delete FROM {database}.aciisst_ddim_sgmntn """.format(database=databaseName,preval_database=preval_databaseName))	

	# DELETE
    cursor.execute(""" Delete FROM {database}.aciisst_mstr_sgmntn """.format(database=databaseName,preval_database=preval_databaseName))

	# DELETE
    cursor.execute(""" Delete FROM {database}.aciisst_bnchmrk_list """.format(database=databaseName,preval_database=preval_databaseName))

	# DELETE
    cursor.execute(""" Delete FROM {database}.clnt """.format(database=databaseName,preval_database=preval_databaseName))	

	# DELETE
    cursor.execute(""" Delete FROM {database}.aciisst_clnt_assn_prfl """.format(database=databaseName,preval_database=preval_databaseName))	

	# DELETE
    cursor.execute(""" Delete FROM {database}.aciisst_grp_prfl """.format(database=databaseName,preval_database=preval_databaseName))	

	# DELETE
    cursor.execute(""" Delete FROM {database}.aciisst_subgrp_rlup """.format(database=databaseName,preval_database=preval_databaseName))	

	# DELETE
    cursor.execute(""" Delete FROM {database}.aciisst_acct_prfl_addnl_data """.format(database=databaseName,preval_database=preval_databaseName))

	# DELETE
    cursor.execute(""" Delete FROM {database}.aciisst_data_avlblty_hist """.format(database=databaseName,preval_database=preval_databaseName))	

	# DELETE
    cursor.execute(""" Delete FROM {database}.aciisst_acct_prfl """.format(database=databaseName,preval_database=preval_databaseName))	
	
	# DELETE
    cursor.execute(""" Delete FROM {database}.aciisst_sgmntn_brdg_scd """.format(database=databaseName,preval_database=preval_databaseName))
	
	# INSERT
    cursor.execute("""INSERT INTO {database}.aciisst_sgmntn_brdg_scd SELECT  * FROM {preval_database}.aciisst_sgmntn_brdg_scd """.format(database=databaseName,preval_database=preval_databaseName))
	
	# INSERT
    cursor.execute("""INSERT INTO {database}.cii_lnd_cbsa_fltr SELECT  * FROM {preval_database}.cii_lnd_cbsa_fltr """.format(database=databaseName,preval_database=preval_databaseName))

	# INSERT
    cursor.execute("""INSERT INTO {database}.aciisst_acct_cvrg SELECT  * FROM {preval_database}.aciisst_acct_cvrg """.format(database=databaseName,preval_database=preval_databaseName))
	
	# INSERT
    cursor.execute("""INSERT INTO {database}.aciisst_acct_exmpt SELECT  * FROM {preval_database}.aciisst_acct_exmpt """.format(database=databaseName,preval_database=preval_databaseName))

	# INSERT
    cursor.execute("""INSERT INTO {database}.aciisst_ddim_sgmntn SELECT  * FROM {preval_database}.aciisst_ddim_sgmntn """.format(database=databaseName,preval_database=preval_databaseName))
	
	# INSERT
    cursor.execute("""INSERT INTO {database}.aciisst_mstr_sgmntn SELECT  * FROM {preval_database}.aciisst_mstr_sgmntn """.format(database=databaseName,preval_database=preval_databaseName))
	
	# INSERT
    cursor.execute("""INSERT INTO {database}.aciisst_bnchmrk_list SELECT  * FROM {preval_database}.aciisst_bnchmrk_list """.format(database=databaseName,preval_database=preval_databaseName))
	
	# INSERT
    cursor.execute("""INSERT INTO {database}.clnt SELECT  * FROM {preval_database}.clnt """.format(database=databaseName,preval_database=preval_databaseName))
	
	# INSERT
    cursor.execute("""INSERT INTO {database}.aciisst_clnt_assn_prfl SELECT  * FROM {preval_database}.aciisst_clnt_assn_prfl """.format(database=databaseName,preval_database=preval_databaseName))
	
	# INSERT
    cursor.execute("""INSERT INTO {database}.aciisst_grp_prfl SELECT  * FROM {preval_database}.aciisst_grp_prfl """.format(database=databaseName,preval_database=preval_databaseName))

	# INSERT
    cursor.execute("""INSERT INTO {database}.aciisst_subgrp_rlup SELECT  * FROM {preval_database}.aciisst_subgrp_rlup """.format(database=databaseName,preval_database=preval_databaseName))
	
	# INSERT
    cursor.execute("""INSERT INTO {database}.aciisst_acct_prfl_addnl_data SELECT  * FROM {preval_database}.aciisst_acct_prfl_addnl_data """.format(database=databaseName,preval_database=preval_databaseName))
	
	# INSERT
    cursor.execute("""INSERT INTO {database}.aciisst_data_avlblty_hist SELECT  * FROM {preval_database}.aciisst_data_avlblty_hist """.format(database=databaseName,preval_database=preval_databaseName))
	
	# INSERT
    cursor.execute("""INSERT INTO {database}.aciisst_acct_prfl SELECT  * FROM {preval_database}.aciisst_acct_prfl """.format(database=databaseName,preval_database=preval_databaseName))	
	
    # INSERT
    cursor.execute("""INSERT INTO {database}.ACIISST_ACCT_RPTG_PKG SELECT  * FROM {preval_database}.ACIISST_ACCT_RPTG_PKG """.format(database=databaseName,preval_database=preval_databaseName))
    logger.info("Completed INSERT")
    conn.commit()

    return

def _read_s3_object(s3_path):
    """
    Function to read object from s3 path
    :param s3_path: S3 object full path
    :return: object
    """
    s3 = boto3.resource('s3')
    bucket = s3_path.split("//")[1].split("/")[0]
    key = "/".join(s3_path.replace("//", "").split("/")[1:])
    
    logger.info("Reading S3 obj {}".format(s3_path))
    obj = s3.Object(bucket, key)
    
    return obj
    
    
def main():
    """
    Main Processing Function
    :param mnthly_ind: Argument.
    :param db_config_path: Configuration file s3 path for database RDS variables
    """
    # Logger Information for the Script

    load_log_config()

    # Defining global Variables
    global databaseName, preval_databaseName , DBname


    # Reads the configuration File from S3
    json_obj = _read_s3_object(db_config_path)
    config = json.loads(json_obj.get()['Body'].read().decode('utf-8'))
    logger.info(f"Config Details - {config}")
	
    # Getting RDS connection Details from configuration file
    databaseName = config['database_details']['database']
    schema_name = config['database_details']['schema']
    host = config['database_details']['host']
    port = config['database_details']['port']
    secret_name = config['database_details']['secret_name']
    preval_databaseName = config['database_details']['preval_database']
    # user = config['database_details']['user']
    # passwd = config['database_details']['passwd']

    # Creates RDS Connection Object and Cursor
    conn = rds_conn(host, secret_name, port, schema_name)
    cursor = conn.cursor()
    logger.info("Connection to RDS has been established, Cursor is created.")
    
    
    if environment == 'prod':
        DBname = databaseName
    elif environment == 'preval':
        DBname = preval_databaseName
    elif environment in ('dev','sit','uat'):
        DBname = databaseName
    else:
        raise ValueError("Invalid parameters has been passed for environment key , Possible parameters are  'prod','preval','dev','sit','uat' ")
        
    
    logger.info(f"Environment is {environment}   and  Database  {DBname} is selected ")
    # Calling function
    copy(conn,cursor)
    logger.info("Completed ddl function")


    logger.info("Committing all the changes made and closing the RDS Connection")
    conn.commit()
    conn.close()


    return


if __name__ == '__main__':
    main()
