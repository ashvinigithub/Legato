import logging
import json
import boto3
import sys
import base64
import os
import re
from ReduceReuseRecycle import load_log_config, InvalidStatus
from botocore.exceptions import ClientError
#from boto_wrapper import *
import pymysql
from datetime import *


LOGGER = load_log_config(glue=True)

# Define the client to interact with AWS Lambda
glue = boto3.client('glue')
client = boto3.client('s3')
sns = boto3.client('sns')

# Define Functions

class acc_info:
    sts_function_client=boto3.client('sts')
    def __init__(self):
        acc_details=acc_info.sts_function_client.get_caller_identity()
        self.account=acc_details['Account']
    @property
    def get_account(self):
        return self.account


def creating_tables(s3_target_bucket, s3_target_key, schema_name, env, account):
    """
    :param s3_target_bucket: S3 Bucket where the delete will be performed
    :param s3_target_key: S3 Key of data to be copied
    :env: environment the job running
    :region_name: region name
    :account: Account number
    """
    bucket_name = s3_target_bucket
    key_name = s3_target_key
    key_path = key_name + '/'
    count_of_slash_in_key_path = key_path.count("/")
    region = os.environ['AWS_DEFAULT_REGION']

    s3_path_to_crawl = ""
    s3_path_to_crawl_copy = ""
    crawled_table_list = []

    kwargs = {'Bucket': bucket_name, 'Prefix': key_name}
    while True:
        result = client.list_objects_v2(**kwargs)
        for key in result[ "Contents" ]:
            keyString = key[ "Key" ]
            s3_path_to_crawl = keyString[:keyString.rfind('/')]
            count_of_slash_in_key = s3_path_to_crawl.count("/")
            if (s3_path_to_crawl == s3_path_to_crawl_copy or key_name not in s3_path_to_crawl or "temp" in s3_path_to_crawl or "$" in s3_path_to_crawl or "flag" in s3_path_to_crawl or count_of_slash_in_key < count_of_slash_in_key_path or count_of_slash_in_key > count_of_slash_in_key_path):
              continue
            else:
              s3_path_to_crawl_copy = s3_path_to_crawl
              if re.search(r'\b' + key_name + r'\b', s3_path_to_crawl_copy):
                 LOGGER.info(f'\nPath which crawler to crawl : {s3_path_to_crawl_copy}\n')
                 table_name = s3_path_to_crawl_copy[s3_path_to_crawl_copy.rfind("/")+1:]
                 LOGGER.info(f'\nTable Name : {table_name}\n')
                 response = glue.start_job_run(
                 JobName = 'ANTM-EDL-' + env + '-Gj-CreateRunCrawler',
                 Arguments = {
                 '--s3_cnsmptn_bkt':   bucket_name,
                 '--s3_cnsmptn_key':  s3_path_to_crawl_copy,
                 '--trgt_tbl_nm':  table_name,
                 '--trgt_schma':  schema_name,
                 '--env':  env,
                 '--region_name':  region,
                 '--account': account,
                 '--unld_partn_key': 'na' } )
                 
                 jobrunid = response['JobRunId']
                 crawled_table_list.append(table_name)
                 LOGGER.info(f'\nJob Run ID for Table: {table_name} Crawler Job: {jobrunid} \n')

        try:
            kwargs['ContinuationToken'] = result['NextContinuationToken']
        except KeyError:
            break
    
    sns_arn = 'arn:aws:sns:' \
              + region + ':' \
              + account + ':{env}-snsCIIPublication'.format(env=env)
    subject = f'Succeeded: CII Creating Athena Database - {schema_name}'
    LOGGER.info('SNS ARN: %s', sns_arn)
    try:
        formatted_msg = f'Tables Created for S3 Location: {bucket_name}/{key_name} \nTables Created: {crawled_table_list}'
        response = sns.publish(TargetArn=sns_arn,
                              Message=formatted_msg,
                              Subject=subject,
                              MessageStructure='string'
                              )
                               
        LOGGER.info('SNS Response: %s', response)
    except ClientError as sns_error:
        LOGGER.critical('*** SNS Message Publication Failed: %s ***', sns_error)
        raise sns_error

def lambda_handler(event, context):
   
    env = event['env'].strip()
    account = acc_info().get_account

    if(env == 'dev'):
        schema_prefix='d01_'    		 
    elif(env == 'sit'):
        schema_prefix='t01_'
    elif(env == 'preprod'):
        schema_prefix='r01_'
    elif(env == 'prod'):
        schema_prefix='p01_'
    else:
        schema_prefix='u01_'
        env='sit'


    #Input Parameters
    s3_target_bucket = event['s3_target_bucket'].strip()
    s3_target_key = event['s3_target_key'].strip()
    schema_name = event['schema_name'].strip()    

    LOGGER.info(f'\n**** Argument List ****\n-----------------------')
    LOGGER.info(f'\env : {env} \ns3_target_bucket : {s3_target_bucket} \ns3_target_key : {s3_target_key} \nschema_name : {schema_prefix}{schema_name} ')
    LOGGER.info(f'\n-----------------------\n')    

    #Calling the function to create tables
    LOGGER.info(f'\nCalling the creating_tables function \n')
    creating_tables(s3_target_bucket, s3_target_key, schema_prefix + schema_name, env, account)