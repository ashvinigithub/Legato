import json
import boto3
import os
import time

ROOT_PATH=os.environ['LAMBDA_TASK_ROOT']

client_ath=boto3.client('athena')
s3=boto3.client("s3")

def create_database(event):
	
	try:
		
		db_name = event['databasename']
		bucket_name = event['bucket']
		query = f"CREATE DATABASE IF NOT EXISTS {db_name};"
		response = client_ath.start_query_execution(
			QueryString=query,
			ResultConfiguration={
				'OutputLocation': f"s3://{bucket_name}/ddl/athenaoutput/"
			}
			)
		query_id = response['QueryExecutionId']
		resp = client_ath.get_query_execution(
			QueryExecutionId=query_id
		)
		status = resp['QueryExecution']['Status']['State']
				
	except Exception as e:
		print(e)
		print("error")

        
def lambda_handler(event,context):
	
	try:
		bucket_name = event['bucket']
		path = event['s3path']
		ddl_list = event['file_list']
		database= event['databasename']
		
		create_database(event)
		
		print("hql files: ",ddl_list)
		for ddl in ddl_list:
			string = ""
			key = f"{path}/{ddl}"
			json_obj=s3.get_object(Bucket=bucket_name, Key=key)
			
			# json_obj = _read_s3_object(s3_path)
			read_file_cont = json_obj['Body'].read().decode("utf-8")
			string=string+read_file_cont
			semi_colon_cnt=string.count(";")
			query=""
			number = str(semi_colon_cnt)
			print("Number of Queries in HQL File: " + number)
			success_cnt = 0
			fail_cnt = 0
			for i in range(0,semi_colon_cnt):
				query=""
				query=string.split(";")[i]
				print("Query to be excuted: ",query)
				try:
					response = client_ath.start_query_execution(QueryString=query,
						QueryExecutionContext={
							'Database': database
						},
						ResultConfiguration={
							'OutputLocation': f"s3://{bucket_name}/ddl/athenaoutput/"
						}
						)
					query_id = response['QueryExecutionId']
					resp = client_ath.get_query_execution(
						QueryExecutionId=query_id
					)
					status = resp['QueryExecution']['Status']['State']
					success_cnt = success_cnt + 1
					
				except Exception as e:
					print("ERROR :")
					print(e)
					print("Failed Query :")
					print(query)
					fail_cnt = fail_cnt + 1
					
			
			print("Number of Queries Succeeded : " + str(success_cnt))
			print("Number of Queries Failed : " + str(fail_cnt))
			
		return "DDL Execution Completed"
			
	except Exception as e:
		print(e)
		raise e
				
