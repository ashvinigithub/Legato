import logging
import json
import boto3
import base64
from botocore.exceptions import ClientError
from boto_wrapper import *
import pymysql
from config_variables import *
from datetime import *

# Define Functions
def load_log_config():
    """
    # Basic config. Replace with your own logging config if required
    :return: object for basic logging
    """
    global logger
    
    MSG_FORMAT = '%(asctime)s %(levelname)s %(name)s: %(message)s'
    DATETIME_FORMAT = '%Y-%m-%d %H:%M:%S'
    logging.basicConfig(format=MSG_FORMAT, datefmt=DATETIME_FORMAT)
    logger = logging.getLogger("Trigger_Smry_sfltr")

    logger.setLevel(logging.INFO)


def get_secret(secret_name):
    """
    Function to fetch details from AWS Secrets Manager
    Usage   : Get Secret JSON String
    Args    : Secret Name
    Returns : Secure string of Secret
    Raises  : Exception While getting the Secret.
    
    """
    secret = ''
    secret_client = boto3.client("secretsmanager")

    try:
        get_secret_value_response = secret_client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as error:
        if error.response['Error']['Code'] == 'DecryptionFailureException':
            raise error
        elif error.response['Error']['Code'] == 'InternalServiceErrorException':
            raise error
        elif error.response['Error']['Code'] == 'InvalidParameterException':
            raise error
        elif error.response['Error']['Code'] == 'InvalidRequestException':
            raise error
        elif error.response['Error']['Code'] == 'ResourceNotFoundException':
            raise error
    else:
        if 'SecretString' in get_secret_value_response:
            secret = get_secret_value_response['SecretString']
            return secret
        else:
            decoded_binary_secret = base64.b64decode(
                get_secret_value_response['SecretBinary'])
            return decoded_binary_secret


def rds_conn(host_name, secret_name, port_no, schema_name):
    """
    Function to use Secrets Manager to create an RDS Connection Object
    :param host_name: Host name of the RDS
    :param secret_name: secret name for fetching user password
    :param port_no: Port Number of RDS
    :param schema_name: Schema Name in RDS
    :return: RDS Connection Object
    """
    try:
        secure_string   = get_secret(secret_name)
        secure_dict     = json.loads(secure_string)
        mysql_username  = secure_dict.get('username')
        mysql_password  = secure_dict.get('password')
        engine = pymysql.connect(host_name, user=mysql_username, passwd=mysql_password, db=schema_name, connect_timeout=10)
        
    except Exception as err:
        logger.critical("ERROR: Unexpected error: Could not connect to Aurora instance.")
        logger.critical('*** ERROR: %s ***', err)
        raise err
        
    return engine
    
    
def trigger_summary_process():
    """
    Function to trigger the monthly load of S3-RDS, Db2-RDS, RDS-Snowflake and Summary 
    once all the discover loads are completed
    :return: None
    """
    
    # Read the EMR Json Template for below Values.
    emr_conf_obj = _read_s3_object(emr_job_template.format(env=env))
    emr_config = json.loads(emr_conf_obj.get()['Body'].read().decode('utf-8'))

    # Creating a input payload to trigger Summary process
    params = json.dumps({
            "etl_stp_parms": {
                "rdstablelist": rdstablelist.format(env=env),
                "emrjobtemplate": emr_job_template.format(env=env),         
                "clusternm": "DB2-RDS-Cluster",
                "jobargs": [
                    emr_config['jobargs']
                ],
                "createcluster": emr_config['createcluster'],
                "application": emr_config['application'],
                "clusterid": emr_config['clusterid'],
                "configfile": db2_rds_cluster_config.format(env=env),
                "maxconcurrency": emr_config['maxconcurrency'],
                "emrenv": env,
                "bootstrapbucket": emr_config['bootstrapbucket'],
                "bootstrapkey": emr_config['bootstrapkey'],
                "terminationwaittime": emr_config['terminationwaittime'],
                "logpath": emr_config['logpath'].format(env=env),
                "terminateoption": emr_config['terminateoption'],
                "re-runstep": "na",
                "smry_dscvr_tables_list": smry_dscvr_tables_list.format(env=env)
            }
        })        
    
    # Invocation of Step function
    from random import choice 
    from string import ascii_lowercase
       
    exec_id = "".join([choice(ascii_lowercase) for x in range(5)])
    run_name = "ANTM-CII-DB2-RDS-SNF-MNTHLY-LOAD-{date_time}-{Id}".format(date_time=datetime.now().strftime('%Y%m%d'),Id=exec_id)
    
    # Invoke Orchestrator Sfn
    call_step_function= 'ANTM-CII-{env}-Sfn-{step_function_arname}'.format(env=env, step_function_arname=smry_step_function_name)
    sfs(env,acc_info().get_region,acc_info().get_account,params,call_step_function,run_name).sfn_execution
    
    return


def trigger_sftlr_mnthly_process():
    """
    Function to trigger the saved filters monthly load once after all the summary loads are completed
    :return: None
    """
    from random import choice 
    from string import ascii_lowercase
    
    params = json.dumps({
            'etl_stp_parms': {
                'mnthlyind': 'M',
                'dbconfigpath': db_config_path.format(env=env),
                'reruntables': 'NA',
                'rerun_emr_config_path': 'NA',
                'sfltrtableslist': sfltr_tables_list.format(env=env),
                'emrjobtemplate': emr_job_template.format(env=env),
                'run_aciisstsgmntnbrdgdmlmonthly_gluejob': 'NO',
                'UnloadSummarySavedFilterTables_flag': 'YES'
            }
        })
    
    exec_id = "".join([choice(ascii_lowercase) for x in range(5)])
    run_name = "ANTM-CII-SFLTR-MNTHLY-LOAD-{date_time}-{Id}".format(date_time=datetime.now().strftime('%Y%m%d'),Id=exec_id)
    
    # Invoke Orchestrator Sfn
    call_step_function= 'ANTM-CII-{env}-Sfn-{step_function_arname}'.format(env=env, step_function_arname=sfltr_step_function_name)
    sfs(env,acc_info().get_region,acc_info().get_account,params,call_step_function,run_name).sfn_execution
    
    
    return


def retrieve_job_status(job_id_list, db_name, audt_tbl):
    """
    Function to format retrieval query which checks whether the dependency jobs are completed are not from EDL Audit Table
    :param job_id_list: list of job id's
    :param db_name: database name of the edl audit table
    :param audt_tbl: table name
    :return: query to fetch the status of all the distinct job id's which are succeeded for current month year
    """
    
    job_id_string = ",".join(job_id_list)
    
    query = """
    SELECT COUNT(DISTINCT job_id) FROM {db_name}.{table} 
    WHERE job_stts = 'SUCCEEDED'
    AND job_id in ({job_id})
    AND DATE(edl_load_dtm) >= '{start_date}'
    AND DATE(edl_load_dtm) <= '{current_date}'
    """.format(
        db_name=db_name,
        table=audt_tbl,
        job_id=job_id_string,
        start_date=datetime.strftime(datetime.now() - timedelta(1), '%Y-%m-%d'),
        current_date=datetime.now().strftime('%Y-%m-%d')
        )
    
    print(query)
    return query


def _read_s3_object(s3_path):
    """
    Function to read object from s3 path
    :param s3_path: S3 object full path
    :return: object with file content
    """
    s3 = boto3.resource('s3')
    bucket = s3_path.split("//")[1].split("/")[0]
    key = "/".join(s3_path.replace("//", "").split("/")[1:])
    
    logger.info("Reading S3 obj {}".format(s3_path))
    obj = s3.Object(bucket, key)
    
    return obj


def lambda_handler(event, context):
    """
    Main Processing Function
    :param event: Event variables for function
    :param context: Lambda execution context variables
    :return: None
    """
    print(event)
    load_log_config()
    
    global env
    env = context.function_name.split("-")[2]
    
    message = event['Records'][0]['Sns']['Message']
    event_message = json.loads(message)

    # EDL Job Audit Table
    rds_table = 'edl_job_audt'
    
    # Reads the configuration File from S3
    json_obj = _read_s3_object(edl_config_path.format(env=env))
    config = json.loads(json_obj.get()['Body'].read().decode('utf-8'))

    # Getting RDS connection Details from configuration file
    databaseName = config['database_details']['database']
    schema_name = config['database_details']['schema']
    host = config['database_details']['host']
    port = config['database_details']['port']
    secret_name = config['database_details']['secret_name']
    # user = config['database_details']['user']
    # passwd = config['database_details']['passwd']

    # Creates RDS Connection Object and Cursor
    conn = rds_conn(host, secret_name, port, schema_name)
    cursor = conn.cursor()
    logger.info("Connection to RDS has been established, Cursor is created.")
    
    
    # Get the Tables list for job id's
    json_obj = _read_s3_object(smry_dscvr_tables_list.format(env=env))
    config = json.loads(json_obj.get()['Body'].read().decode('utf-8'))
    
    
    # Checks the Status of all Summary or Discover Loads based on the input event.
    if(event_message['job_type'].lower() == 'glue'):
        query = retrieve_job_status(config['discover'].values(), databaseName, rds_table)
        
        logger.info("Executing Query {}".format(query))
        cursor.execute(query)
        res = cursor.fetchone()[0]
        
        logger.info("*** No of Dashboard Tables loaded: {} ***".format(res))
        logger.info("*** Total No of Dashboard Tables Needed for Downstream Process: {} ***".format(
            len(config['discover'].values())))
        if(res == len(config['discover'].values())):
            print("Summary trigger")
            trigger_summary_process()
        else:
            logger.info("*** Discover Load needs to be completed for Triggering Downstream Process ***")
            
    elif(event_message['job_type'].lower() == 'sfn'):
        query = retrieve_job_status(config['summary'].values(), databaseName, rds_table)
        
        logger.info("Executing Query {}".format(query))
        cursor.execute(query)
        res = cursor.fetchone()[0]
        
        logger.info("*** No of Summary Tables loaded: {} ***".format(res))
        logger.info("*** Total No of Summary Tables Needed for Downstream Process: {} ***".format(
            len(config['summary'].values())))
        if(res == len(config['summary'].values())):
            print("Sfltr trigger")
            trigger_sftlr_mnthly_process()
        else:
            logger.info("*** Summary Load Needs to be Completed for Triggering Save Filters Monthly Process ***")
    else:
        logger.exception("Invalid Job Type")
        raise Exception("Invalid Job Type")
    
    # Commits all the Changes done and closes the connection.
    conn.close()
    
    return 