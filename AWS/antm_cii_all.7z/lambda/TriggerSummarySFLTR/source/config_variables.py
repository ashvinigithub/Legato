# Config Variables 

edl_config_path = "s3://antm-cii-{env}-codez-nogbd-nophi-useast1/cii_config/cii_sf_edl_dbconfig_{env}.json"
db_config_path = "s3://antm-cii-{env}-codez-nogbd-nophi-useast1/cii_config/cii_sf_sfltr_dbconfig_{env}.json"
smry_dscvr_tables_list = "s3://antm-cii-{env}-codez-nogbd-nophi-useast1/cii_config/cii_sf_smry_dst_job_id.json"
sfltr_tables_list = "s3://antm-cii-{env}-codez-nogbd-nophi-useast1/cii_config/cii_sf_sfltr_tables_{env}.csv"
emr_job_template = "s3://antm-cii-{env}-codez-nogbd-nophi-useast1/cii_config/cii_sf_emr_template.json"
rdstablelist = "s3://antm-cii-{env}-codez-nogbd-nophi-useast1/cii_config/cii_sf_db2_s3_rds_snf_tables_{env}.csv"
sfltr_step_function_name= "SF-Save-Filter-Process"
smry_step_function_name = "SF-Trigger-Db2-Rds-Smry-Process"
db2_rds_cluster_config = "s3://antm-cii-{env}-codez-nogbd-nophi-useast1/emr_config/CII_SF_STANDARD_AA_2X_3N.json"