import logging
import json
import boto3
import base64
import os
from botocore.exceptions import ClientError
from ReduceReuseRecycle import *
from datetime import *
from uuid import uuid1

class acc_info:
    sts_function_client=boto3.client('sts')
    def __init__(self):
        acc_details=acc_info.sts_function_client.get_caller_identity()
        self.account=acc_details['Account']
        self.region=os.environ['AWS_REGION']
        self.function_name=acc_details['Arn']
    @property
    def get_account(self):
        return self.account
    @property
    def get_region(self):
        return self.region
    @property
    def get_handler_name(self):
        return self.function_name.split("/")[-1]    

def lambda_handler(event, context):
    """
    Main Processing Function
    """
    # Create a Logger
    logger = load_log_config()
    
    data = {}
    data["etl_stp_parms"] = {}
    env = context.function_name.split("-")[2]
    aplctn_cd = context.function_name.split("-")[1]
    data["etl_stp_parms"]["env"] = env
    data["etl_stp_parms"]["aplctn_cd"] = context.function_name.split("-")[1]
    pkg_id = event['pkg_id']
    rpt_run_id = pkg_id
    data["etl_stp_parms"]["rpt_run_id"] =  str(pkg_id)
    data["etl_stp_parms"]["db_config_path"] = "s3://antm-cii-{env}-codez-nogbd-nophi-useast1/cii_config/cii_sf_sfltr_dbconfig_{env}.json".format(env=env)
    data["etl_stp_parms"]["l2_config_file"] = "s3://antm-cii-{env}-codez-nogbd-nophi-useast1/cii_config/cii_standard_insights_l2_config_file.config".format(env=env)
    data["etl_stp_parms"]["l2_sqls_path"] = "s3://antm-cii-{env}-codez-nogbd-nophi-useast1/cii/snowflake-etl/static-rpt".format(env=env)
    data["etl_stp_parms"]["aciisst_adhoc_schema_name"] = "ACIISST_ADHOC_ALLPHI"
    data["etl_stp_parms"]["aciisst_schema_name"] = "ACIISST_ALLPHI"
    data["etl_stp_parms"]["evolve_schema_name"] = "CII_EVOLVE_ALLPHI"
    data["etl_stp_parms"]["manual_run"] = "NO"
    
    #Getting region_name, account and account_name
    region_name = get_region_name()
    account = get_account()
    account_name = get_account_name()
              
    logger.info(f'*** Input parameters and Environment, Application and other variables- {event}, {env}, {aplctn_cd}*****')
    #---------------------------------------------------------------------------------#
    #Boto3 Clients for Step Function                                                  #
    #---------------------------------------------------------------------------------#
    sfn = boto3.client('stepfunctions')

    try:
        load_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        load_time = load_time.replace('-', '').replace(' ', '-').replace(':', '')
        execution_name = f"{aplctn_cd}-StandardInsights-L2-{rpt_run_id}-RunDt-{load_time}"[:100]
        # Create Step Function Execution with ARN, Custom Name and Config JSON
        sfn_arn = 'arn:aws:states:' + region_name + ':' + account + ':stateMachine:ANTM-' + aplctn_cd.upper() + '-' + env + '-Sfn-SF-Aciisst-StandardInsightsL2Process'
        logger.info('*** Call Step Function : %s ***', sfn_arn)
        sfn_json = json.dumps(data)
        logger.info('*** Call Step Function with input: %s ***', sfn_json)
        response = sfn.start_execution(stateMachineArn=sfn_arn,
                                       name=execution_name,
                                       input=sfn_json)
        logger.info(f'*** Step Function Response ARN: {response.get("executionArn")}')
        logger.info(f"*** Step Function Execution Name: {execution_name}")
            

    except ClientError as sfn_exception:
        logger.critical('*** SFN Exception occured: %s', sfn_exception)
        logger.critical('*** Failed to create SFN ***')