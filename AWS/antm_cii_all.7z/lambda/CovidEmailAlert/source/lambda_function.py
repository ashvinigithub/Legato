import json
import boto3
import pandas as pd
import time
import smtplib
from pathlib import Path
from email.mime.multipart import MIMEMultipart
from email.contentmanager import ContentManager
from email.message import EmailMessage
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from email.mime.application import MIMEApplication
import os
from datetime import datetime
import csv
import pathlib
import logging
import botocore
from pytz import timezone

def load_log_config():
    """
    # Basic config. Replace with your own logging config if required
    :return: object for basic logging
    """
    global logger

    MSG_FORMAT = '%(asctime)s %(levelname)s %(name)s: %(message)s'
    DATETIME_FORMAT = '%Y-%m-%d %H:%M:%S'
    logging.basicConfig(format=MSG_FORMAT, datefmt=DATETIME_FORMAT)
    logger = logging.getLogger("Email alerts")

    logger.setLevel(logging.INFO)

def _download_s3_object(bucketname,file_path_name):
    """
    Function to read s3 object and download the content into local file
    :param local_path :String: Path for downloading s3 content in Local file path
    :param s3_file_path :String: Path to read the s3 file.
    :return :boto3 Object: boto3 object with S3 file Content downloaded on local file path
    """
    s3_object = boto3.client('s3')
    s3_data = s3_object.get_object(Bucket=bucketname, Key=file_path_name)
    body = s3_data['Body'].read()
    return body

def _send_mail(sender,reciever,email_subject,email_body,athena_filename,report_bucket_final,report_folder,report_file_extnsn,status):
    """
    Function to generate and send an email based on message_type
    :param sender :String: Sender Address of the email
    :param receiver :String: Comma seperated string of Reciever Address
    :param message_type :String: Type of email generation. This is Specific for PCMS use case
    :param attachement :Boolean: If attachement required value should be True else False.
    :param filepaths :List: If attachement required, we need to provide the s3 paths of the files in List
    :return :String: Appropriate message
    """
    message = MIMEMultipart()
    env_upper = env.upper()
    message["Subject"] = email_subject
    message["From"] = sender
    message["To"] = reciever
    html = MIMEText(email_body,"plain")
    message.attach(html)
    
    if status == 'failed':
        filepath = report_folder+athena_filename+report_file_extnsn
        bodyattach = _download_s3_object(report_bucket_final,filepath)
        att = MIMEApplication(bodyattach, 'covid_email_alert.csv')
        att.add_header('Content-Disposition','attachment',filename='covid_email_alert.csv')
        message.attach(att)
    else :
        print("not needed an attachment for load delay")
    
    smtpObj = smtplib.SMTP('smtpinternal.wellpoint.com')
    smtpObj.sendmail(sender,reciever,message.as_string())

def _run_athena_query(query,database):
    """
    Function to run query in athena and return the output and s3 output location
    :param query :Query to be run in athena
    :param database :String: Database against which query will be ran
    :return String, String: query output and s3 query output location
    """
    client = boto3.client('athena')
    queryStart = client.start_query_execution(
        QueryString=query,
        QueryExecutionContext={
            'Database': database
        },
        ResultConfiguration={
            'OutputLocation': 's3://antm-cii-'+env+'-cnfz-nogbd-phi-useast1/cii/aicovid_cons/email/'
        }
    )
    
    time.sleep(10)
    result1 = client.get_query_execution(QueryExecutionId=queryStart['QueryExecutionId'])
    result = client.get_query_results(QueryExecutionId=queryStart['QueryExecutionId'])
    output_location = result1['QueryExecution']['QueryExecutionId']
    res = result['ResultSet']['Rows'][1]['Data'][0]
    res2 = res['VarCharValue']
    return res2,output_location
    
def _get_env(env):
    """
    Function to get database prefix as per environment
    :param env :Environment where lambda is running
    :return db :String: Database prefix as per environment
    """
    if env == 'dev':
        db = 'd01'
    elif env == 'sit':
        db = 't01'
    elif env == 'uat':
        db = 'u01'
    elif env == 'preprod':
        db = 'r01'
    elif env == 'prod':
        db = 'p01'
    else:
        print("invalid environment")
    
    return db
    
def lambda_handler(event, context):
    """
    Main Processing Function
    :return: EMR job parms in a list 
    """
    global template_path, env
    # Create a Logger
    load_log_config()
    print(event)
    
    env = context.function_name.split("-")[2]
    jsonbody = event['etl_stp_parms']
    json_dict = json.loads(json.dumps(jsonbody))
    kpi_query = json_dict["kpi_query"]
    audit_query = json_dict["audit_query"]
    trends_audit_query = json_dict["trends_audit_query"]
    trends_check_query = json_dict["trends_check_query"]
    audit_failed_query = json_dict["audit_failed_query"]
    report_bucket = json_dict["report_bucket"]
    report_folder = json_dict["report_folder"]
    report_file_extnsn = json_dict["report_file_extnsn"]
    email_body_audit_fail = "Hi Business Team,\r\n\r\nAnthem Insights Central C19 load is failed due to Audit check.  We are working on resolving the issue.  \r\nPlease reach out to DL-CII-Covid-DF@anthem.com for more information. \r\n\r\n \r\nThanks,\r\nCOVID DataFoundation Team"
    email_body_load_delay = "Hi Business Team,\r\n\r\nAnthem Insights Central C19 load is delayed today and the dashboard is not refreshed. We are working on resolving the issue.  \r\nPlease reach out to DL-CII-Covid-DF@anthem.com for more information. \r\n\r\n \r\nThanks,\r\nCOVID DataFoundation Team"
    senderdl = json_dict["senderdl"]
    recieverdl = json_dict["recieverdl"]
    email_subject = env.upper() +" : "+ "Delay in Anthem Insights Load"+" - "+datetime.today().strftime('%m-%d')
    
    db = _get_env(env)
    
    discover_db = db+'_cii_discover'
    discover_stg_db = db+'_cii_discover_stg'
    
    report_bucket_final = report_bucket.replace("env",env)
    print(report_bucket_final)
    
    kpi_date_diff,kpi_output_location = _run_athena_query(kpi_query,discover_stg_db)
    trg_audit,trg_audit_output_location = _run_athena_query(audit_query,discover_db)
    trends_check,trends_check_output_location = _run_athena_query(trends_audit_query,discover_stg_db)
    print("Calling function to send email")
    
    if int(kpi_date_diff) > 0:
        if int(trg_audit) > 0:
            if int(trends_check) > 0:
                trends_check, trends_check_query_op = _run_athena_query(audit_failed_query,discover_stg_db)
                msg = _send_mail(senderdl,recieverdl,email_subject,email_body_audit_fail,trends_check_query_op,report_bucket_final,report_folder,report_file_extnsn,'failed')
            else:
               audit_failed, audit_op = _run_athena_query(audit_failed_query,discover_stg_db)
               msg = _send_mail(senderdl,recieverdl,email_subject,email_body_audit_fail,audit_op,report_bucket_final,report_folder,report_file_extnsn,'failed')
        else:
            msg = _send_mail(senderdl,recieverdl,email_subject,email_body_load_delay,'',report_bucket_final,report_folder,report_file_extnsn,'delay')
            print("hello")
    else:
        print("Load is running fine")
