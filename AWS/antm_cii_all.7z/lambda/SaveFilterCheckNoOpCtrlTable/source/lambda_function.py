import logging
import json
import boto3
import base64
from botocore.exceptions import ClientError
import psycopg2
import awswrangler as wr
import pandas as pd

# Define Functions
def load_log_config():
    """
    # Basic config. Replace with your own logging config if required
    :return: object for basic logging
    """
    global logger
    
    MSG_FORMAT = '%(asctime)s %(levelname)s %(name)s: %(message)s'
    DATETIME_FORMAT = '%Y-%m-%d %H:%M:%S'
    logging.basicConfig(format=MSG_FORMAT, datefmt=DATETIME_FORMAT)
    logger = logging.getLogger("SAVE_FLTR_No_Op_Upd")

    logger.setLevel(logging.INFO)


def get_secret(secret_name):
    """
    Function to fetch details from AWS Secrets Manager
    Usage   : Get Secret JSON String
    Args    : Secret Name
    Returns : Secure string of Secret
    Raises  : Exception While getting the Secret.
    
    """
    secret = ''
    secret_client = boto3.client("secretsmanager")

    try:
        get_secret_value_response = secret_client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as error:
        if error.response['Error']['Code'] == 'DecryptionFailureException':
            raise error
        elif error.response['Error']['Code'] == 'InternalServiceErrorException':
            raise error
        elif error.response['Error']['Code'] == 'InvalidParameterException':
            raise error
        elif error.response['Error']['Code'] == 'InvalidRequestException':
            raise error
        elif error.response['Error']['Code'] == 'ResourceNotFoundException':
            raise error
    else:
        if 'SecretString' in get_secret_value_response:
            secret = get_secret_value_response['SecretString']
            return secret
        else:
            decoded_binary_secret = base64.b64decode(
                get_secret_value_response['SecretBinary'])
            return decoded_binary_secret


def rds_conn(host_name, secret_name, port_no, schema_name):
    """
    Function to use Secrets Manager to create an RDS Connection Object
    :param host_name: Host name of the RDS
    :param secret_name: secret name for fetching user password
    :param port_no: Port Number of RDS
    :param schema_name: Schema Name in RDS
    :return: RDS Connection Object
    """
    try:
        secure_string   = get_secret(secret_name)
        secure_dict     = json.loads(secure_string)
        postgre_username  = secure_dict.get('username')
        postgre_password  = secure_dict.get('password')
        engine = psycopg2.connect(
                database=schema_name,
                user=postgre_username,
                password=postgre_password,
                host=host_name,
                port=port_no
            )
    except Exception as err:
        logger.critical("ERROR: Unexpected error: Could not connect to Aurora instance.")
        logger.critical('*** ERROR: %s ***', err)
        raise err
        
    return engine


def retrieve_tables_list(csv_args, mnthly_ind):
    """
    Function to create EMR job parms
    :param csv_args: Details of tables with run frequency and spark submit args.
    :param mnthly_ind: Monthly Indicator used for picking up the tables corresponding from the csv file.
    :return: list of all the tables present in csv_args with matching monthly indicator
    """
    tables_list = []
    columns = []

    logger.info("Retrieving tables satisfying monthly indicator")
    for row in csv_args:
        columns = row.split(",")
        run_frequency = [ind.upper() for ind in columns[1].strip().split("|")]
        
        if(mnthly_ind.upper() in run_frequency):
            tables_list.append(str(columns[0]).upper())

    return tables_list
    
    
def _read_s3_object(s3_path):
    """
    Function to read object from s3 path
    :param s3_path: S3 object full path
    :return: object with file content
    """
    
    s3 = boto3.resource('s3')
    bucket = s3_path.split("//")[1].split("/")[0]
    key = "/".join(s3_path.replace("//", "").split("/")[1:])
    
    logger.info("Reading S3 obj {}".format(s3_path))
    obj = s3.Object(bucket, key)
    
    return obj


def _updt_save_filters_dtm(conn, cursor, database_nm, tables_list):
    """
    Function to update timestamp of save filter tables in SAVE_FLTR_TBL_CNTRL
    :param conn: Connection Object to RDS
    :param cursor: Cursor object for execution of queries on RDS
    :param database_nm: Database Name
    :param tables_list: List of all the save filters tables which needs to be updated with latest date time
    :return: None
    """
    
    updt_query = "UPDATE {db_name}.SAVE_FLTR_TBL_CNTRL SET REFRESH_DTM = CURRENT_TIMESTAMP WHERE TBL_NM = '{table_name}'"
    insrt_query = "INSERT INTO {db_name}.SAVE_FLTR_TBL_CNTRL (TBL_NM, REFRESH_DTM) VALUES ('{table_name}', CURRENT_TIMESTAMP)"
    
    valdn_query = "SELECT COUNT(*) AS row_count FROM {db_name}.SAVE_FLTR_TBL_CNTRL WHERE TBL_NM = '{table_name}'"
    
    try:
        tbl_name = ""
        for tbl_name in tables_list:
            
            logger.info("Executing Query: {}".format(valdn_query.format(db_name=database_nm, table_name=tbl_name)))
            cursor.execute(valdn_query.format(db_name=database_nm, table_name=tbl_name))
            val_res = cursor.fetchone()[0]
            
            if(val_res > 0):
                logger.info("Executing Query: {}".format(updt_query.format(db_name=database_nm, table_name=tbl_name)))
                cursor.execute(updt_query.format(db_name=database_nm, table_name=tbl_name))
                conn.commit()
            else:
                logger.info("Executing Query: {}".format(insrt_query.format(db_name=database_nm, table_name=tbl_name)))
                cursor.execute(insrt_query.format(db_name=database_nm, table_name=tbl_name))
                conn.commit()
                
        # conn.commit()
    except:
        logger.exception("Failed updating Timestamp for Table: {}".format(tbl_name))
        raise Exception("Failed updating Timestamp for Table: {}".format(tbl_name))
    
    
    return

    
def lambda_handler(event, context):
    """
    Main Processing Function.
    This Function updates the refresh date time for save filters tables if there are no updates for savefilters
    :param event: Event variables for function
    :param context: Lambda execution context variables
    :return: None
    """
    load_log_config()
    
    db_config_path = str(event['Input']['data']['dbconfigpath'])
    sfltr_tables_list = str(event['Input']['data']['sfltrtableslist'])
    mnthly_ind = str(event['Input']['data']['mnthlyind'])
    UnloadSummarySavedFilterTables_flag = str(event['Input']['data']['UnloadSummarySavedFilterTables_flag'])
    
    # Reads the db configuration File from S3
    json_obj = _read_s3_object(db_config_path)
    config = json.loads(json_obj.get()['Body'].read().decode('utf-8'))

    # Getting RDS connection Details from configuration file
    databaseName = config['database_details']['database']
    schema_name = config['database_details']['schema']
    host = config['database_details']['host']
    port = config['database_details']['port']
    secret_name = config['database_details']['secret_name']
    # user = config['database_details']['user']
    # passwd = config['database_details']['passwd']
    
    # Create RDS Connection object for query execution.
    logger.info("Connecting to RDS Instance")
    conn = rds_conn(host, secret_name, port, schema_name)
    cursor = conn.cursor()
    # cursor = conn.connect()
    logger.info("Connection Established with RDS, Cursor object is created")
    
    # Retrieve the tables list from config csv file
    csv_args = []
    # csv_obj = _read_s3_object(sfltr_tables_list)
    # csv_content = csv_obj.get()['Body'].read().decode('utf-8')
    # csv_args = csv_content.split("\n")[1:]
    
    csv_df = wr.s3.read_csv([sfltr_tables_list])
    csv_args = csv_df.values.tolist()
    csv_args = [','.join(i) for i in csv_args]
    
    tables_list = retrieve_tables_list(csv_args, mnthly_ind)
    
    # Updates the Refresh date time for all the save filter tables
    _updt_save_filters_dtm(conn, cursor, databaseName, tables_list)
    logger.info("Update Process Completed.")
    
    
    # Formatting the Output to meet SNS Criteria
    tbl_list = []
    for table in tables_list:
        tbl_list.append({
            "job_stts": "SUCCEEDED",
            "tgttblnm": table,
            "mnthlyind": mnthly_ind,
            "dbconfigpath": db_config_path,
            "UnloadSummarySavedFilterTables_flag": UnloadSummarySavedFilterTables_flag
        })

    # Closes the connection.
    conn.close()
    
    return tbl_list