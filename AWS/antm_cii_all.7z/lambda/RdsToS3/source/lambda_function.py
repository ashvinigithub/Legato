######################################################################################
#                                                                                    #
#  Description           :  This function will connect to Aurora Postgres & get data #
#                           to put into S3 in Parquet format                         #
#  Environment Variables :  None                                                     #
#  Author                :  Rajdeep Das                                              #                
#  Modified By           :  Rajdeep Das                                              #
#  Creation Date         :  14th Aug-2020                                            #
#                                                                                    #
######################################################################################

################################ Import Modules ######################################

import psycopg2
import boto3
import awswrangler as wr
import pandas as pd
import traceback
import os
import base64
import json
from botocore.exceptions import ClientError

############################ Setting Env Variable ###################################

ROOT_PATH=os.environ['LAMBDA_TASK_ROOT']

############################## Initializing Clients ##################################

secret_client = boto3.client("secretsmanager")

################################## Get Secret Value ##################################

def get_secret(secret_name):

	"""
	Usage   : Get Secret JSON String
	Args    : Secret Name
	Returns : Secure string of Secret
	Raises  : Exception While getting the Secret.
	
	"""
	secret = ''
	
	try:
		get_secret_value_response = secret_client.get_secret_value(
			SecretId=secret_name
		)
	except ClientError as error:
		if error.response['Error']['Code'] == 'DecryptionFailureException':
			raise error
		elif error.response['Error']['Code'] == 'InternalServiceErrorException':
			raise error
		elif error.response['Error']['Code'] == 'InvalidParameterException':
			raise error
		elif error.response['Error']['Code'] == 'InvalidRequestException':
			raise error
		elif error.response['Error']['Code'] == 'ResourceNotFoundException':
			raise error
	else:
		if 'SecretString' in get_secret_value_response:
			secret = get_secret_value_response['SecretString']
			return secret
		else:
			decoded_binary_secret = base64.b64decode(
				get_secret_value_response['SecretBinary'])
			return decoded_binary_secret

################################# Create DB Connection ###############################

def create_conn(dbhost,secret_name):

    """
    Usage   : Creates Connection Engine
    Args    : None
    Returns : Connection Engine
    Raises  : Exception While Creating Connection.
    
    """

    secure_string   = get_secret(secret_name)
    secure_dict     = json.loads(secure_string)
    postgre_username  = secure_dict.get('username')
    postgre_password  = secure_dict.get('password')

    try:
        eng_postgresql = wr.db.get_engine(
            db_type="postgresql",
            host=dbhost,
            port=5432,
            database="cii_appl_snowui",
            user=postgre_username,
            password=postgre_password
        )
    except Exception as e:
        print(e)
        print("Cannot Connect to RDS Postgres")
        raise e
        
        
    return eng_postgresql
    
############################## Create Panda Dataframe #############################
    
def create_dataframe(table_name,connection,database):
    
    """
    Usage   : Creates Dataframe by running select query
    Args    : Connection Engine
    Returns : Dataframe
    Raises  : Exception While Creating Dataframe OR running queries.
    
    """
    try:
        
        query = f"SELECT * FROM {database}.{table_name}"
        df = wr.db.read_sql_query(query, con=connection)
        
    except Exception as e:
        print(e)
        print("Cannot Execute Queries")
        raise e
        
    return df
    
########################## Upload to S3 as Parquet File #########################
    
def upload_to_s3_as_parquet(object_key,dataframe):
    
    """
    Usage   : Uploads to S3 as Parquet file
    Args    : Dataframe
    Returns : Nothing
    Raises  : Exception While Uploading to S3.
    
    """
    try:
    
        wr.s3.to_parquet(dataframe, object_key)
        
    except Exception as e:
        print(e)
        print("Cannot Upload to S3")
        raise e

def _read_s3_object(s3_path):
    """
    Function to read object from s3 path
    :param s3_path: S3 object full path
    :return: object
    """
    s3 = boto3.resource('s3')
    bucket = s3_path.split("//")[1].split("/")[0]
    key = "/".join(s3_path.replace("//", "").split("/")[1:])
    
    obj = s3.Object(bucket, key)
    
    return obj

########################### Main Handler Function ############################## 

def lambda_handler(event,context):
    
    try:
        
        # config_path='{root}/config.json'.format(root=ROOT_PATH)
        # config_file = open(config_path,"r",encoding="utf-8")
        # file_dict = json.load(config_file)
        # config_file.close()
        
        # print(type(event))
        # print(event)
        
        # event_dict = json.loads(event)
        
        # print(type(event_dict))

        db_config_path = event['db_config_path']

        json_obj = _read_s3_object(db_config_path)
        config = json.loads(json_obj.get()['Body'].read().decode('utf-8'))

        table_list = config['tablelist']
        s3_path = config['s3path']
        database = config['database']
        host = config['host']
        secret_name = config['secretname']
        
        connection = create_conn(host,secret_name)
        
        for table in table_list:
            dataframe = create_dataframe(table,connection,database)
            print("Fetched " + table + " contents Successfully")
            object_key = f"{s3_path}/{table}/{table}.parquet"
            try:
                upload_to_s3_as_parquet(object_key,dataframe)
            except Exception as e:
                if "EmptyDataFrame" in str(e):
                    wr.s3.delete_objects(object_key)
                    continue
            
            print("Uploaded " + table + " contents to S3 path :" + object_key)
        
        
        return 'Function Executed Successfully'
        
    except Exception as e:
        
        print('Function failed due to exception.') 
        print(e)
        traceback.print_exc()
        raise e