import logging
import json
import boto3
from botocore.exceptions import ClientError
import os

# Define Functions
def load_log_config():
    """
    # Basic config. Replace with your own logging config if required
    :return: object for basic logging
    """
    global logger
    
    MSG_FORMAT = '%(asctime)s %(levelname)s %(name)s: %(message)s'
    DATETIME_FORMAT = '%Y-%m-%d %H:%M:%S'
    logging.basicConfig(format=MSG_FORMAT, datefmt=DATETIME_FORMAT)
    logger = logging.getLogger("ACIISST_SAVE_FLTR")

    logger.setLevel(logging.INFO)


def _read_s3_object(s3_path):
    """
    Function to read object from s3 path
    :param s3_path: S3 object full path
    :return: object with file content
    """
    s3 = boto3.resource('s3')
    bucket = s3_path.split("//")[1].split("/")[0]
    key = "/".join(s3_path.replace("//", "").split("/")[1:])
    
    logger.info("Reading S3 obj {}".format(s3_path))
    obj = s3.Object(bucket, key)
    
    return obj
    
    
def lambda_handler(event, context):
    """
    Main Processing Function
    :param event: Event variables for function
    :param context: Lambda execution context variables
    :return: None
    """
    print(event)
    load_log_config()
    
    
    # Gets the Table Config Path from Map Iteration of Step Function
    tbl_config_path = event['Input']['data']['configpath']
    
    # Reads the EMR job configuration File from S3
    json_obj = _read_s3_object(tbl_config_path)
    emr_args = json.loads(json_obj.get()['Body'].read().decode('utf-8'))
    
    # emr_args['jobargs']['job'] = emr_args['jobargs']['job'][0].split(" ")
    
    return emr_args