import logging
import json
import boto3
import sys
import base64
import os
from ReduceReuseRecycle import load_log_config, InvalidStatus
from botocore.exceptions import ClientError
#from boto_wrapper import *
import pymysql
from datetime import *


sns = boto3.client('sns')

# Define Functions

class acc_info:
    sts_function_client=boto3.client('sts')
    def __init__(self):
        acc_details=acc_info.sts_function_client.get_caller_identity()
        self.account=acc_details['Account']
        self.region=os.environ['AWS_REGION']
        self.function_name=acc_details['Arn']
    @property
    def get_account(self):
        return self.account
    @property
    def get_region(self):
        return self.region
    @property
    def get_handler_name(self):
        return self.function_name.split("/")[-1]


def start_state_machine(logger, env, region_name, account, aplctn_cd, sfn, sfn_json):
    """
    Function to start the Step Function state machine with JSON input
    :param logger: basic log object
    :param env: environment (dev, sit, prod)
    :param region_name: region on aws (us-east-1)
    :param account: aws account number
    :param sfn: Step functions client
    :param sfn_json: JSON Input for state machine
    :return:
    """
    
    load_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S').replace('-', '').replace(' ', '-').replace(':', '')
    execution_name = f"{aplctn_cd}-{sfn_json['job_id']}-RunDt-{load_time}"[:100]

    sfn_json = json.dumps(sfn_json)

    # Create Step Function Execution with ARN, Custom Name and Config JSON
    sfn_arn = 'arn:aws:states:' + region_name + ':' + account \
              + ':stateMachine:ANTM-EDL-' + env + '-Sfn-ETLOrchestrator'

    try:
        logger.info('*** Call Step Function with the following inputs: %s ***',
                    sfn_json)
        response = sfn.start_execution(stateMachineArn=sfn_arn,
                                       name=execution_name,
                                       input=sfn_json)

        logger.info(f'*** Step Function Response ARN: {response.get("executionArn")}')
        logger.info(f"*** Step Function Execution Name: {execution_name}")
        return True
    except ClientError as sfn_exception:
        logger.critical('*** SFN Exception occured: %s', sfn_exception)
        logger.critical('*** Failed to create SFN ***')
        return False


def lambda_handler(event, context):
   
    # Define the client to interact with AWS Lambda
    sfn = boto3.client('stepfunctions')

    logger = load_log_config()

    env = event['env'].strip()
    region_name = acc_info().get_region
    account = acc_info().get_account

    if(env == 'dev'):
        schema_prefix='d01_' 
        aplctn_cd='CII'   		 
    elif(env == 'sit'):
        schema_prefix='t01_'
        aplctn_cd='CII'
    elif(env == 'preprod'):
        schema_prefix='r01_'
        aplctn_cd='CII'   		 
    elif(env == 'prod'):
        schema_prefix='p01_'
        aplctn_cd='CII'   		 
    else:
        schema_prefix='u01_'
        env='sit'
        aplctn_cd='CIIU01'

    data = {}
    input_job_ids = []

    #Input Parameters
    input_job_ids = event['input_job_ids'].strip().split("|")
    input_retry = event['input_retry'].strip()    

    logger.info(f'\n**** Argument List ****\n-----------------------')
    logger.info(f'\env : {env} \ninput_job_ids : {input_job_ids} \ninput_retry : {input_retry} ')
    logger.info(f'\n-----------------------\n')    

    #Calling the function to trigger the jobs
    for job_id in input_job_ids:
        logger.info(f'\nCalling the orchestrator step function for {job_id} \n')
        data["job_id"] = job_id
        data["retry"] = input_retry
        sfn_json = data
        start_state_machine(logger, env, region_name, account, aplctn_cd, sfn, sfn_json)