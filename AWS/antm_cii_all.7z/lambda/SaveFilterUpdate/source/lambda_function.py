import logging
import json
import boto3
import base64
from botocore.exceptions import ClientError
import psycopg2

# Define Functions
def load_log_config():
    """
    # Basic config. Replace with your own logging config if required
    :return: object for basic logging
    """
    global logger
    
    MSG_FORMAT = '%(asctime)s %(levelname)s %(name)s: %(message)s'
    DATETIME_FORMAT = '%Y-%m-%d %H:%M:%S'
    logging.basicConfig(format=MSG_FORMAT, datefmt=DATETIME_FORMAT)
    logger = logging.getLogger("SAVE_FLTR_UPDATE")

    logger.setLevel(logging.INFO)


def get_secret(secret_name):
    """
    Function to fetch details from AWS Secrets Manager
    Usage   : Get Secret JSON String
    Args    : Secret Name
    Returns : Secure string of Secret
    Raises  : Exception While getting the Secret.
    
    """
    secret = ''
    secret_client = boto3.client("secretsmanager")

    try:
        get_secret_value_response = secret_client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as error:
        if error.response['Error']['Code'] == 'DecryptionFailureException':
            raise error
        elif error.response['Error']['Code'] == 'InternalServiceErrorException':
            raise error
        elif error.response['Error']['Code'] == 'InvalidParameterException':
            raise error
        elif error.response['Error']['Code'] == 'InvalidRequestException':
            raise error
        elif error.response['Error']['Code'] == 'ResourceNotFoundException':
            raise error
    else:
        if 'SecretString' in get_secret_value_response:
            secret = get_secret_value_response['SecretString']
            return secret
        else:
            decoded_binary_secret = base64.b64decode(
                get_secret_value_response['SecretBinary'])
            return decoded_binary_secret


def rds_conn(host_name, secret_name, port_no, schema_name):
    """
    Function to use Secrets Manager to create an RDS Connection Object
    :param host_name: Host name of the RDS
    :param secret_name: secret name for fetching user password
    :param port_no: Port Number of RDS
    :param schema_name: Schema Name in RDS
    :return: RDS Connection Object
    """
    
    try:
        secure_string   = get_secret(secret_name)
        secure_dict     = json.loads(secure_string)
        postgre_username  = secure_dict.get('username')
        postgre_password  = secure_dict.get('password')
        engine = psycopg2.connect(
                database=schema_name,
                user=postgre_username,
                password=postgre_password,
                host=host_name,
                port=port_no
            )
    except Exception as err:
        logger.critical("ERROR: Unexpected error: Could not connect to Aurora instance.")
        logger.critical('*** ERROR: %s ***', err)
        raise err
        
    return engine  


def _read_s3_object(s3_path):
    """
    Function to read object from s3 path
    :param s3_path: S3 object full path
    :return: object with file content
    """
    s3 = boto3.resource('s3')
    bucket = s3_path.split("//")[1].split("/")[0]
    key = "/".join(s3_path.replace("//", "").split("/")[1:])
    
    logger.info("Reading S3 obj {}".format(s3_path))
    obj = s3.Object(bucket, key)
    
    return obj
    
    
def get_save_fltr_upd_query():
    """
    Function to return the update query of Save Filter Table
    :return: Update Query Variable
    """
    
    '''Take any parent records out of Pending state if we processed them on this latest run.'''
    
    upd_query = """
    UPDATE {db_name}.ACIISST_SAVE_FLTR
    SET actv_fltr_flag_cd = 'Y'
    WHERE SAVE_FLTR_ID IN 
    (SELECT SFLTR.SAVE_FLTR_ID
    FROM  {db_name}.ACIISST_SAVE_FLTR SFLTR
        , {db_name}.SAVE_FLTR_CNTRL CNTRL
        , {db_name}.SAVE_FLTR_SGMNTN_BRDG SFB
    WHERE CNTRL.LKUP_ID = 5
    AND CNTRL.ACTV_LOAD_IND = 'Y'
    AND SFLTR.UPDTD_DTM BETWEEN CNTRL.SAVE_FLTR_LOW_DTM AND CNTRL.SAVE_FLTR_HIGH_DTM
    AND SFLTR.SAVE_FLTR_ID = SFB.SAVE_FLTR_ID
    AND SFLTR.actv_fltr_flag_cd = 'P') """.format(db_name=databaseName)
    
    return upd_query


def get_save_fltr_ctrl_upd_query(month_ind):
    """
    Function to return the update query of Save Filter Control Table
    :return: Update Query Variable
    """
    
    ''' Mark control record as no longer in loading state Since Monthly run occurs in Passive schema, we do NOT update the REFRESH_DTM for monthly.
    Catchup runs also occur in the Passive schema but we assume that the views will be toggled 
    immediately after a catchup run so we advance the REFRESH_DTM in that case. '''
    
    upd_query = """
    UPDATE {db_name}.SAVE_FLTR_CNTRL
    SET ACTV_LOAD_IND = 'N'
    , SAVE_FLTR_LOW_DTM =
      ( CASE '{mnthly_ind}'
          WHEN 'M' THEN RFRSH_DTM
          WHEN 'D' THEN SAVE_FLTR_HIGH_DTM
          ELSE CASE WHEN RFRSH_DTM < SAVE_FLTR_HIGH_DTM THEN RFRSH_DTM ELSE SAVE_FLTR_HIGH_DTM END
        END )
    , UPDTD_DTM = CURRENT_TIMESTAMP
    , RFRSH_DTM =
      ( CASE '{mnthly_ind}'
          WHEN 'M' THEN RFRSH_DTM
          WHEN 'D' THEN SAVE_FLTR_HIGH_DTM
          ELSE CASE WHEN RFRSH_DTM < SAVE_FLTR_HIGH_DTM THEN RFRSH_DTM ELSE SAVE_FLTR_HIGH_DTM END
        END )
    , MNTHLY_RFRSH_DTM =
      ( CASE
          WHEN '{mnthly_ind}' = 'M' THEN SAVE_FLTR_HIGH_DTM
          ELSE MNTHLY_RFRSH_DTM
        END )
    WHERE LKUP_ID = 5
    AND ACTV_LOAD_IND = 'Y' """.format(db_name=databaseName, mnthly_ind=month_ind)
    
    return upd_query



def lambda_handler(event, context):
    """
    :param event: Event variables for function
    :param context: Lambda execution context variables
    :return: None
    """
    global databaseName
    
    # Intialize the Logger
    load_log_config()
    
    
    # Assigning the source Variables
    MNTHLY_IND = event['Input']['config']['mnthlyind']
    db_config_path = event['Input']['config']['dbconfigpath']
    
    if(MNTHLY_IND.lower() not in ('d','m','c')):
        logger.exception("FAILED: Invalid Monthly Run Indicator. Valid values are 'M', 'D', or 'C'")
        raise Exception("FAILED: Invalid Monthly Run Indicator. Valid values are 'M', 'D', or 'C'")
        
    # Reads the configuration File from S3
    json_obj = _read_s3_object(db_config_path)
    config = json.loads(json_obj.get()['Body'].read().decode('utf-8'))

    # Getting RDS connection Details from configuration file
    databaseName = config['database_details']['database']
    schema_name = config['database_details']['schema']
    host = config['database_details']['host']
    port = config['database_details']['port']
    secret_name = config['database_details']['secret_name']
    # user = config['database_details']['user']
    # passwd = config['database_details']['passwd']
    
    # Creating Rds Object
    conn = rds_conn(host, secret_name, port, schema_name)
    cursor = conn.cursor()
    
    print(get_save_fltr_upd_query())
    print(get_save_fltr_ctrl_upd_query(MNTHLY_IND))
    cursor.execute(get_save_fltr_upd_query())
    
    cursor.execute(get_save_fltr_ctrl_upd_query(MNTHLY_IND))
    
    # Commits all the Changes done and closes the connection.
    conn.commit()
    conn.close()

    return {
        'Message': json.dumps('Saved Filters Control Tables Updated Sucessfully')
    }