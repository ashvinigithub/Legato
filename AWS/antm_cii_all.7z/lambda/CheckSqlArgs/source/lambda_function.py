import logging
import json
import boto3
import base64
import os
from botocore.exceptions import ClientError
from ReduceReuseRecycle import *
from datetime import *
from uuid import uuid1

def lambda_handler(event, context):
    """
    Main Processing Function
    :return: Env and metadata_dict
    """
    # Create a Logger
    logger = load_log_config()
    logger.info('*** Parsing the input parameters*****')
    logger.info(f'*** Input parameters - {event}*****')
    input_data_dict = event['data']
    #print(input_data_dict)
    output_dict={}
    output_metadata_dict = {}

    try:
        #anthem_id = input_data_dict['anthem_id']
        env = input_data_dict['env']
        etl_stp_s3_code_bkt = input_data_dict['etl_stp_s3_code_bkt']
        etl_stp_s3_code_key = input_data_dict['etl_stp_s3_code_key']
        etl_stp_trgt_platfrm = input_data_dict['etl_stp_trgt_platfrm']
        aplctn_cd = input_data_dict['aplctn_cd']
        warehouse_size_suffix = input_data_dict['warehouse_size_suffix']
        trgt_tbl_nm = input_data_dict['trgt_tbl_nm']
        trgt_db_nm = input_data_dict['trgt_db_nm']
        trgt_schma = input_data_dict['trgt_schma']
        etl_stp_parms = input_data_dict['etl_stp_parms']
        execution_name = input_data_dict['execution_name']
        execute_async = input_data_dict['execute_async']
        etl_sfn_parms = input_data_dict['etl_sfn_parms']

    except KeyError:
        logger.info('*** Key not Found in the input parameters *****')

    print("Running code")
    etl_stp_parms_str = json.dumps(etl_stp_parms)
    load_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    output_metadata_dict['etl_stp_s3_code_bkt'] = etl_stp_s3_code_bkt
    output_metadata_dict['etl_stp_s3_code_key'] = etl_stp_s3_code_key
    output_metadata_dict['etl_stp_trgt_schma'] = ""
    output_metadata_dict['etl_stp_trgt_stg_schma'] = ""
    output_metadata_dict['etl_stp_src_schma'] = ""
    output_metadata_dict['etl_stp_src_stg_schma'] = ""
    output_metadata_dict['etl_stp_trgt_platfrm'] = etl_stp_trgt_platfrm
    output_metadata_dict['aplctn_cd'] = aplctn_cd
    output_metadata_dict['edl_run_id'] = str(uuid1())
    output_metadata_dict['edl_load_dtm'] = load_time
    output_metadata_dict['etl_stp_parms'] = etl_stp_parms_str
    output_metadata_dict['etl_stp_trgt_tbl_nm'] = ""
    output_metadata_dict['trgt_tbl_nm'] = trgt_tbl_nm
    output_metadata_dict['trgt_schma'] = trgt_schma
    output_metadata_dict['clnt_id'] = ""
    output_metadata_dict['edl_sor_cd'] = ""
    output_metadata_dict['trgt_db_nm'] = trgt_db_nm
    output_metadata_dict['etl_sfn_parms'] = etl_sfn_parms
    
    output_metadata_str = json.dumps(output_metadata_dict)
    #output_dict['anthem_id']=anthem_id
    output_dict['env']=env
    output_dict['warehouse_size_suffix']=warehouse_size_suffix
    output_dict['output_metadata_str']=output_metadata_str
    output_dict['execution_name']=execution_name
    output_dict['execute_async']=execute_async
    print(output_dict)
    logger.info(f'*** output :   {output_dict} *****')
    return  output_dict
        


