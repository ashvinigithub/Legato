import os
import logging
import logging.config
import boto3
import json
from datetime import *
from boto_wrapper import acc_info
from botocore.exceptions import ClientError
from config_variables import *

# Define Functions
def load_log_config():
    """
    # Basic config. Replace with your own logging config if required
    """
    global logger
    
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    

def format_smry_success_message(payload, payload_attr, payload_sub):
    
    message_template = """
    Job ID: {job_id}
    Table Name: {table_name}
    Job Status: {job_status}
    Execution Name: {exec_name}
    Job Type: {job_type}
    Load Date: {load_date}
    """.format(
        job_id=payload['job_id'],
        table_name=payload['job_nm'].split("-")[1].upper(),
        job_status=payload['job_stts'],
        exec_name=payload['execution_name'],
        job_type=payload['job_type'],
        load_date=payload['edl_load_dtm']
        )
    
    return message_template
    

def format_smry_fail_message(payload, payload_attr, payload_sub):
    
    print("Here 1", payload_attr)
    
    message_template = """
    Job ID: {job_id}
    Table Name: {table_name}
    Job Status: {job_status}
    Execution Name: {exec_name}
    Job Type: {job_type}
    
    For Failure you can refer the stepfunction execution using EDL Run ID
        EDL Run Id: {edl_runid}
    
    Please Follow below Steps to re-run the failed job
        1. Create a new adhoc Json file similar to actual file 'cii_sf_smry_dst_job_id.json'
        2. Add the failed table_name and corresponding job_id in the created adhoc json file
        3. Run a Lambda function by configuring the Test input with newly created json file. please find the lambda details below.
            Lambda Function Name: ANTM-CII-{env}-Lmda-SF-TriggerETLSfn
            Test Event Sample to be given in json format:
                'smry_dst_tables_list' : 's3://antm-cii-{env}-codez-nogbd-nophi-useast1/cii_config/<Adhoc_json_file>.json'
    
    Note: If you have 3 tables failed then you can put all the three tables as part of adhoc json.
    """.format(
        job_id=payload_attr['job_id']['Value'],
        table_name=payload['msg'].split(":")[-1].replace("ANTM_Run_CII_SF_", "")[:-22].upper(),
        job_status="FAILED",
        exec_name=payload['msg'].split(":")[-1],
        job_type="sfn",
        env=env,
        edl_runid=payload_attr['edl_run_id']['Value']
        )
    
    return message_template
    
def format_sfltr_success_message(payload, payload_attr, payload_sub):
    
    tables = ", ".join(payload_attr['tables'])
    
    if('no_op' in payload.keys()):
        note_msg = "No Update has happened to Saved Filters"
    else:
        note_msg = "Update has happened to Saved Filters"
    
    message_template = """
    Job Status: {job_status}
    Execution Name: {exec_name}
    Job Type: {job_type}
    Load Date: {load_date}
    Run Indicator: {mnthly_ind}
    
    {note_msg}
    
    Below are the List of tables which are loaded Successfully
    {tables_list}
    
    """.format(
        job_status="SUCCEEDED",
        exec_name=payload['execution_arn'],
        job_type=payload['job_type'],
        load_date=datetime.now().strftime("%Y-%m-%d"),
        tables_list=tables,
        mnthly_ind=payload_attr['mnthlyind'],
        note_msg=note_msg
        )
    
    return message_template
    

def format_dst_success_message(payload, payload_attr, payload_sub):
    
    message_template = """
    Job ID: {job_id}
    Table Name: {table_name}
    Table Schema: {table_schma}
    Job Status: {job_status}
    Execution Name: {exec_name}
    Job Type: {job_type}
    Inbound Location: {s3_bkt_key_cmbntn}
    Confirmed Bkt Name: {s3_cnsmptn_bkt_name}
    Confirmed Location: {s3_cnsmptn_key}
    Load DTM:  {edl_load_dtm}
    Stage Table Name: {stg_tbl_nm}
    Stage Schema: {stg_schma}
    Src File Type: {src_file_type}    
    S3 BackUp Bkt Name: {s3_bkup_bkt}
    S3 Archieve Bkt Name: {s3_archv_bkt}
    Ownership Team: {ownrshp_team}
    """.format(
        job_id=payload['job_id'],
        table_name=payload['job_nm'].split("-")[1].upper(),
        table_schma=payload["trgt_schma"],
        job_status=payload['job_stts'],
        exec_name=payload['execution_name'],
        job_type=payload["job_type"],
        s3_bkt_key_cmbntn=payload["s3_bkt_key_cmbntn"],
        s3_cnsmptn_bkt_name=payload["s3_cnsmptn_bkt"],
        s3_cnsmptn_key=payload["s3_cnsmptn_key"],
        edl_load_dtm=payload["edl_load_dtm"],         
        stg_tbl_nm=payload["stg_tbl_nm"],
        stg_schma=payload["stg_schma"],   
        src_file_type=payload["src_file_type"],                              
        s3_bkup_bkt=payload["s3_bkup_bkt"],
        s3_archv_bkt=payload["s3_archv_bkt"],
        ownrshp_team=payload["ownrshp_team"]
    )
    
    return message_template


def format_dst_fail_message(payload, payload_attr, payload_sub):
    
    message_template = """
    Table Name: {table_name}
    Table Schema: {trgt_schma}
    Job Status: {job_status}
    Confirmed Bkt Name: {s3_cnsmptn_bkt}
    Confirmed Location: {s3_cnsmptn_key}
    Error Message : {ErrorMessage}
       
    """.format(
        table_name=payload['trgt_tbl_nm'],
        trgt_schma=payload['trgt_schma'],
        job_status=payload['JobRunState'],
        s3_cnsmptn_bkt=payload['s3_cnsmptn_bkt'],
        s3_cnsmptn_key=payload['s3_cnsmptn_key'],
        ErrorMessage=payload['ErrorMessage']
        )
    
    return message_template
    

def format_sfltr_fail_message(payload, payload_attr, payload_sub):
    
    tables = ", ".join(payload_attr['tables'])
    
    message_template = """
    Job Status: {job_status}
    Execution Name: {exec_name}
    Job Type: {job_type}
    Load Date: {load_date}
    Run Indicator: {mnthly_ind}
    
    Below are the List of tables which are Failed
    {tables_list}
    
    For Reload of the failed job please follow below steps
        1. Create an adhoc csv file with all the list for tables to reload in similar format of cii_sf_sfltr_tables_{env}.csv
        2. Submit below parameters as Step function input.
            Step Function Name: ANTM-CII-{env}-Sfn-{sfn_name}
            Parms to be submitted in json:
                'mnthlyind': '{mnthly_ind}',
                'dbconfigpath': 's3://antm-cii-{env}-codez-nogbd-phi-useast1/cii_config/cii_sf_sfltr_db_config_{env}.json',
                'sfltrtableslist': 's3://antm-cii-{env}-codez-nogbd-phi-useast1/cii_config/cii_sf_sfltr_tables_{env}_adhoc.csv',
                'emrjobtemplate': 's3://antm-cii-{env}-codez-nogbd-phi-useast1/cii_config/cii_sf_emr_job_template.json'
    """.format(
        job_status="FAILED",
        exec_name=payload['execution_arn'],
        job_type=payload['job_type'],
        load_date=datetime.now().strftime("%Y-%m-%d"),
        mnthly_ind=payload_attr['mnthlyind'],
        tables_list=tables,
        env=env,
        sfn_name=sfn_name
        )
    
    return message_template


def get_message_formatter(job_type, job_status):

    formatter_success = {
        "glue": format_dst_success_message,
        "sfn": format_smry_success_message,
        "sfltr": format_sfltr_success_message
    }

    formatter_failure = {
        "glue": format_dst_fail_message,
        "sfn": format_smry_fail_message,
        "sfltr": format_sfltr_fail_message
    }

    if(job_status.upper() == "SUCCEEDED"):
        return formatter_success[job_type]
    else:
        return formatter_failure[job_type]


def process_event_sfltr(payload, payload_attr):
    """
    Seperates the failure and success tables from the input event for Saved Filters
    :param payload: Message of the event
    :param payload_attr: Message Attributes of the event
    :return:
    """
    payload_success_attr = {}
    payload_fail_attr = {}
    success_tbl_list = []
    failure_tbl_list = []
    exec_arn = ""
    mnthly_ind = ""
    
    tables_list = payload_attr['Value']
    print("sftr disp")
    print("type:", type(tables_list))
    for item in tables_list:
        print("item:", item)
        print("type:", type(item))
        mnthly_ind = item['mnthlyind']
        if(item['job_stts'].upper() == "FAILED"):
            failure_tbl_list.append(item['tgttblnm'])
        elif(item['job_stts'].upper() == "SUCCEEDED"):
            success_tbl_list.append(item['tgttblnm'])
    
    sfn_client = boto3.client('stepfunctions')
    
    response = sfn_client.list_executions(
        stateMachineArn='arn:aws:states:' + acc_info().get_region + ':' + acc_info().get_account \
            + ':stateMachine:ANTM-CII-{env}-Sfn-{sfn_name}'.format(
            env=env, sfn_name=sfn_name),
        statusFilter='RUNNING'
    )
    
    for execution in response['executions']:
        if(execution['executionArn'].find("MNTHLY") != -1 and mnthly_ind.upper() == "M" ):
            exec_arn = execution['executionArn']
        else:
            exec_arn = execution['executionArn']
        
    payload.update({"execution_arn": exec_arn})
    payload_success_attr.update({"tables": success_tbl_list})
    payload_success_attr.update({"mnthlyind": payload_attr['Value'][0]['mnthlyind']})
    payload_fail_attr.update({"tables": failure_tbl_list})
    payload_fail_attr.update({"mnthlyind": payload_attr['Value'][0]['mnthlyind']})
    
    
    if(len(failure_tbl_list) > 0 and len(success_tbl_list) > 0):
        subject = "Succeeded: CII Saved Filters Load"
        payload.update({"job_stts": "SUCCEEDED"})
        send_sns_publication(payload, payload_success_attr, subject)
        
        subject = "Failed: CII Saved Filters Load"
        payload.update({"job_stts": "FAILED"})
        send_sns_notification(payload, payload_fail_attr, subject)
    elif(len(failure_tbl_list) == 0 and len(success_tbl_list) > 0):
        
        subject = "Succeeded: CII Saved Filters Load"
        payload.update({"job_stts": "SUCCEEDED"})
        send_sns_publication(payload, payload_success_attr, subject)
    elif(len(failure_tbl_list) > 0 and len(success_tbl_list) == 0):
        
        subject = "Failed: CII Saved Filters Load"
        payload.update({"job_stts": "FAILED"})
        send_sns_notification(payload, payload_fail_attr, subject)
    
    if(len(failure_tbl_list) > 0):
        raise Exception("Discover Tables Load Failed")
        
    return
        

def send_sns_notification(payload, payload_attr, subject):
    """
    Sends a notification to an SNS message that can be routed via email
    :param payload: All relevant job metadata
    :param payload_attr: Message Attributes
    :param subject: Subject message for the Publication
    :return:
    """
    # Create an SNS client
    sns = boto3.client('sns')

    sns_arn = 'arn:aws:sns:' \
              + acc_info().get_region + ':' \
              + acc_info().get_account + ':{env}-snsCIINotification'.format(env=env)
    logger.info('SNS ARN: %s', sns_arn)

    try:
        formatted_msg = get_message_formatter(payload['job_type'], payload['job_stts'])(payload, payload_attr, subject)
        response = sns.publish(TargetArn=sns_arn,
                              Message=formatted_msg,
                              Subject=subject,
                              MessageStructure='string'
                              )
                               
        logger.info('SNS Response: %s', response)
    except ClientError as sns_error:
        logger.critical('*** SNS Message Notification Failed: %s ***', sns_error)
        raise sns_error


def send_sns_publication(payload, payload_attr, subject):
    """
    Sends a notification to an SNS message that can be routed via email
    :param payload: All relevant job metadata
    :param payload_attr: Message Attributes
    :param subject: Subject message for the Publication
    :return:
    """
    # Create an SNS client
    sns = boto3.client('sns')

    sns_arn = 'arn:aws:sns:' \
              + acc_info().get_region + ':' \
              + acc_info().get_account + ':{env}-snsCIIPublication'.format(env=env)
              
    logger.info('SNS ARN: %s', sns_arn)
    try:
        formatted_msg = get_message_formatter(payload['job_type'], payload['job_stts'])(payload, payload_attr, subject)
        response = sns.publish(TargetArn=sns_arn,
                              Message=formatted_msg,
                              Subject=subject,
                              MessageStructure='string'
                              )
    except ClientError as sns_error:
        logger.critical('*** SNS Message Publication Failed: %s ***', sns_error)
        raise sns_error


def lambda_handler(event, context):
    """
    :param event: Event variables for function
    :param context: Lambda execution context variables
    :return: None
    """
    load_log_config()
    print("Event:", event)

    global env
    env=context.function_name.split("-")[2]
    
    message_dict = {}
    try:
        message = event['Records'][0]['Sns']['Message']
        message_dict = json.loads(message)
        message_attrs = event['Records'][0]['Sns']['MessageAttributes']
        message_sub = event['Records'][0]['Sns']['Subject']
        print("here")
    except:
        print("except")
        message = event['Input']['Records'][0]['Sns']['Message']
        message_dict = message
        message_attrs = event['Input']['Records'][0]['Sns']['MessageAttributes']
        message_sub = event['Input']['Records'][0]['Sns']['Subject']
    
    
    message_attrs_dict = message_attrs
    print(message_dict)
    print(type(message_dict))
    if (type(message_dict) is dict):
        if('job_stts' in message_dict.keys() and message_dict['job_stts'].upper() == "SUCCEEDED"):
            if(message_dict['job_type'].lower() == 'glue'):
                subject = "Succeeded: CII Discover Load - {table_nm}".format(table_nm=message_dict['trgt_tbl_nm'])
            elif(message_dict['job_type'].lower() == 'sfn'):
                subject = "Succeeded: CII Discover Load - {table_nm}".format(table_nm=message_dict['job_nm'].split("-")[1].upper())
            else:
                raise Exception("Invalid Job Type")
            
            send_sns_publication(message_dict, message_attrs_dict, subject)
        elif('job_stts' in message_dict.keys() and message_dict['job_stts'].upper() == "FAILED"):
            if(message_dict['job_type'].lower() == 'glue'):
                subject = "Failed: CII Discover Load - {table_nm}".format(table_nm=message_dict['--trgt_tbl_nm'])
            else:
                raise Exception("Invalid Job Type")

            send_sns_notification(message_dict, message_attrs_dict, subject)
        else:
            if(message_dict['job_type'].lower() == 'sfltr'):
                print("sfltr")
                print(message_dict)
                print(message_attrs_dict)
                process_event_sfltr(message_dict, message_attrs_dict)
                
                print("returning ")
                return {
                    'mnthlyind': message_attrs_dict['Value'][0]['mnthlyind'],
                    'dbconfigpath': message_attrs_dict['Value'][0]['dbconfigpath']
                }
            else:
                raise Exception("Invalid Job Type")
    else:
        message_dict = {}
        message_dict.update({"Message":message})
        tgt_tbl_nm = message_sub.split(":")[-1].replace("ANTM_Run_CII_SF_", "")[:-22]
        
        subject = "Failed: CII Discover Load - {table_nm}".format(table_nm=tgt_tbl_nm.upper())
        message_dict.update({"job_type":"sfn"})
        message_dict.update({"job_stts":"FAILED"})
        message_dict.update({"msg": message_sub})

        send_sns_notification(message_dict, message_attrs_dict, subject)
        
    print("Final")

    # Process Completed
    return {
        'message': json.dumps('Notification/publication is sent successfully')
    }
