import logging
import json
import boto3
import base64
import os
from ReduceReuseRecycle import load_log_config, InvalidStatus
from botocore.exceptions import ClientError
#from boto_wrapper import *
import pymysql
from datetime import *


LOGGER = load_log_config(glue=True)

# Define Functions

def lambda_handler(event, context):
   
    # Define the client to interact with AWS Lambda
    glue = boto3.client('glue')

    env = event['env'].strip()

    if(env == 'dev'):
        schema_prefix='d01_'    		 
    elif(env == 'sit'):
        schema_prefix='t01_'
    elif(env == 'preprod'):
        schema_prefix='r01_'
    elif(env == 'prod'):
        schema_prefix='p01_'
    else:
        schema_prefix='u01_'


    #Input Parameters
    s3_source_bucket = event['s3_source_bucket'].strip()
    s3_source_key = event['s3_source_key'].strip()
    s3_target_bucket = event['s3_target_bucket'].strip()
    s3_target_key = event['s3_target_key'].strip()
    table_creation = event['table_creation'].strip()
    schema_name = event['schema_name'].strip()    

    LOGGER.info(f'\n**** Argument List ****\n-----------------------')
    LOGGER.info(f'\env : {env} \ns3_source_bucket : {s3_source_bucket} \ns3_source_key : {s3_source_key} \ns3_target_bucket : {s3_target_bucket} '
            f'\ns3_target_key : {s3_target_key} \nschema_name : {schema_prefix}{schema_name} ')
    LOGGER.info(f'\n-----------------------\n')    

    try:
        response = glue.start_job_run(
        JobName = 'ANTM-CII-' + env + '-Gj-HistoryCopyProcess',
        Arguments = {
        '--env':   env,
        '--s3_source_bucket':  s3_source_bucket,
        '--s3_source_key':  s3_source_key,
        '--s3_target_bucket':  s3_target_bucket,
        '--s3_target_key':  s3_target_key,
        '--table_creation': table_creation,
        '--schema_name':  schema_prefix + schema_name } )
        jobrunid = response['JobRunId']
        LOGGER.info(f'\nJob Run ID : {jobrunid} \n')
    except Exception as err:
        LOGGER.critical('*** ERROR: %s ***', err)
        raise err