import json
import requests
import base64
from ReduceReuseRecycle import *
from ReduceReuseRecycle.apifunc import *

def lambda_handler(event, context):
    
    headers={'Accept': 'application/json', 'Content-type': 'application/json'}
    IndxAlias=event['IndexAlias']
    #code to get the index name where alias is pointing 
    print("======== INFO: Before Flip : code to get the index name where alias is pointing =======")
    LOGGER=load_log_config()
    application_name='CII'
    LOGGER.info(f'application_name: {application_name}')
    env=get_env(application_name, lambda_context=context)
    region_name=get_region_name()
    Aliasresult=get_es_request(log= LOGGER, env=env, region_name=region_name, aplctn_cd= application_name.lower(), auth_type= 'basic', key_index= IndxAlias)
    print("Execution Status =",Aliasresult)
    currentIndxAlias=list(Aliasresult.keys())[0]
    print(IndxAlias , " = ",currentIndxAlias)
    #code to generate opposite alias name 
    if ((currentIndxAlias[-1::])=='a'): updateTrgIndxAlias=currentIndxAlias[:-1:] + 'b' 
    if ((currentIndxAlias[-1::])=='b'): updateTrgIndxAlias=currentIndxAlias[:-1:] + 'a' 
    print("updateTrgIndxAlias=",updateTrgIndxAlias)
    #Code to execute the flip script
    print("======= Code to execute the flip script=========")
    requestJson='{"actions" : [ { "add" :    { "index" : "' + updateTrgIndxAlias + '", "alias" : "'+IndxAlias+'" } },{ "remove" : { "index" : "'+ currentIndxAlias +'", "alias" : "'+IndxAlias+'" } } ]} '
    print(requestJson)
    r=post_es_request(log= LOGGER, env=env, region_name=region_name, aplctn_cd= application_name.lower(), auth_type= 'basic', key_index='_aliases', body=requestJson, headers=headers )
    print("Execution Status for r=",r)
    #code to validate after flip where alias is pointing
    print("=======INFO: After Flip :code to validate after flip where alias is pointing=======")
    Aliasresult=get_es_request(log= LOGGER, env=env, region_name=region_name, aplctn_cd= application_name.lower(), auth_type= 'basic', key_index= IndxAlias)
    print("Execution Status=",Aliasresult)
    aftercurrentIndxAlias=list(Aliasresult.keys())[0]
    print(IndxAlias, " = ",currentIndxAlias)
    return {IndxAlias +" "+ "Before flip" : currentIndxAlias, 
    IndxAlias +" "+"After flip":aftercurrentIndxAlias}
