import json

def lambda_handler(event, context):
    
    print(event['Input']['data']['emrcount'])
    event['Input']['data']['emrcount'] = event['Input']['data']['emrcount'] + 1
    
    return event['Input']['data']['emrcount']
