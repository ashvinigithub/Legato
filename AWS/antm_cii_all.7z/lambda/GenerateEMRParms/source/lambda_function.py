import json
import boto3
import os
import logging
import awswrangler as wr
import pandas as pd
from io import StringIO

def load_log_config():
    """
    # Basic config. Replace with your own logging config if required
    :return: object for basic logging
    """
    global logger

    MSG_FORMAT = '%(asctime)s %(levelname)s %(name)s: %(message)s'
    DATETIME_FORMAT = '%Y-%m-%d %H:%M:%S'
    logging.basicConfig(format=MSG_FORMAT, datefmt=DATETIME_FORMAT)
    logger = logging.getLogger("GEN_EMR_PARMS")

    logger.setLevel(logging.INFO)

def _create_emr_args(csv_args, json_frmt, mnthly_ind, reruntables, rerun_emr_config_path):
    """
    Function to create EMR job parms
    We will be adding monthly indicator as an additional arguement in spark submit
    :param csv_args: details of tables with run frequency and spark submit args.
    :param json_frmt: json template used to create input for step function Map state which triggers EMR ETL for save filters.
    :param mnthly_ind: Monthly Indicator used for picking up the tables corresponding from the csv file.
    :return: list of emr job parms for all the tables present in csv_args with matching monthly indicator
    """
    task_list = []
    pass_list = []
    columns = []
    cluster_no = 0
    tbl_config_path = ""
    
    bucket = template_path.split("//")[1].split("/")[0]
    key = "/".join(template_path.replace("//", "").split("/")[1:-1])
    
    rerun_table_list = reruntables.strip().split("|")
    
    logger.info("Creating EMR job parms list for tables satisfying monthly indicator")
    if(rerun_table_list[0].upper() == 'NA'):
       for row in csv_args:
           columns = row.split(",")
           run_frequency = [ind.upper() for ind in columns[1].strip().split("|")]
           if(mnthly_ind.upper() in run_frequency):
              cluster_no += 1
              json_frmt['clusternm'] = str(columns[0]).upper() + "-SFLTR-LOAD"
              json_frmt['tgttblnm'] = str(columns[0])
              json_frmt['configfile'] = str(columns[2])
              json_frmt['jobargs']['job'] = columns[3].replace(
                  "{mnth_ind}", mnthly_ind.upper()).split(" ")
              json_frmt['emrenv'] = env
              json_frmt['logpath'] = json_frmt['logpath'].format(env=env)
            
              tbl_config_path = "s3://" + bucket + "/" + key + "/emr_parms/" + columns[0] + ".json"
              pass_list.append({"tablenm":columns[0], "configpath":tbl_config_path})
              _upload_s3_object(tbl_config_path, json.dumps(json_frmt))              
    else:
    	for row in csv_args:
           columns = row.split(",")
           run_frequency = [ind.upper() for ind in columns[1].strip().split("|")]
           if(mnthly_ind.upper() in run_frequency and columns[0] in rerun_table_list):
              cluster_no += 1
              json_frmt['clusternm'] = str(columns[0]).upper() + "-SFLTR-LOAD"
              json_frmt['tgttblnm'] = str(columns[0])
              
              if(rerun_emr_config_path.upper() == 'NA'):
                 json_frmt['configfile'] = str(columns[2])
              else:
                 json_frmt['configfile'] = str(rerun_emr_config_path)
                 
              json_frmt['jobargs']['job'] = columns[3].replace(
                  "{mnth_ind}", mnthly_ind.upper()).split(" ")
              json_frmt['emrenv'] = env
              json_frmt['logpath'] = json_frmt['logpath'].format(env=env)
            
              tbl_config_path = "s3://" + bucket + "/" + key + "/emr_parms/" + columns[0] + ".json"
              pass_list.append({"tablenm":columns[0], "configpath":tbl_config_path})
              _upload_s3_object(tbl_config_path, json.dumps(json_frmt))
        
        # task_list.append(json.dumps(json_frmt))

    # print(json.loads(task_list[0]))

    return pass_list


def _create_db2_emr_args(csv_args, json_frmt, job_reqstd):
    
    """
    Function to create EMR job parms for S3 to RDS/ Db2 to RDS/ Rds to Snowflake process
    :param csv_args: details of tables with spark submit args.
    :param json_frmt: json template used to create input for step function Map state which triggers EMR ETL for save filters.
    :param job_reqstd: Based on the re-run indicator if it is na by default all the parms will be generated.
     else only job type corresponding parameters will be returned.
    :return: list of emr job parms for the tables present in csv_args with matching job_reqstd.
    """
    pass_db2_list = []
    columns = []
    
    logger.info("Creating EMR job parms list for DB2toRDS/ RDS to Snowflake process")
    
    # Filtering the csv arguements based on the job type provided
    filtered_csv_args = []
    if(job_reqstd.lower() == 'na'):
        filtered_csv_args = csv_args
    elif(job_reqstd.lower() == 's3tords'):
        filtered_csv_args = [line if line.split(",")[1].lower() == 's3tords' else '' for line in csv_args]    
    elif(job_reqstd.lower() == 'db2rds'):
        filtered_csv_args = [line if line.split(",")[1].lower() == 'db2rds' else '' for line in csv_args]
    elif(job_reqstd.lower() == 'rdstosnf'):
        filtered_csv_args = [line if line.split(",")[1].lower() == 'rdstosnf' else '' for line in csv_args]
    else:
        logger.exception("Invalid Job Type")
        raise Exception("Invalid Job Type")
    
    if(len(filtered_csv_args) <= 0):
        logger.exception("Invalid Csv File Provided. Expecting TableName, Jobtype, Spark Submit Args in the file with atleast one record")
        raise Exception("Invalid Csv File Provided. Expecting TableName, Jobtype, Spark Submit Args in the file with atleast one record")
    
    
    # Removes unwanted items in CSV file
    if '' in filtered_csv_args :
        count = filtered_csv_args.count('')
        for iter in range(0, count):
            filtered_csv_args.remove('')
    else :
        filtered_csv_args
    
    
    # Creating EMR parms for the job type requested
    for row in filtered_csv_args:
        columns = row.split(",")
        table_name = str(columns[0])
        job_args = columns[2].split(" ")
        job_jar = json_frmt['jobargs']['jar']
        
        pass_db2_list.append(
            {
                "jobname": table_name,
                "job": job_args,
                "jar": job_jar
            })
         	
    return pass_db2_list
    
    
def _read_s3_object(s3_path):
    """
    Function to read s3 config path for job processing
    :param s3_path: path to read the s3 file.
    :return: object 
    """
    s3 = boto3.resource('s3')
    bucket = s3_path.split("//")[1].split("/")[0]
    key = "/".join(s3_path.replace("//", "").split("/")[1:])
    
    logger.info("Reading s3 object {}".format(s3_path))
    obj = s3.Object(bucket, key)
    
    return obj
    

def _upload_s3_object(s3_path, data):
    """
    Function to upload file to s3
    :param bucket_name: Bucket name for s3 upload
    :param object_key: key name for s3 upload
    :param table_nm: Table name for s3 upload
    :return: None
    """
    
    s3 = boto3.resource('s3')
    bucket = s3_path.split("//")[1].split("/")[0]
    key = "/".join(s3_path.replace("//", "").split("/")[1:])
    obj = s3.Object(bucket, key)
    
    logger.info("Uploading s3 object {}".format(s3_path))
    obj.put(Body=data)
    
    return


def _read_csv(s3_file_path):
    """
    Function to read csv file
    :param s3_file_path : s3 Path of the csv file
    :return: List of the contents in Csv File
    """
    # Read the Csv file and send the content of it as list
    csv_args = []
    csv_df = wr.s3.read_csv([s3_file_path])
    csv_args = csv_df.values.tolist()
    
    csv_args = [','.join(i) for i in csv_args]
    
    return csv_args
    
    
def _validate_job_type(event):
    """
    Function to Validate the event input and do the operation accordingly
    :param event : s3 Path of the csv file
    :return: job type whether it is a Save Filter Operation/ Db2 Rds operation
    """
    
    if('mnthlyind' in event['Input'].keys() and
       'sfltrtableslist' in event['Input'].keys()):
        return "sfltr"    		 
    elif('rdstablelist' in event['Input'].keys() and 
         're-run' in event['Input'].keys()):
        
        if(event['Input']['re-run'].lower() not in ['s3tords', 'db2rds', 'rdstosnf', 'na']):
            raise Exception("Invalid Re-run indicator Provided. Expected s3tords/db2rds/rdstosnf")
    	
        return "rds_process"
    else:
        logger.exception("Invalid Arguements as Input for Generating EMR Parms")
        raise Exception("Invalid Arguements as Input for Generating EMR Parms")
        
        
def lambda_handler(event, context):
    """
    Main Processing Function
    :return: EMR job parms in a list 
    """
    global template_path, env
    # Create a Logger
    load_log_config()
    print(event)
    
    env = context.function_name.split("-")[2]
    
    template_path = event['Input']['emrjobtemplate']
    
    # Read the EMR job template from s3.
    job_tmplt_obj = _read_s3_object(template_path)
    json_tmplt = json.loads(job_tmplt_obj.get()['Body'].read().decode('utf-8'))
    
    # Read the Save filter tables list
    csv_args = []
    
    # Validate Input Parameters of Event and Process Accordingly
    job_type = _validate_job_type(event)

    # Create EMR job parms in a list based on the Process type
    if(job_type =="sfltr"):
        mnthly_ind = event['Input']['mnthlyind']
        sfltr_args = _read_csv(event['Input']['sfltrtableslist'])
        reruntables = event['Input']['reruntables']
        rerun_emr_config_path = event['Input']['rerun_emr_config_path']
        config_list = _create_emr_args(sfltr_args, json_tmplt, mnthly_ind, reruntables, rerun_emr_config_path)
    else:
        rds_args = _read_csv(event['Input']['rdstablelist'])
        config_list = _create_db2_emr_args(rds_args, json_tmplt, event['Input']['re-run'])
    
    return config_list
