from boto_wrapper import sfs,acc_info,secretkey
import uuid
import json
import boto3
import os
import logging
import logging.config
from datetime import datetime
from config_variables import *
import time

# Define Functions
def load_log_config():
    """
    # Basic config. Replace with your own logging config if required
    :return: object for basic logging
    """
    global logger
    
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    


def get_step_function_name(table_nm, date_time):
    """
    Function to get a Execution name for Step Function Execution
    :param table_nm: Table name which is used as part of execution name
    :param date_time: current date time to define the execution name
    :return: Execution Name
    """
    # Importing required Modules
    from random import choice 
    from string import ascii_lowercase
    
    name="".join([choice(ascii_lowercase) for x in range(5)])
    
    return f'ANTM_Run_CII_SF_{table_nm}_{name}_{date_time}'

    
'''This Function Triggers the StepFunction'''
def run_stepfunction(job_args):
    """
    Function Invoke a ETL Orchestrator stepfunction with input parameters
    :param job_args: Job Arguments with Job Id and Job Name
    :return: None
    """
    # Importing Required Modules
    from uuid import uuid1 
    
    # Configured the EDL Framework Step Function Name as Environment Variable
    # step_function_arname=os.environ['stepfunctionname']
    
    # Invocating the EDL Orchestrator Step Function with the tables mentioned as per the config
    for table_nm, job_id in job_args.items():
        run_name = get_step_function_name(table_nm, datetime.now().strftime("%Y%m%d_%H%M%S"))
        
        etl_sfn_parms = dict()
        
        params=json.dumps({
            'job_id':str(job_id),
            'job_nm':'SMRY-' + str(table_nm),
            'src_load_prfx': 'na',
            'edl_load_dtm': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            'edl_run_id': str(uuid1()),
            'env': env,
            'account': acc_info().get_account,
            'region_name': acc_info().get_region,
            'etl_sfn_parms': json.dumps(etl_sfn_parms),
            'execution_name': run_name,
            'load_log_key': '',
            'retry': 'yes'
        })
        
        
        # Invoke Orchestrator Sfn
        call_step_function = 'ANTM-EDL-{env}-{step_function_arname}'.format(env=env, step_function_arname=step_function_arname)

        logger.info("Preparing Invocation of Step Function {}".format(call_step_function))
        sfs(env,acc_info().get_region,acc_info().get_account,params,call_step_function,run_name).sfn_execution
        
        
    return
    

def _read_config_file(config_path):
    """
    Function to read s3 config path for job processing
    :param config_path: path to read the config file.
    :return: Json Content
    """
    s3 = boto3.resource('s3')
    bucket = config_path.split("//")[1].split("/")[0]
    key = "/".join(config_path.replace("//", "").split("/")[1:])
    obj = s3.Object(bucket, key)
    config_args = json.loads(obj.get()['Body'].read().decode('utf-8') )
    
    return config_args
    

def lambda_handler(event,context):
    """
    Function to Trigger Step function based on Parameters, Config file Provided
    :param event: Event variables for function
    :param context: Lambda execution context variables
    :return: None
    """
    # Load Logger
    load_log_config()
    print(event)

    global env
    env = context.function_name.split("-")[2]
    
    # Initial Validations
    if ('smry_dscvr_tables_list' not in event['Input'].keys()):
        logger.exception("Invalid Arguments. Expected smry_dscvr_tables_list")
        raise Exception("Invalid Arguments. Expected smry_dscvr_tables_list")
    
    if (len(event['Input']['smry_dscvr_tables_list']) == 0):
        logger.exception("Invalid Value for smry_dscvr_tables_list, Expected S3 path with Summary Tables List")
        raise Exception("Invalid Value for smry_dscvr_tables_list, Expected S3 path with Summary Tables List")
        
    try:
        job_args = _read_config_file(event['Input']['smry_dscvr_tables_list'])
        
        # job_args = {'summary': {'cii_clms_cost_pgm_smry':'261141175'}}
        run_stepfunction(job_args['summary'])

        return json.dumps({"Message":"Step Function Has Started"})
    except:
        logger.exception("Failed running the Step Function")
        raise Exception("Failed running the Step Function")