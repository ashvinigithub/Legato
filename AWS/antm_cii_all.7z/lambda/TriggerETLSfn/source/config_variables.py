# Config Variables

step_function_arname = "Sfn-ETLOrchestrator"