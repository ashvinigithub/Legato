import boto3 
import os
import base64
import json

class secretkey:
    secret_manager=boto3.client('secretsmanager')
    def __init__(self,secretid):
        self.secretid=secretid
    @property
    def get_secret_key(self):
        try:
            get_secret_val=secretkey.secret_manager.get_secret_value(
                SecretId=self.secretid
            )
            if 'SecretString' in get_secret_val :
                secret = get_secret_val[ 'SecretString' ]
                return json.loads(secret)
            else :
                decoded_binary_secret = base64.b64decode ( get_secret_val[ 'SecretBinary' ] )
                return decoded_binary_secret.password
        except Exception as e:
            print(str(e))
            return None
class sfs:
    step_function_client=boto3.client('stepfunctions')
    def __init__(self,env,region,account,input_json,sf_name,run_name):
        self.env=env
        self.region=region
        self.account=account
        self.input_json=input_json
        self.sf_name=sf_name
        self.run_name=run_name
        self.state_arn=None
    @property
    def create_full_arn(self):
        '''sample - 
        arn:aws:states:us-east-1:481935479534:stateMachine:EMR_NCCT'''
        if self.state_arn!=None:
            return self.state_arn
        else:
            self.state_arn=f'arn:aws:states:{self.region}:{self.account}:stateMachine:{self.sf_name}'
            return self.state_arn
    @property
    def sfn_execution(self):
        response=sfs.step_function_client.start_execution(
            stateMachineArn=self.create_full_arn,
            name=self.run_name,
            input=self.input_json
        )
        return response
class acc_info:
    sts_function_client=boto3.client('sts')
    def __init__(self):
        acc_details=acc_info.sts_function_client.get_caller_identity()
        self.account=acc_details['Account']
        self.region=os.environ['AWS_REGION']
        self.function_name=acc_details['Arn']
    @property
    def get_account(self):
        return self.account
    @property
    def get_region(self):
        return self.region
    @property
    def get_handler_name(self):
        return self.function_name.split("/")[-1]
    



        
