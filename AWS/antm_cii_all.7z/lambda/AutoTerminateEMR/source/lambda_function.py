import logging
import json
import boto3
import base64
import os
from ReduceReuseRecycle import load_log_config, InvalidStatus
from botocore.exceptions import ClientError
#from boto_wrapper import *
import pymysql
from datetime import *
from datetime import datetime


#---------------------------------------------------------------------------------#
# Creating boto3 client for glue, stepfuntion, s3, sns                            #
#---------------------------------------------------------------------------------#
glue = boto3.client('glue')
s3 = boto3.client('s3')
sns = boto3.client('sns')
sfn = boto3.client('stepfunctions')
LOGGER = load_log_config(glue=True)
#---------------------------------------------------------------------------------#
# Define Functions
#---------------------------------------------------------------------------------#
class acc_info:
    sts_function_client=boto3.client('sts')
    def __init__(self):
        acc_details=acc_info.sts_function_client.get_caller_identity()
        self.account=acc_details['Account']
        self.region=os.environ['AWS_REGION']
        self.function_name=acc_details['Arn']
    @property
    def get_account(self):
        return self.account
    @property
    def get_region(self):
        return self.region
    @property
    def get_handler_name(self):
        return self.function_name.split("/")[-1]
#---------------------------------------------------------------------------------#
# Function to read an object in S3                                                #
#---------------------------------------------------------------------------------#
def read_s3_object(s3_path):
    """
    Function to read s3 config path for job processing
    :param s3_path: path to read the s3 file.
    :return: object 
    """
    s3 = boto3.resource('s3')
    bucket = s3_path.split("//")[1].split("/")[0]
    key = "/".join(s3_path.replace("//", "").split("/")[1:])
    
    LOGGER.info("\n Reading s3 object {} \n".format(s3_path))
    obj = s3.Object(bucket, key)
    
    return obj
#---------------------------------------------------------------------------------#
#Fucntion to Upload an object to S3                                               #
#---------------------------------------------------------------------------------#
def upload_s3_object(s3_path, data):
    """
    Function to upload file to s3
    :param bucket_name: Bucket name for s3 upload
    :param object_key: key name for s3 upload
    :param table_nm: Table name for s3 upload
    :return: None
    """
    
    s3 = boto3.resource('s3')
    bucket = s3_path.split("//")[1].split("/")[0]
    key = "/".join(s3_path.replace("//", "").split("/")[1:])
    obj = s3.Object(bucket, key)
    
    LOGGER.info("\n Uploading s3 object {} \n".format(s3_path))
    obj.put(Body=data)
    
    return
#---------------------------------------------------------------------------------#
# SNS Publication
#---------------------------------------------------------------------------------#
def SNSPublication(env, subject, message, region, account):
    sns_arn = 'arn:aws:sns:' \
              + region + ':' \
              + account + ':{env}-snsCIIPublication'.format(env=env)
    subject = subject
    LOGGER.info('SNS ARN: %s', sns_arn)
    try:
        response = sns.publish(TargetArn=sns_arn,
                              Message=message,
                              Subject=subject,
                              MessageStructure='string'
                              )
                               
        LOGGER.info('SNS Response: %s', response)
    except ClientError as sns_error:
        LOGGER.critical('*** SNS Message Publication Failed: %s ***', sns_error)
        raise sns_error
#---------------------------------------------------------------------------------#
#Generating parameters for EMR Async                                              #
#---------------------------------------------------------------------------------#  
def emrConfigParameters(env, json_frmt, job_args, table, cluster_name, create_cluster, emr_config_name, term_cluster):
    
    json_frmt['clusternm'] = cluster_name
    json_frmt['configfile'] = emr_config_name
    json_frmt['jobargs'][0]['jobname'] = table
    json_frmt['jobargs'][0]['job'] = job_args.format(env=env).split(" ")
    json_frmt['emrenv'] = env
    json_frmt['createcluster'] = create_cluster
    json_frmt['terminateoption'] = term_cluster
    json_frmt['logpath'] = json_frmt['logpath'].format(env=env)
    json_frmt['bootstrapbucket'] = json_frmt['bootstrapbucket'].format(env=env)
                    
    return json_frmt
#---------------------------------------------------------------------------------#
#Function to Invoke EMR Async                                                     #
#---------------------------------------------------------------------------------#        
def callingEMRAsync(LOGGER, env, sfn_json):
    """
    Function to start the Step Function state machine with JSON input
    :param LOGGER: basic log object
    :param env: environment (dev, sit, prod)
    :param region_name: region on aws (us-east-1)
    :param account: aws account number
    :param account_name: aws account name (edl)
    :param sfn: Step functions client
    :param sfn_json: JSON Input for state machine
    :return:
    """

    load_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S').replace('-', '').replace(' ', '-').replace(':', '')
    execution_name = f"CII-RunDt-{load_time}"[:100]
    region_name = os.environ['AWS_DEFAULT_REGION']
    account = acc_info().get_account

    sfn_json = json.dumps(sfn_json)

    # Create Step Function Execution with ARN, Custom Name and Config JSON
    sfn_arn = 'arn:aws:states:' + region_name + ':' + account \
              + ':stateMachine:ANTM-' + 'EDL' + '-' + env + '-Sfn-InvokeEMRAsync'

    try:
        LOGGER.info('\n *** Call Step Function with the following inputs: %s *** \n',
                    sfn_json)
        response = sfn.start_execution(stateMachineArn=sfn_arn,
                                       name=execution_name,
                                       input=sfn_json)
        execution_arn = response.get("executionArn")
        LOGGER.info(f'\n *** Step Function Response ARN: {response.get("executionArn")} \n')
        LOGGER.info(f"\n *** Step Function Execution Name: {execution_name} \n")
        return execution_arn
    except ClientError as sfn_exception:
        LOGGER.critical('\n *** SFN Exception occured: %s \n', sfn_exception)
        LOGGER.critical('\n *** Failed to create SFN *** \n')
        raise sfn_exception
#---------------------------------------------------------------------------------#
# Function to Create EMR Cluster                                                  #
#---------------------------------------------------------------------------------#
def createEMRCluster(LOGGER, env, json_tmplt, dummy_job_args, table, input_cluster_name, create_cluster, emr_config_name, term_cluster):
    emr_job_param={}
    emr_job_param['etl_stp_parms']=emrConfigParameters(env, json_tmplt, dummy_job_args, table, input_cluster_name, create_cluster, emr_config_name, term_cluster)
    LOGGER.info(f"\n EMR Async Input Configuration - {emr_job_param} \n")
    executionArn=callingEMRAsync(LOGGER, env, emr_job_param)
    LOGGER.info(f"\n Creating the Cluster, Execution ARN - {executionArn}\n")
    	
#---------------------------------------------------------------------------------#
#Business Logic#1 - Identity EMR Cluster to Terminate
#---------------------------------------------------------------------------------#
def analyze_cluster(env, app_name, create_for_development, clusters_list, number_of_nodes, instances_allowed, term_wait_time, term_cluster, term_strict, term_strict_wait_time, exempted_cluster_names, input_cluster_id, dev_end_time, name_for_development):
    """
    Function to term EMR Clusters based on input given
    :param clusters_list: Which hold the EMR Cluster Information.
    :param number_of_nodes: Number of Nodes allowed in Dev/SIT.
    :param instances_allowed: Instance Types allowed in Dev/SIT.
    :param term_wait_time: Time to be considered for cluster terminated, when it is in Waiting state more than this time in Minutes.
    :param term_cluster: If 'yes' teminate the cluster otherwise not terminated.
    """
    client = boto3.client('emr')
    i = 0
    subject = f'{env} - Auto term EMR'
    region_name = acc_info().get_region
    account = acc_info().get_account
    cluster_ids_collected = []
    for clusters_response in clusters_list:
        while (i < len(clusters_response['Clusters'])):
            cluster_id=json.dumps(clusters_response['Clusters'][i]['Id']).strip().replace("\"","")
            cluster_name=json.dumps(clusters_response['Clusters'][i]['Name']).strip().replace("\"","")
            i = i + 1
            if('ANTM-'+app_name.upper()[:3] in cluster_name.upper()):
                describe_cluster_response = client.describe_cluster(ClusterId=cluster_id)
                application_name = json.dumps(describe_cluster_response['Cluster']['Tags'][0]['Value']).strip().replace("\"","")
                application_cost_center = json.dumps(describe_cluster_response['Cluster']['Tags'][12]['Value']).strip().replace("\"","")
                for name in exempted_cluster_names:
                    if(name.strip() in cluster_name and application_name.upper() == app_name.upper() and application_cost_center == "6590211300"):
                        cluster_ids_collected.append(cluster_id)
        i = 0
        LOGGER.info(f'\n Cluster_iDs as per the input cluster names - {cluster_ids_collected} \n')
        while (i < len(clusters_response['Clusters'])):
            cluster_id=clusters_response['Clusters'][i]['Id']
            cluster_name=json.dumps(clusters_response['Clusters'][i]['Name']).strip().replace("\"","")
            if('ANTM-'+app_name.upper()[:3] in cluster_name.upper()):
                describe_cluster_response = client.describe_cluster(ClusterId=cluster_id)
                application_name = json.dumps(describe_cluster_response['Cluster']['Tags'][0]['Value']).strip().replace("\"","")
                application_cost_center = json.dumps(describe_cluster_response['Cluster']['Tags'][12]['Value']).strip().replace("\"","")
                LOGGER.info(f'Analyze2:Cluster Name - {cluster_name}, Cluster_application_name, ' + application_name.upper() + ", input app_name " + app_name.upper())
                if(application_name.upper() == app_name.upper() and application_cost_center == "6590211300"):
                    list_instances_response = client.list_instances(ClusterId=cluster_id)
                    list_steps_response = client.list_steps(ClusterId=cluster_id)
                    date_time_format = "%Y-%m-%d %H:%M:%S"
                    current_datetime = datetime.utcnow()
                    current_datetime = datetime.strptime(current_datetime.strftime(date_time_format), date_time_format)
                    emr_cluster_creation_datetime = datetime.strptime((describe_cluster_response['Cluster']['Status']['Timeline']['CreationDateTime']).strftime(date_time_format), date_time_format)
                    start_time_in_minutes  = (current_datetime - emr_cluster_creation_datetime).total_seconds() / 60.0
                    if(len(list_instances_response['Instances']) == 0):
                        if(start_time_in_minutes > 20):
                            LOGGER.info(f'Terminate-Abrupt:Taking Longer time for Starting Cluster and also Unable to get the Instance Type for the application_name - {application_name}, Cluster_id - {cluster_id}, Cluster_Name - {cluster_name}')
                            client.set_termination_protection(JobFlowIds=[cluster_id], TerminationProtected=False)
                            client.terminate_job_flows(JobFlowIds=[cluster_id])
                            message=f'Abrupt:Terminating the cluster - Taking Longer time for Starting Cluster and also Unable to get the Instance Type for the application_name - {application_name}, Cluster_id - {cluster_id}, Cluster_Name - {cluster_name}'
                            SNSPublication(env, subject, message, region_name, account)
                        instance_type = ''
                    else:
                        instance_type = json.dumps(list_instances_response['Instances'][0]['InstanceType']).strip().replace("\"","")
                    #Initializing Count Variables
                    count=0
                    number_of_core_nodes=0
                    while (count < len(list_instances_response['Instances'])):
                        if(list_instances_response['Instances'][count]['Status']['State'] == 'RUNNING'):
                            number_of_core_nodes = number_of_core_nodes + 1
                            count = count + 1
                    #Substracting 1 to take the count only for Core Nodes
                    number_of_core_nodes = number_of_core_nodes - 1
                    if not(number_of_core_nodes <= int(number_of_nodes) and instance_type in instances_allowed and term_strict.upper() == "NO"):
                        LOGGER.info(f'Highest Number of Nodes Allowed - {number_of_nodes}')
                        if(term_cluster.upper() == 'YES'):
                            date_time_format = "%Y-%m-%d %H:%M:%S"
                            current_datetime = datetime.utcnow()
                            current_datetime = datetime.strptime(current_datetime.strftime(date_time_format), date_time_format)
                            if(len(list_steps_response['Steps']) == 0):
                                if(describe_cluster_response['Cluster']['Status']['State'] in ['STARTING','BOOTSTRAPPING','RUNNING']):
                                    wait_time_after_last_step_in_minutes  = 0.0
                                else:
                                    emr_ready_time=datetime.strptime((describe_cluster_response['Cluster']['Status']['Timeline']['ReadyDateTime']).strftime(date_time_format), date_time_format)
                                    wait_time_after_last_step_in_minutes  = (current_datetime - emr_ready_time).total_seconds() / 60.0
                                emr_cluster_creation_datetime = datetime.strptime((describe_cluster_response['Cluster']['Status']['Timeline']['CreationDateTime']).strftime(date_time_format), date_time_format)
                                total_time_in_minutes = (current_datetime - emr_cluster_creation_datetime).total_seconds() / 60.0
                                end_time = datetime.strptime(str(datetime.utcnow().year) + "-" + str(datetime.utcnow().month) + "-" + str(datetime.utcnow().day) + " " + dev_end_time + ":00", date_time_format)
                                if(describe_cluster_response['Cluster']['Status']['State'] in ['RUNNING']):
                                    dct_min = 1.0
                                else:
                                    dct_min = (end_time - current_datetime).total_seconds() / 60.0
                                if((wait_time_after_last_step_in_minutes  > (int(term_wait_time))) or term_strict.upper() == "YES"):
        	                        if((term_strict.upper() == "YES" and (cluster_id in input_cluster_id or cluster_id in cluster_ids_collected) and wait_time_after_last_step_in_minutes  <= term_strict_wait_time) or (term_strict.upper() == "YES" and name_for_development in cluster_name and create_for_development.upper() == 'YES' and 0 < int(dct_min))):
        	                            LOGGER.info(f'STEPS#0:Not Terminating Cluster_ID - {cluster_id} as it is in list - {input_cluster_id}, {cluster_ids_collected}, create_for_development - {create_for_development}, Time Left Development Cluster - {dct_min}')
        	                        else:
        	                            LOGGER.info(f'STEPS#0:Terminating the cluster which is not using recommended Instances/more number of Nodes and also in Waiting State for More than allowed Time - {term_wait_time} OR Cluster Name/ID not allowed OR term_strict - {term_strict}, Name - {cluster_name} and ID - {cluster_id}, Number of Instances - ' + str(number_of_core_nodes) + f', instance_type - {instance_type}, wait_time_after_last_step_in_minutes  - {wait_time_after_last_step_in_minutes }, total_time_in_minutes - {total_time_in_minutes}, create_for_development - {create_for_development}, dct_min - {dct_min}')
        	                            message=f'STEPS#0:Terminating the cluster which is not using recommended Instances/more number of Nodes and also in Waiting State for More than allowed Time - {term_wait_time} OR Cluster Name/ID not allowed OR term_strict - {term_strict}, Name - {cluster_name} and ID - {cluster_id}, Number of Instances - ' + str(number_of_core_nodes) + f', instance_type - {instance_type}, wait_time_after_last_step_in_minutes  - {wait_time_after_last_step_in_minutes }, total_time_in_minutes - {total_time_in_minutes}, create_for_development - {create_for_development}, dct_min - {dct_min}'
        	                            client.set_termination_protection(JobFlowIds=[cluster_id], TerminationProtected=False)
        	                            client.terminate_job_flows(JobFlowIds=[cluster_id])
        	                            SNSPublication(env, subject, message, region_name, account)
                            else:
        	                    date_time_format = "%Y-%m-%d %H:%M:%S"
        	                    current_datetime = datetime.utcnow()
        	                    current_datetime = datetime.strptime(current_datetime.strftime(date_time_format), date_time_format)
        	                    if(describe_cluster_response['Cluster']['Status']['State'] in ['RUNNING','STARTING','BOOTSTRAPPING']):
        	                        wait_time_after_last_step_in_minutes  = 0.0
        	                    else:
        	                        emr_cluster_step_end_datetime=datetime.strptime((list_steps_response['Steps'][0]['Status']['Timeline']['EndDateTime']).strftime(date_time_format), date_time_format)
        	                        wait_time_after_last_step_in_minutes  = (current_datetime - emr_cluster_step_end_datetime).total_seconds() / 60.0
        	                    emr_cluster_creation_datetime = datetime.strptime((describe_cluster_response['Cluster']['Status']['Timeline']['CreationDateTime']).strftime(date_time_format), date_time_format)
        	                    total_time_in_minutes = (current_datetime - emr_cluster_creation_datetime).total_seconds() / 60.0
        	                    end_time = datetime.strptime(str(datetime.utcnow().year) + "-" + str(datetime.utcnow().month) + "-" + str(datetime.utcnow().day) + " " + dev_end_time + ":00", date_time_format)
        	                    if(describe_cluster_response['Cluster']['Status']['State'] in ['RUNNING']):
        	                        dct_min = 1.0
        	                    else:
        	                        dct_min = (end_time - current_datetime).total_seconds() / 60.0
        	                    if((wait_time_after_last_step_in_minutes  > int(term_wait_time)) or term_strict.upper() == "YES"):
        	                        if((term_strict.upper() == "YES" and (cluster_id in input_cluster_id or cluster_id in cluster_ids_collected) and wait_time_after_last_step_in_minutes  <= term_strict_wait_time) or (term_strict.upper() == "YES" and name_for_development in cluster_name and create_for_development.upper() == 'YES' and 0 < int(dct_min))):
        	                            LOGGER.info(f'STEPS#1:Not Terminating Cluster_ID - {cluster_id} as it is in list - {input_cluster_id}, {cluster_ids_collected}, create_for_development - {create_for_development}, Time Left Development Cluster - {dct_min}')
        	                        else:
        	                            LOGGER.info(f'STEPS#1:Terminating the cluster which is not using recommended Instances/more number of Nodes and also in Waiting State for More than allowed Time - {term_wait_time} OR Cluster Name/ID not allowed OR term_strict - {term_strict}, Name - {cluster_name} and ID - {cluster_id}, Number of Instances - ' + str(number_of_core_nodes) + f', instance_type - {instance_type}, wait_time_after_last_step_in_minutes  - {wait_time_after_last_step_in_minutes }, total_time_in_minutes - {total_time_in_minutes}, create_for_development - {create_for_development}, dct_min - {dct_min}')
        	                            message=f'STEPS#1:Terminating the cluster which is not using recommended Instances/more number of Nodes and also in Waiting State for More than allowed Time - {term_wait_time} OR Cluster Name/ID not allowed OR term_strict - {term_strict}, Name - {cluster_name} and ID - {cluster_id}, Number of Instances - ' + str(number_of_core_nodes) + f', instance_type - {instance_type}, wait_time_after_last_step_in_minutes  - {wait_time_after_last_step_in_minutes }, total_time_in_minutes - {total_time_in_minutes}, create_for_development - {create_for_development}, dct_min - {dct_min}'
        	                            client.set_termination_protection(JobFlowIds=[cluster_id], TerminationProtected=False)
        	                            client.terminate_job_flows(JobFlowIds=[cluster_id])
        	                            SNSPublication(env, subject, message, region_name, account)
                    else:
                        if(application_name.upper() == app_name.upper() and application_cost_center == "6590211300"):
                            if(term_cluster.upper() == 'YES'):
                                date_time_format = "%Y-%m-%d %H:%M:%S"
                                current_datetime = datetime.utcnow()
                                current_datetime = datetime.strptime(current_datetime.strftime(date_time_format), date_time_format)
                                if(len(list_steps_response['Steps']) == 0):
                                    if(describe_cluster_response['Cluster']['Status']['State'] in ['STARTING','BOOTSTRAPPING','RUNNING']):
                                        wait_time_after_last_step_in_minutes  = 0.0
                                    else:
                                        emr_ready_time=datetime.strptime((describe_cluster_response['Cluster']['Status']['Timeline']['ReadyDateTime']).strftime(date_time_format), date_time_format)
                                        wait_time_after_last_step_in_minutes  = (current_datetime - emr_ready_time).total_seconds() / 60.0
                                    emr_cluster_creation_datetime = datetime.strptime((describe_cluster_response['Cluster']['Status']['Timeline']['CreationDateTime']).strftime(date_time_format), date_time_format)
                                    total_time_in_minutes = (current_datetime - emr_cluster_creation_datetime).total_seconds() / 60.0
                                    end_time = datetime.strptime(str(datetime.utcnow().year) + "-" + str(datetime.utcnow().month) + "-" + str(datetime.utcnow().day) + " " + dev_end_time + ":00", date_time_format)
                                    if(describe_cluster_response['Cluster']['Status']['State'] in ['RUNNING']):
                                        dct_min = 1.0
                                    else:
                                        dct_min = (end_time - current_datetime).total_seconds() / 60.0
                                    if(wait_time_after_last_step_in_minutes  > int(term_wait_time) or term_strict.upper() == "YES"):
                                        if((term_strict.upper() == "YES" and (cluster_id in input_cluster_id or cluster_id in cluster_ids_collected) and wait_time_after_last_step_in_minutes  <= term_strict_wait_time) or (term_strict.upper() == "YES" and name_for_development in cluster_name and create_for_development.upper() == 'YES' and 0 < int(dct_min))):
                                            LOGGER.info(f'#0:Not Terminating Cluster_ID - {cluster_id} as it is in list - {input_cluster_id}, {cluster_ids_collected}, create_for_development - {create_for_development}, Time Left Development Cluster - {dct_min}')
                                        else:
                                            LOGGER.info(f'#0:Terminating the cluster in Waiting State for More than allowed Time - {term_wait_time} OR Cluster Name/ID not allowed, Name - {cluster_name} and ID - {cluster_id}, Number of Instances - ' + str(number_of_core_nodes) + f', instance_type - {instance_type}, wait_time_after_last_step_in_minutes  - {wait_time_after_last_step_in_minutes }, total_time_in_minutes - {total_time_in_minutes}, create_for_development - {create_for_development}, dct_min - {dct_min}, term_strict - {term_strict}')
                                            message=f'#0:Terminating the cluster in Waiting State for More than allowed Time - {term_wait_time} OR Cluster Name/ID not allowed, Name - {cluster_name} and ID - {cluster_id}, Number of Instances - ' + str(number_of_core_nodes) + f', instance_type - {instance_type}, wait_time_after_last_step_in_minutes  - {wait_time_after_last_step_in_minutes }, total_time_in_minutes - {total_time_in_minutes}, create_for_development - {create_for_development}, dct_min - {dct_min}, term_strict - {term_strict}'
                                            client.set_termination_protection(JobFlowIds=[cluster_id], TerminationProtected=False)
                                            client.terminate_job_flows(JobFlowIds=[cluster_id])
                                            SNSPublication(env, subject, message, region_name, account)
                                else:
                                    date_time_format = "%Y-%m-%d %H:%M:%S"
                                    current_datetime = datetime.utcnow()
                                    current_datetime = datetime.strptime(current_datetime.strftime(date_time_format), date_time_format)
                                    if(describe_cluster_response['Cluster']['Status']['State'] in ['RUNNING','STARTING','BOOTSTRAPPING']):
                                        wait_time_after_last_step_in_minutes  = 0.0
                                    else:
                                        emr_cluster_step_end_datetime=datetime.strptime((list_steps_response['Steps'][0]['Status']['Timeline']['EndDateTime']).strftime(date_time_format), date_time_format)
                                        wait_time_after_last_step_in_minutes  = (current_datetime - emr_cluster_step_end_datetime).total_seconds() / 60.0
                                    emr_cluster_creation_datetime = datetime.strptime((describe_cluster_response['Cluster']['Status']['Timeline']['CreationDateTime']).strftime(date_time_format), date_time_format)
                                    total_time_in_minutes = (current_datetime - emr_cluster_creation_datetime).total_seconds() / 60.0
                                    end_time = datetime.strptime(str(datetime.utcnow().year) + "-" + str(datetime.utcnow().month) + "-" + str(datetime.utcnow().day) + " " + dev_end_time + ":00", date_time_format)
                                    if(describe_cluster_response['Cluster']['Status']['State'] in ['RUNNING']):
                                        dct_min = 1.0
                                    else:
                                        dct_min = (end_time - current_datetime).total_seconds() / 60.0
                                    if(wait_time_after_last_step_in_minutes  > int(term_wait_time) or term_strict.upper() == "YES"):
                                        if((term_strict.upper() == "YES" and (cluster_id in input_cluster_id or cluster_id in cluster_ids_collected) and wait_time_after_last_step_in_minutes  <= term_strict_wait_time) or (term_strict.upper() == "YES" and name_for_development in cluster_name and create_for_development.upper() == 'YES' and 0 < int(dct_min))):
                                            LOGGER.info(f'#1:Not Terminating Cluster_ID - {cluster_id} as it is in list - {input_cluster_id}, {cluster_ids_collected}, create_for_development - {create_for_development}, Time Left Development Cluster - {dct_min}')
                                        else:
                                            message=f'#1:Terminating the cluster in Waiting State for More than allowed Time - {term_wait_time} OR Cluster Name/ID not allowed, Name - {cluster_name} and ID - {cluster_id}, Number of Instances - ' + str(number_of_core_nodes) + f', instance_type - {instance_type}, wait_time_after_last_step_in_minutes  - {wait_time_after_last_step_in_minutes }, total_time_in_minutes - {total_time_in_minutes}, create_for_development - {create_for_development}, dct_min - {dct_min}, term_strict - {term_strict}'
                                            LOGGER.info(f'#1:Terminating the cluster in Waiting State for More than allowed Time - {term_wait_time} OR Cluster Name/ID not allowed, Name - {cluster_name} and ID - {cluster_id}, Number of Instances - ' + str(number_of_core_nodes) + f', instance_type - {instance_type}, wait_time_after_last_step_in_minutes  - {wait_time_after_last_step_in_minutes }, total_time_in_minutes - {total_time_in_minutes}, create_for_development - {create_for_development}, dct_min - {dct_min}, term_strict - {term_strict}')
                                            client.set_termination_protection(JobFlowIds=[cluster_id], TerminationProtected=False)
                                            client.terminate_job_flows(JobFlowIds=[cluster_id])
                                            SNSPublication(env, subject, message, region_name, account)
            i = i + 1
#---------------------------------------------------------------------------------#
#Business Logic#2 - Create EMR Cluster for Development
#---------------------------------------------------------------------------------#
def development_cluster_routine(env, app_name, name_for_development, create_for_development, emr_template_path, emr_config_name, dev_start_time, dev_end_time):
    client = boto3.client('emr')
    create_cluster_needed=create_for_development
    cluster_created='NO'
    region_name = acc_info().get_region
    account = acc_info().get_account
    subject = f'{env} - Auto term EMR - Cluster Creation'
    for cluster_state in ['STARTING','WAITING','RUNNING','BOOTSTRAPPING']:
        clusters_list = client.get_paginator('list_clusters').paginate(ClusterStates=[cluster_state])
        for clusters_response in clusters_list:
            i = 0
            while (i < len(clusters_response['Clusters'])):
                cluster_name=json.dumps(clusters_response['Clusters'][i]['Name']).strip().replace("\"","")
                cluster_id=clusters_response['Clusters'][i]['Id']
                i = i + 1
                if(name_for_development.strip().upper() in cluster_name.upper()):
                    LOGGER.info(f'Checking for - {cluster_name} - Clusters ')
                    LOGGER.info(f"\n Cluster_ID - {cluster_id} \n")
                    describe_cluster_response = client.describe_cluster(ClusterId=cluster_id)
                    cluster_status = describe_cluster_response['Cluster']['Status']['State'].strip().replace("\"","")
                    application_name = json.dumps(describe_cluster_response['Cluster']['Tags'][0]['Value']).strip().replace("\"","")
                    application_cost_center = json.dumps(describe_cluster_response['Cluster']['Tags'][12]['Value']).strip().replace("\"","")
                    LOGGER.info(f'Checking for - {application_name}, {application_cost_center} - Clusters ')
                    if(cluster_status == 'STARTING' and application_name.upper() == app_name.upper()[:3] and application_cost_center == '6590211300'):
                        date_time_format = "%Y-%m-%d %H:%M:%S"
                        current_datetime = datetime.utcnow()
                        current_datetime = datetime.strptime(current_datetime.strftime(date_time_format), date_time_format)
                        emr_creation_time=datetime.strptime((describe_cluster_response['Cluster']['Status']['Timeline']['CreationDateTime']).strftime(date_time_format), date_time_format)
                        wait_time_after_last_step_in_minutes  = (current_datetime - emr_creation_time).total_seconds() / 60.0
                        if(wait_time_after_last_step_in_minutes  > 15):
                            LOGGER.info(f'Cluster - {cluster_name}, taking longer time than to be created, Terminating it, cluster_id - {cluster_id}, instance_type - {instance_type}, time taken for creation - {wait_time_after_last_step_in_minutes }')
                            message=f'Cluster - {cluster_name}, taking longer time than to be created, Terminating it, cluster_id - {cluster_id}, instance_type - {instance_type}, time taken for creation - {wait_time_after_last_step_in_minutes }'
                            client.set_termination_protection(JobFlowIds=[cluster_id], TerminationProtected=False)
                            client.terminate_job_flows(JobFlowIds=[cluster_id])
                            SNSPublication(env, subject, message, region_name, account)
                            create_cluster_needed='YES'
                        else:
                            create_cluster_needed='NO'
                    else:
                        if((cluster_status in ['WAITING','RUNNING','BOOTSTRAPPING'] and application_name.upper() == app_name.upper() and application_cost_center == '6590211300')):
                            create_cluster_needed='NO'
            LOGGER.info(f"\n create_cluster_needed - {create_cluster_needed} \n")
    #Calling Create Cluster Function
    LOGGER.info(f"\n create_cluster_needed - {create_cluster_needed} \n")
    dummy_job_args="/usr/bin/spark-submit s3://antm-cii-{env}-codez-nogbd-nophi-useast1/cii/config/cii_dummy.py --driver-memory 4G --executor-cores 4 --conf spark.dynamicAllocation.enabled=true --conf spark.shuffle.service.enabled=true"
    job_tmplt_obj = read_s3_object(emr_template_path)
    json_tmplt = json.loads(job_tmplt_obj.get()['Body'].read().decode('utf-8'))
    current_datetime = datetime.utcnow()
    current_year = int(current_datetime.year)
    current_month = int(current_datetime.month)
    current_day = int(current_datetime.day)
    current_hour = int(current_datetime.hour)
    current_minute = int(current_datetime.minute)
    dev_start_time_hour = int(dev_start_time.split(':')[0])
    dev_start_time_minute = int(dev_start_time.split(':')[1])
    dev_end_time_hour = int(dev_end_time.split(':')[0])
    dev_end_time_minute = int(dev_end_time.split(':')[1])
    LOGGER.info(f"\n Current Time Info in UTC, current_hour - {current_hour}, current_minute - {current_minute} \n")
    LOGGER.info(f"\n Start Time Info in UTC - " + str(datetime(current_year,current_month,current_day,dev_start_time_hour,dev_start_time_minute)) + 
    " End Time Info in UTC - " + str(datetime(current_year,current_month,current_day,dev_end_time_hour,dev_end_time_minute)) + "\n")
    if(create_cluster_needed=='YES' and datetime.utcnow() > datetime(current_year,current_month,current_day,dev_start_time_hour,dev_start_time_minute)
                                    and datetime.utcnow() < datetime(current_year,current_month,current_day,dev_end_time_hour,dev_end_time_minute)):
      LOGGER.info(f"\n Calling Create EMR Cluster Fucntion One Time \n")
      createEMRCluster(LOGGER, env, json_tmplt, dummy_job_args, 'dummy_job', name_for_development, create_cluster_needed, emr_config_name, 'NO')
      cluster_created='YES'
    return cluster_created
#---------------------------------------------------------------------------------#
#Business Logic#3 - Generate Report for All Terminated EMR Clusters
#---------------------------------------------------------------------------------#
def generate_cluster_report(env, app_name, page_iterator, run_report_type, time_frame, from_time, to_time):
    """
    Function to Generate Report on Cluster Created
    """
    client = boto3.client('emr')
    
    region_name = acc_info().get_region
    account = acc_info().get_account
    final_output_list = []
    count = 0
    for clusters_response in page_iterator:
        i=0
        while (i < len(clusters_response['Clusters'])):
            cluster_id=clusters_response['Clusters'][i]['Id']
            cluster_name=json.dumps(clusters_response['Clusters'][i]['Name']).strip().replace("\"","")
            i = i + 1
            if('ANTM-'+app_name.upper()[:3] in cluster_name.upper()):
                describe_cluster_response = client.describe_cluster(ClusterId=cluster_id)
                application_name = json.dumps(describe_cluster_response['Cluster']['Tags'][0]['Value']).strip().replace("\"","")
                application_cost_center = json.dumps(describe_cluster_response['Cluster']['Tags'][12]['Value']).strip().replace("\"","")
                if(application_name.upper() == app_name.upper() and application_cost_center == "6590211300"):
                    date_time_format = "%Y-%m-%d %H:%M:%S"
                    count = count + 1
                    emr_cluster_creation_datetime = datetime.strptime((describe_cluster_response['Cluster']['Status']['Timeline']['CreationDateTime']).strftime(date_time_format), date_time_format)
                    emr_cluster_end_datetime=datetime.strptime((describe_cluster_response['Cluster']['Status']['Timeline']['EndDateTime']).strftime(date_time_format), date_time_format)
                    total_run_time_in_minutes = (emr_cluster_end_datetime - emr_cluster_creation_datetime).total_seconds() / 60.0
                    final_output_list.append({"Serial Number":count, "cluster_name":cluster_name, "cluster_id":cluster_id, "emr_cluster_creation_datetime":str(emr_cluster_creation_datetime), "emr_cluster_end_datetime":str(emr_cluster_end_datetime), "total_run_time_in_minutes":str(total_run_time_in_minutes)})
    subject = f'Succeeded: EMR Usage Report - {run_report_type}, From - {from_time} To - {to_time}'
    message = """Running Report for Time Frame: {time_frame} \n Report Details: {final_output_list}
                       """.format(
                                  time_frame=time_frame,
                                  final_output_list=json.dumps(final_output_list)
                                 )
    LOGGER.info(f'EMR Cluster Report - {final_output_list}')
    SNSPublication(env, subject, message, region_name, account)
#---------------------------------------------------------------------------------#
#Main Function
#---------------------------------------------------------------------------------#
def lambda_handler(event, context):
   
    # Define the client to interact with AWS Lambda
    glue = boto3.client('glue')
    client = boto3.client('emr')

    env = event['etl_stp_parms']['env'].strip()

    #Input Parameters
    app_name = event['etl_stp_parms']['app_name'].strip()
    number_of_nodes = event['etl_stp_parms']['number_of_nodes'].strip()
    number_of_nodes = int(number_of_nodes)
    instances_allowed = event['etl_stp_parms']['instances_allowed'].strip().split('|')
    term_wait_time = event['etl_stp_parms']['term_wait_time'].strip()
    term_wait_time = int(term_wait_time)
    term_cluster = event['etl_stp_parms']['term_cluster'].strip()
    term_strict = event['etl_stp_parms']['term_strict'].strip()
    term_strict_wait_time = event['etl_stp_parms']['term_strict_wait_time'].strip()
    term_strict_wait_time = int(term_strict_wait_time)
    create_for_development = event['etl_stp_parms']['create_for_development'].strip()
    name_for_development = event['etl_stp_parms']['name_for_development'].strip()
    dev_start_time = event['etl_stp_parms']['dev_start_time'].strip()
    dev_end_time = event['etl_stp_parms']['dev_end_time'].strip()
    emr_config_name = event['etl_stp_parms']['emr_config_name'].strip()
    run_report_start_type_from_to = event['etl_stp_parms']['run_report_start_type_from_to'].strip().split('|')
    run_report = run_report_start_type_from_to[0].strip()
    run_report_start = run_report_start_type_from_to[1].replace('(','').replace(')','')
    run_report_type = run_report_start_type_from_to[2].strip()
    run_report_from = run_report_start_type_from_to[3].replace('(','').replace(')','').strip()
    run_report_to = run_report_start_type_from_to[4].replace('(','').replace(')','').strip()
    #Fixed Parameters
    emr_template_path = "s3://antm-cii-{env}-codez-nogbd-nophi-useast1/cii_config/cii_sf_emr_template_autoterm.json".format(env=env)
    exemption_details_path = "s3://antm-cii-{env}-codez-nogbd-nophi-useast1/cii_config/cii_performance_clusters_exemption_details_{env}.json".format(env=env)
    
    #Fetching the details for Exempted Cluster_ids and Cluster Names
    exemption_details_list_obj = read_s3_object(exemption_details_path)
    exemption_details_list_json = json.loads(exemption_details_list_obj.get()['Body'].read().decode('utf-8'))
    #Generated Parameters
    exempted_cluster_names = exemption_details_list_json['exempted_cluster_names'].strip().split("|")
    exempted_cluster_ids = exemption_details_list_json['exempted_cluster_ids'].strip().split("|")
    #Initializing Parameter
    cluster_created_for_development="NO"

    LOGGER.info(f'\n**** Argument List ****\n-----------------------')
    LOGGER.info(f'\nenv : {env} \napp_name : {app_name} \nnumber_of_nodes : {number_of_nodes} \ninstances_allowed : {instances_allowed} \nterm_wait_time : {term_wait_time} \nterm_cluster : {term_cluster} \nterm_strict : {term_strict} '
            f'\nterm_strict_wait_time : {term_strict_wait_time} \ncreate_for_development : {create_for_development} \nname_for_development : {name_for_development} \nemr_config_name : {emr_config_name}'
            f'\nemr_template_path : {emr_template_path} \nexemption_details_path : {exemption_details_path} \nexempted_cluster_names : {exempted_cluster_names}'
            f'\nexempted_cluster_ids : {exempted_cluster_ids} \ndev_start_time : {dev_start_time} \ndev_end_time : {dev_end_time} \nrun_report_start_type_from_to : {run_report_start_type_from_to} ')
    LOGGER.info(f'\n-----------------------\n')    

    try:
        if(term_cluster.upper() == 'YES' or term_strict.upper() == 'YES'):
            for cluster_state in ['STARTING','WAITING','RUNNING','BOOTSTRAPPING']:
                clusters_list = client.get_paginator('list_clusters').paginate(ClusterStates=[cluster_state])
                LOGGER.info(f'Calling Function to check on - {cluster_state} - Clusters ')
                analyze_cluster(env,app_name,create_for_development,clusters_list, number_of_nodes, instances_allowed, term_wait_time, term_cluster, term_strict, term_strict_wait_time, exempted_cluster_names, exempted_cluster_ids, dev_end_time, name_for_development)
    except Exception as err:
        LOGGER.critical('*** ERROR: %s ***', err)
        
    try:
        if(create_for_development.upper() == 'YES'):
          LOGGER.info(f'Calling Function to Create Cluster for Development if not created already')
          cluster_created_for_development=development_cluster_routine(env, app_name, name_for_development, create_for_development, emr_template_path, emr_config_name, dev_start_time, dev_end_time)
          LOGGER.info(f'Created Cluster for Development - {cluster_created_for_development} Note: Yes Means Created, NO Means not created as it is already exist OR Current Time is Out Side of Allowed Time Frame')
    except Exception as err:
        LOGGER.critical('*** ERROR: %s ***', err)
        
    try:
        if(run_report == 'YES'):
            if(run_report_type.upper() == 'ADHOC'):
                year_from = int(run_report_from.split(',')[0])
                month_from = int(run_report_from.split(',')[1])
                day_from = int(run_report_from.split(',')[2])
                hour_from = int(run_report_from.split(',')[3])
                minute_from = int(run_report_from.split(',')[4])
                year_to = int(run_report_to.split(',')[0])
                month_to = int(run_report_to.split(',')[1])
                day_to = int(run_report_to.split(',')[2])
                hour_to = int(run_report_to.split(',')[3])
                minute_to = int(run_report_to.split(',')[4])
                page_iterator = client.get_paginator('list_clusters').paginate(CreatedAfter=datetime(year_from, month_from, day_from,hour_from,minute_from),CreatedBefore=datetime(year_to, month_to, day_to,hour_to,minute_to),ClusterStates=['TERMINATED'])
                LOGGER.info(f'Generating Adhoc Report for the time period from - ' + str(datetime(year_from, month_from, day_from,hour_from,minute_from)) + 
                              '\n to - ' + str(datetime(year_to, month_to, day_to,hour_to,minute_to)) + ' Frames ')
                time_frame=(f'Generating Adhoc Report for the time period from - ' + str(datetime(year_from, month_from, day_from,hour_from,minute_from)) + 
                              '\n to - ' + str(datetime(year_to, month_to, day_to,hour_to,minute_to)) + ' Frames ')
                generate_cluster_report(env, app_name, page_iterator, run_report_type, time_frame, str(datetime(year_from, month_from, day_from,hour_from,minute_from)), str(datetime(year_to, month_to, day_to,hour_to,minute_to)))
            else:
                year_today = (datetime.utcnow()).year
                month_today = (datetime.utcnow()).month
                day_today = (datetime.utcnow()).day
                hour_today = (datetime.utcnow()).hour
                minute_today = (datetime.utcnow()).minute
                year_to = (datetime.utcnow()).year
                month_to = (datetime.utcnow()).month
                day_to = (datetime.utcnow()).day
                year_from = (datetime.utcnow() - timedelta(1)).year
                month_from = (datetime.utcnow() - timedelta(1)).month
                day_from = (datetime.utcnow() - timedelta(1)).day
                hour = int(run_report_start.split(',')[0])
                minute = int(run_report_start.split(',')[1])
                if((cluster_created_for_development == 'YES') or (datetime(year_today, month_today, day_today,hour_today,minute_today) == datetime(year_today, month_today, day_today,hour,minute))):
                    page_iterator = client.get_paginator('list_clusters').paginate(CreatedAfter=datetime(year_from, month_from, day_from,hour,minute),CreatedBefore=datetime(year_to, month_to, day_to,hour,minute),ClusterStates=['TERMINATED'])
                    LOGGER.info(f'Generating Report for the time period from - ' + str(datetime(year_from, month_from, day_from,hour,minute)) + 
                              '\n to - ' + str(datetime(year_to, month_to, day_to,hour,minute)) + ' Frames ')
                    time_frame=(f'Generating Report for the time period from - ' + str(datetime(year_from, month_from, day_from,hour,minute)) + 
                              '\n to - ' + str(datetime(year_to, month_to, day_to,hour,minute)) + ' Frames ')
                    generate_cluster_report(env, app_name, page_iterator, 'Daily', time_frame, str(datetime(year_from, month_from, day_from,hour,minute)), str(datetime(year_to, month_to, day_to,hour,minute)))
    except Exception as err:
        LOGGER.critical('*** ERROR: %s ***', err)