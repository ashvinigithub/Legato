import logging
import json
import boto3
import base64
from botocore.exceptions import ClientError
import psycopg2
import os

# Define Functions
def load_log_config():
    """
    # Basic config. Replace with your own logging config if required
    :return: object for basic logging
    """
    global logger
    
    MSG_FORMAT = '%(asctime)s %(levelname)s %(name)s: %(message)s'
    DATETIME_FORMAT = '%Y-%m-%d %H:%M:%S'
    logging.basicConfig(format=MSG_FORMAT, datefmt=DATETIME_FORMAT)
    logger = logging.getLogger("Save_Filter_No_Op")

    logger.setLevel(logging.INFO)


def get_secret(secret_name):
    """
    Function to fetch details from AWS Secrets Manager
    Usage   : Get Secret JSON String
    Args    : Secret Name
    Returns : Secure string of Secret
    Raises  : Exception While getting the Secret.
    
    """
    secret = ''
    secret_client = boto3.client("secretsmanager")

    try:
        get_secret_value_response = secret_client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as error:
        if error.response['Error']['Code'] == 'DecryptionFailureException':
            raise error
        elif error.response['Error']['Code'] == 'InternalServiceErrorException':
            raise error
        elif error.response['Error']['Code'] == 'InvalidParameterException':
            raise error
        elif error.response['Error']['Code'] == 'InvalidRequestException':
            raise error
        elif error.response['Error']['Code'] == 'ResourceNotFoundException':
            raise error
    else:
        if 'SecretString' in get_secret_value_response:
            secret = get_secret_value_response['SecretString']
            return secret
        else:
            decoded_binary_secret = base64.b64decode(
                get_secret_value_response['SecretBinary'])
            return decoded_binary_secret


def rds_conn(host_name, secret_name, port_no, schema_name):
    """
    Function to use Secrets Manager to create an RDS Connection Object
    :param host_name: Host name of the RDS
    :param secret_name: secret name for fetching user password
    :param port_no: Port Number of RDS
    :param schema_name: Schema Name in RDS
    :return: RDS Connection Object
    """
    try:
        secure_string   = get_secret(secret_name)
        secure_dict     = json.loads(secure_string)
        postgre_username  = secure_dict.get('username')
        postgre_password  = secure_dict.get('password')
        engine = psycopg2.connect(
                database=schema_name,
                user=postgre_username,
                password=postgre_password,
                host=host_name,
                port=port_no
            )
    except Exception as err:
        logger.critical("ERROR: Unexpected error: Could not connect to Aurora instance.")
        logger.critical('*** ERROR: %s ***', err)
        raise err
        
    return engine

        
def _read_s3_object(s3_path):
    """
    Function to read object from s3 path
    :param s3_path: S3 object full path
    :return: object with file content
    """
    s3 = boto3.resource('s3')
    bucket = s3_path.split("//")[1].split("/")[0]
    key = "/".join(s3_path.replace("//", "").split("/")[1:])
    
    logger.info("Reading S3 obj {}".format(s3_path))
    obj = s3.Object(bucket, key)
    
    return obj


def _check_for_save_filters(conn, cursor, database_nm):
    """
    Function to check whether there are any updates in Save Filters
    :param conn: Connection Object to RDS
    :param cursor: Cursor object for execution of queries on RDS
    :param db_name: Database Name
    :return: Indicator Flag which returns Yes or No based on the Save Filter Control Tables
    """
    
    # Query to Check whether there are any save filters for update or not. If no then we will skip the processing.
    
    check_sfltr_upds = """ 
    SELECT COUNT(*) FROM {db_name}.SAVE_FLTR_SGMNTN_BRDG BRDG, {db_name}.SAVE_FLTR_CNTRL CNTRL
    WHERE BRDG.EFCTV_DTM BETWEEN CNTRL.SAVE_FLTR_LOW_DTM AND CNTRL.SAVE_FLTR_HIGH_DTM
    AND CNTRL.LKUP_ID = 5 """.format(db_name=database_nm)
    
    cursor.execute(check_sfltr_upds)
    result = int(cursor.fetchone()[0])
    
    if(result == 0):
        return 'No'
    else:
        return 'Yes'

    
def lambda_handler(event, context):
    """
    Main Processing Function
    :param event: Event variables for function
    :param context: Lambda execution context variables
    :return: None
    """
    print(event)
    load_log_config()
    
    db_config_path = str(event['Input']['dbconfigpath'])
    
    # Reads the configuration File from S3
    json_obj = _read_s3_object(db_config_path)
    config = json.loads(json_obj.get()['Body'].read().decode('utf-8'))
    print(config)

    # Getting RDS connection Details from configuration file
    databaseName = config['database_details']['database']
    schema_name = config['database_details']['schema']
    host = config['database_details']['host']
    port = config['database_details']['port']
    secret_name = config['database_details']['secret_name']
    # user = config['database_details']['user']
    # passwd = config['database_details']['passwd']

    # Creates RDS Connection Object and Cursor
    conn = rds_conn(host, secret_name, port, schema_name)
    cursor = conn.cursor()
    logger.info("Connection to RDS has been established, Cursor is created.")
    
    logger.info("Checking for save filter updates")
    operate_flag = _check_for_save_filters(conn, cursor, databaseName)
    
    
    logger.info("Process Completed.")
    # Commits all the Changes done and closes the connection.
    conn.commit()
    conn.close()
    
    # Returns the Operation Flag
    return  {"operate_flag": operate_flag}