import json
import boto3, csv, codecs
import os
import logging
from ReduceReuseRecycle import load_log_config, InvalidStatus
from botocore.exceptions import ClientError
#import awswrangler as wr
#import pandas as pd
from io import StringIO

# Define the client to interact with AWS Lambda
client_ath = boto3.client('athena')
s3 = boto3.client('s3')

LOGGER = load_log_config(glue=True)

def lambda_handler(event, context):
    
    glue = boto3.client('glue')
    
    # Input parameters
    bucket_name = event['etl_stp_parms']['bucket_name'].strip()
    key = event['etl_stp_parms']['key'].strip()
    env = event['etl_stp_parms']['env'].strip()
    
    LOGGER.info(f'\n**** Argument List ****\n-----------------------')
    LOGGER.info(f'\nenv : {env} \nbucket_name : {bucket_name} \nkey : {key}')
    LOGGER.info(f'\n-----------------------\n')
    
    if(env == 'dev'):
        schema_prefix='d01_'    		 
    elif(env == 'sit'):
        schema_prefix='t01_'
    elif(env == 'preprod'):
        schema_prefix='r01_'
    elif(env == 'prod'):
        schema_prefix='p01_'
    else:
        schema_prefix='u01_'
    
    #print(bucket_name,key)
    
    job_ids = {}
    try:    
        data = s3.get_object(Bucket=bucket_name, Key=key)
        for row in csv.DictReader(codecs.getreader("utf-8")(data["Body"])):
            #print(row['table'])
            response = glue.start_job_run(
            JobName = 'ANTM-CII-' + env + '-Gj-HistoryCopyProcess',
            Arguments = {
            '--env':   env,
            '--s3_source_bucket':  row['source_bucket'],
            '--s3_source_key':  row['source_key'],
            '--s3_target_bucket':  row['target_bucket'],
            '--s3_target_key':  row['target_key'],
            '--table_creation': row['table_creation'],
            '--schema_name':  schema_prefix + row['schema'] } )
            jobrunid = response['JobRunId']
            job_ids[row['table']] = jobrunid
        json_data = json.dumps(job_ids)
        LOGGER.info(f'\nJob Run IDs : {json_data} \n')
    except Exception as err:
        LOGGER.critical('*** ERROR: %s ***', err)
        raise err
