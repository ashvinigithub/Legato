import logging
import json
import boto3
import base64
import os
from botocore.exceptions import ClientError
#from boto_wrapper import *
import pymysql
from ReduceReuseRecycle import *
from datetime import *

# Define Functions
required_params = ["job_id",  "trgt_tbl_nm", "trgt_schma", "s3_cnsmptn_bkt", "s3_cnsmptn_key", "unld_type",
                   "unld_file_type", "unld_partn_key", "trgt_pltfrm", "dlmtr", "aplctn_cd", "ownrshp_team",
                   "unld_s3_bucket_set", "warehouse_size_suffix"]


def start_state_machine(logger, env, region_name, account, account_name, sfn, sfn_json):
    """
    Function to start the Step Function state machine with JSON input
    :param logger: basic log object
    :param env: environment (dev, sit, prod)
    :param region_name: region on aws (us-east-1)
    :param account: aws account number
    :param account_name: aws account name (edl)
    :param sfn: Step functions client
    :param sfn_json: JSON Input for state machine
    :return:
    """

    execution_name = f"{sfn_json['aplctn_cd']}-{sfn_json['job_nm']}-{sfn_json['src_load_prfx']}-RunDt-{sfn_json['edl_evnt_dtm']}"[:100]

    sfn_json = json.dumps(sfn_json)

    # Create Step Function Execution with ARN, Custom Name and Config JSON
    sfn_arn = 'arn:aws:states:' + region_name + ':' + account \
              + ':stateMachine:ANTM-' + account_name + '-' + env + '-Sfn-DatalakeUnload'

    try:
        logger.info('*** Call Step Function with the following inputs: %s ***',
                    sfn_json)
        response = sfn.start_execution(stateMachineArn=sfn_arn,
                                       name=execution_name,
                                       input=sfn_json)

        logger.info(f'*** Step Function Response ARN: {response.get("executionArn")}')
        logger.info(f"*** Step Function Execution Name: {execution_name}")
        return True
    except ClientError as sfn_exception:
        logger.critical('*** SFN Exception occured: %s', sfn_exception)
        logger.critical('*** Failed to create SFN ***')
        return False


def get_sfn_input(logger, env, data):
    for i in required_params:
        if not data.get(i):
            logger.info(f"input missing value for '{i}'")
            raise InvalidStatus(f"input missing value for '{i}'")
    trgt_schma = data["trgt_schma"]
    s3_cnsmptn_bkt = data["s3_cnsmptn_bkt"]
    aplctn_cd = data["aplctn_cd"]
    unld_zone_cd = data["unld_zone_cd"]
    s3_cnsmptn_key = data["s3_cnsmptn_key"]

    data["unld_trgt_pltfrm"] = "snowflake"
    data["prcsng_type"] = "sfunload"
    data["env"] = env

    data["job_nm"] = data["job_nm"].replace('sfload', 'unload')
    data["edl_evnt_dtm"] = data["edl_load_dtm"].replace('-', '').replace(' ', '-').replace(':', '')

    data["nogbd_phi_trgt_schma"] = trgt_schma + "_nogbd"
    data["nogbd_phi_cnsmptn_bkt"] = nogbd_phi_bkt = s3_cnsmptn_bkt.replace('-gbd-', '-nogbd-')
    data["nogbd_nophi_trgt_schma"] = nogbd_nophi_schma = trgt_schma + "_nophi_nogbd"
    data["nogbd_nophi_cnsmptn_bkt"] = nogbd_phi_bkt.replace('-phi-', '-nophi-')
    data["gbd_nophi_trgt_schma"] = gbd_nophi_schma = trgt_schma + "_nophi"
    data["gbd_nophi_cnsmptn_bkt"] = s3_cnsmptn_bkt.replace('-phi-', '-nophi-')
    data["snowflake_trgt_schma"] = sf_schma = trgt_schma.lower().replace('d01_', '').replace('t01_', '')
    trgt_db = sf_schma
    bkt_split = s3_cnsmptn_bkt.split("-")
    data["snowflake_cnsmptn_bkt"] = sf_bkt = f"{bkt_split[0]}-sf-{bkt_split[2]}-dataz-{bkt_split[4]}-{bkt_split[5]}-{bkt_split[6]}"
    data["snowflake_nogbd_phi_trgt_schma"] = sf_schma + "_nogbd"
    data["snowflake_nogbd_phi_cnsmptn_bkt"] = sf_nogbd_phi_bkt = sf_bkt.replace('-gbd-', '-nogbd-')
    data["snowflake_nogbd_nophi_trgt_schma"] = nogbd_nophi_schma.lower().replace('d01_', '').replace('t01_', '')
    data["snowflake_nogbd_nophi_cnsmptn_bkt"] = sf_nogbd_phi_bkt.replace('-phi-', '-nophi-')
    data["snowflake_gbd_nophi_trgt_schma"] = gbd_nophi_schma.lower().replace('d01_', '').replace('t01_', '')
    data["snowflake_gbd_nophi_cnsmptn_bkt"] = sf_bkt.replace('-phi-', '-nophi-')
    data["snowflake_cnfz_key"] = f'{unld_zone_cd}/{aplctn_cd.lower()}/{s3_cnsmptn_key}'
    data["trgt_db_nm"] = trgt_db
    data["trgt_db_nm_nogbd_phi"] = trgt_db + "_allphi_nogbd"
    data["trgt_db_nm_nogbd_nophi"] = trgt_db + "_nophi_gbd"
    data["trgt_db_nm_gbd_nophi"] = trgt_db + "_nophi"
    data["trgt_db_nm_gbd_phi"] = trgt_db + "_allphi"
    data["unld_frmt_parms"] = "{}"

    logger.info(f"json_input === \n {data}")

    return data
    
    
class acc_info:
    sts_function_client=boto3.client('sts')
    def __init__(self):
        acc_details=acc_info.sts_function_client.get_caller_identity()
        self.account=acc_details['Account']
        self.region=os.environ['AWS_REGION']
        self.function_name=acc_details['Arn']
    @property
    def get_account(self):
        return self.account
    @property
    def get_region(self):
        return self.region
    @property
    def get_handler_name(self):
        return self.function_name.split("/")[-1]    

def lambda_handler(event, context):
   
    # Define the client to interact with AWS Lambda
    client = boto3.client('lambda')
    sfn = boto3.client('stepfunctions')

    logger = load_log_config()

    env = event['input']['data']['env']
    env_input = event['input']['data']['env']

    try:
        if (event['input']['data']['aplctn_cd'].strip().upper() == 'CII'):
            aplctn_cd = "CII"
        else:
            aplctn_cd = event['input']['data']['aplctn_cd'].strip().upper()
    except Exception:
        aplctn_cd = "CII"
    
    if(env == 'dev'):
        schema_prefix='d01_'    		 
    elif(env == 'sit'):
        schema_prefix='t01_'
    elif(env == 'preprod'):
        schema_prefix='r01_'
    elif(env == 'prod'):
        schema_prefix=''
    else:
        schema_prefix='u01_'

    if(aplctn_cd[-3:] == 'C01'):
        schema_prefix='c01_'


    unload_needed_tables = []
    unload_trgt_schemas = []
    data = {}
        
    #Summary Tables
    unload_needed_tables = event['input']['data']['unload_needed_tables'].strip().split("|")
    #Snowflake Validation Schema and final Schema
    unload_trgt_schemas = event['input']['data']['unload_trgt_schemas'].strip().split("|")
    unld_s3_bucket_set = event['input']['data']['unld_s3_bucket_set'].strip().split("|")
    unld_zone_cd = event['input']['data']['unld_zone_cd']
    stg_schma = event['input']['data']['stg_schma']
    region_name = acc_info().get_region
    account = acc_info().get_account
    
    
    for schema in unload_trgt_schemas:
      for table in unload_needed_tables:
          for s3_bucket_set in unld_s3_bucket_set:
              # Collect metadata
              load_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
              #logger.info('*** Building JSON Input for Lambda Function ***')
              data["job_id"] = "555555555"
              data["trgt_tbl_nm"] = table
              data["trgt_schma"] = schema_prefix + schema
              data["s3_cnsmptn_bkt"] = "antm-" + aplctn_cd + "-" + env + "-cnfz" + s3_bucket_set + "useast1"
              data["s3_cnsmptn_key"] = "discover/" + schema + "/" + table
              data["unld_type"] = "full"
              data["unld_file_type"] = "parquet"
              data["unld_partn_key"] = "na"
              data["trgt_pltfrm"] = "snowflake"
              data["dlmtr"] = "na"
              data["aplctn_cd"] = aplctn_cd
              data["ownrshp_team"] = aplctn_cd
              data["unld_s3_bucket_set"] = s3_bucket_set
              data["warehouse_size_suffix"] = " "
              data["edl_load_dtm"] = load_time
              data["job_nm"] = table + '-' + s3_bucket_set.replace('-','')
              data["src_load_prfx"] = schema
              data["region_name"] = region_name
              data["account"] = account
              data["unld_zone_cd"] = unld_zone_cd
              data["stg_schma"] = stg_schma
        
              region_name = get_region_name()
              account = get_account()
              account_name = get_account_name()

              # Collect metadata
              logger.info('*** Building JSON Input for Step Function ***')
              sfn_json = get_sfn_input(logger, env, data)

              start_state_machine(logger, env, region_name, account, account_name, sfn, sfn_json)
              logger.info('*** Step Function is Running ***')
